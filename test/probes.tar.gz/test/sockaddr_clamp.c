/* sockaddr_clamp.c — A/B probe for the review-func round of
 * kernel/src/syscall/network.rs.
 *
 * Exercises five reference-contract behaviors around socket address
 * write-backs and unix datagram sends:
 *
 *   unix-dgram-100k       sendto() on an AF_UNIX SOCK_DGRAM pair must
 *                         deliver the WHOLE 100KB datagram (all-or-nothing
 *                         datagram contract; the bug staged only the first
 *                         RW_CHUNK=64KB and reported a successful partial
 *                         send — the receiver saw a truncated record).
 *   unix-dgram-300k       a datagram above the 4*RW_CHUNK staging ceiling
 *                         fails with EMSGSIZE (never a silent truncation).
 *   udp-recvmsg-namelen   recvmsg() must set msg_namelen to the actual
 *                         address length (16 for sockaddr_in) — the bug
 *                         reinterpreted the msg_namelen VALUE field as a
 *                         pointer, so the field was never updated (and a
 *                         short hint must still yield 16, per
 *                         move_addr_to_user).
 *   udp-recvfrom-shortlen recvfrom() must copy min(*fromlen, 16) address
 *                         bytes only (canary after a short sockaddr object
 *                         stays intact) and set *fromlen = 16.
 *   accept-shortlen-clamp accept() must copy min(*addrlen, 16) bytes only
 *                         (canary intact) and set *addrlen = 16.
 *   v6-getsockname-16b-obj getsockname() on an AF_INET6 socket with a
 *                         16-byte object must copy only 16 bytes (the bug
 *                         wrote the full 28-byte sockaddr_in6 past the
 *                         caller's object) and set *addrlen = 28.
 *
 * Prints one "SOCKADDR-CASE <name> PASS|FAIL (detail)" line per case and
 * a final "SOCKADDR-DONE fails=<n>", then parks on a console read (the
 * boot driver kills QEMU on DONE).
 */

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <unistd.h>

#define CANARY 0xCAA4E1100BADF00DULL

static int fails;

static void check(const char *name, int ok, const char *detail)
{
    if (!ok)
        fails++;
    printf("SOCKADDR-CASE %s %s (%s)\n", name, ok ? "PASS" : "FAIL",
           detail);
    fflush(stdout);
}

/* --- unix datagram all-or-nothing + EMSGSIZE ceiling --- */
static unsigned char big[100 * 1024];
static unsigned char huge[300 * 1024];
static unsigned char rbuf[320 * 1024];

static void case_unix_dgram(void)
{
    int sv[2];
    char d[160];

    if (socketpair(AF_UNIX, SOCK_DGRAM, 0, sv) < 0) {
        check("unix-dgram-100k", 0, "socketpair failed");
        check("unix-dgram-300k", 0, "socketpair failed");
        return;
    }
    memset(big, 0x5A, sizeof big);
    ssize_t n = send(sv[0], big, sizeof big, 0);
    ssize_t r = recv(sv[1], rbuf, sizeof rbuf, MSG_DONTWAIT);
    int whole = n == (ssize_t)sizeof big && r == (ssize_t)sizeof big
                && !memcmp(rbuf, big, sizeof big);
    snprintf(d, sizeof d, "send=%zd recv=%zd expect=102400/102400", n, r);
    check("unix-dgram-100k", whole, d);

    n = send(sv[0], huge, sizeof huge, 0);
    snprintf(d, sizeof d, "send=%zd errno=%d expect=-1/EMSGSIZE(90)", n,
             errno);
    check("unix-dgram-300k", n == -1 && errno == EMSGSIZE, d);

    close(sv[0]);
    close(sv[1]);
}

/* --- recvmsg msg_namelen contract --- */
static void case_udp_recvmsg(void)
{
    int s;
    struct sockaddr_in b;
    struct msghdr mh;
    struct iovec iov;
    unsigned char namebuf[128];
    char payload[] = "hello-clamp";
    char rb[64];
    char d[160];
    socklen_t bl;
    ssize_t n;
    unsigned short fam;

    s = socket(AF_INET, SOCK_DGRAM, 0);
    if (s < 0) {
        check("udp-recvmsg-namelen", 0, "socket failed");
        return;
    }
    memset(&b, 0, sizeof b);
    b.sin_family = AF_INET;
    b.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    if (bind(s, (struct sockaddr *)&b, sizeof b) < 0) {
        check("udp-recvmsg-namelen", 0, "bind failed");
        close(s);
        return;
    }
    bl = sizeof b;
    if (getsockname(s, (struct sockaddr *)&b, &bl) < 0) {
        check("udp-recvmsg-namelen", 0, "getsockname failed");
        close(s);
        return;
    }

    /* Full-size hint: namelen must come back as the actual size (16). */
    memset(&mh, 0, sizeof mh);
    memset(namebuf, 0xEE, sizeof namebuf);
    iov.iov_base = rb;
    iov.iov_len = sizeof rb;
    mh.msg_name = namebuf;
    mh.msg_namelen = (socklen_t)sizeof namebuf; /* input hint 128 */
    mh.msg_iov = &iov;
    mh.msg_iovlen = 1;
    sendto(s, payload, sizeof payload, 0, (struct sockaddr *)&b, sizeof b);
    n = recvmsg(s, &mh, MSG_DONTWAIT);
    fam = *(unsigned short *)namebuf;
    snprintf(d, sizeof d, "ret=%zd namelen=%u fam=%u expect namelen=16 fam=2",
             n, (unsigned)mh.msg_namelen, fam);
    check("udp-recvmsg-namelen",
          n == (ssize_t)sizeof payload && mh.msg_namelen == 16
              && fam == AF_INET,
          d);

    /* Short hint: copy is clamped to 8 bytes but namelen still reports 16
     * (move_addr_to_user stores the family size, not the clamp). */
    memset(namebuf, 0xEE, sizeof namebuf);
    mh.msg_namelen = 8;
    sendto(s, payload, sizeof payload, 0, (struct sockaddr *)&b, sizeof b);
    n = recvmsg(s, &mh, MSG_DONTWAIT);
    fam = *(unsigned short *)namebuf;
    snprintf(d, sizeof d, "ret=%zd namelen=%u fam=%u expect namelen=16 fam=2",
             n, (unsigned)mh.msg_namelen, fam);
    check("udp-recvmsg-namelen-short",
          n == (ssize_t)sizeof payload && mh.msg_namelen == 16
              && fam == AF_INET,
          d);
    close(s);
}

/* --- recvfrom clamp: bytes past a short sockaddr object stay intact --- */
static void case_udp_recvfrom_shortlen(void)
{
    int s;
    struct sockaddr_in b;
    socklen_t bl;
    char payload[] = "hello-short";
    char rb[64];
    ssize_t n;
    char d[160];
    struct {
        unsigned char sa[8];
        volatile unsigned long canary;
    } obj;

    s = socket(AF_INET, SOCK_DGRAM, 0);
    memset(&b, 0, sizeof b);
    b.sin_family = AF_INET;
    b.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    if (bind(s, (struct sockaddr *)&b, sizeof b) < 0) {
        check("udp-recvfrom-shortlen", 0, "bind failed");
        close(s);
        return;
    }
    bl = sizeof b;
    getsockname(s, (struct sockaddr *)&b, &bl);
    sendto(s, payload, sizeof payload, 0, (struct sockaddr *)&b, sizeof b);
    obj.canary = CANARY;
    socklen_t sl = 8;
    n = recvfrom(s, rb, sizeof rb, MSG_DONTWAIT, (struct sockaddr *)obj.sa,
                 &sl);
    int intact = obj.canary == CANARY;
    snprintf(d, sizeof d, "ret=%zd sl=%u canary=%s expect ret=12 sl=16 canary-intact",
             n, sl, intact ? "intact" : "CLOBBERED");
    check("udp-recvfrom-shortlen",
          n == (ssize_t)sizeof payload && sl == 16 && intact, d);
    close(s);
}

/* --- accept clamp: bytes past a short sockaddr object stay intact --- */
static void case_accept_shortlen(void)
{
    int ls, a;
    struct sockaddr_in b;
    socklen_t bl;
    pid_t p;
    char d[160];
    struct {
        unsigned char sa[8];
        volatile unsigned long canary;
    } obj;

    ls = socket(AF_INET, SOCK_STREAM, 0);
    memset(&b, 0, sizeof b);
    b.sin_family = AF_INET;
    b.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
    if (bind(ls, (struct sockaddr *)&b, sizeof b) < 0) {
        check("accept-shortlen-clamp", 0, "bind failed");
        close(ls);
        return;
    }
    bl = sizeof b;
    getsockname(ls, (struct sockaddr *)&b, &bl);
    if (listen(ls, 4) < 0) {
        check("accept-shortlen-clamp", 0, "listen failed");
        close(ls);
        return;
    }
    p = fork();
    if (p == 0) {
        int c = socket(AF_INET, SOCK_STREAM, 0);
        /* Loopback TCP connect can wedge (separate finding): self-exit
         * so the parent's waitpid cannot hang the rest of the probe. */
        signal(SIGALRM, SIG_DFL);
        alarm(12);
        printf("CHILD-CONNECT-START\n");
        fflush(stdout);
        int rc = connect(c, (struct sockaddr *)&b, sizeof b);
        printf("CHILD-CONNECT-RC=%d errno=%d\n", rc, errno);
        fflush(stdout);
        close(c);
        _exit(rc == 0 ? 0 : 1);
    }
    obj.canary = CANARY;
    socklen_t sl = 4;
    /* Blocking accept wedges against a blocking forked connect (loopback
     * handshake stall, filed separately) — poll with a nonblocking accept
     * so the parent's poll drives the handshake; the clamp contract under
     * test is the address write-back, identical in both shapes. */
    int fl = fcntl(ls, F_GETFL, 0);
    fcntl(ls, F_SETFL, fl | O_NONBLOCK);
    a = -1;
    for (int i = 0; i < 160; i++) {
        a = accept(ls, (struct sockaddr *)obj.sa, &sl);
        if (a >= 0 || errno != EAGAIN)
            break;
        usleep(50000);
    }
    fcntl(ls, F_SETFL, fl);
    int intact = obj.canary == CANARY;
    snprintf(d, sizeof d, "fd=%d sl=%u canary=%s expect fd>=0 sl=16 canary-intact",
             a, sl, intact ? "intact" : "CLOBBERED");
    check("accept-shortlen-clamp", a >= 0 && sl == 16 && intact, d);
    if (a >= 0)
        close(a);
    close(ls);
    waitpid(p, NULL, 0);
}

/* --- AF_INET6 getsockname must not overrun a 16-byte object --- */
static void case_v6_getsockname(void)
{
    int s, r;
    struct sockaddr_in6 b6;
    char d[160];
    socklen_t sl;
    struct {
        unsigned char sa[16];
        volatile unsigned long canary;
        volatile unsigned long pad;
    } obj;

    s = socket(AF_INET6, SOCK_DGRAM, 0);
    memset(&b6, 0, sizeof b6);
    b6.sin6_family = AF_INET6;
    b6.sin6_addr = in6addr_loopback;
    if (bind(s, (struct sockaddr *)&b6, sizeof b6) < 0) {
        check("v6-getsockname-16b-obj", 0, "bind6 failed");
        close(s);
        return;
    }
    obj.canary = CANARY;
    obj.pad = CANARY;
    sl = 16;
    r = getsockname(s, (struct sockaddr *)obj.sa, &sl);
    int intact = obj.canary == CANARY && obj.pad == CANARY;
    snprintf(d, sizeof d, "r=%d sl=%u canary=%s expect r=0 sl=28 canary-intact",
             r, sl, intact ? "intact" : "CLOBBERED");
    check("v6-getsockname-16b-obj", r == 0 && sl == 28 && intact, d);
    close(s);
}

static void on_alarm(int sig)
{
    (void)sig;
    printf("SOCKADDR-DONE fails=%d (alarm)\n", fails);
    fflush(stdout);
    for (;;)
        pause();
}

int main(void)
{
    /* sockaddr.skip_accept=1 on the kernel cmdline skips the TCP accept
     * case (x86_64: the loopback TCP handshake does not complete there
     * and the blocking accept would wedge the probe). */
    int skip_accept = 0;
    int fd = open("/proc/cmdline", O_RDONLY);
    if (fd >= 0) {
        char cmd[512];
        ssize_t n = read(fd, cmd, sizeof cmd - 1);
        close(fd);
        if (n > 0) {
            cmd[n] = 0;
            skip_accept = strstr(cmd, "sockaddr.skip_accept=1") != NULL;
        }
    }

    signal(SIGALRM, on_alarm);
    alarm(40);

    printf("SOCKADDR-START\n");
    case_unix_dgram();
    case_udp_recvmsg();
    case_udp_recvfrom_shortlen();
    if (!skip_accept)
        case_accept_shortlen();
    case_v6_getsockname();
    printf("SOCKADDR-DONE fails=%d\n", fails);
    fflush(stdout);

    /* Park like the other init probes: the boot driver kills QEMU on the
     * DONE line; exiting init would take the kernel down first. */
    for (;;) {
        char c;
        if (read(0, &c, 1) < 0)
            pause();
    }
    return 0;
}
