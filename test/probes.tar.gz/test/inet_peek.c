/*
 * inet_peek.c — MSG_PEEK on AF_INET sockets (review-func F7 A/B probe).
 *
 * Verdict line: INETPEEK-DONE fails=<n>
 *
 * Cases:
 *   udp-peek-same      two MSG_PEEK recvfroms return the same datagram
 *   udp-peek-consume   plain recvfrom after peek still returns it (peek
 *                      did not consume), then EAGAIN
 *   udp-peek-trunc     a short peek buffer returns a prefix and leaves
 *                      the datagram queued
 *   tcp-peek-same      two MSG_PEEK recvs on a stream return the same
 *                      prefix
 *   tcp-peek-consume   plain recv after peek returns the same bytes and
 *                      drains them
 */
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

static int fails = 0;

static void check(const char *name, int ok, const char *detail)
{
    printf("INETPEEK-CASE %s %s (%s)\n", name, ok ? "PASS" : "FAIL", detail);
    if (!ok)
        fails++;
}


int main(void)
{
    /* ---- UDP over loopback ---- */
    {
        int s = socket(AF_INET, SOCK_DGRAM, 0);
        struct sockaddr_in a;
        socklen_t al = sizeof a;
        memset(&a, 0, sizeof a);
        a.sin_family = AF_INET;
        a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
        a.sin_port = 0;
        if (bind(s, (struct sockaddr *)&a, sizeof a) < 0) {
            check("udp-peek-same", 0, "bind failed");
            close(s);
        } else {
            getsockname(s, (struct sockaddr *)&a, &al);
            const char *msg = "peek-datagram";
            sendto(s, msg, strlen(msg), 0, (struct sockaddr *)&a, sizeof a);
            char b1[64] = {0}, b2[64] = {0}, b3[64] = {0};
            ssize_t n1 = recvfrom(s, b1, sizeof b1 - 1, MSG_PEEK, NULL, NULL);
            /* Second peek is DONTWAIT: on a kernel where the first peek
                 * consumed the datagram this returns EAGAIN instead of
                 * wedging the probe in a blocking receive. */
            ssize_t n2 = recvfrom(s, b2, sizeof b2 - 1, MSG_PEEK | MSG_DONTWAIT, NULL, NULL);
            char d[256];
            snprintf(d, sizeof d, "n1=%zd '%s' n2=%zd '%s' expect same '%s'",
                     n1, b1, n2, b2, msg);
            check("udp-peek-same",
                  n1 == (ssize_t)strlen(msg) && n2 == n1 &&
                      strcmp(b1, msg) == 0 && strcmp(b2, msg) == 0,
                  d);
            ssize_t n3 = recvfrom(s, b3, sizeof b3 - 1, MSG_DONTWAIT, NULL, NULL);
            ssize_t n4 = recvfrom(s, b1, sizeof b1 - 1, MSG_DONTWAIT, NULL, NULL);
            snprintf(d, sizeof d, "n3=%zd '%s' n4=%zd errno=%d expect n3=len n4=-1",
                     n3, b3, n4, errno);
            check("udp-peek-consume",
                  n3 == (ssize_t)strlen(msg) && strcmp(b3, msg) == 0 && n4 < 0,
                  d);
            /* truncated peek leaves the datagram queued */
            sendto(s, "0123456789AB", 12, 0, (struct sockaddr *)&a, sizeof a);
            char pre[5] = {0};
            ssize_t pt = recvfrom(s, pre, 4, MSG_PEEK, NULL, NULL);
            char full[16] = {0};
            ssize_t pf = recvfrom(s, full, sizeof full - 1, MSG_DONTWAIT, NULL, NULL);
            snprintf(d, sizeof d, "peek=%zd '%s' then=%zd '%s' expect peek=4 '0123' then=12",
                     pt, pre, pf, full);
            check("udp-peek-trunc",
                  pt == 4 && strcmp(pre, "0123") == 0 && pf == 12,
                  d);
            close(s);
        }
    }

    /* ---- TCP over loopback (in-process: connect+accept) ---- */
    {
        int ls = socket(AF_INET, SOCK_STREAM, 0);
        struct sockaddr_in a;
        socklen_t al = sizeof a;
        memset(&a, 0, sizeof a);
        a.sin_family = AF_INET;
        a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
        a.sin_port = 0;
        if (bind(ls, (struct sockaddr *)&a, sizeof a) < 0 ||
            listen(ls, 4) < 0) {
            check("tcp-peek-same", 0, "bind/listen failed");
            close(ls);
        } else {
            getsockname(ls, (struct sockaddr *)&a, &al);
            int c = socket(AF_INET, SOCK_STREAM, 0);
            if (connect(c, (struct sockaddr *)&a, sizeof a) < 0) {
                check("tcp-peek-same", 0, "connect failed");
                close(c);
                close(ls);
            } else {
                int fcntl_fl = fcntl(ls, F_GETFL, 0);
                fcntl(ls, F_SETFL, fcntl_fl | O_NONBLOCK);
                int afd = -1;
                for (int i = 0; i < 200; i++) {
                    afd = accept(ls, NULL, NULL);
                    if (afd >= 0 || errno != EAGAIN)
                        break;
                    usleep(20000);
                }
                fcntl(ls, F_SETFL, fcntl_fl);
                if (afd < 0) {
                    check("tcp-peek-same", 0, "accept failed");
                } else {
                    const char *msg = "stream-peek-payload";
                    send(afd, msg, strlen(msg), 0);
                    usleep(100000); /* let loopback deliver */
                    char b1[64] = {0}, b2[64] = {0}, b3[64] = {0};
                    ssize_t n1 = recv(c, b1, sizeof b1 - 1, MSG_PEEK);
                    /* DONTWAIT: see the UDP note — a consuming peek
                     * must fail fast here, not wedge the probe. */
                    ssize_t n2 = recv(c, b2, sizeof b2 - 1, MSG_PEEK | MSG_DONTWAIT);
                    char d[256];
                    snprintf(d, sizeof d, "n1=%zd n2=%zd expect %zd both '%s'",
                             n1, n2, (ssize_t)strlen(msg), msg);
                    check("tcp-peek-same",
                          n1 == (ssize_t)strlen(msg) && n2 == n1 &&
                              strcmp(b1, msg) == 0 && strcmp(b2, msg) == 0,
                          d);
                    ssize_t n3 = recv(c, b3, sizeof b3 - 1, MSG_DONTWAIT);
                    snprintf(d, sizeof d, "n3=%zd '%s' expect %zd '%s'",
                             n3, b3, (ssize_t)strlen(msg), msg);
                    check("tcp-peek-consume",
                          n3 == (ssize_t)strlen(msg) && strcmp(b3, msg) == 0,
                          d);
                    close(afd);
                }
                close(c);
                close(ls);
            }
        }
    }

    printf("INETPEEK-DONE fails=%d\n", fails);
    return fails ? 1 : 0;
}
