// metaanat.c — metadata-op anatomy driver (perf-gaps G3, 2026-11).
//
// Runs mkdir/rmdir and creat/unlink loops while the kernel-side fsw
// counters (cmdline fsw=1, dump every 60s from the timer tick) collect
// the per-op cost anatomy (FSW2/FSW3: mkdir/rmdir/unlink bracket and
// phase timers, journal counters, I/O counters). Userspace medians are
// printed alongside for the syscall-view numbers. The probe idles past
// two fsw dump boundaries before finishing so the serial log carries
// populated counter snapshots.
#define _GNU_SOURCE
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <time.h>
#include <unistd.h>

#ifndef AT_FDCWD
#define AT_FDCWD -100
#endif

static unsigned long long tsc_hz;

static inline unsigned long long rdtsc(void)
{
	unsigned int lo, hi;
	asm volatile("rdtsc" : "=a"(lo), "=d"(hi));
	return ((unsigned long long)hi << 32) | lo;
}

static void calibrate(void)
{
	unsigned long long t0 = rdtsc();
	struct timespec ts0, ts1;
	clock_gettime(CLOCK_MONOTONIC, &ts0);
	for (;;) {
		clock_gettime(CLOCK_MONOTONIC, &ts1);
		long long ns = (ts1.tv_sec - ts0.tv_sec) * 1000000000LL
			     + (ts1.tv_nsec - ts0.tv_nsec);
		if (ns >= 200000000LL) {
			tsc_hz = (rdtsc() - t0) * 1000000000ULL / (unsigned long long)ns;
			return;
		}
	}
}

#define N 2000
static unsigned long long s[N];

static int cmp_ull(const void *a, const void *b)
{
	unsigned long long x = *(const unsigned long long *)a;
	unsigned long long y = *(const unsigned long long *)b;
	return x < y ? -1 : x > y;
}

static void med_line(const char *name)
{
	unsigned n = 0;
	while (n < N && s[n])
		n++;
	if (!n) {
		printf("PBENCH %s n=0\n", name);
		return;
	}
	qsort(s, n, sizeof s[0], cmp_ull);
	double us = (double)s[n / 2] / (double)tsc_hz * 1e6;
	double us1 = (double)s[n / 10] / (double)tsc_hz * 1e6;
	double us9 = (double)s[(n - 1) * 9 / 10] / (double)tsc_hz * 1e6;
	printf("PBENCH %s n=%u med=%.3f p10=%.3f p90=%.3f\n", name, n, us, us1, us9);
}

int main(void)
{
	static char p[128];
	calibrate();
	printf("PBENCH MD start (tsc_hz=%llu)\n", tsc_hz);

	/* mkdir + rmdir pairs */
	for (unsigned i = 0; i < N; i++) {
		snprintf(p, sizeof p, "/test/mdp.d.%u", i % 64);
		unsigned long long t0 = rdtsc();
		if (mkdir(p, 0755) == 0)
			rmdir(p);
		s[i] = rdtsc() - t0;
	}
	med_line("v_mkdir_rmdir");

	/* creat (1 buffered byte) then unlink — the p6_unlink shape */
	{
		unsigned char one = 'x';
		for (unsigned i = 0; i < N; i++) {
			snprintf(p, sizeof p, "/test/mdp.f.%u", i % 64);
			int fd = open(p, O_CREAT | O_WRONLY | O_TRUNC, 0644);
			if (fd >= 0) {
				write(fd, &one, 1);
				close(fd);
			}
			unsigned long long t0 = rdtsc();
			unlink(p);
			s[i] = rdtsc() - t0;
		}
		med_line("v_unlink");
	}

	/* mkdir alone */
	for (unsigned i = 0; i < N; i++) {
		snprintf(p, sizeof p, "/test/mdp.solo.%u", i);
		unsigned long long t0 = rdtsc();
		if (mkdir(p, 0755) != 0)
			break;
		s[i] = rdtsc() - t0;
	}
	med_line("v_mkdir_only");
	for (unsigned i = 0; i < N; i++) {
		snprintf(p, sizeof p, "/test/mdp.solo.%u", i);
		rmdir(p);
	}

	/* idle past two fsw dump boundaries (60s cadence, first dump ~90s) */
	printf("PBENCH MD idling for fsw dumps...\n");
	for (int i = 0; i < 13; i++)
		sleep(10);
	printf("PBENCH DONE rc=0\n");
	return 0;
}
