// runit.c — static session bootstrap for the Ubuntu riscv64 GNOME image.
//
// Port of test/gnome-x86/runit.c (the surviving mirror of the lost gp3i
// chain). Chain: system dbus, session dbus (address captured through a
// pipe so every later client shares ONE bus), Xorg on fbdev, then the
// gnome-session chain. riscv64 differences from the x86 version:
//   - /etc/runit-session selects the session name (default "gnome": the
//     full stock chain with gsd; "rux" pins org.gnome.Shell as the only
//     required component for a minimal bring-up).
//   - Compiled with the repo musl toolchain (same reason as udesk: the
//     host cross-gcc static glibc targets a newer baseline than QEMU
//     rv64). See test/ubuntu-gui/build-img.sh.
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/wait.h>
#include <poll.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

static void spawn_stdin_null(const char *file, char *const argv[]) {
    pid_t pid = fork();
    if (pid == 0) {
        int devnull = open("/dev/null", O_RDONLY);
        if (devnull >= 0) { dup2(devnull, STDIN_FILENO); close(devnull); }
        setsid();
        execvp(file, argv);
        _exit(127);
    }
}

// Start the session dbus daemon and capture its printed address
// ("unix:path=...") through a pipe, so the whole session shares one bus
// instead of every client dbus-launching its own.
static int start_session_bus(char *addr_out, size_t addr_cap) {
    int fds[2];
    if (pipe(fds) < 0) return -1;
    pid_t pid = fork();
    if (pid == 0) {
        close(fds[0]);
        dup2(fds[1], STDOUT_FILENO);
        dup2(fds[1], STDERR_FILENO);
        close(fds[1]);
        int devnull = open("/dev/null", O_RDONLY);
        if (devnull >= 0) { dup2(devnull, STDIN_FILENO); close(devnull); }
        setsid();
        execl("/usr/bin/dbus-daemon", "dbus-daemon", "--session", "--fork",
              "--address=unix:path=/tmp/dbus-session.sock",
              "--print-address=1", "--nopidfile", (char *)NULL);
        _exit(127);
    }
    close(fds[1]);
    ssize_t n = read(fds[0], addr_out, addr_cap - 1);
    close(fds[0]);
    if (n <= 0) return -1;
    addr_out[n] = 0;
    char *nl = strchr(addr_out, '\n');
    if (nl) *nl = 0;
    int st; waitpid(pid, &st, 0);
    if (strncmp(addr_out, "unix:", 5) != 0) return -1; // exec/config failure text
    return 0;
}

// Wait until Xorg's socket shows up (or give up after `sec` seconds).
static void wait_for_x(int sec) {
    for (int i = 0; i < sec; i++) {
        struct stat st;
        if (stat("/tmp/.X11-unix/X0", &st) == 0) return;
        sleep(1);
    }
}

// Launch a session child with stdout/stderr to `logpath`, stdin null.
static pid_t launch_logged(const char *logpath, const char *file,
                           const char *arg0, const char *const *argv) {
    int log = open(logpath, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    pid_t pid = fork();
    if (pid == 0) {
        if (log >= 0) { dup2(log, STDOUT_FILENO); dup2(log, STDERR_FILENO); }
        int devnull = open("/dev/null", O_RDONLY);
        if (devnull >= 0) { dup2(devnull, STDIN_FILENO); close(devnull); }
        setsid();
        execv(file, (char *const *)argv);
        printf("[runit] exec %s failed errno-dummy\n", file);
        _exit(127);
    }
    if (log >= 0) close(log);
    (void)arg0;
    return pid;
}

// Print "== dump PATH ==" then `tail -n <n> PATH` to the console.
static void dump_log_prefix(const char *path, int n) {
    printf("== dump %s (tail) ==\n", path);
    fflush(stdout);
    char nbuf[8];
    snprintf(nbuf, sizeof nbuf, "%d", n);
    pid_t d = fork();
    if (d == 0) {
        int con = open("/dev/console", O_WRONLY);
        if (con >= 0) { dup2(con, STDOUT_FILENO); dup2(con, STDERR_FILENO); }
        execl("/usr/bin/tail", "tail", "-n", nbuf, path, (char *)NULL);
        _exit(127);
    }
    int st; waitpid(d, &st, 0);
}

static void dump_log(const char *path) {
    dump_log_prefix(path, 40);
}

// Run `file argv` with stdout/stderr on the console; wait up to
// `max_sec` seconds (SIGKILL a straggler) and return its exit status
// (-1 on timeout/fork failure). Used by the gdm branch for the
// synchronous udev coldplug steps.
static int run_console_wait(const char *file, const char *const argv[],
                            int max_sec) {
    pid_t pid = fork();
    if (pid < 0) return -1;
    if (pid == 0) {
        int con = open("/dev/console", O_WRONLY);
        if (con >= 0) { dup2(con, STDOUT_FILENO); dup2(con, STDERR_FILENO); }
        int devnull = open("/dev/null", O_RDONLY);
        if (devnull >= 0) { dup2(devnull, STDIN_FILENO); close(devnull); }
        execv(file, (char *const *)argv);
        _exit(127);
    }
    for (int i = 0; i < max_sec; i++) {
        int st;
        pid_t r = waitpid(pid, &st, WNOHANG);
        if (r == pid) return st;
        if (r < 0) return -1;
        sleep(1);
    }
    kill(pid, SIGKILL);
    waitpid(pid, NULL, 0);
    printf("[runit] %s timed out after %ds\n", file, max_sec);
    return -1;
}

// X-state probe: ground truth for the "windows never paint" hunt
// (leg-6). Clients like gnome-session-failed run for the whole session
// yet no window ever appears on screen — the shell's own chrome
// (panel/wallpaper/cursor) paints fine, so the open question is
// whether client windows ever MAP and get MANAGED before blaming the
// compositing (GLX texture-from-pixmap) path. xwininfo -tree -root
// lists every window with map state and geometry; xprop then shows
// which windows the WM reports as its clients (_NET_CLIENT_LIST).
// x11-xserver-utils ships both. Console-only, ~30 lines when idle.
static void dump_xstate(void) {
    static const char *const probes[][4] = {
        { "== dump X tree (xwininfo -root -tree) ==",
          "/usr/bin/xwininfo", "-root", "-tree" },
        { "== dump X clients (xprop _NET_CLIENT_LIST) ==",
          "/usr/bin/xprop", "-root", "_NET_CLIENT_LIST _NET_SUPPORTING_WM_CHECK" },
        // GLX capabilities as seen by a CLIENT on this stack (mesa-utils
        // joined the image in r8): server glX extensions string incl.
        // GLX_EXT_texture_from_pixmap — the capability mutter's X11
        // compositing needs. Windows map+frame but never paint; if TFP
        // is missing from this string the silent-drop hypothesis is
        // settled image-side, if present the hunt moves to
        // glXCreatePixmap texturing (leg-7).
        { "== dump GLX caps (glxinfo -B) ==",
          "/usr/bin/glxinfo", "-B", "" },
    };
    for (unsigned i = 0; i < sizeof probes / sizeof probes[0]; i++) {
        printf("%s\n", probes[i][0]);
        fflush(stdout);
        pid_t d = fork();
        if (d == 0) {
            int con = open("/dev/console", O_WRONLY);
            if (con >= 0) { dup2(con, STDOUT_FILENO); dup2(con, STDERR_FILENO); }
            setenv("DISPLAY", ":0", 1);
            if (probes[i][3][0])
                execl(probes[i][1], "probe", probes[i][2], probes[i][3],
                      (char *)NULL);
            else
                execl(probes[i][1], "probe", probes[i][2], (char *)NULL);
            _exit(127);
        }
        int st; waitpid(d, &st, 0);
        if (st != 0)
            printf("[runit] xprobe %s exited st=%d\n", probes[i][1], st);
    }
    // Server GLX extension string (leg-8): glxinfo -B prints only the
    // brief block; the full run's "server glx extensions" list is where
    // GLX_EXT_texture_from_pixmap (mutter's X11 composite texture path)
    // appears or does not. sh -c so the pipe lives guest-side.
    {
        printf("== dump GLX server extensions (TFP check) ==\n");
        fflush(stdout);
        pid_t d = fork();
        if (d == 0) {
            int con = open("/dev/console", O_WRONLY);
            if (con >= 0) { dup2(con, STDOUT_FILENO); dup2(con, STDERR_FILENO); }
            setenv("DISPLAY", ":0", 1);
            execl("/bin/sh", "sh", "-c",
                  "/usr/bin/glxinfo 2>/dev/null | "
                  "sed -n '/server glx extensions/,+8p'; "
                  "/usr/bin/glxinfo 2>/dev/null | grep -c texture_from_pixmap "
                  "| sed 's/^/tfp-lines=/'; "
                  "/usr/bin/glxinfo 2>/dev/null | grep -m2 'GLX visual\\|GLX fbconfig'",
                  (char *)NULL);
            _exit(127);
        }
        int st; waitpid(d, &st, 0);
    }
    // Per-window content walk (leg-8): XGetImage every sizable window's
    // own content. An xterm body with white-with-glyph pixels in its own
    // window (absent from scanout) convicts the mutter composite path;
    // an all-black xterm window convicts client drawing. Replaces the
    // hard-coded rects as the primary frontier instrument (the two rect
    // probes stay for root-vs-scanout continuity).
    {
        printf("== dump XWALK (per-window content) ==\n");
        fflush(stdout);
        pid_t d = fork();
        if (d == 0) {
            int con = open("/dev/console", O_WRONLY);
            if (con >= 0) { dup2(con, STDOUT_FILENO); dup2(con, STDERR_FILENO); }
            setenv("DISPLAY", ":0", 1);
            execl("/usr/local/bin/xregion", "xregion", "-w", "100",
                  (char *)NULL);
            _exit(127);
        }
        int st; waitpid(d, &st, 0);
        if (st != 0)
            printf("[runit] xregion -w exited st=%d\n", st);
    }
    // Composited-content probe (leg-7): XGetImage the root window where
    // the xterm probe window should be (its geometry has been 904x536 at
    // +140+90 or +140+127 — sample the interior so either placement is
    // covered), plus the panel strip. If XREGION shows the window body
    // in the root but the QMP screendump of the same area does not, the
    // break is Xorg->scanout; if the root lacks it too, mutter never
    // composited the client (GLX texture-from-pixmap hunt).
    {
        static const char *const rects[][5] = {
            { "window-body", "200", "200", "700", "300" },
            { "panel-strip", "0", "0", "1280", "30" },
        };
        for (unsigned i = 0; i < sizeof rects / sizeof rects[0]; i++) {
            printf("== dump XREGION %s ==\n", rects[i][0]);
            fflush(stdout);
            pid_t d = fork();
            if (d == 0) {
                int con = open("/dev/console", O_WRONLY);
                if (con >= 0) { dup2(con, STDOUT_FILENO); dup2(con, STDERR_FILENO); }
                setenv("DISPLAY", ":0", 1);
                execl("/usr/local/bin/xregion", "xregion",
                      rects[i][1], rects[i][2], rects[i][3], rects[i][4],
                      (char *)NULL);
                _exit(127);
            }
            int st; waitpid(d, &st, 0);
            if (st != 0)
                printf("[runit] xregion %s exited st=%d\n", rects[i][0], st);
        }
    }
}

// --- kernel trace forensics (merged-main tracing subsystem) ---
// /sys/kernel/debug/tracing is auto-mounted by the kernel. Arm the
// sched + page-fault events before the session chain starts so any
// stall or crash has a scheduling/fault trail. Knob runit-trace=0 on
// the kernel cmdline disables (default on).
#define TRACE_BASE "/sys/kernel/debug/tracing"

static void write_file_text(const char *path, const char *text) {
    int fd = open(path, O_WRONLY);
    if (fd < 0) return;
    write(fd, text, strlen(text));
    close(fd);
}

static void arm_tracing(int on) {
    if (!on) return;
    // Focused set: scheduling + page faults only. Arming every event
    // (the old events/enable=1) included sys_enter/sys_exit, which
    // floods the per-CPU rings on every syscall — under the gsd storm
    // the buffer held only ~160ms of history (1.5M+ overwrites/10min),
    // far too little to see a stall. sched+exceptions keeps enough
    // history to name where the chain stalls.
    write_file_text(TRACE_BASE "/events/sched/enable", "1");
    write_file_text(TRACE_BASE "/events/exceptions/enable", "1");
    write_file_text(TRACE_BASE "/tracing_on", "1");
}

// Tail of the buffered trace records + per-CPU stats, to the console.
// Called when a session child dies (and periodically by the tailer) so
// the serial log carries the last scheduled events before the death.
static void dump_trace(int lines) {
    struct stat st;
    if (stat(TRACE_BASE "/trace", &st) != 0) return;
    printf("== trace tail (last events before death) ==\n");
    fflush(stdout);
    dump_log_prefix(TRACE_BASE "/trace", lines);
    dump_log_prefix(TRACE_BASE "/per_cpu/cpu0/stats", 4);
}

// Read a one-line knob file (/etc/runit-mode, /etc/runit-session).
// Falls back to the kernel cmdline (/proc/cmdline) knob of the same
// name: "runit-mode=gs runit-session=rux" on the qemu -append line
// overrides the image-baked defaults, so fire.py can flip modes per
// boot without an image rebuild (boots use -snapshot).
static void read_knob(const char *path, char *buf, size_t cap) {
    buf[0] = 0;
    const char *eq = strrchr(path, '/');
    const char *key = eq ? eq + 1 : path;
    char cmb[2048] = "";
    int cf = open("/proc/cmdline", O_RDONLY);
    if (cf >= 0) {
        ssize_t n = read(cf, cmb, sizeof cmb - 1);
        close(cf);
        if (n > 0) cmb[n] = 0;
    }
    char pat[64];
    snprintf(pat, sizeof pat, "%s=", key);
    char *cm = cmb[0] ? strstr(cmb, pat) : NULL;
    if (cm) {
        cm += strlen(pat);
        size_t i = 0;
        while (cm[i] && cm[i] != ' ' && cm[i] != '\n' && i < cap - 1) {
            buf[i] = cm[i];
            i++;
        }
        buf[i] = 0;
        return; // cmdline knob wins over the image file
    }
    int mf = open(path, O_RDONLY);
    if (mf >= 0) {
        ssize_t n = read(mf, buf, cap - 1);
        close(mf);
        if (n > 0) {
            buf[n] = 0;
            for (size_t i = 0; buf[i]; i++)
                if (buf[i] == '\n' || buf[i] == '\r') buf[i] = 0;
        }
    }
}

// --- notification-banner probe (leg-8) ---
// The shell's org.freedesktop.Notifications daemon registers at the END
// of the JS init walk ("GNOME Shell started"), so a banner can only be
// tested once that line appears. Watch /tmp/gnome-shell.log for the
// marker; on first sight (then every 200s) fire a Notify call with a
// long expire-time and print NOTIFY-SENT — fire.py sees the marker and
// takes a burst of screendumps timed to the banner lifetime, so the
// banner check does not depend on the 30s idle shot cadence.
static int shell_started(void)
{
    // Cheap tail scan: the marker is printed by the shell itself and
    // also mirrored by the periodic log tailer, so the last 8 KiB is
    // enough.
    int fd = open("/tmp/gnome-shell.log", O_RDONLY);
    if (fd < 0) return 0;
    char buf[8192];
    ssize_t n = read(fd, buf, sizeof buf - 1);
    close(fd);
    if (n <= 0) return 0;
    buf[n] = 0;
    return strstr(buf, "GNOME Shell started") != NULL;
}

static void fire_notify_banner(void)
{
    pid_t d = fork();
    if (d == 0) {
        int con = open("/dev/console", O_WRONLY);
        if (con >= 0) { dup2(con, STDOUT_FILENO); dup2(con, STDERR_FILENO); }
        execl("/usr/bin/gdbus", "gdbus", "call", "--session",
              "--dest", "org.freedesktop.Notifications",
              "--object-path", "/org/freedesktop/Notifications",
              "--method", "org.freedesktop.Notifications.Notify",
              "rux-probe", "0", "", "Rux banner probe",
              "banner body alpha 24680", "[]", "{}", "45000",
              (char *)NULL);
        _exit(127);
    }
    int st; waitpid(d, &st, 0);
    printf("[runit] NOTIFY-SENT gdbus st=%d\n", st);
    fflush(stdout);
}

// gdm greeter session bridge (gdmr46): write the sd-login state files
// that gdm-manager's RegisterDisplay sender lookup needs (see the call
// site for the full story). Idempotent and cheap; called at boot AND
// every tailer cycle because logind clears/rewrites these files under
// its own state management during startup.
static void write_sdlogin_bridge(void) {
    mkdir("/run", 0755);
    mkdir("/run/systemd", 0755);
    mkdir("/run/systemd/seats", 0755);
    mkdir("/run/systemd/sessions", 0755);
    mkdir("/run/systemd/users", 0755);
    static const char seats_body[] = "ID=seat0\nSTATE=active\nSESSIONS=c1\n";
    static const char sess_body[] =
        "UID=120\nACTIVE=1\nSTATE=active\nREMOTE=0\n"
        "TYPE=x11\nCLASS=greeter\nSEAT=seat0\nDISPLAY=:0\n"
        "TTY=tty1\nLEADER=1\n";
    static const char user_body[] =
        "UID=120\nSTATE=online\nSESSIONS=c1\nSESSIONS_BY_TIME=c1\n"
        "ACTIVE_SESSIONS=c1\nONLINE_SESSIONS=c1\nONLINE=c1\nACTIVE=c1\n"
        "SEATS=seat0\nONLINE_SEATS=seat0\nACTIVE_SEATS=seat0\n";
    const char *to_write[3][2] = {
        { "/run/systemd/seats/seat0", seats_body },
        { "/run/systemd/sessions/c1", sess_body },
        { "/run/systemd/users/120", user_body },
    };
    for (int i = 0; i < 3; i++) {
        int fd = open(to_write[i][0], O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (fd >= 0) {
            const char *b = to_write[i][1];
            size_t l = strlen(b), off = 0;
            while (off < l) {
                ssize_t w = write(fd, b + off, l - off);
                if (w <= 0) break;
                off += (size_t)w;
            }
            close(fd);
        }
    }
}

// Minimal /dev/log sink (gdm bring-up r7): gdm3's [debug] output goes
// to syslog(3); with no syslog daemon and no /dev/log socket every
// line is silently DROPPED — the single biggest evidence gap in the
// display-manager bring-up. A tiny AF_UNIX SOCK_DGRAM reader bound to
// /dev/log, appending everything to /tmp/gdm-syslog.log (tailer dumps
// it). Protocol: syslog(3) sends "<pri>message" — stored verbatim.
static void start_devlog_sink(void) {
    pid_t p = fork();
    if (p != 0) return; // PID1 side: fire and forget
    int s = socket(AF_UNIX, SOCK_DGRAM, 0);
    if (s < 0) _exit(1);
    struct sockaddr_un a;
    memset(&a, 0, sizeof a);
    a.sun_family = AF_UNIX;
    strcpy(a.sun_path, "/dev/log");
    unlink("/dev/log");
    if (bind(s, (struct sockaddr *)&a, sizeof a) < 0) _exit(2);
    chmod("/dev/log", 0666);
    for (;;) {
        char buf[2048];
        ssize_t n = recv(s, buf, sizeof buf - 1, 0);
        if (n <= 0) { sleep(1); continue; }
        buf[n] = 0;
        int f = open("/tmp/gdm-syslog.log",
                     O_WRONLY | O_CREAT | O_APPEND, 0644);
        if (f >= 0) {
            ssize_t off = 0;
            while (off < n) {
                ssize_t w = write(f, buf + off, n - off);
                if (w <= 0) break;
                off += w;
            }
            close(f);
        }
    }
}

int main(void) {
    // NOTE: SIGCHLD must stay SIG_DFL — SIG_IGN is inherited across
    // fork AND exec, and it makes gnome-session/glib waitpid() calls
    // return ECHILD (auto-reap), so every spawned component looks like
    // an instant failure.

    // PID1's inherited stdout is not the console (kernel init path):
    // attach it explicitly so every printf below reaches the serial log.
    {
        int con = open("/dev/console", O_WRONLY);
        if (con >= 0) {
            dup2(con, STDOUT_FILENO);
            dup2(con, STDERR_FILENO);
            close(con);
        }
    }

    char modebuf[16] = "";
    read_knob("/etc/runit-mode", modebuf, sizeof modebuf);
    // "gs" = unsupervised gnome-shell --replace (TCG-friendly: no 20s
    // register deadline). "gdm" = stock display-manager chain (logind +
    // gdm3; see the gdm branch below). Default "session" = full
    // gnome-session chain. Exact match only — "g" alone is NOT gs.
    const char *MODE = "session";
    if (strcmp(modebuf, "gs") == 0) MODE = "gs";
    else if (strcmp(modebuf, "gdm") == 0) MODE = "gdm";
    printf("[runit] mode=%s\n", MODE);

    char tracebuf[8] = "";
    read_knob("/etc/runit-trace", tracebuf, sizeof tracebuf);
    int TRACE = (tracebuf[0] == '0') ? 0 : 1;
    arm_tracing(TRACE);
    printf("[runit] trace armed=%d\n", TRACE);

    char sessbuf[32] = "";
    read_knob("/etc/runit-session", sessbuf, sizeof sessbuf);
    const char *SESSION = sessbuf[0] ? sessbuf : "gnome";
    printf("[runit] session=%s\n", SESSION);

    setenv("PATH", "/usr/bin:/usr/sbin:/bin:/sbin", 1);
    setenv("HOME", "/root", 1);
    setenv("USER", "root", 1);
    setenv("LANG", "C.UTF-8", 1);
    setenv("XDG_RUNTIME_DIR", "/tmp/xdg", 1);
    setenv("DISPLAY", ":0", 1);
    setenv("XDG_SESSION_TYPE", "x11", 1);
    setenv("XDG_CURRENT_DESKTOP", "GNOME", 1);
    setenv("LIBGL_ALWAYS_SOFTWARE", "1", 1);
    setenv("GALLIUM_DRIVER", "llvmpipe", 1);
    // NO_AT_BRIDGE: every GTK app and gsd plugin retries the missing
    // org.a11y.Bus for the whole session ("AT-SPI: Error retrieving
    // accessibility bus address" — dozens of dbind warnings per boot,
    // each potentially costing a serialized dbus round trip in the
    // 25s-timeout shell init walk). GTK respects this env by skipping
    // the a11y bridge entirely. Cheaper than shipping at-spi correctly
    // and removes a whole timeout class from the init walk (leg-7).
    setenv("NO_AT_BRIDGE", "1", 1);
    mkdir("/tmp/xdg", 0700);

    // auto-clear stale X locks (an unclean prior run would wedge Xorg)
    unlink("/tmp/.X0-lock");
    unlink("/tmp/.X11-unix/X0");
    // gdm's greeter Xorg runs as the gdm user (gdm-x-session) and
    // _XSERVTransmkdir REFUSES to create /tmp/.X11-unix when euid != 0
    // (gdmr33: "_XSERVTransmkdir: ERROR: euid != 0"), so the listening
    // socket would never bind. Create it root-side, 1777.
    mkdir("/tmp/.X11-unix", 01777);

    // gdm greeter session bridge — RETIRED (gdmr55). The gdmr46 bridge
    // faked /run/systemd/{sessions/c1,users/120} from PID1, but logind
    // owns users/120 and rewrote/unlinked it through its user-record
    // churn on every greeter attempt (gdmr51: RegisterDisplay failed
    // deterministically), and the fake sessions/c1 pollutes logind's
    // startup load ("Cannot attach session c1 to seat seat0", gdmr54).
    // The real path is in place: pam_systemd (image) + login1
    // CreateSession + the systemd1shim scope jobs. write_sdlogin_bridge
    // stays in the file for reference; it is no longer called.

    printf("[runit] starting system dbus\n");
    mkdir("/run/dbus", 0755);
    spawn_stdin_null("dbus-daemon", (char *[]){ "dbus-daemon", "--system", "--fork",
        "--print-address", NULL });
    sleep(1);

    // gdmr70 fd-negotiation ground truth (session-21 hunt): gdmr69
    // proved logind replies org.freedesktop.DBus.Error.NotSupported to
    // every fd-carrying reply — its sd-bus connection never negotiated
    // unix fd support, and NO process on this system has ever passed
    // one fd through the system bus (scmtap). Speak the RAW auth
    // protocol to the daemon: AUTH EXTERNAL, then NEGOTIATE_UNIX_FD,
    // and print every line the daemon sends back. If AGREE_UNIX_FD
    // never arrives, the daemon (or the socket under it) is the
    // break; if it arrives, the loss is in the clients' read of it.
    {
        int s = socket(AF_UNIX, SOCK_STREAM, 0);
        if (s < 0) {
            printf("AUTHPROBE: socket errno=%d\n", errno);
        } else {
            struct sockaddr_un aa;
            memset(&aa, 0, sizeof aa);
            aa.sun_family = AF_UNIX;
            strcpy(aa.sun_path, "/run/dbus/system_bus_socket");
            if (connect(s, (struct sockaddr *)&aa, sizeof aa) < 0) {
                printf("AUTHPROBE: connect errno=%d\n", errno);
            } else {
                // root: EXTERNAL hex of the decimal uid string "0" = "30"
                const char init[] = "\0AUTH EXTERNAL 30\r\n";
                if (write(s, init, sizeof init - 1) < 0)
                    printf("AUTHPROBE: write AUTH errno=%d\n", errno);
                const char steps[][24] = { "NEGOTIATE_UNIX_FD\r\n",
                                           "BEGIN\r\n" };
                for (unsigned st = 0; st < 2; st++) {
                    // read everything available (up to 5s), print raw
                    char buf[512];
                    struct pollfd pf = { .fd = s, .events = POLLIN };
                    int pr = poll(&pf, 1, 5000);
                    if (pr <= 0) {
                        printf("AUTHPROBE: step %u poll=%d errno=%d\n",
                               st, pr, errno);
                        break;
                    }
                    ssize_t n = read(s, buf, sizeof buf - 1);
                    if (n <= 0) {
                        printf("AUTHPROBE: step %u read=%zd errno=%d\n",
                               st, n, errno);
                        break;
                    }
                    buf[n] = 0;
                    printf("AUTHPROBE: step %u got %zd bytes: '", st, n);
                    for (ssize_t i = 0; i < n; i++)
                        printf("%c",
                               (buf[i] >= 32 && buf[i] < 127) ? buf[i] : '.');
                    printf("'\n");
                    fflush(stdout);
                    if (write(s, steps[st], strlen(steps[st])) < 0)
                        printf("AUTHPROBE: write step %u errno=%d\n",
                               st, errno);
                }
            }
            close(s);
        }

        // gdmr71: replicate sd-bus's EXACT auth write — ONE sendmsg
        // with THREE iovecs ("\0AUTH EXTERNAL\r\nDATA\r\n" +
        // "NEGOTIATE_UNIX_FD\r\n" + "BEGIN\r\n", bus-socket.c
        // bus_socket_start_auth_client) — then drain the daemon's
        // replies with recvmsg+control-buffer (sd-bus's
        // bus_socket_read_auth shape). If the AGREE line is missing
        // here while the step-by-step probe above got it, the
        // divergence is in this exact syscall shape (multi-iov sendmsg
        // / cmsg-buffer recvmsg), not in the daemon.
        {
            int s = socket(AF_UNIX, SOCK_STREAM, 0);
            if (s < 0) {
                printf("AUTHIOV: socket errno=%d\n", errno);
            } else {
                struct sockaddr_un aa;
                memset(&aa, 0, sizeof aa);
                aa.sun_family = AF_UNIX;
                strcpy(aa.sun_path, "/run/dbus/system_bus_socket");
                if (connect(s, (struct sockaddr *)&aa, sizeof aa) < 0) {
                    printf("AUTHIOV: connect errno=%d\n", errno);
                } else {
                    static const char iov0[] = "\0AUTH EXTERNAL\r\nDATA\r\n";
                    static const char iov1[] = "NEGOTIATE_UNIX_FD\r\n";
                    static const char iov2[] = "BEGIN\r\n";
                    struct iovec iov[3] = {
                        { (void *)iov0, sizeof iov0 - 1 },
                        { (void *)iov1, sizeof iov1 - 1 },
                        { (void *)iov2, sizeof iov2 - 1 },
                    };
                    char ctl[CMSG_SPACE(8 * sizeof(int))];
                    struct msghdr mh;
                    memset(&mh, 0, sizeof mh);
                    mh.msg_iov = iov;
                    mh.msg_iovlen = 3;
                    mh.msg_control = ctl;
                    mh.msg_controllen = sizeof ctl;
                    ssize_t k = sendmsg(s, &mh, MSG_DONTWAIT | MSG_NOSIGNAL);
                    printf("AUTHIOV: sendmsg=%zd errno=%d (want %zu)\n",
                           k, errno, sizeof iov0 + sizeof iov1 + sizeof iov2 - 3);
                    fflush(stdout);
                    for (int round = 0; round < 6; round++) {
                        char buf[512];
                        struct iovec ri = { buf, sizeof buf - 1 };
                        struct msghdr rm;
                        memset(&rm, 0, sizeof rm);
                        rm.msg_iov = &ri;
                        rm.msg_iovlen = 1;
                        rm.msg_control = ctl;
                        rm.msg_controllen = sizeof ctl;
                        struct pollfd pf = { .fd = s, .events = POLLIN };
                        int pr = poll(&pf, 1, 4000);
                        if (pr <= 0) {
                            printf("AUTHIOV: round %d poll=%d (done)\n",
                                   round, pr);
                            break;
                        }
                        ssize_t n = recvmsg(s, &rm, MSG_DONTWAIT);
                        if (n <= 0) {
                            printf("AUTHIOV: round %d recvmsg=%zd errno=%d\n",
                                   round, n, errno);
                            break;
                        }
                        buf[n] = 0;
                        printf("AUTHIOV: round %d got %zd bytes: '", round, n);
                        for (ssize_t i = 0; i < n; i++)
                            printf("%c",
                                   (buf[i] >= 32 && buf[i] < 127) ? buf[i] : '.');
                        printf("' flags=0x%x controllen=%zu\n",
                               rm.msg_flags, rm.msg_controllen);
                        fflush(stdout);
                    }
                }
                close(s);
            }
        }
    }

    char addr[512] = "";
    if (start_session_bus(addr, sizeof addr) == 0 && addr[0]) {
        printf("[runit] session bus: %s\n", addr);
        setenv("DBUS_SESSION_BUS_ADDRESS", addr, 1);
    } else {
        printf("[runit] session bus capture FAILED (%s); clients will dbus-launch\n", addr);
    }

    // upowerd from PID1 instead of dbus activation: gsd-power exits(1)
    // and gnome-session respawn-loops it when org.freedesktop.UPower is
    // missing. The daemon IS activatable via the (now-fixed) setuid
    // helper, but a cold upowerd start takes ~20s even on a QUIET boot
    // (measured, run/upowerd-probe) — dbus's 25s service_start_timeout
    // loses that race under the session storm and activation times out.
    // Starting it here removes the race entirely.
    {
        pid_t u = launch_logged("/tmp/upowerd.log", "/usr/libexec/upowerd",
                                "upowerd",
                                (const char *const []){ "upowerd", NULL });
        (void)u;
        printf("[runit] upowerd started (pid %d)\n", (int)u);
    }

    // accounts-daemon from PID1, same reasoning as upowerd (leg-7): the
    // shell's ActUserManager and gsd-xsettings talk to
    // org.freedesktop.Accounts on the SYSTEM bus. With the service
    // absent every proxy creation runs the activator, times out or
    // errors ("ActUserManager: user (null) has no username", the
    // accountsservice-CRITICAL spam in every serial so far), and the
    // per-plugin waits serialize into the shell init walk. The daemon
    // is small and idles quietly once up. jammy ships it under
    // /usr/libexec; the legacy /usr/lib/accountsservice path is the
    // fallback.
    {
        const char *acct = "/usr/libexec/accounts-daemon";
        if (access(acct, X_OK) != 0)
            acct = "/usr/lib/accountsservice/accounts-daemon";
        pid_t a = launch_logged("/tmp/accounts-daemon.log", acct,
                                "accounts-daemon",
                                (const char *const []){ "accounts-daemon",
                                                        NULL });
        (void)a;
        printf("[runit] accounts-daemon started (pid %d, %s)\n",
               (int)a, acct);
    }

    printf("[runit] starting Xorg (fbdev)\n");
    // gdk-pixbuf loaders cache: dpkg -x skips the postinst that writes
    // it, and without the cache every pixbuf load beyond the built-ins
    // fails ("Could not load a pixbuf from icon theme" — the shell's
    // SVG icons need the librsvg loader registered). Generate it once,
    // guest-side, before anything paints.
    {
        pid_t q = fork();
        if (q == 0) {
            const char *cachepath =
                "/usr/lib/riscv64-linux-gnu/gdk-pixbuf-2.0/2.10.0/loaders.cache";
            int out = open(cachepath, O_WRONLY | O_CREAT | O_TRUNC, 0644);
            if (out >= 0) { dup2(out, STDOUT_FILENO); close(out); }
            execl("/usr/lib/riscv64-linux-gnu/gdk-pixbuf-2.0/gdk-pixbuf-query-loaders",
                  "gdk-pixbuf-query-loaders", (char *)NULL);
            _exit(127);
        }
        if (q > 0) { int st; waitpid(q, &st, 0); }
    }
    // Xorg output goes to the serial console (console=ttyS0) for
    // headless bring-up diagnosis; the log file copy stays as well.
    // Xorg is runit's OWN bring-up server for the session/gs modes. In
    // gdm mode gdm3 owns the display stack completely (its greeter X
    // server, its vt/display bookkeeping) — a second Xorg from PID1
    // would squat :0 and gdm's display would collide with it (r4: both
    // ran; gdm3 died on an option anyway, but the design is single
    // owner). gdk-pixbuf cache + stale-lock cleanup stay: cheap and
    // idempotent, and the greeter wants the loaders cache too.
    pid_t xpid = -1;
    if (strcmp(MODE, "gdm") != 0) {
        pid_t xfork = fork();
        if (xfork == 0) {
            int xlog = open("/tmp/Xorg.log", O_WRONLY | O_CREAT | O_TRUNC, 0644);
            if (xlog >= 0) { dup2(xlog, STDOUT_FILENO); dup2(xlog, STDERR_FILENO); }
            int con = open("/dev/console", O_WRONLY);
            if (con >= 0) { dup2(con, STDOUT_FILENO); dup2(con, STDERR_FILENO); }
            int devnull = open("/dev/null", O_RDONLY);
            if (devnull >= 0) { dup2(devnull, STDIN_FILENO); close(devnull); }
            setsid();
            // The riscv64 kernel does interpret shebangs, but exec the real
            // server binary directly anyway — same as the proven x86 path.
            execl("/usr/lib/xorg/Xorg", "Xorg", ":0",
                  "-config", "/etc/X11/xorg-fbdev.conf",
                  "-noreset", "-verbose", "3", (char *)NULL);
            _exit(127);
        }
        xpid = xfork;
        wait_for_x(30);
        sleep(2); // let GLX initialize before the first client connects
    }

    printf("[runit] starting session chain (mode=%s session=%s)\n", MODE, SESSION);
    // Periodic log tailer: every 20s push the tail of the session logs
    // to the console, so bring-up forensics do not depend on death
    // detection working.
    {
        pid_t tp = fork();
        if (tp == 0) {
            int cyc = 0;
            int notified = 0;
            for (;;) {
                sleep(20);
                cyc++;
                // (sd-login bridge re-write retired at gdmr55 —
                // pam_systemd + systemd1shim own the session state now)
                // gdm-mode logs ride along (stat-guarded; missing files
                // are skipped) so the first display-manager boots leave
                // their forensics on the serial console too.
                const char *logs[11] = { "/tmp/gnome-session.log",
                                        "/tmp/gnome-shell.log",
                                        "/tmp/Xorg.log",
                                        "/tmp/logind.log", // (500-tail below)
                                        "/tmp/gdm-syslog.log",
                                        // the systemd1 shim's own stdout
                                        "/tmp/systemd1shim.log",
                                        // gdm's X server logs (root-written)
                                        "/var/log/Xorg.0.log",
                                        // the greeter Xorg runs as the gdm
                                        // user (gdm-x-session), so its log
                                        // also lands in the gdm HOME
                                        "/var/lib/gdm/.local/share/xorg/Xorg.0.log",
                                        // gdm-launch-environment's program-
                                        // session log (gdm-session-worker
                                        // _open_program_session_log) — the
                                        // greeter's own stdout/stderr;
                                        // LOGDIR is /var/log/gdm3 (gdm3
                                        // binary strings)
                                        "/var/log/gdm3/:0-greeter.log",
                                        "/var/log/gdm3/greeter.log",
                                        // gdmr73+: the gnome-shell stderr
                                        // tee wrapper (gdm-repack installs
                                        // /usr/bin/gnome-shell as a dash
                                        // wrapper around the real binary)
                                        // — gdm3 daemonizes to /dev/null,
                                        // so without this the shell's own
                                        // exit(1) reason is unrecoverable
                                        "/tmp/gshell.log",
                                        NULL };
                for (int i = 0; i < 11; i++) {
                    struct stat st;
                // greeter.log paths dump UNCONDITIONALLY: the worker
                // is believed to create them at session start, and
                // tail's own "No such file" error is the diagnostic
                // when it does not.
                    // gdm-syslog.log (i==4) gets the big tail: gdm3's own post-mortem
                    // spam pushes the worker/x-session lines out of a 150-line tail
                    // inside one 20 s cycle (gdmr55 evidence gap).
                    if (i == 2 || i == 4 || i >= 8) { dump_log_prefix(logs[i], 500); continue; }
                    if (stat(logs[i], &st) != 0) continue;
                    dump_log_prefix(logs[i], 150);
                }
                // gdm bring-up (gdmr37+): the greeter session's output is
                // the missing forensics (the raw tail is all Xorg
                // -verbose flood). Filter to session-relevant lines, and
                // keep knocking down /run/systemd/system so the worker's
                // sd_booted() stays false and the log file keeps being
                // written (logind re-creates it via session setup).
                {
                    pid_t ls = fork();
                    if (ls == 0) {
                        int con = open("/dev/console", O_WRONLY);
                        if (con >= 0) { dup2(con, STDOUT_FILENO); dup2(con, STDERR_FILENO); }
                        execl("/bin/sh", "sh", "-c",
                              "echo == greeter-log filtered ==; "
                              "ls -la /var/log/gdm3 /var/lib/gdm /var/cache/fontconfig "
                              "/var/lib/gdm/.cache/fontconfig 2>&1 | head -n 30; "
                              "tail -n 40 /tmp/gxs.log 2>/dev/null; tail -n 40 /tmp/greeter-session.log 2>/dev/null; "
                              "grep -aiE 'gnome-session|dbus-run|x-session|gnome-shell|"
                              "gsd-|ERROR|CRITICAL|WARNING|Cannot|cannot|Unable|failed|Failed|"
                              "abort|Abort|exit' /var/log/gdm3/greeter.log 2>/dev/null | tail -n 80",
                              (char *)NULL);
                        _exit(127);
                    }
                    if (ls > 0) { int st2; waitpid(ls, &st2, 0); }
                }
                // notification-banner probe (leg-8): fire on the shell
                // marker, re-fire every 10 cycles so at least one lands
                // in a calm window (each call prints NOTIFY-SENT).
                if (shell_started()) {
                    if (!notified || (cyc % 10) == 0) {
                        notified = 1;
                        fire_notify_banner();
                    }
                }
                if (TRACE && (cyc % 3) == 0) {
                    dump_log_prefix(TRACE_BASE "/per_cpu/cpu0/stats", 4);
                    // Short scheduling snapshot every minute: names the
                    // tasks the CPUs are actually running (or failing to
                    // run) during long stalls like the slow Shell boot.
                    dump_log_prefix(TRACE_BASE "/trace", 24);
                }
                // X window-state snapshot every minute: window map/
                // manage ground truth (see dump_xstate). Once the
                // desktop is up this is ~20 lines; before X starts the
                // probes just fail fast on connect.
                if ((cyc % 3) == 0)
                    dump_xstate();
            }
            _exit(0);
        }
    }
    if (strcmp(MODE, "gdm") == 0) {
        // Real display-manager path (gdm bring-up, session 17): runit
        // starts ONLY the background daemons and hands the display to
        // gdm3, which owns Xorg, the greeter session (gnome-shell
        // --mode=gdm via gdm-session-worker), PAM authentication and
        // the logged-in user session. No manual Xorg, no manual session
        // bus, no session chain — everything past this point is stock.
        // - /run/systemd/system makes sd_booted() return true for gdm
        //   and libsystemd clients without systemd as PID1.
        // - logind runs STANDALONE from the systemd package: it owns
        //   org.freedesktop.login1 on the system bus and /dev/tty0
        //   (kernel VT layer — the bring-up question this mode maps).
        //   NO cgroup2 mount anymore (gdmr17b): with sd_booted()>0 and
        //   ppid==1, udevd records its "own" cgroup from
        //   /proc/self/cgroup; when a unified hierarchy is mounted and
        //   its root lists every task (our synthetic one does), udevd's
        //   idle cleanup cg_kill()s the whole root — the SIGKILL storm.
        //   The kernel no longer pre-mounts cgroup2 nor fabricates
        //   "0::/" in /proc/pid/cgroup, so cg_pid_get_path() answers
        //   -ENOMEDIUM and udevd records nothing.
        mkdir("/run/systemd", 0755);
        mkdir("/run/systemd/system", 0755);
        // logind does NOT take --debug (r2 lesson: "unrecognized
        // option" -> exit 1); debug level comes from this env var.
        // G_MESSAGES_DEBUG=all: gdm3 logs through GLib to stderr —
        // without it /tmp/gdm3.log stays empty (its syslog() calls go
        // nowhere; there is no /dev/log on this image).
        setenv("SYSTEMD_LOG_LEVEL", "debug", 1);
        setenv("G_MESSAGES_DEBUG", "all", 1);
        // /dev/log sink BEFORE gdm3: its syslog(3) lines are the
        // primary debug stream (see start_devlog_sink).
        start_devlog_sink();
        // udevd + coldplug (r5 lesson): gdm3 never launches the greeter
        // while seat0's CanGraphical is false, and logind's seat0 gets
        // graphics devices ONLY through udev database tags
        // (71-seat.rules: master-of-seat) — without udevd logind runs
        // fine but its seat stays graphics-less and gdm idles forever.
        // The kernel already broadcasts userspace-triggered uevents
        // (write "add" to any /sys/.../uevent — sysfs uevent attr), so
        // stock udevadm trigger coldplugs drm/input/graphics.
        {
            const char *const uargv[] = { "systemd-udevd", "--daemon", NULL };
            pid_t upid = launch_logged("/tmp/udevd.log",
                                       "/lib/systemd/systemd-udevd",
                                       "systemd-udevd", uargv);
            printf("[runit] systemd-udevd started (pid %d)\n", (int)upid);
            sleep(3);
            // udevadm lives at /bin/udevadm (the r8 "enumeration finds
            // zero devices" verdict was an artifact: every
            // /usr/bin/udevadm exec ENOENT'd with silent exit 127, so
            // the coldplug NEVER ran and the udev db stayed empty for
            // that reason alone). /lib/systemd/systemd-udevd is a
            // symlink to the same multi-call binary (argv[0] picks the
            // tool).
            // Synchronous coldplug of the seat-relevant subsystems
            // (full-tree trigger is slow under TCG for zero seat value).
            const char *const trig[] = {
                "udevadm", "trigger", "--action=add",
                "--subsystem-match=drm",
                "--subsystem-match=input",
                "--subsystem-match=graphics", NULL };
            int trc = run_console_wait("/bin/udevadm", trig, 120);
            printf("[runit] udevadm trigger rc=%d\n", trc);
            const char *const settle[] = {
                "udevadm", "settle", "--timeout=15", NULL };
            int src = run_console_wait("/bin/udevadm", settle, 30);
            printf("[runit] udevadm settle rc=%d\n", src);
            // gdmr19 diagnostics (two open questions from gdmr18):
            // (1) the udev db dir /run/udev/data was present seconds
            // after each trigger (export-db listed bare entries) and
            // GONE again by every later ls — sample at 1 Hz to catch
            // the disappearance moment against the EXITGRP timeline;
            // (2) udevd must narrate worker spawn/exit and rule
            // decisions: raise its log level so /tmp/udevd.log
            // (captured by the ground-truth cycles) says which of the
            // two it is.
            {
                const char *const prio[] = {
                    "udevadm", "control", "--log-priority=debug", NULL };
                printf("log-priority rc=%d\n",
                       run_console_wait("/bin/udevadm", prio, 20));
                const char *const probe[] = {
                    "sh", "-c",
                    "for i in $(seq 1 40); do "
                    "printf 'dbprobe %d: ' $i; "
                    "ls /run/udev/data 2>/dev/null | wc -l; "
                    "sleep 1; done",
                    NULL };
                run_console_wait("/bin/sh", probe, 60);
            }
        }
        {
            // gdmr59 diagnostics: the greeter session dies of an
            // immediate fifo EOF (logind "Session c1 logged out" right
            // after "Choosing session c1" — the CreateSession reply's
            // passed write-end fd never reaches pam_systemd, or the
            // fifo's writer accounting is wrong). Both suspects are
            // cheap to discriminate at boot: (1) SCM_RIGHTS over an
            // AF_UNIX stream socketpair — send one fd, receive it,
            // read a byte through it; (2) a fifo read end polled
            // NONBLOCKING while a writer holds the other end — Linux
            // reports NO HUP in that state.
            {
                int sv[2];
                if (socketpair(AF_UNIX, SOCK_STREAM, 0, sv) == 0) {
                    // Isolation case A: plain data, recvmsg WITH control
                    // buffer (no fds). If THIS errors, plain recvmsg is
                    // broken and SCM_RIGHTS is innocent.
                    pid_t ta = fork();
                    if (ta == 0) {
                        close(sv[0]);
                        char cb[24];
                        char qb = '?';
                        struct iovec io = { .iov_base = &qb, .iov_len = 1 };
                        struct msghdr m;
                        memset(&m, 0, sizeof m);
                        m.msg_iov = &io;
                        m.msg_iovlen = 1;
                        m.msg_control = cb;
                        m.msg_controllen = sizeof cb;
                        ssize_t r = recvmsg(sv[1], &m, 0);
                        printf("PLAINCTL: recv=%zd errno=%d\n", r, errno);
                        fflush(stdout);
                        _exit(0);
                    }
                    close(sv[1]);
                    write(sv[0], "q", 1);
                    int sta; waitpid(ta, &sta, 0);
                    // socketpair is consumed; make a fresh one below.
                    close(sv[0]);
                }
                if (socketpair(AF_UNIX, SOCK_STREAM, 0, sv) == 0) {
                    pid_t t = fork();
                    if (t == 0) {
                        // receiver: pass the byte through the sent fd.
                        close(sv[0]);
                        char cmsgbuf[CMSG_SPACE(sizeof(int))];
                        char xb = '?';
                        struct iovec iov = { .iov_base = &xb, .iov_len = 1 };
                        struct msghdr mh;
                        memset(&mh, 0, sizeof mh);
                        mh.msg_iov = &iov;
                        mh.msg_iovlen = 1;
                        mh.msg_control = cmsgbuf;
                        mh.msg_controllen = sizeof cmsgbuf;
                        ssize_t r = recvmsg(sv[1], &mh, 0);
                        int got = -1;
                        struct cmsghdr *ch;
                        for (ch = CMSG_FIRSTHDR(&mh); ch; ch = CMSG_NXTHDR(&mh, ch))
                            if (ch->cmsg_level == SOL_SOCKET &&
                                ch->cmsg_type == SCM_RIGHTS)
                                got = *(int *)CMSG_DATA(ch);
                        if (r >= 1 && got >= 0) {
                            char b;
                            ssize_t rr = pread(got, &b, 1, 0);
                            printf("SCMFDS: ok (recv=%zd fd=%d read=%zd)\n",
                                   r, got, rr);
                        } else {
                            printf("SCMFDS: FAIL (recv=%zd errno=%d fd=%d)\n",
                                   r, errno, got);
                        }
                        fflush(stdout);
                        _exit(0);
                    }
                    close(sv[1]);
                    int magic = open("/etc/passwd", O_RDONLY);
                    char cmsgbuf[CMSG_SPACE(sizeof(int))];
                    char yb = 'y';
                    struct iovec iov = { .iov_base = &yb, .iov_len = 1 };
                    struct msghdr mh;
                    memset(&mh, 0, sizeof mh);
                    mh.msg_iov = &iov;
                    mh.msg_iovlen = 1;
                    mh.msg_control = cmsgbuf;
                    mh.msg_controllen = sizeof cmsgbuf;
                    struct cmsghdr *ch = CMSG_FIRSTHDR(&mh);
                    ch->cmsg_level = SOL_SOCKET;
                    ch->cmsg_type = SCM_RIGHTS;
                    ch->cmsg_len = CMSG_LEN(sizeof(int));
                    *(int *)CMSG_DATA(ch) = magic;
                    ssize_t sr = sendmsg(sv[0], &mh, 0);
                    printf("SCMFDS: send=%zd\n", sr);
                    fflush(stdout);
                    int st; waitpid(t, &st, 0);
                    close(magic);
                }
                // Transit test: the reference kernel keeps passed fds
                // alive through the receive queue even if the sender
                // closes its copy instantly after sendmsg (this is the
                // CreateSession session-fifo shape: logind's write end
                // is closed right after the reply is queued).
                {
                    int sv2[2];
                    if (socketpair(AF_UNIX, SOCK_STREAM, 0, sv2) == 0) {
                        pid_t t = fork();
                        if (t == 0) {
                            close(sv2[0]);
                            char cb2[CMSG_SPACE(sizeof(int))];
                            char zb = '?';
                            struct iovec io = { .iov_base = &zb, .iov_len = 1 };
                            struct msghdr m;
                            memset(&m, 0, sizeof m);
                            m.msg_iov = &io;
                            m.msg_iovlen = 1;
                            m.msg_control = cb2;
                            m.msg_controllen = sizeof cb2;
                            ssize_t r = recvmsg(sv2[1], &m, 0);
                            int got = -1;
                            struct cmsghdr *ch;
                            for (ch = CMSG_FIRSTHDR(&m); ch; ch = CMSG_NXTHDR(&m, ch))
                                if (ch->cmsg_level == SOL_SOCKET &&
                                    ch->cmsg_type == SCM_RIGHTS)
                                    got = *(int *)CMSG_DATA(ch);
                            char b;
                            ssize_t rr = got >= 0 ? pread(got, &b, 1, 0) : -1;
                            printf("SCMTRANSIT: recv=%zd fd=%d read=%zd errno=%d\n",
                                   r, got, rr, errno);
                            fflush(stdout);
                            _exit(0);
                        }
                        close(sv2[1]);
                        int fdx = open("/etc/passwd", O_RDONLY);
                        char cb2[CMSG_SPACE(sizeof(int))];
                        char zb2 = 'z';
                        struct iovec io = { .iov_base = &zb2, .iov_len = 1 };
                        struct msghdr m;
                        memset(&m, 0, sizeof m);
                        m.msg_iov = &io;
                        m.msg_iovlen = 1;
                        m.msg_control = cb2;
                        m.msg_controllen = sizeof cb2;
                        struct cmsghdr *ch = CMSG_FIRSTHDR(&m);
                        ch->cmsg_level = SOL_SOCKET;
                        ch->cmsg_type = SCM_RIGHTS;
                        ch->cmsg_len = CMSG_LEN(sizeof(int));
                        *(int *)CMSG_DATA(ch) = fdx;
                        sendmsg(sv2[0], &m, 0);
                        close(fdx); // sender drops its copy IMMEDIATELY
                        int st; waitpid(t, &st, 0);
                        close(sv2[0]);
                    }
                }
                unlink("/tmp/fdprobe.fifo");
                if (mkfifo("/tmp/fdprobe.fifo", 0600) == 0) {
                    int rfd = open("/tmp/fdprobe.fifo", O_RDONLY | O_NONBLOCK);
                    int wfd = open("/tmp/fdprobe.fifo", O_WRONLY | O_NONBLOCK);
                    struct pollfd pf = { .fd = rfd, .events = 0 };
                    int pr = poll(&pf, 1, 0);
                    printf("FIFOPOLL: rc=%d revents=0x%x (HUP=0x%x; HUP set -> "
                           "kernel fifo bug)\n", pr, pf.revents, POLLHUP);
                    fflush(stdout);
                    close(rfd); close(wfd);
                    // Transit test: the reference kernel keeps passed fds
                // alive through the receive queue even if the sender
                // closes its copy instantly after sendmsg (this is the
                // CreateSession session-fifo shape: logind's write end
                // is closed right after the reply is queued).
                {
                    int sv2[2];
                    if (socketpair(AF_UNIX, SOCK_STREAM, 0, sv2) == 0) {
                        pid_t t = fork();
                        if (t == 0) {
                            close(sv2[0]);
                            char cb2[CMSG_SPACE(sizeof(int))];
                            char zb = '?';
                            struct iovec io = { .iov_base = &zb, .iov_len = 1 };
                            struct msghdr m;
                            memset(&m, 0, sizeof m);
                            m.msg_iov = &io;
                            m.msg_iovlen = 1;
                            m.msg_control = cb2;
                            m.msg_controllen = sizeof cb2;
                            ssize_t r = recvmsg(sv2[1], &m, 0);
                            int got = -1;
                            struct cmsghdr *ch;
                            for (ch = CMSG_FIRSTHDR(&m); ch; ch = CMSG_NXTHDR(&m, ch))
                                if (ch->cmsg_level == SOL_SOCKET &&
                                    ch->cmsg_type == SCM_RIGHTS)
                                    got = *(int *)CMSG_DATA(ch);
                            char b;
                            ssize_t rr = got >= 0 ? pread(got, &b, 1, 0) : -1;
                            printf("SCMTRANSIT: recv=%zd fd=%d read=%zd errno=%d\n",
                                   r, got, rr, errno);
                            fflush(stdout);
                            _exit(0);
                        }
                        close(sv2[1]);
                        int fdx = open("/etc/passwd", O_RDONLY);
                        char cb2[CMSG_SPACE(sizeof(int))];
                        char zb2 = 'z';
                        struct iovec io = { .iov_base = &zb2, .iov_len = 1 };
                        struct msghdr m;
                        memset(&m, 0, sizeof m);
                        m.msg_iov = &io;
                        m.msg_iovlen = 1;
                        m.msg_control = cb2;
                        m.msg_controllen = sizeof cb2;
                        struct cmsghdr *ch = CMSG_FIRSTHDR(&m);
                        ch->cmsg_level = SOL_SOCKET;
                        ch->cmsg_type = SCM_RIGHTS;
                        ch->cmsg_len = CMSG_LEN(sizeof(int));
                        *(int *)CMSG_DATA(ch) = fdx;
                        sendmsg(sv2[0], &m, 0);
                        close(fdx); // sender drops its copy IMMEDIATELY
                        int st; waitpid(t, &st, 0);
                        close(sv2[0]);
                    }
                }
                unlink("/tmp/fdprobe.fifo");
                }
            }
        }
        {
            // systemd1 shim (gdmr54): logind's CreateSession starts the
            // session scope through org.freedesktop.systemd1 — with the
            // name unowned, dbus activation fails and pam_systemd gets
            // "Failed to create session: Launch helper exited with
            // unknown return code 1" (gdmr53). The shim owns the name
            // and completes every job instantly ("done"), so the
            // greeter's logind session materializes for real.
            // SUPERVISED (gdmr59): once per boot the shim's bus
            // CONNECTION dies while the process lives (name lost; same
            // one-shot death hit logind — it self-heals through dbus
            // activation, the shim has no activator). The shim now
            // exits(3) on a closed connection; this supervisor respawns
            // it so later greeter attempts keep their scope jobs.
            pid_t shim = fork();
            if (shim == 0) {
                for (;;) {
                    pid_t k = fork();
                    if (k == 0) {
                        int lg = open("/tmp/systemd1shim.log",
                                      O_WRONLY | O_CREAT | O_TRUNC, 0644);
                        if (lg >= 0) {
                            dup2(lg, STDOUT_FILENO);
                            dup2(lg, STDERR_FILENO);
                        }
                        setsid();
                        execl("/usr/libexec/systemd1shim",
                              "systemd1shim", (char *)NULL);
                        _exit(127);
                    }
                    int st;
                    printf("[runit] systemd1shim spawned (pid %d)\n", (int)k);
                    fflush(stdout);
                    waitpid(k, &st, 0);
                    printf("[runit] systemd1shim exited st=%d; respawning\n", st);
                    fflush(stdout);
                    sleep(2);
                }
            }
            printf("[runit] systemd1shim supervisor started (pid %d)\n",
                   (int)shim);
            sleep(2); // own the name before logind's Subscribe
        }
        {
            const char *logind = "/lib/systemd/systemd-logind";
            if (access(logind, X_OK) != 0)
                logind = "/usr/lib/systemd/systemd-logind";
            const char *const largv[] = { "systemd-logind", NULL };
            pid_t lpid = launch_logged("/tmp/logind.log", logind,
                                       "systemd-logind", largv);
            printf("[runit] logind started (pid %d, %s)\n", (int)lpid, logind);
            sleep(3); // own login1 on the system bus before gdm asks

            // gdmr67 fd-relay ground truth (session-21 hunt): logind's
            // Inhibit returns a fd ("h") through the SAME sd-bus
            // connection + dbus-daemon relay the CreateSession reply
            // uses. r66's scmtap evidence: logind's session reply never
            // reached ONE sendmsg — no TX line, pam never answered.
            // This probe splits "the relay drops fd messages" from
            // "logind's connection cannot send fds at all": busctl is
            // an sd-bus peer, gdbus a glib peer; both call Inhibit and
            // print the reply (or its error) to the console. The WHAT
            // must be a real inhibitor name (idle), the MODE is
            // block/delay (gdmr68 lesson: "delay" as what ->
            // InvalidArgs before any fd was involved).
            {
                const char *const probe[] = {
                    "busctl", "call", "org.freedesktop.login1",
                    "/org/freedesktop/login1",
                    "org.freedesktop.login1.Manager", "Inhibit",
                    "ssss", "idle", "probe", "probe", "block", NULL };
                int fdp = run_console_wait("/usr/bin/busctl", probe, 40);
                printf("[runit] INHIBIT-FD-PROBE busctl rc=%d\n", fdp);
                const char *const probe2[] = {
                    "gdbus", "call", "--system",
                    "--dest", "org.freedesktop.login1",
                    "--object-path", "/org/freedesktop/login1",
                    "--method", "org.freedesktop.login1.Manager.Inhibit",
                    "idle", "probe", "probe", "block", NULL };
                int gdp = run_console_wait("/usr/bin/gdbus", probe2, 40);
                printf("[runit] INHIBIT-FD-PROBE gdbus rc=%d\n", gdp);
            }
        }
        {
            const char *const gargv[] = { "gdm3", NULL };
            pid_t gpid2 = launch_logged("/tmp/gdm3.log", "/usr/sbin/gdm3",
                                        "gdm3", gargv);
            printf("[runit] gdm3 started (pid %d)\n", (int)gpid2);
            (void)gpid2;
        }
        // Ground-truth dumps (r7): 60 s after gdm3 starts, name the
        // exact stall point on the console —
        //   - udev database export (did the trigger tag card0
        //     master-of-seat?)
        //   - seat0 CanGraphical AS LOGININD SEES IT (gdm's gate)
        //   - login1 ListSessions (any greeter session yet?)
        // then every 120 s: shorter re-dumps so state transitions are
        // visible. run_console_wait(60) bounds each probe.
        {
            pid_t d = fork();
            if (d == 0) {
                for (int cyc = 0;; cyc++) {
                    sleep(cyc == 0 ? 60 : 120);
                    int con = open("/dev/console", O_WRONLY);
                    if (con >= 0) {
                        dup2(con, STDOUT_FILENO); dup2(con, STDERR_FILENO);
                    }
                    printf("== gdm ground truth (cycle %d) ==\n", cyc);
                    fflush(stdout);
                    // (r8) verbose re-trigger FIRST: does enumeration
                    // find the drm/input nodes at all, and does a live
                    // trigger populate the udev db afterwards?
                    const char *const trig2[] = {
                        "udevadm", "trigger", "--action=add", "--verbose",
                        "--subsystem-match=drm",
                        "--subsystem-match=input",
                        "--subsystem-match=graphics", NULL };
                    printf("trigger --verbose rc=%d\n",
                           run_console_wait("/bin/udevadm", trig2, 60));
                    const char *const rundump[] = {
                        "sh", "-c",
                        "echo '-- /run/udev --'; ls -la /run/udev /run/udev/data 2>&1 | head -14; "
                        "echo '-- ps --'; ps -ef 2>&1 | grep -E 'udevd|logind|gdm|polkit' | grep -v grep | head -8",
                        NULL };
                    run_console_wait("/bin/sh", rundump, 20);
                    // gdmr19: rule-engine ground truth. udevadm test runs
                    // the FULL rule pipeline on card0 in-process (no
                    // daemon workers involved) with per-rule decisions —
                    // the discriminator between "rules never load/match"
                    // and "the daemon's worker path is broken". The
                    // rules.d listing + udevd.log tail catch load and
                    // spawn failures. The helper stat verifies the ext4
                    // S_ISUID visibility fix (must print 04754 root).
                    {
                        const char *const udiag[] = {
                            "sh", "-c",
                            "echo '-- rules.d --'; ls /lib/udev/rules.d 2>&1 | head -6; "
                            "echo '-- helper --'; ls -la /usr/lib/dbus-1.0/dbus-daemon-launch-helper 2>&1; "
                            "echo '-- udevd.log --'; tail -12 /tmp/udevd.log 2>&1",
                            NULL };
                        run_console_wait("/bin/sh", udiag, 20);
                        const char *const utest[] = {
                            "udevadm", "test",
                            "/sys/devices/pci0000:00/0000:00:02.0/drm/card0",
                            NULL };
                        printf("udevadm-test rc=%d\n",
                               run_console_wait("/bin/udevadm", utest, 60));
                    }
                    const char *const uinfo[] = {
                        "udevadm", "info", "--export-db", NULL };
                    printf("export-db rc=%d\n",
                           run_console_wait("/bin/udevadm", uinfo, 30));
                    const char *const cg[] = {
                        "gdbus", "call", "--system",
                        "--dest", "org.freedesktop.login1",
                        // logind exports the seat bus objects under the
                        // manager's seat/ subtree; the old flat
                        // /org/freedesktop/login1/seat0 path always
                        // answered UnknownObject — a probe artifact,
                        // not a gate failure (gdmr50).
                        "--object-path", "/org/freedesktop/login1/seat/seat0",
                        "--method", "org.freedesktop.DBus.Properties.Get",
                        "org.freedesktop.login1.Seat", "CanGraphical", NULL };
                    printf("CanGraphical rc=%d\n",
                           run_console_wait("/usr/bin/gdbus", cg, 25));
                    const char *const sdstate[] = {
                        "sh", "-c",
                        "for f in /run/systemd/sessions/* "
                        "/run/systemd/users/* /run/systemd/seats/*; do "
                        "echo \"-- $f\"; cat $f 2>/dev/null; done",
                        NULL };
                    run_console_wait("/bin/sh", sdstate, 20);
                    const char *const ls[] = {
                        "gdbus", "call", "--system",
                        "--dest", "org.freedesktop.login1",
                        "--object-path", "/org/freedesktop/login1",
                        "--method",
                        "org.freedesktop.login1.Manager.ListSessions",
                        NULL };
                    printf("ListSessions rc=%d\n",
                           run_console_wait("/usr/bin/gdbus", ls, 25));
                }
            }
            (void)d;
        }
        for (;;) {
            int st;
            pid_t p = wait(&st);
            if (p > 0)
                printf("[runit] child %d exited st=%d\n", (int)p, st);
            else
                sleep(2);
        }
    }
    if (strcmp(MODE, "gs") == 0) {
        // Unsupervised shell: no register timeout, unlimited JS boot
        // time (the TCG-friendly bring-up path).
        pid_t gpid = launch_logged("/tmp/gnome-shell.log",
                                   "/usr/bin/gnome-shell", "gnome-shell",
                                   (const char *const []){
                                       "gnome-shell", "--replace", NULL });
        signal(SIGCHLD, SIG_DFL);
        for (;;) {
            int st;
            pid_t p = wait(&st);
            if (p > 0) {
                printf("[runit] child %d exited st=%d\n", (int)p, st);
                if (p == gpid) {
                    if (TRACE) dump_trace(40);
                    dump_log("/tmp/gnome-shell.log"); dump_log("/tmp/Xorg.log");
                }
            } else {
                sleep(2);
            }
        }
    }
    {
        char sessflag[64];
        snprintf(sessflag, sizeof sessflag, "--session=%s", SESSION);
        const char *const argv[] = { "gnome-session-binary", sessflag, NULL };
        pid_t gpid = launch_logged("/tmp/gnome-session.log",
                                   "/usr/libexec/gnome-session-binary",
                                   "gnome-session-binary", argv);
        time_t t0 = time(NULL);
        signal(SIGCHLD, SIG_DFL);
        int gs_dead = 0;
        for (;;) {
            int st;
            pid_t p = wait(&st);
            if (p == gpid) {
                gs_dead = 1;
                printf("[runit] gnome-session died st=%d after %lds\n",
                       st, (long)(time(NULL) - t0));
                if (TRACE) dump_trace(40);
                dump_log("/tmp/gnome-session.log");
                dump_log("/tmp/gnome-shell.log");
                if ((long)(time(NULL) - t0) < 150) break; // early death -> fallback
                // late death: keep reaping, no restart (bring-up mode)
                gpid = -1;
            } else if (p > 0) {
                printf("[runit] child %d exited st=%d\n", (int)p, st);
            } else {
                sleep(2);
            }
            if (p == xpid) {
                dump_log("/tmp/Xorg.log");
                break;
            }
        }
        if (gs_dead) {
            printf("[runit] falling back to minimal path: gnome-shell --replace\n");
            const char *const argv2[] = { "gnome-shell", "--replace", NULL };
            gpid = launch_logged("/tmp/gnome-shell.log",
                                 "/usr/bin/gnome-shell", "gnome-shell", argv2);
            for (;;) {
                int st;
                pid_t p = wait(&st);
                if (p > 0) {
                    printf("[runit] child %d exited st=%d\n", (int)p, st);
                    if (p == gpid) { dump_log("/tmp/gnome-shell.log"); dump_log("/tmp/Xorg.log"); }
                } else {
                    sleep(2);
                }
            }
        }
        // Xorg died under a live session — park reaping.
        for (;;) {
            int st;
            pid_t p = wait(&st);
            if (p > 0) printf("[runit] child %d exited st=%d\n", (int)p, st);
            else sleep(2);
        }
    }
    return 0;
}
