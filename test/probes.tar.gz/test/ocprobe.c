// ocprobe.c — open/close path decomposition (perf-gaps G2, 2026-11).
//
// p6_openclose med 21.7 us vs reference 0.371: p6_stat (same lookup,
// same 1000-file sweep) is only 5.0 us, so ~16.5 us is open/close
// machinery, not path walk. This probe splits that machinery into
// variants and runs the SAME binary on both kernels
// (pbench_boot.py --probe-bin) for a true A/B decomposition.
//
// PBENCH protocol (the boot driver relays + stops at DONE rc=0).
#define _GNU_SOURCE
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>

#ifndef AT_FDCWD
#define AT_FDCWD -100
#endif

static unsigned long long tsc_hz;

static inline unsigned long long rdtsc(void)
{
	unsigned int lo, hi;
	asm volatile("rdtsc" : "=a"(lo), "=d"(hi));
	return ((unsigned long long)hi << 32) | lo;
}

static void calibrate(void)
{
	unsigned long long t0 = rdtsc();
	struct timespec ts0, ts1;
	clock_gettime(CLOCK_MONOTONIC, &ts0);
	for (;;) {
		clock_gettime(CLOCK_MONOTONIC, &ts1);
		long long ns = (ts1.tv_sec - ts0.tv_sec) * 1000000000LL
			     + (ts1.tv_nsec - ts0.tv_nsec);
		if (ns >= 200000000LL) {
			tsc_hz = (rdtsc() - t0) * 1000000000ULL / (unsigned long long)ns;
			return;
		}
	}
}

#define N 20000
static unsigned long long s[N];

static int cmp_ull(const void *a, const void *b)
{
	unsigned long long x = *(const unsigned long long *)a;
	unsigned long long y = *(const unsigned long long *)b;
	return x < y ? -1 : x > y;
}

static void med_line(const char *name)
{
	unsigned n = 0;
	while (n < N && s[n])
		n++;
	qsort(s, n, sizeof s[0], cmp_ull);
	double us = n ? (double)s[n / 2] / (double)tsc_hz * 1e6 : 0;
	printf("PBENCH %s n=%u med=%.3f\n", name, n, us);
}

#define TIMEIT(name, body)						\
	do {								\
		for (unsigned i = 0; i < N; i++) {			\
			unsigned long long t0 = rdtsc();		\
			body;						\
			unsigned long long t1 = rdtsc();		\
			s[i] = t1 - t0;				\
		}							\
		med_line(name);						\
	} while (0)

int main(void)
{
	static char path[128];
	int fd = open("/test/pbench-tree/f0000", O_RDONLY);
	if (fd < 0) {
		// tree may not exist (standalone boot): create our own file
		fd = open("/test/ocp.dat", O_CREAT | O_RDWR | O_TRUNC, 0644);
		if (fd < 0) {
			printf("PBENCH DONE rc=1\n");
			return 1;
		}
		char b[4096] = {1};
		write(fd, b, sizeof b);
		close(fd);
		snprintf(path, sizeof path, "/test/ocp.dat");
	} else {
		close(fd);
		snprintf(path, sizeof path, "/test/pbench-tree/f0000");
	}
	calibrate();
	printf("PBENCH OCAL tsc_hz=%llu\n", tsc_hz);

	/* fdtable install/remove alone */
	TIMEIT("v_dup_close", { int d = dup(0); if (d >= 0) close(d); });

	/* null syscall baseline */
	TIMEIT("v_getpid", (void)getpid());

	/* stat of the hot file (lookup+dentry+getattr, no open) */
	{
		struct stat st;
		TIMEIT("v_stat_hot", stat(path, &st));
	}

	/* the target row: open + close, hot file */
	TIMEIT("v_open_close_hot", { int f = open(path, O_RDONLY); if (f >= 0) close(f); });

	/* openat flavor */
	TIMEIT("v_openat_close", { int f = syscall(SYS_openat, AT_FDCWD, path, O_RDONLY, 0); if (f >= 0) close(f); });

	/* O_PATH: no file ops, no lease/DAC-read machinery */
	TIMEIT("v_opath_close", { int f = open(path, O_PATH); if (f >= 0) close(f); });

	/* open + fstat + close: adds the fstat side */
	{
		struct stat st;
		TIMEIT("v_open_fstat_close", {
			int f = open(path, O_RDONLY);
			if (f >= 0) { fstat(f, &st); close(f); }
		});
	}

	/* open + 4K read + close */
	{
		static char b[4096];
		TIMEIT("v_open_read_close", {
			int f = open(path, O_RDONLY);
			if (f >= 0) { pread(f, b, sizeof b, 0); close(f); }
		});
	}

	/* close-only cost: open once, then time close after dup */
	TIMEIT("v_open_only", { int f = open(path, O_RDONLY); if (f >= 0) { int d = dup(f); close(d); close(f); } });

	/* re-open of a DIFFERENT file each time (the p6 sweep shape):
	 * 32 files round-robin so dentry/icache stay warm-ish but the
	 * File/ra-state objects are fresh each time. */
	{
		static char paths[32][128];
		int ok = 0;
		for (int i = 0; i < 32; i++) {
			snprintf(paths[i], sizeof paths[i], "/test/pbench-tree/f%04d", i * 31);
			if (access(paths[i], R_OK) == 0)
				ok++;
		}
		if (ok >= 16) {
			for (unsigned i = 0; i < N; i++) {
				unsigned long long t0 = rdtsc();
				int f = open(paths[i & 31], O_RDONLY);
				if (f >= 0)
					close(f);
				unsigned long long t1 = rdtsc();
				s[i] = t1 - t0;
			}
			med_line("v_open_close_sweep32");
		}
	}

	printf("PBENCH DONE rc=0\n");
	return 0;
}
