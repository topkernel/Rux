/* ipcdisc2.c — same-CPU wake-dance timeline capture (perf-ipc).
 *
 * Boots as init, mounts debugfs, arms the sched trace events, runs a
 * SHORT read64-samecpu window (300 timed sendto's, read-drain child,
 * both pinned to CPU0) with tracing on, stops tracing, dumps the ring
 * to serial. Repeats for recv64-samecpu. The sched_switch/waking/
 * wakeup timeline then shows exactly how the 275 us cycle decomposes:
 * when the child is woken, when it is picked, and what runs in
 * between.
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <sched.h>
#include <signal.h>
#include <sys/mount.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/wait.h>

typedef unsigned long long u64;
#define REC 74
#define N_TIMED 300
#define WARM 200

static u64 tsc_hz;
static inline u64 rdtsc_(void)
{
    unsigned lo, hi;
    __asm__ volatile("rdtsc" : "=a"(lo), "=d"(hi));
    return ((u64)hi << 32) | lo;
}
static double us(u64 t) { return (double)t / tsc_hz * 1e6; }

static void calibrate(void)
{
    struct timespec ts0, ts1;
    clock_gettime(CLOCK_MONOTONIC, &ts0);
    u64 t0 = rdtsc_();
    struct timespec req = { 0, 200 * 1000 * 1000 };
    nanosleep(&req, 0);
    clock_gettime(CLOCK_MONOTONIC, &ts1);
    u64 ns = (ts1.tv_sec - ts0.tv_sec) * 1000000000ull
            + (ts1.tv_nsec - ts0.tv_nsec);
    tsc_hz = (rdtsc_() - t0) * 1000000000ull / ns;
}

static void pin_to(int cpu)
{
    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(cpu, &set);
    sched_setaffinity(0, sizeof(set), &set);
}

static void wr(const char *path, const char *val)
{
    int fd = open(path, O_WRONLY);
    if (fd < 0) { printf("IPCDISC2 open-fail %s errno=%d\n", path, errno); return; }
    write(fd, val, strlen(val));
    close(fd);
}

static void dump_trace(void)
{
    int fd = open("/sys/kernel/debug/tracing/trace", O_RDONLY);
    if (fd < 0) { printf("IPCDISC2 trace-open-fail errno=%d\n", errno); return; }
    char buf[2048];
    ssize_t r;
    while ((r = read(fd, buf, sizeof(buf))) > 0) {
        ssize_t off = 0;
        while (off < r) {
            ssize_t w = write(1, buf + off, r - off);
            if (w <= 0) break;
            off += w;
        }
    }
    close(fd);
}

static int cmp_u64(const void *a, const void *b)
{
    u64 x = *(const u64 *)a, y = *(const u64 *)b;
    return x < y ? -1 : x > y ? 1 : 0;
}

static void run_case(const char *tag, int use_recv, int nevent)
{
    char p[128];
    /* flush the ring and re-arm */
    wr("/sys/kernel/debug/tracing/tracing_on", "0");
    snprintf(p, sizeof(p), "/sys/kernel/debug/tracing/events/sched/sched_%s/enable", nevent == 0 ? "waking" : (nevent == 1 ? "wakeup" : "switch"));
    wr(p, "1");

    int sv[2];
    if (socketpair(AF_UNIX, SOCK_STREAM, 0, sv) < 0) {
        printf("IPCDISC2 %s socketpair-errno=%d\n", tag, errno);
        return;
    }
    pid_t pid = fork();
    if (pid < 0) return;
    if (pid == 0) {
        close(sv[0]);
        pin_to(0);
        char buf[65536];
        for (;;) {
            ssize_t r = use_recv ? recvfrom(sv[1], buf, sizeof(buf), 0, 0, 0)
                                 : read(sv[1], buf, sizeof(buf));
            if (r <= 0) break;
        }
        _exit(0);
    }
    close(sv[1]);
    pin_to(0);
    char rec[REC];
    memset(rec, 0xa3, sizeof(rec));
    for (int i = 0; i < WARM; i++)
        if (sendto(sv[0], rec, REC, 0, 0, 0) != REC) break;
    u64 *t = malloc(N_TIMED * sizeof(u64));
    u64 n = 0;
    wr("/sys/kernel/debug/tracing/tracing_on", "1");
    for (int i = 0; i < N_TIMED; i++) {
        u64 t0 = rdtsc_();
        ssize_t r = sendto(sv[0], rec, REC, 0, 0, 0);
        u64 t1_ = rdtsc_();
        if (r != REC) break;
        t[n++] = t1_ - t0;
    }
    wr("/sys/kernel/debug/tracing/tracing_on", "0");
    close(sv[0]);
    kill(pid, SIGKILL);
    int st; waitpid(pid, &st, 0);
    if (n) {
        qsort(t, n, sizeof(u64), cmp_u64);
        printf("IPCDISC2 %s parent n=%llu p10=%.2f med=%.2f p90=%.2f max=%.2f\n",
               tag, n, us(t[n / 10]), us(t[n / 2]), us(t[n * 9 / 10]), us(t[n - 1]));
    }
    dump_trace();
    free(t);
}

int main(void)
{
    setbuf(stdout, NULL);
    calibrate();
    printf("IPCDISC2 START tsc_hz=%llu\n", tsc_hz);

    mkdir("/sys", 0755);
    mkdir("/sys/kernel", 0755);
    mkdir("/sys/kernel/debug", 0755);
    /* the kernel mounts debugfs at boot; only mount when absent */
    if (access("/sys/kernel/debug/tracing/tracing_on", F_OK) < 0
        && mount("debugfs", "/sys/kernel/debug", "debugfs", 0, "") < 0) {
        printf("IPCDISC2 debugfs-mount errno=%d\n", errno);
        printf("IPCDISC2 DONE\n");
        return 0;
    }
    /* ring snapshot mode so the window keeps the earliest events */
    wr("/sys/kernel/debug/tracing/events/sched/sched_waking/enable", "1");
    wr("/sys/kernel/debug/tracing/events/sched/sched_wakeup/enable", "1");
    wr("/sys/kernel/debug/tracing/events/sched/sched_switch/enable", "1");

    run_case("read64-samecpu", 0, 2);
    run_case("recv64-samecpu", 1, 2);

    printf("IPCDISC2 DONE\n");
    return 0;
}
