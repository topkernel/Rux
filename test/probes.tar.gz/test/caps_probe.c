// caps_probe.c — sec-r1 L3 capability wiring A/B probe.
//
// Exercises the capability gates this round wired to live syscall
// surface, in both privilege states:
//
//   root phase (full effective set — the boot-time configuration paths
//   must keep working):
//     - socket(AF_PACKET, SOCK_DGRAM, 0) succeeds
//     - socket(AF_INET, SOCK_RAW, IPPROTO_ICMP) succeeds
//     - socket(AF_INET, SOCK_RAW, 0) still EPROTONOSUPPORT (protocol
//       lookup precedes the cap check)
//     - acct(NULL) succeeds
//     - setxattr security.capability succeeds (CAP_SETFCAP via root)
//     - SIOCSIFADDR on a nonexistent iface reaches the device lookup
//       (ENODEV — the caller passed the CAP_NET_ADMIN gate)
//
//   nobody phase (uid/gid 65534 after setgroups/setgid/setuid):
//     - AF_PACKET socket → EPERM
//     - AF_INET SOCK_RAW → EPERM
//     - AF_INET SOCK_RAW proto 0 → EPROTONOSUPPORT (precedence kept)
//     - acct(NULL) → EPERM
//     - setxattr security.capability → EPERM (CAP_SETFCAP gate)
//     - SIOCSIFADDR → EPERM before the device lookup
//     - perf_event_open without exclude_kernel → EACCES
//     - perf_event_open with exclude_kernel → NOT EACCES
//
// Print contract: "SEC-R1-CAPS: PASS <name>" / "SEC-R1-CAPS: FAIL
// <name> (<detail>)", one line per check; the host driver greps them.

#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/xattr.h>
#include <sys/types.h>
#include <unistd.h>

#ifndef AF_PACKET
#define AF_PACKET 17
#endif
#define SOCK_RAW_L 3
#define IPPROTO_ICMP_L 1
#define SIOCSIFADDR_L 0x8916

// asm-generic perf_event_open (riscv64). x86_64 uses 298; the probe is
// riscv64-only today (the minimal rootfs flow).
#ifdef __riscv
#define NR_PERF_EVENT_OPEN 241
#else
#define NR_PERF_EVENT_OPEN 298
#endif

static int pass_count;
static int fail_count;

static void check(int ok, const char *name, const char *detail) {
    if (ok) {
        pass_count++;
        printf("SEC-R1-CAPS: PASS %s\n", name);
    } else {
        fail_count++;
        printf("SEC-R1-CAPS: FAIL %s (%s)\n", name, detail ? detail : "");
    }
    fflush(stdout);
}

struct perf_attr_min {
    uint32_t type_;
    uint32_t size;
    uint64_t config;
    uint64_t sample_period;
    uint64_t sample_type;
    uint64_t read_format;
    uint64_t flags1; // bitfield word: bit5 = exclude_kernel
    uint64_t pad[2];  // AttrHead is 48 bytes; the kernel demands size >= 64
};

static long perf_open(struct perf_attr_min *a, long pid, long cpu,
                      long group_fd, unsigned long flags) {
    return syscall(NR_PERF_EVENT_OPEN, a, pid, cpu, group_fd, flags);
}

static void drop_to_nobody(void) {
    // Drop supplementary groups first (CAP_SETGID still held), then
    // gid, then uid — the canonical order so no later step can fail.
    syscall(SYS_setgroups, 0, (const void *)0);
    setgid(65534);
    setuid(65534);
}

int main(void) {
    printf("SEC-R1-CAPS: start\n");
    fflush(stdout);

    // ---------------- root phase ----------------
    int fd = socket(AF_PACKET, SOCK_DGRAM, 0);
    check(fd >= 0, "root-afpacket-ok", fd < 0 ? strerror(errno) : 0);
    if (fd >= 0) close(fd);

    fd = socket(AF_INET, SOCK_RAW_L, IPPROTO_ICMP_L);
    check(fd >= 0, "root-rawicmp-ok", fd < 0 ? strerror(errno) : 0);
    if (fd >= 0) close(fd);

    fd = socket(AF_INET, SOCK_RAW_L, 0);
    check(fd < 0 && errno == EPROTONOSUPPORT, "root-raw-proto0-EPROTONOSUPPORT",
          fd < 0 ? strerror(errno) : "unexpected success");
    if (fd >= 0) close(fd);

    long r = syscall(SYS_acct, (const void *)0);
    check(r == 0, "root-acct-ok", r ? strerror(errno) : 0);

    // xattr: CAP_SETFCAP gate on security.capability. Marker file is
    // chmod 666 so the nobody phase is not DAC-blocked.
    const char *marker = "/tmp/caps_probe_marker";
    int mfd = open(marker, O_CREAT | O_RDWR | O_TRUNC, 0666);
    if (mfd < 0) {
        marker = "/caps_probe_marker";
        mfd = open(marker, O_CREAT | O_RDWR | O_TRUNC, 0666);
    }
    if (mfd >= 0) {
        fchmod(mfd, 0666);
        close(mfd);
    }
    static const char capv[8] = {0, 0, 0, 2, 0xff, 0xff, 0, 0};
    r = setxattr(marker, "security.capability", capv, sizeof(capv), 0);
    check(r == 0, "root-setfcap-ok", r ? strerror(errno) : 0);
    if (r == 0) {
        r = removexattr(marker, "security.capability");
        check(r == 0, "root-setfcap-remove-ok", r ? strerror(errno) : 0);
    }

    // SIOCSIFADDR on a nonexistent interface: the CAP_NET_ADMIN gate
    // must pass for root, so the failure mode is the device lookup
    // (ENODEV), not EPERM. ifreq: name[16] + 24-byte union with an
    // AF_INET sockaddr at offset 16.
    {
        int s = socket(AF_INET, SOCK_DGRAM, 0);
        unsigned char ifreq[40];
        memset(ifreq, 0, sizeof(ifreq));
        strcpy((char *)ifreq, "zz9x");
        ifreq[16] = 2; // AF_INET
        long rc = s >= 0 ? ioctl(s, SIOCSIFADDR_L, ifreq) : -1;
        check(s >= 0 && rc < 0 && errno == ENODEV,
              "root-ifwrite-past-cap-ENODEV",
              s < 0 ? "no dgram socket" : strerror(errno));
        if (s >= 0) close(s);
    }

    // ---------------- nobody phase ----------------
    drop_to_nobody();
    check(getuid() == 65534, "drop-to-nobody", "setuid failed");

    fd = socket(AF_PACKET, SOCK_DGRAM, 0);
    check(fd < 0 && errno == EPERM, "nobody-afpacket-EPERM",
          fd < 0 ? strerror(errno) : "unexpected success");
    if (fd >= 0) close(fd);

    fd = socket(AF_INET, SOCK_RAW_L, IPPROTO_ICMP_L);
    check(fd < 0 && errno == EPERM, "nobody-rawicmp-EPERM",
          fd < 0 ? strerror(errno) : "unexpected success");
    if (fd >= 0) close(fd);

    fd = socket(AF_INET, SOCK_RAW_L, 0);
    check(fd < 0 && errno == EPROTONOSUPPORT,
          "nobody-raw-proto0-EPROTONOSUPPORT",
          fd < 0 ? strerror(errno) : "unexpected success");
    if (fd >= 0) close(fd);

    r = syscall(SYS_acct, (const void *)0);
    check(r < 0 && errno == EPERM, "nobody-acct-EPERM",
          r < 0 ? strerror(errno) : "unexpected success");

    r = setxattr(marker, "security.capability", capv, sizeof(capv), 0);
    check(r < 0 && errno == EPERM, "nobody-setfcap-EPERM",
          r < 0 ? strerror(errno) : "unexpected success");

    {
        int s = socket(AF_INET, SOCK_DGRAM, 0);
        unsigned char ifreq[40];
        memset(ifreq, 0, sizeof(ifreq));
        strcpy((char *)ifreq, "lo");
        ifreq[16] = 2;
        long rc = s >= 0 ? ioctl(s, SIOCSIFADDR_L, ifreq) : -1;
        check(s >= 0 && rc < 0 && errno == EPERM, "nobody-ifwrite-EPERM",
              s < 0 ? "no dgram socket" : strerror(errno));
        if (s >= 0) close(s);
    }

    // perf: kernel-inclusive events are privileged (perfmon_capable());
    // exclude_kernel events stay open to unprivileged callers.
    {
        struct perf_attr_min a;
        memset(&a, 0, sizeof(a));
        a.type_ = 1; /* PERF_TYPE_SOFTWARE */
        a.size = 64;
        a.config = 0; /* PERF_COUNT_SW_CPU_CLOCK */
        a.sample_period = 1000000;
        a.sample_type = 1ULL << 31; /* PERF_SAMPLE_IP */
        long pfd = perf_open(&a, 0, -1, -1, 0);
        check(pfd < 0 && errno == EACCES, "nobody-perf-nokernel-EACCES",
              pfd < 0 ? strerror(errno) : "unexpected success");
        if (pfd >= 0) close((int)pfd);

        a.flags1 = (1ULL << 5); /* exclude_kernel */
        pfd = perf_open(&a, 0, -1, -1, 0);
        check(pfd < 0 && errno != EACCES, "nobody-perf-exckernel-not-EACCES",
              pfd < 0 ? strerror(errno) : "opened (allowed)");
        if (pfd >= 0) close((int)pfd);
    }

    printf("SEC-R1-CAPS: done pass=%d fail=%d\n", pass_count, fail_count);
    fflush(stdout);
    return fail_count ? 1 : 0;
}
