/* uafault — bad-user-pointer EFAULT contract probe (x86_64 SMAP leg).
 *
 * Pins the 2026-10-31 x86_64 user-pointer hardening pair: CR4.SMAP
 * enabled (commit bdc9234e) and the bootstrap identity map PML4[0]
 * dropped (commit e22f72a8). Before both, a kernel dereference of a
 * low user VA read PHYSICAL page 0/1 through the identity window, so
 * syscalls handed an unmapped user pointer could "succeed" (prlimit64
 * new_rlim at VA 1 read page 1 and applied garbage limits) instead of
 * returning EFAULT. With SMAP + no identity window every one of these
 * must return -1/EFAULT — and the kernel must survive (no oops, no
 * SMAP-VIOL beacon).
 *
 * Prints UAF-PASS / UAF-FAIL:<n>.
 */
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/resource.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/time.h>
#include <unistd.h>

/* The in-tree musl SDK predates sys/prlimit.h — prlimit64 is a plain
 * syscall (SYS_prlimit64), no libc wrapper needed. */
#define BAD ((void *)1) /* user range (access_ok passes), unmapped page 0 */

static int fails;

static void expect_eFault(const char *what, long ret)
{
    if (ret != -1) {
        printf("UAF %s: NOT rejected (ret=%ld)\n", what, ret);
        fails++;
        return;
    }
    if (errno != EFAULT) {
        printf("UAF %s: errno %d, want EFAULT(14)\n", what, errno);
        fails++;
        return;
    }
    printf("UAF %s: EFAULT ok\n", what);
}

int main(void)
{
    /* prlimit64 new_rlim at VA 1 — the exact case the identity window
     * used to satisfy (read physical page 1 as rlim_cur/rlim_max). */
    expect_eFault("prlimit64-new",
                  syscall(SYS_prlimit64, 0, RLIMIT_NOFILE, BAD, NULL));

    /* prlimit64 old_rlim out-buffer at VA 1. */
    expect_eFault("prlimit64-old",
                  syscall(SYS_prlimit64, 0, RLIMIT_NOFILE, NULL, BAD));

    /* setrlimit/getrlimit through the same uaccess path. */
    expect_eFault("setrlimit",
                  syscall(SYS_setrlimit, RLIMIT_NOFILE, BAD));
    expect_eFault("getrlimit",
                  syscall(SYS_getrlimit, RLIMIT_NOFILE, BAD));

    /* getitimer / setitimer out-buffers (same discarded-copy bug class
     * the probe's first run caught in getrlimit). */
    expect_eFault("getitimer",
                  syscall(SYS_getitimer, ITIMER_REAL, BAD));
    {
        struct itimerval zero;
        memset(&zero, 0, sizeof(zero));
        expect_eFault("setitimer-old",
                      syscall(SYS_setitimer, ITIMER_REAL,
                              (long)&zero, (long)BAD));
    }

    /* write to the console with a bad source buffer. */
    expect_eFault("write", write(1, BAD, 16));

    /* read into a bad destination buffer from a regular file. */
    int fd = open("/uaf.txt", O_CREAT | O_RDWR | O_TRUNC, 0600);
    if (fd < 0) {
        printf("UAF open: errno %d\n", errno);
        fails++;
    } else {
        if (write(fd, "0123456789abcdef", 16) != 16) {
            printf("UAF setup-write: errno %d\n", errno);
            fails++;
        }
        lseek(fd, 0, SEEK_SET);
        expect_eFault("read", read(fd, BAD, 16));

        /* fstat into a bad buffer. */
        struct stat st;
        if (fstat(fd, &st) != 0) {
            printf("UAF fstat-setup: errno %d\n", errno);
            fails++;
        }
        expect_eFault("fstat",
                      syscall(SYS_fstat, fd, BAD));

        /* getcwd into a bad buffer. */
        expect_eFault("getcwd", (long)syscall(SYS_getcwd, BAD, 64));

        close(fd);
        unlink("/uaf.txt");
    }

    /* Control: the same syscalls with a VALID buffer must succeed —
     * the EFAULTs above prove rejection, this proves the uaccess
     * brackets still let legitimate copies through (SMAP AC window
     * actually opens; a permanently-closed window would fail here). */
    struct rlimit rl;
    if (syscall(SYS_prlimit64, 0, RLIMIT_NOFILE, NULL, &rl) != 0) {
        printf("UAF prlimit64-valid: errno %d\n", errno);
        fails++;
    } else {
        printf("UAF prlimit64-valid: ok (cur=%llu)\n",
               (unsigned long long)rl.rlim_cur);
    }
    char cwd[64];
    if (getcwd(cwd, sizeof(cwd)) == NULL) {
        printf("UAF getcwd-valid: errno %d\n", errno);
        fails++;
    } else {
        printf("UAF getcwd-valid: ok (%s)\n", cwd);
    }
    char wbuf[16];
    memset(wbuf, 'u', sizeof(wbuf));
    if (write(1, wbuf, 0) != 0) {
        printf("UAF write-valid: errno %d\n", errno);
        fails++;
    } else {
        printf("UAF write-valid: ok\n");
    }

    if (fails == 0) {
        printf("UAF-PASS\n");
        return 0;
    }
    printf("UAF-FAIL:%d\n", fails);
    return 1;
}
