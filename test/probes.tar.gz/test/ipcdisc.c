/* ipcdisc.c — IPC lane discriminator probe (perf-ipc).
 *
 * Localizes the p5c-slow (write/sendto + sleeping read-drain child,
 * ~276 us parent sample) vs p5c3-fast (recvfrom-drain child, ~33 us)
 * gap on unix stream socketpairs:
 *
 *   - drain-syscall variants: read(2) 64K / read(2) 74B / recvfrom 64K
 *     / recvfrom 74B, unpinned (the p5c/p5c3 shapes)
 *   - pin variants: parent CPU0 + child CPU1 (cross-cpu: wake costs an
 *     IPI, parent never preempted at trap-exit) and parent CPU0 +
 *     child CPU0 (same-cpu: wake sets NEED_RESCHED on the parent's own
 *     cpu; trap_exit may preempt the parent INSIDE the timed window)
 *   - child-side cycle timing: each drain syscall that had to sleep
 *     (duration > 20 us proxy) is sampled; distribution printed — the
 *     child's wake->drain->resleep cycle is the leading suspect for
 *     the parent's 276 us when preemption is same-cpu
 *   - spin control: O_NONBLOCK spin-drain child (never sleeps, never
 *     woken; the p5e fast control)
 *
 * Every timed parent loop runs the pbench p5c shape: socketpair, fork,
 * 2000-record warmup, 50000 timed 74B sendto's, median + p10/p90 +
 * >100us fraction. Children are SIGKILLed after the loop.
 *
 * Output: IPCDISC lines on stdout (serial).
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <sched.h>
#include <signal.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <sys/syscall.h>

typedef unsigned long long u64;
typedef long long s64;

#define N_TIMED 50000
#define WARM 2000
#define REC 74

static u64 tsc_hz;
static inline u64 rdtsc_(void)
{
    unsigned lo, hi;
    __asm__ volatile("rdtsc" : "=a"(lo), "=d"(hi));
    return ((u64)hi << 32) | lo;
}
static double us(u64 ticks) { return (double)ticks / tsc_hz * 1e6; }

static void calibrate(void)
{
    /* measure tsc against clock_gettime like pbench does */
    struct timespec ts0, ts1;
    clock_gettime(CLOCK_MONOTONIC, &ts0);
    u64 t0 = rdtsc_();
    struct timespec req = { 0, 200 * 1000 * 1000 };
    nanosleep(&req, 0);
    clock_gettime(CLOCK_MONOTONIC, &ts1);
    u64 t1 = rdtsc_();
    u64 ns = (ts1.tv_sec - ts0.tv_sec) * 1000000000ull
            + (ts1.tv_nsec - ts0.tv_nsec);
    tsc_hz = (t1 - t0) * 1000000000ull / ns;
}

static int cmp_u64(const void *a, const void *b)
{
    u64 x = *(const u64 *)a, y = *(const u64 *)b;
    return x < y ? -1 : x > y ? 1 : 0;
}

static void pin_to(int cpu)
{
    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(cpu, &set);
    sched_setaffinity(0, sizeof(set), &set);
}

/* child drain loop: mode selects syscall; cbuf = buffer size;
 * times each syscall in a local array (first N_TIMED) */
#define MODE_READ 0
#define MODE_RECV 1
#define MODE_SPIN 2

struct child_stats {
    u64 n;
    u64 med10;   /* tsc ticks */
    u64 med;
    u64 med90;
    u64 n_slow;  /* syscalls > 20us (slept, probably) */
    u64 max;
};

static void child_drain(int fd, int mode, size_t cbuf, int nonblock,
                        int wfd)
{
    char *buf = malloc(cbuf);
    u64 *t = malloc(N_TIMED * sizeof(u64));
    if (!buf || !t) _exit(41);
    if (nonblock) fcntl(fd, F_SETFL, O_NONBLOCK);
    u64 n = 0, n_slow = 0;
    for (;;) {
        u64 t0 = rdtsc_();
        ssize_t r;
        if (mode == MODE_READ) r = read(fd, buf, cbuf);
        else r = recvfrom(fd, buf, cbuf, 0, 0, 0);
        u64 t1 = rdtsc_();
        if (r <= 0) {
            if (r < 0 && (errno == EAGAIN) && mode == MODE_SPIN) continue;
            break;
        }
        if (n < N_TIMED) {
            t[n++] = t1 - t0;
            if (us(t1 - t0) > 20.0) n_slow++;
        }
    }
    /* spin mode never exits the loop on its own; the parent kills us */
    struct child_stats cs;
    cs.n = n;
    cs.n_slow = n_slow;
    if (n) {
        qsort(t, n, sizeof(u64), cmp_u64);
        cs.med10 = t[n / 10];
        cs.med = t[n / 2];
        cs.med90 = t[n * 9 / 10];
        cs.max = t[n - 1];
    } else {
        cs.med10 = cs.med = cs.med90 = cs.max = 0;
    }
    write(wfd, &cs, sizeof(cs));
    _exit(0);
}

static void run_case(const char *tag, int mode, size_t cbuf, int nonblock,
                     int child_cpu, int parent_cpu)
{
    int sv[2], ctl[2];
    if (socketpair(AF_UNIX, SOCK_STREAM, 0, sv) < 0) {
        printf("IPCDISC %s socketpair-errno=%d\n", tag, errno);
        return;
    }
    if (pipe(ctl) < 0) {
        printf("IPCDISC %s pipe-errno=%d\n", tag, errno);
        return;
    }
    pid_t pid = fork();
    if (pid < 0) {
        printf("IPCDISC %s fork-errno=%d\n", tag, errno);
        return;
    }
    if (pid == 0) {
        close(sv[0]); close(ctl[0]);
        if (child_cpu >= 0) pin_to(child_cpu);
        child_drain(sv[1], mode, cbuf, nonblock, ctl[1]);
        _exit(0);
    }
    close(sv[1]); close(ctl[1]);
    if (parent_cpu >= 0) pin_to(parent_cpu);
    char rec[REC];
    memset(rec, 0xa3, sizeof(rec));
    for (int i = 0; i < WARM; i++)
        if (sendto(sv[0], rec, REC, 0, 0, 0) != REC) break;
    u64 *t = malloc(N_TIMED * sizeof(u64));
    if (!t) { kill(pid, SIGKILL); waitpid(pid, 0, 0); return; }
    u64 n = 0;
    for (int i = 0; i < N_TIMED; i++) {
        u64 t0 = rdtsc_();
        ssize_t r = sendto(sv[0], rec, REC, 0, 0, 0);
        u64 t1 = rdtsc_();
        if (r != REC) break;
        t[n++] = t1 - t0;
    }
    close(sv[0]);
    struct child_stats cs;
    memset(&cs, 0, sizeof(cs));
    read(ctl[0], &cs, sizeof(cs));   /* may block until child exits; spin child is killed below */
    if (mode == MODE_SPIN) { kill(pid, SIGKILL); }
    int st; waitpid(pid, &st, 0);
    if (n == 0) { printf("IPCDISC %s no-samples\n", tag); return; }
    qsort(t, n, sizeof(u64), cmp_u64);
    u64 n_big = 0;
    for (u64 i = 0; i < n; i++) if (us(t[i]) > 100.0) n_big++;
    printf("IPCDISC %s parent n=%llu p10=%.2f med=%.2f p90=%.2f max=%.2f frac>100us=%.3f\n",
           tag, n, us(t[n / 10]), us(t[n / 2]), us(t[n * 9 / 10]),
           us(t[n - 1]), (double)n_big / n);
    fflush(stdout);
    if (cs.n) {
        printf("IPCDISC %s child  n=%llu p10=%.2f med=%.2f p90=%.2f max=%.2f slow(>20us)=%llu\n",
               tag, cs.n, us(cs.med10), us(cs.med), us(cs.med90),
               us(cs.max), cs.n_slow);
    } else {
        printf("IPCDISC %s child  no-summary\n", tag);
    }
    fflush(stdout);
    free(t);
}

int main(void)
{
    setbuf(stdout, NULL);
    calibrate();
    printf("IPCDISC START tsc_hz=%llu\n", tsc_hz);

    /* unpinned controls (the p5c/p5c3 shapes) */
    run_case("read64-unpin", MODE_READ, 65536, 0, -1, -1);
    run_case("recv64-unpin", MODE_RECV, 65536, 0, -1, -1);
    run_case("read74-unpin", MODE_READ, REC, 0, -1, -1);
    run_case("recv74-unpin", MODE_RECV, REC, 0, -1, -1);

    /* pinned: parent CPU0, child CPU1 (cross-cpu wake) */
    run_case("read64-xcpu", MODE_READ, 65536, 0, 1, 0);
    run_case("recv64-xcpu", MODE_RECV, 65536, 0, 1, 0);

    /* pinned: parent and child SAME cpu */
    run_case("read64-samecpu", MODE_READ, 65536, 0, 0, 0);
    run_case("recv64-samecpu", MODE_RECV, 65536, 0, 0, 0);

    /* spin control (never sleeps) */
    run_case("recv64-spin", MODE_SPIN, 65536, 1, -1, -1);

    printf("IPCDISC DONE\n");
    return 0;
}
