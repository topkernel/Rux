// wx_probe.c — sec-r1 W^X A/B probe (execstack variant selected at
// BUILD time: default vs -z execstack -DWX_EXECSTACK).
//
// Checks, in order:
//   1. stack executability follows PT_GNU_STACK: the default build's
//      stack is NX (executing stack code raises SIGSEGV); the
//      execstack build's stack runs code (EXSTACK_ENABLE_X).
//   2. mprotect RW→RX upgrade (the JIT shape): code written into an
//      anonymous RW page runs after mprotect(PROT_READ|PROT_EXEC).
//   3. READ_IMPLIES_EXEC personality (0x0400000): with the bit set, a
//      PROT_READ FILE mapping becomes executable — the legacy-libc
//      shape the reference do_mmap honors. A file carrying real
//      instructions discriminates cleanly: SIGSEGV = NX still on,
//      return 42 = executable.
//
// Print contract: "SEC-R1-WX: PASS <name>" / FAIL lines; the host
// driver greps them.

#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <setjmp.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <unistd.h>

#define READ_IMPLIES_EXEC 0x0400000U

static int pass_count;
static int fail_count;

static void check(int ok, const char *name, const char *detail) {
    if (ok) {
        pass_count++;
        printf("SEC-R1-WX: PASS %s\n", name);
    } else {
        fail_count++;
        printf("SEC-R1-WX: FAIL %s (%s)\n", name, detail ? detail : "");
    }
    fflush(stdout);
}

static sigjmp_buf recover;
static volatile int got_signo;

static void fault_handler(int signo) {
    got_signo = signo;
    siglongjmp(recover, 1);
}

// riscv64: li a0,42 ; ret   |  x86_64: mov eax,42 ; ret
#if defined(__riscv)
static const unsigned char code_ret42[8] = {0x13, 0x05, 0xa0, 0x02,
                                            0x67, 0x80, 0x00, 0x00};
#elif defined(__x86_64)
static const unsigned char code_ret42[8] = {0xb8, 0x2a, 0x00, 0x00, 0x00,
                                            0xc3, 0x90, 0x90};
#else
#error "wx_probe: unsupported arch"
#endif

#ifdef WX_EXECSTACK
#define EXPECT_STACK_EXEC 1
#else
#define EXPECT_STACK_EXEC 0
#endif

// Call `f` under the fault recovery: on a fault returns -signal, on a
// clean call returns the callee's return value.
static int try_call(int (*f)(void)) {
    got_signo = 0;
    if (setjmp(recover) == 0) {
        return f();
    }
    return -got_signo;
}

int main(void) {
    printf("SEC-R1-WX: start (expect stack-exec=%d)\n", EXPECT_STACK_EXEC);
    fflush(stdout);

    struct sigaction sa;
    memset(&sa, 0, sizeof(sa));
    sa.sa_handler = fault_handler;
    sa.sa_flags = SA_NODEFER;
    sigaction(SIGSEGV, &sa, 0);
    sigaction(SIGBUS, &sa, 0);

    // ---- 1. stack executability ----
    {
        unsigned char buf[64];
        memcpy(buf, code_ret42, sizeof(code_ret42));
        __builtin___clear_cache((char *)buf, (char *)buf + sizeof(buf));
        int v = try_call((int (*)(void))buf);
        if (EXPECT_STACK_EXEC) {
            check(v == 42, "stack-exec-enabled-ran",
                  v < 0 ? "fault on exec stack" : "wrong return value");
        } else {
            check(v == -SIGSEGV, "stack-nx-faulted",
                  v == 42 ? "stack code ran; stack is executable"
                          : "unexpected outcome");
        }
    }

    // ---- 2. mprotect RW->RX (JIT shape) ----
    {
        unsigned char *pg = mmap(0, 4096, PROT_READ | PROT_WRITE,
                                 MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (pg == MAP_FAILED) {
            check(0, "mprotect-rx-jit", strerror(errno));
        } else {
            memcpy(pg, code_ret42, sizeof(code_ret42));
            mprotect(pg, 4096, PROT_READ | PROT_EXEC);
            __builtin___clear_cache((char *)pg, (char *)pg + sizeof(code_ret42));
            int v = try_call((int (*)(void))pg);
            check(v == 42, "mprotect-rx-jit",
                  v < 0 ? "fault after RX upgrade" : "wrong return value");
            munmap(pg, 4096);
        }
    }

    // ---- 3. READ_IMPLIES_EXEC personality on file mappings ----
    {
        // A file carrying the ret42 code.
        const char *path = "/tmp/wx_probe_code.bin";
        int ffd = open(path, O_CREAT | O_RDWR | O_TRUNC, 0644);
        if (ffd < 0) {
            path = "/wx_probe_code.bin";
            ffd = open(path, O_CREAT | O_RDWR | O_TRUNC, 0644);
        }
        if (ffd < 0) {
            check(0, "rie-read-map-exec", "cannot create code file");
        } else if (write(ffd, code_ret42, sizeof(code_ret42)) < 0) {
            check(0, "rie-read-map-exec", "write failed");
        } else {
            unsigned char *pg = mmap(0, 4096, PROT_READ, MAP_PRIVATE, ffd, 0);
            if (pg == MAP_FAILED) {
                check(0, "rie-read-map-exec", strerror(errno));
            } else {
                // Baseline: without RIE the PROT_READ mapping is NX.
                int v0 = try_call((int (*)(void))pg);
                check(v0 == -SIGSEGV, "rie-baseline-nx",
                      v0 == -SIGSEGV ? 0
                                     : "PROT_READ mapping executable without RIE");

                // Control: an EXPLICIT PROT_READ|PROT_EXEC file mapping
                // must run — separates a file-fault X bug from the RIE
                // injection.
                unsigned char *pgx = mmap(0, 4096, PROT_READ | PROT_EXEC,
                                          MAP_PRIVATE, ffd, 0);
                if (pgx == MAP_FAILED) {
                    check(0, "file-rx-fetch", strerror(errno));
                } else {
                    int vx = try_call((int (*)(void))pgx);
                    check(vx == 42, "file-rx-fetch",
                          vx < 0 ? "explicit RX file fetch blocked" : "wrong value");
                    munmap(pgx, 4096);
                }

                long old = syscall(SYS_personality, 0xffffffffU);
                long rc2 = syscall(SYS_personality,
                                   (unsigned long)(unsigned int)old |
                                       READ_IMPLIES_EXEC);
                check(rc2 == (long)old, "personality-set-RIE",
                      rc2 == old ? 0 : "readback mismatch");

                unsigned char *pg2 = mmap(0, 4096, PROT_READ, MAP_PRIVATE,
                                          ffd, 0);
                if (pg2 == MAP_FAILED) {
                    check(0, "rie-read-map-exec", strerror(errno));
                } else {
                    int v = try_call((int (*)(void))pg2);
                    check(v == 42, "rie-read-map-exec",
                          v < 0 ? "fetch blocked (NX still on)"
                                : "wrong return value");
                    munmap(pg2, 4096);
                }
                // Restore (affects later mmaps in this process only).
                syscall(SYS_personality, (unsigned long)(unsigned int)old);
                munmap(pg, 4096);
            }
            close(ffd);
            unlink(path);
        }
    }

    printf("SEC-R1-WX: done pass=%d fail=%d\n", pass_count, fail_count);
    fflush(stdout);
    return fail_count ? 1 : 0;
}
