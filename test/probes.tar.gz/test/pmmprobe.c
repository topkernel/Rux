/*
 * pmmprobe.c — mm-lane decomposition probe (perf-mm lane, 2026-10-31).
 *
 * Splits the pbench rows that lag the reference kernel on the same
 * TCG machine into their cost components:
 *
 *   MM1 cold file fault   write+fsync a fresh file, mmap, touch every
 *                         page (the p3c shape: page cache empty at
 *                         fault time — every window pays the populate)
 *   MM2 warm file fault   same file, pread()ed whole FIRST (page cache
 *                         warm), mmap, touch — isolates the pure mm
 *                         fault cost (pin + map + bookkeeping)
 *   MM3 rewarm file fault re-mmap the same warm file a second time
 *                         (frames cached, unpinned) — steady-state hit
 *   MM4 anon fault        64MB first-touch (p3a shape; the 1/16
 *                         fault-around tail vs the pre-mapped med)
 *   MM5 fork syscall      fork() return time in the parent with the
 *                         child parked in a 200ms sleep (fork+mm-copy
 *                         alone, no exit/reap interference)
 *   MM6 fork+exit+wait    the p4_fork_exit shape (round trip)
 *
 * Output: one parsable line per bench,
 *   PMMP <name> n=<N> med=<us> p99=<us> min=<us> max=<us> avg=<us> wall=<us>
 * plus PMMP DONE rc=0 at the end. Static musl x86_64, runs as init.
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <time.h>

typedef unsigned int u32;
typedef unsigned long long u64;
typedef long long s64;

static u64 tsc_hz;
static char *g_self;

static u64 rdtsc_(void)
{
    unsigned a, d;
    __asm__ volatile ("rdtsc" : "=a"(a), "=d"(d));
    return ((u64)d << 32) | a;
}

static s64 mnr_ns(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC_RAW, &ts);
    return (s64)ts.tv_sec * 1000000000LL + ts.tv_nsec;
}

static void calibrate(void)
{
    s64 t0 = mnr_ns();
    u64 c0 = rdtsc_();
    struct timespec req = { 0, 60 * 1000 * 1000 };
    nanosleep(&req, 0);
    s64 t1 = mnr_ns();
    u64 c1 = rdtsc_();
    tsc_hz = (u64)((double)(c1 - c0) / ((double)(t1 - t0) / 1e9));
    printf("PMMP CAL tsc_hz=%llu\n", tsc_hz);
}

struct pstats { u64 med, p99, min, max, avg; };

static void stats(u64 *t, size_t n, struct pstats *s)
{
    /* insertion sort: n <= 16384 and mostly pre-sorted */
    for (size_t i = 1; i < n; i++) {
        u64 k = t[i];
        size_t j = i;
        while (j > 0 && t[j-1] > k) { t[j] = t[j-1]; j--; }
        t[j] = k;
    }
    s->min = t[0];
    s->max = t[n-1];
    s->med = t[n/2];
    s->p99 = t[(n * 99) / 100];
    u64 sum = 0;
    for (size_t i = 0; i < n; i++) sum += t[i];
    s->avg = sum / n;
}

static void report(const char *name, u64 *t, size_t n, s64 wall_ns)
{
    struct pstats s;
    stats(t, n, &s);
    printf("PMMP %s n=%zu med=%.3f p99=%.3f min=%.3f max=%.3f avg=%.3f wall=%.3f\n",
           name, n,
           (double)s.med * 1e6 / (double)tsc_hz,
           (double)s.p99 * 1e6 / (double)tsc_hz,
           (double)s.min * 1e6 / (double)tsc_hz,
           (double)s.max * 1e6 / (double)tsc_hz,
           (double)s.avg * 1e6 / (double)tsc_hz,
           (double)wall_ns / 1000.0);
}

static void *xmalloc_samples(size_t n) { return malloc(n * sizeof(u64)); }

/* ---------- MM1/2/3: file fault shapes ---------- */
#define FILE_BYTES (16UL * 1024 * 1024)
#define FILE_PAGES (FILE_BYTES / 4096)

static int write_file(const char *path)
{
    int fd = open(path, O_CREAT | O_RDWR | O_TRUNC, 0644);
    if (fd < 0) return -1;
    static char blk[65536];
    u32 seed = 12345;
    for (size_t i = 0; i < sizeof(blk); i++) {
        seed = seed * 1103515245 + 12345;
        blk[i] = (char)(seed >> 16);
    }
    for (size_t off = 0; off < FILE_BYTES; off += sizeof(blk)) {
        if (write(fd, blk, sizeof(blk)) != (ssize_t)sizeof(blk)) { close(fd); return -1; }
    }
    if (fsync(fd) != 0) { close(fd); return -1; }
    return fd;
}

static void touch_all(const char *tag, const char *path, size_t passes)
{
    u64 *t = xmalloc_samples(FILE_PAGES);
    if (!t) return;
    for (size_t pass = 0; pass < passes; pass++) {
        int fd = open(path, O_RDONLY);
        if (fd < 0) { free(t); return; }
        char *p = mmap(0, FILE_BYTES, PROT_READ, MAP_PRIVATE, fd, 0);
        close(fd);
        if (p == MAP_FAILED) { free(t); return; }
        char name[32];
        snprintf(name, sizeof(name), "%s_p%zu", tag, pass);
        s64 w0 = mnr_ns();
        size_t n = 0;
        for (size_t i = 0; i < FILE_PAGES; i++) {
            u64 t0 = rdtsc_();
            char c = *(volatile char *)(p + i * 4096);
            u64 t1 = rdtsc_();
            t[n++] = t1 - t0;
            (void)c;
        }
        s64 w = mnr_ns() - w0;
        report(name, t, n, w);
        munmap(p, FILE_BYTES);
    }
    free(t);
}

static void pread_whole(const char *path)
{
    int fd = open(path, O_RDONLY);
    if (fd < 0) return;
    static char buf[65536];
    size_t got = 0;
    ssize_t r;
    while (got < FILE_BYTES && (r = pread(fd, buf, sizeof(buf), (off_t)got)) > 0)
        got += (size_t)r;
    close(fd);
}

/* ---------- MM4: anon fault ---------- */
#define ANON_PAGES 16384

static void anon_fault(void)
{
    size_t bytes = ANON_PAGES * 4096UL;
    char *p = mmap(0, bytes, PROT_READ | PROT_WRITE,
                   MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (p == MAP_FAILED) return;
    u64 *t = xmalloc_samples(ANON_PAGES);
    if (!t) { munmap(p, bytes); return; }
    s64 w0 = mnr_ns();
    size_t n = 0;
    for (size_t i = 0; i < ANON_PAGES; i++) {
        u64 t0 = rdtsc_();
        *(volatile char *)(p + i * 4096) = (char)i;
        u64 t1 = rdtsc_();
        t[n++] = t1 - t0;
    }
    s64 w = mnr_ns() - w0;
    report("mm4_anon_fault", t, n, w);
    free(t);
    munmap(p, bytes);
}

/* ---------- MM5/6: fork decomposition ---------- */
#define FORK_N 400

#ifndef CLONE_VM
#define CLONE_VM 0x100
#define CLONE_FS 0x200
#define CLONE_FILES 0x400
#endif

static long clone_(unsigned long flags, void *stack)
{
    return syscall(56, flags, stack, 0, 0, 0); /* SYS_clone on x86_64 */
}

static void fork_probe(void)
{
    u64 *t = xmalloc_samples(FORK_N);
    if (!t) return;

    /* MM5: fork-syscall cost — child parks 200ms, so the parent's
     * fork() return path carries fork+mm-copy only. Reap after. */
    struct pstats s;
    size_t n = 0;
    s64 w0 = mnr_ns();
    for (int i = 0; i < FORK_N; i++) {
        u64 t0 = rdtsc_();
        pid_t pid = fork();
        u64 t1 = rdtsc_();
        if (pid == 0) { struct timespec r = {0, 200*1000*1000}; nanosleep(&r, 0); _exit(0); }
        if (pid < 0) break;
        t[n++] = t1 - t0;
    }
    s64 w = mnr_ns() - w0;
    stats(t, n, &s);
    printf("PMMP mm5_fork_syscall n=%zu med=%.3f p99=%.3f min=%.3f max=%.3f avg=%.3f wall=%.3f note=child_parks_200ms\n",
           n,
           (double)s.med*1e6/(double)tsc_hz, (double)s.p99*1e6/(double)tsc_hz,
           (double)s.min*1e6/(double)tsc_hz, (double)s.max*1e6/(double)tsc_hz,
           (double)s.avg*1e6/(double)tsc_hz, (double)w/1000.0);
    for (int i = 0; i < (int)n; i++) { int st; wait(&st); }
    free(t);

    /* MM6: full round trip (p4 shape) */
    t = xmalloc_samples(FORK_N);
    if (!t) return;
    for (int i = 0; i < 20; i++) {
        pid_t pid = fork();
        if (pid == 0) _exit(0);
        if (pid > 0) waitpid(pid, 0, 0);
    }
    n = 0;
    w0 = mnr_ns();
    for (int i = 0; i < FORK_N; i++) {
        u64 t0 = rdtsc_();
        pid_t pid = fork();
        if (pid == 0) _exit(0);
        if (pid < 0) break;
        waitpid(pid, 0, 0);
        u64 t1 = rdtsc_();
        t[n++] = t1 - t0;
    }
    w = mnr_ns() - w0;
    report("mm6_fork_exit_wait", t, n, w);
    free(t);

    /* MM7: vfork round trip — CLONE_VM|CLONE_VFORK: the child shares
     * the mm (no COW copy, no MmStruct teardown at exit) and the parent
     * is parked until the child's _exit, so the measurement isolates
     * the task setup + exit-notify-reap machinery. mm6 - mm7 isolates
     * the mm-copy + mm-teardown share of the round trip. (The raw
     * CLONE_VM same-stack variant races on the shared frame slot and
     * corrupts the probe — vfork is the well-defined shape.) */
    t = xmalloc_samples(FORK_N);
    if (!t) return;
    for (int i = 0; i < 20; i++) {
        pid_t pid = vfork();
        if (pid == 0) _exit(0);
        if (pid > 0) waitpid(pid, 0, 0);
    }
    n = 0;
    w0 = mnr_ns();
    for (int i = 0; i < FORK_N; i++) {
        u64 t0 = rdtsc_();
        pid_t pid = vfork();
        if (pid == 0) _exit(0);
        if (pid < 0) break;
        waitpid(pid, 0, 0);
        u64 t1 = rdtsc_();
        t[n++] = t1 - t0;
    }
    w = mnr_ns() - w0;
    report("mm7_vfork_exit_wait", t, n, w);
    free(t);

    /* MM8: fork+exec round trip (p4_fork_exec shape): child execve's
     * this binary with -x (immediate clean exit). mm8 - mm6 isolates
     * execve's cost on a small mm. */
    t = xmalloc_samples(FORK_N);
    if (!t) return;
    char *av_x[3]; av_x[0] = g_self; av_x[1] = (char *)"-x"; av_x[2] = 0;
    char *ev[1]; ev[0] = 0;
    for (int i = 0; i < 20; i++) {
        pid_t pid = fork();
        if (pid == 0) { execve(g_self, av_x, ev); _exit(111); }
        if (pid > 0) waitpid(pid, 0, 0);
    }
    n = 0;
    w0 = mnr_ns();
    for (int i = 0; i < FORK_N; i++) {
        u64 t0 = rdtsc_();
        pid_t pid = fork();
        if (pid == 0) { execve(g_self, av_x, ev); _exit(111); }
        if (pid < 0) break;
        int st;
        waitpid(pid, &st, 0);
        u64 t1 = rdtsc_();
        if (!(WIFEXITED(st) && WEXITSTATUS(st) == 0)) break;
        t[n++] = t1 - t0;
    }
    w = mnr_ns() - w0;
    report("mm8_fork_exec_wait", t, n, w);
    free(t);
}

int main(int argc, char **argv)
{
    g_self = argv[0];
    if (argc > 1 && !strcmp(argv[1], "-x")) return 0; /* exec target shape (unused) */
    setvbuf(stdout, NULL, _IOLBF, 0);
    printf("PMMP START self=%s\n", argv[0]);
    calibrate();

    /* warm the anon fault machinery once (page tables, allocator) */
    anon_fault();

    const char *path = "/test/pmmfile.bin";

    /* MM1: cold-cache file faults (fresh file; page cache empty) */
    int fd = write_file(path);
    if (fd < 0) { printf("PMMP mm1 SKIP write\n"); } else { close(fd); }
    touch_all("mm1_cold_file_fault", path, 1);

    /* MM2: warm cache (pread whole file), re-mmap fresh */
    pread_whole(path);
    touch_all("mm2_warm_file_fault", path, 2);

    /* MM3 = the second warm pass inside touch_all above (mm2_p1). */

    /* MM4 second pass on a FRESH map (allocator steady state) */
    anon_fault();

    fork_probe();

    unlink(path);
    printf("PMMP DONE rc=0\n");
    return 0;
}
