/* forkbench.c — p4 attribution probe: where do fork+exit's 472 us go?
 *
 * Three loops, one PBENCH line each (same stats format as pbench.c so
 * pbmed.py parses them):
 *   fb_mm    : fork() + child _exit() + parent wait   (full mm copy + teardown)
 *   fb_thr   : clone(CLONE_VM|...) + child _exit() + wait  (no mm copy —
 *              the delta fb_mm - fb_thr is the mm copy/teardown cost)
 *   fb_forkonly : fork + child _exit WITHOUT wait reaping cost isolation
 *   (wait is inside both loops; the delta isolates the mm work, not wait)
 *
 * tsc-calibrated like pbench.c (PBENCH CAL line). Build:
 *   toolchain/x86_64-rux-linux-musl/bin/musl-gcc -static -O2 -o forkbench forkbench.c
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <stdint.h>
#include <sched.h>
#include <sys/syscall.h>
#include <sys/wait.h>
#include <time.h>

typedef uint64_t u64;
typedef int64_t s64;

static u64 rdtsc(void)
{
    unsigned lo, hi;
    __asm__ __volatile__("rdtsc" : "=a"(lo), "=d"(hi));
    return ((u64)hi << 32) | lo;
}

static u64 g_tsc_hz = 0;

static void calibrate(void)
{
    struct timespec ts0, ts1;
    u64 t0, t1;
    clock_gettime(CLOCK_MONOTONIC, &ts0);
    t0 = rdtsc();
    usleep(200000);
    t1 = rdtsc();
    clock_gettime(CLOCK_MONOTONIC, &ts1);
    s64 ns = (s64)(ts1.tv_sec - ts0.tv_sec) * 1000000000LL
           + (ts1.tv_nsec - ts0.tv_nsec);
    if (ns > 0)
        g_tsc_hz = (u64)((double)(t1 - t0) * 1e9 / (double)ns);
    printf("PBENCH CAL tsc_hz=%llu\n", (unsigned long long)g_tsc_hz);
}

static int cmp_u64(const void *a, const void *b)
{
    u64 x = *(const u64 *)a, y = *(const u64 *)b;
    return x < y ? -1 : (x > y ? 1 : 0);
}

static void report(const char *name, u64 *t, int n, s64 wall_ns, const char *extra)
{
    qsort(t, n, sizeof(u64), cmp_u64);
    double k = g_tsc_hz > 0 ? 1e9 / (double)g_tsc_hz : -1.0;
    double med = t[n / 2] * k, p99 = t[(n * 99) / 100 >= n ? n - 1 : (n * 99) / 100] * k;
    double mn = t[0] * k, mx = t[n - 1] * k;
    u64 acc = 0;
    for (int i = 0; i < n; i++) acc += t[i];
    double av = (double)acc * k / n;
    double wl = (double)wall_ns / n;
    printf("PBENCH %s n=%d med=%.3f p99=%.3f min=%.3f max=%.3f avg=%.3f wall=%.3f%s%s\n",
           name, n, med, p99, mn, mx, av, wl,
           extra && *extra ? " " : "", extra ? extra : "");
    fflush(stdout);
}

#define N 2000

static int child_thunk_thr(void *arg)
{
    (void)arg;
    _exit(0);
    return 0;
}

static u64 loop_fork_exit(int pin_cpu, const char *name, const char *extra)
{
    static u64 t[N];
    struct timespec ts0, ts1;
    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(pin_cpu, &set);
    sched_setaffinity(0, sizeof(set), &set);

    clock_gettime(CLOCK_MONOTONIC, &ts0);
    for (int i = 0; i < N; i++) {
        u64 t0 = rdtsc();
        pid_t p = fork();
        if (p == 0)
            _exit(0);
        int st;
        waitpid(p, &st, 0);
        t[i] = rdtsc() - t0;
    }
    clock_gettime(CLOCK_MONOTONIC, &ts1);
    s64 wall = (s64)(ts1.tv_sec - ts0.tv_sec) * 1000000000LL
             + (ts1.tv_nsec - ts0.tv_nsec);
    report(name, t, N, wall, extra);
    return wall;
}

static u64 loop_thread_exit(int pin_cpu, const char *name, const char *extra)
{
    static u64 t[N];
    struct timespec ts0, ts1;
    char stack[65536] __attribute__((aligned(16)));
    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(pin_cpu, &set);
    sched_setaffinity(0, sizeof(set), &set);

    clock_gettime(CLOCK_MONOTONIC, &ts0);
    for (int i = 0; i < N; i++) {
        u64 t0 = rdtsc();
        /* CLONE_VM | CLONE_FS | CLONE_FILES | CLONE_SIGHAND | CLONE_SYSVSEM
         * — the pthread_create shape: NO mm copy, NO page-table work. */
        pid_t p = syscall(SYS_clone,
                          (unsigned long)(0x00000100 | 0x00000200 | 0x00000800
                                          | 0x00010000 | 0x00040000UL),
                          stack + sizeof(stack) - 8, NULL, NULL, NULL);
        if (p == 0)
            _exit(0);
        int st;
        waitpid(p, &st, __WCLONE);
        t[i] = rdtsc() - t0;
    }
    clock_gettime(CLOCK_MONOTONIC, &ts1);
    s64 wall = (s64)(ts1.tv_sec - ts0.tv_sec) * 1000000000LL
             + (ts1.tv_nsec - ts0.tv_nsec);
    report(name, t, N, wall, extra);
    return wall;
}

int main(void)
{
    calibrate();
    printf("PBENCH START self=/test/forkbench\n");
    fflush(stdout);

    /* warm the allocator/fork paths, discard */
    for (int i = 0; i < 50; i++) {
        pid_t p = fork();
        if (p == 0) _exit(0);
        int st; waitpid(p, &st, 0);
    }

    /* Interleave the two loops so host drift hits both equally. */
    u64 w1a = loop_fork_exit(0, "fb_mm_a", "pin=0");
    u64 w1b = loop_thread_exit(0, "fb_thr_a", "pin=0");
    u64 w2a = loop_fork_exit(0, "fb_mm_b", "pin=0");
    u64 w2b = loop_thread_exit(0, "fb_thr_b", "pin=0");
    (void)w1a; (void)w1b; (void)w2a; (void)w2b;

    printf("PBENCH DONE rc=0\n");
    fflush(stdout);
    sync();
    syscall(SYS_reboot, 0x4321fedc, 0, 0xa9f10001ULL /* POWER_OFF */);
    return 0;
}
