// delalloc_check.c — functional correctness probe for the ext4
// buffered-write (delayed allocation) path. Boots as init via
// pbench_boot.py --probe-bin. Every case writes through write(2)/
// pwrite(2)/mmap and verifies the bytes read back through INDEPENDENT
// opens (and after fsync/msync/truncate where the semantics demand).
//
// Print protocol: "PBENCH DLC <case> PASS/FAIL ..." lines, final
// "PBENCH DONE rc=0|1" (PBENCH prefix so pbench_boot.py relays the
// lines and its DONE watcher stops the boot).

#define _GNU_SOURCE
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

static int fails;

static void fill(unsigned char *p, unsigned seed, size_t n)
{
    for (size_t i = 0; i < n; i++)
        p[i] = (unsigned char)(seed + (i >> 12));
}

static int check(const char *name, int ok, const char *detail)
{
    // PBENCH prefix: pbench_boot.py's --probe-bin path only relays
    // PBENCH-prefixed serial lines and only stops at "PBENCH DONE rc=0".
    printf("PBENCH DLC %s %s %s\n", name, ok ? "PASS" : "FAIL",
           detail ? detail : "");
    if (!ok)
        fails++;
    return ok;
}

#define W "/test/dl.dat"

// T1: N x 4K appends, close, reopen, read back.
static void t1_append_reopen(void)
{
    unlink(W);
    int fd = open(W, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) { check("t1_append_reopen", 0, "open"); return; }
    unsigned char buf[4096];
    const int N = 64;
    for (int i = 0; i < N; i++) {
        fill(buf, i, sizeof buf);
        ssize_t r = write(fd, buf, sizeof buf);
        if (r != sizeof buf) { check("t1_append_reopen", 0, "write"); close(fd); return; }
    }
    close(fd);  // NO fsync: bytes live in dirty frames only

    fd = open(W, O_RDONLY);
    if (fd < 0) { check("t1_append_reopen", 0, "reopen"); return; }
    unsigned char rb[4096];
    int ok = 1;
    for (int i = 0; i < N && ok; i++) {
        ssize_t r = read(fd, rb, sizeof rb);
        if (r != sizeof rb) { ok = 0; break; }
        fill(buf, i, sizeof buf);
        if (memcmp(rb, buf, sizeof rb)) { ok = 0; break; }
    }
    struct stat st;
    if (fstat(fd, &st) == 0 && st.st_size != (off_t)N * 4096)
        ok = 0;
    close(fd);
    check("t1_append_reopen", ok, "64x4K append, close, reopen, verify");
}

// T2: appends + fsync, then verify through a fresh open after the
// fsync forced writeback of the dirty frames.
static void t2_fsync(void)
{
    unlink(W);
    int fd = open(W, O_RDWR | O_CREAT | O_TRUNC, 0644);
    unsigned char buf[4096], rb[4096];
    int ok = 1;
    for (int i = 0; i < 16; i++) {
        fill(buf, 0x40 + i, sizeof buf);
        if (write(fd, buf, sizeof buf) != sizeof buf) { ok = 0; break; }
    }
    if (fsync(fd) != 0) ok = 0;
    // Overwrite mid-file after the fsync, fsync again (write-through of
    // a range the flush already wrote).
    fill(buf, 0xAA, sizeof buf);
    if (pwrite(fd, buf, sizeof buf, 3 * 4096) != sizeof buf) ok = 0;
    if (fsync(fd) != 0) ok = 0;
    close(fd);
    int v = open(W, O_RDONLY);
    for (int i = 0; i < 16 && ok; i++) {
        if (read(v, rb, sizeof rb) != sizeof rb) { ok = 0; break; }
        if (i == 3) fill(buf, 0xAA, sizeof buf); else fill(buf, 0x40 + i, sizeof buf);
        if (memcmp(rb, buf, sizeof rb)) { ok = 0; break; }
    }
    close(v);
    check("t2_fsync", ok, "16x4K + fsync + mid-file overwrite + verify");
}

// T3: sparse pwrite (hole below), read zeros in the hole.
static void t3_sparse(void)
{
    unlink(W);
    int fd = open(W, O_RDWR | O_CREAT | O_TRUNC, 0644);
    unsigned char buf[4096];
    fill(buf, 0x77, sizeof buf);
    if (pwrite(fd, buf, sizeof buf, 100 * 4096) != sizeof buf) {
        check("t3_sparse", 0, "pwrite"); close(fd); return;
    }
    fsync(fd);
    unsigned char rb[4096];
    int ok = 1;
    if (pread(fd, rb, sizeof rb, 0) != sizeof rb) ok = 0;
    else for (size_t i = 0; i < sizeof rb; i++) if (rb[i]) { ok = 0; break; }
    if (pread(fd, rb, sizeof rb, 100 * 4096) != sizeof rb) ok = 0;
    else {
        fill(buf, 0x77, sizeof buf);
        if (memcmp(rb, buf, sizeof rb)) ok = 0;
    }
    struct stat st;
    if (fstat(fd, &st) == 0 && st.st_size != 101 * 4096) ok = 0;
    close(fd);
    check("t3_sparse", ok, "pwrite@400K, hole reads zero, size");
}

// T4: odd-offset multi-page write (unaligned head+tail).
static void t4_unaligned(void)
{
    unlink(W);
    int fd = open(W, O_RDWR | O_CREAT | O_TRUNC, 0644);
    unsigned char buf[4096 * 3 + 1234];
    fill(buf, 0x1B, sizeof buf);
    int ok = write(fd, buf, sizeof buf) == (ssize_t)sizeof buf;
    // second write starts mid-page, straddling into a new page
    unsigned char buf2[8192 + 777];
    fill(buf2, 0x2C, sizeof buf2);
    if (pwrite(fd, buf2, sizeof buf2, 1000) != (ssize_t)sizeof buf2) ok = 0;
    fsync(fd);
    unsigned char *rb = malloc(sizeof buf2);
    if (pread(fd, rb, sizeof buf2, 1000) != (ssize_t)sizeof buf2) {
        ok = 0;
        printf("PBENCH DLC t4_unaligned straddle-read-short\n");
    } else if (memcmp(rb, buf2, sizeof buf2)) {
        size_t d = 0;
        while (d < sizeof buf2 && rb[d] == buf2[d]) d++;
        ok = 0;
        printf("PBENCH DLC t4_unaligned straddle-mismatch at +%zd\n", d);
    }
    free(rb);
    // Untouched heads/tails around the straddled span still hold write 1
    // (fill adds page index: expected byte at offset o is 0x1B + o/4096).
    unsigned char hb[1024];
    if (pread(fd, hb, 1000, 0) != 1000) {
        ok = 0;
        printf("PBENCH DLC t4_unaligned head-read-short\n");
    } else for (int i = 0; i < 1000; i++)
        if (hb[i] != (unsigned char)(0x1B + i / 4096)) {
            ok = 0;
            printf("PBENCH DLC t4_unaligned head-mismatch at %d\n", i);
            break;
        }
    off_t tail = 1000 + (off_t)sizeof buf2;   // 9969
    ssize_t twant = (13522 - tail > 1024) ? 1024 : (ssize_t)(13522 - tail);
    if (pread(fd, hb, twant, tail) != twant) {
        ok = 0;
        printf("PBENCH DLC t4_unaligned tail-read-short\n");
    } else for (off_t o = tail; o < tail + twant; o++)
        if (hb[o - tail] != (unsigned char)(0x1B + o / 4096)) {
            ok = 0;
            printf("PBENCH DLC t4_unaligned tail-mismatch at %lld\n",
                   (long long)o);
            break;
        }
    struct stat st;
    // The first write already set 13522; the pwrite stays inside it.
    if (fstat(fd, &st) != 0 || st.st_size != (off_t)sizeof buf) {
        printf("PBENCH DLC t4_unaligned size=%lld want=13522\n",
               (long long)(fstat(fd, &st) == 0 ? st.st_size : -1));
        ok = 0;
    }
    close(fd);
    check("t4_unaligned", ok, "odd-offset straddling writes");
}

// T5: truncate down past buffered data.
static void t5_truncate(void)
{
    unlink(W);
    int fd = open(W, O_RDWR | O_CREAT | O_TRUNC, 0644);
    unsigned char buf[4096];
    for (int i = 0; i < 8; i++) {
        fill(buf, i, sizeof buf);
        if (write(fd, buf, sizeof buf) != sizeof buf) { close(fd); check("t5_truncate", 0, "write"); return; }
    }
    if (ftruncate(fd, 3 * 4096 + 100) != 0) { close(fd); check("t5_truncate", 0, "ftruncate"); return; }
    fsync(fd);
    struct stat st;
    int ok = fstat(fd, &st) == 0 && st.st_size == 3 * 4096 + 100;
    if (!ok)
        printf("PBENCH DLC t5_truncate size=%lld want=12388\n",
               (long long)(fstat(fd, &st) == 0 ? st.st_size : -1));
    char t[8];
    ssize_t r = pread(fd, t, 8, 3 * 4096 + 100);   // at EOF: 0
    if (r != 0) { ok = 0; printf("PBENCH DLC t5_truncate eof-read=%zd want=0\n", r); }
    unsigned char rb[4096];
    for (int i = 0; i < 3 && ok; i++) {
        if (pread(fd, rb, sizeof rb, i * 4096) != sizeof rb) { ok = 0; break; }
        fill(buf, i, sizeof rb);
        if (memcmp(rb, buf, sizeof rb)) {
            ok = 0;
            printf("PBENCH DLC t5_truncate page=%d mismatch\n", i);
            break;
        }
    }
    if (pread(fd, rb, 100, 3 * 4096) != 100) {
        ok = 0;
        printf("PBENCH DLC t5_truncate partial-tail short\n");
    }
    close(fd);
    int v = open(W, O_RDONLY);
    if (v >= 0) {
        r = pread(v, t, 8, 3 * 4096 + 100);   // fresh open: EOF at the cut
        if (r != 0) {
            ok = 0;
            printf("PBENCH DLC t5_truncate reopen-eof-read=%zd want=0\n", r);
        }
        close(v);
    } else ok = 0;
    check("t5_truncate", ok, "write 32K, cut to 12388, tail gone");
}

// T6: MAP_SHARED store + msync + read back through read(2).
static void t6_mmap_msync(void)
{
    unlink(W);
    int fd = open(W, O_RDWR | O_CREAT | O_TRUNC, 0644);
    unsigned char z[4096] = {0};
    if (write(fd, z, sizeof z) != sizeof z) { close(fd); check("t6_mmap_msync", 0, "setup"); return; }
    void *p = mmap(NULL, 4096, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (p == MAP_FAILED) { close(fd); check("t6_mmap_msync", 0, "mmap"); return; }
    memset(p, 0x5A, 4096);
    msync(p, 4096, MS_SYNC);
    munmap(p, 4096);
    unsigned char rb[4096];
    int ok = pread(fd, rb, sizeof rb, 0) == sizeof rb;
    if (ok) for (size_t i = 0; i < sizeof rb; i++) if (rb[i] != 0x5A) { ok = 0; break; }
    close(fd);
    check("t6_mmap_msync", ok, "MAP_SHARED store + MS_SYNC flush");
}

// T7: two processes appending through separate fds — disjoint pages,
// no lost/duplicated extents (the CAS reservation).
static void t7_two_writers(void)
{
    unlink(W);
    int fd = open(W, O_WRONLY | O_CREAT | O_TRUNC | O_APPEND, 0644);
    if (fd < 0) { check("t7_two_writers", 0, "open"); return; }
    pid_t pid = fork();
    unsigned char buf[4096];
    unsigned seed = pid == 0 ? 0x99 : 0x66;
    for (int i = 0; i < 32; i++) {
        fill(buf, seed + i, sizeof buf);
        if (write(fd, buf, sizeof buf) != sizeof buf) _exit(2);
    }
    if (pid == 0) _exit(0);
    int st;
    wait(&st);
    close(fd);
    int v = open(W, O_RDONLY);
    struct stat sb;
    int ok = v >= 0 && fstat(v, &sb) == 0 && sb.st_size == 64 * 4096;
    unsigned char rb[4096];
    // Every page is uniform (fill: byte = seed + page_index within the
    // writer). Parent family = 0x66..0x85, child family = 0x99..0xB8 —
    // count occurrences of each value; both families must appear
    // exactly once per member. (The old check compared the first byte
    // against 0x99/0x66 only — 2 pages total, always FAIL.)
    int fam_p[256] = {0}, fam_c[256] = {0}, nbad = 0;
    for (int i = 0; i < 64 && ok; i++) {
        if (read(v, rb, sizeof rb) != sizeof rb) { ok = 0; break; }
        unsigned char first = rb[0];
        int consistent = 1;
        for (size_t j = 0; j < sizeof rb; j++) if (rb[j] != first) { consistent = 0; break; }
        if (!consistent) { nbad++; continue; }
        if (first >= 0x66 && first <= 0x85) fam_p[first]++;
        else if (first >= 0x99 && first <= 0xB8) fam_c[first]++;
        else nbad++;
    }
    for (int b = 0x66; b <= 0x85; b++)
        if (fam_p[b] != 1) { ok = 0; }
    for (int b = 0x99; b <= 0xB8; b++)
        if (fam_c[b] != 1) { ok = 0; }
    if (nbad || !ok) {
        int tp = 0, tc = 0;
        for (int b = 0x66; b <= 0x85; b++) tp += fam_p[b];
        for (int b = 0x99; b <= 0xB8; b++) tc += fam_c[b];
        printf("PBENCH DLC t7_two_writers parent_pages=%d child_pages=%d torn=%d\n",
               tp, tc, nbad);
    }
    close(v);
    check("t7_two_writers", ok, "2 procs x 32 appends, 64 whole pages");
}

// T8: O_SYNC write must be visible through a separate open at return.
static void t8_osync(void)
{
    unlink(W);
    int fd = open(W, O_WRONLY | O_CREAT | O_TRUNC | O_SYNC, 0644);
    unsigned char buf[4096];
    fill(buf, 0xE1, sizeof buf);
    int ok = write(fd, buf, sizeof buf) == sizeof buf;
    close(fd);
    int v = open(W, O_RDONLY);
    unsigned char rb[4096];
    if (v >= 0 && read(v, rb, sizeof rb) == sizeof rb) {
        if (memcmp(rb, buf, sizeof rb)) ok = 0;
    } else ok = 0;
    if (v >= 0) close(v);
    check("t8_osync", ok, "O_SYNC write visible to fresh open");
}

// T9: buffered write, unlink, read through the still-open fd.
static void t9_unlink_open(void)
{
    unlink(W);
    int fd = open(W, O_RDWR | O_CREAT | O_TRUNC, 0644);
    unsigned char buf[4096];
    fill(buf, 0x3D, sizeof buf);
    int ok = write(fd, buf, sizeof buf) == sizeof buf;
    if (unlink(W) != 0) ok = 0;
    unsigned char rb[4096];
    lseek(fd, 0, SEEK_SET);
    if (read(fd, rb, sizeof rb) != sizeof rb) ok = 0;
    else if (memcmp(rb, buf, sizeof rb)) ok = 0;
    close(fd);
    if (open(W, O_RDONLY) >= 0) ok = 0;   // must be gone
    check("t9_unlink_open", ok, "write, unlink, read via open fd");
}

// T10: many files to churn the icache/page cache, then re-read an
// early buffered-written file (revival-guard path when its inode was
// evicted between write and read).
static void t10_churn_reread(void)
{
    unlink(W);
    int fd = open(W, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    unsigned char buf[4096];
    fill(buf, 0x50, sizeof buf);
    for (int i = 0; i < 10; i++)
        if (write(fd, buf, sizeof buf) != sizeof buf) { close(fd); check("t10_churn_reread", 0, "write"); return; }
    close(fd);

    char p[64];
    for (int i = 0; i < 400; i++) {
        snprintf(p, sizeof p, "/test/churn/%d.dat", i);
        int c = open(p, O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (c < 0) continue;
        unsigned char cb[512];
        fill(cb, i & 0xff, sizeof cb);
        for (int j = 0; j < 8; j++) write(c, cb, sizeof cb);
        close(c);
    }

    int v = open(W, O_RDONLY);
    struct stat st;
    int ok = v >= 0 && fstat(v, &st) == 0 && st.st_size == 10 * 4096;
    unsigned char rb[4096];
    for (int i = 0; i < 10 && ok; i++) {
        if (read(v, rb, sizeof rb) != sizeof rb) { ok = 0; break; }
        if (memcmp(rb, buf, sizeof rb)) { ok = 0; break; }
    }
    if (v >= 0) close(v);
    for (int i = 0; i < 400; i++) {
        snprintf(p, sizeof p, "/test/churn/%d.dat", i);
        unlink(p);
    }
    check("t10_churn_reread", ok, "write, 400-file churn, reread");
}

// T11: stat size immediately after a buffered append (the published
// cached view — data-before-size).
static void t11_stat_size(void)
{
    unlink(W);
    int fd = open(W, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    unsigned char buf[1234];
    fill(buf, 0x0F, sizeof buf);
    int ok = write(fd, buf, sizeof buf) == sizeof buf;
    struct stat st;
    if (fstat(fd, &st) == 0 && st.st_size != 1234) ok = 0;
    close(fd);
    check("t11_stat_size", ok, "fstat size right after buffered write");
}

int main(void)
{
    mkdir("/test", 0755);
    mkdir("/test/churn", 0755);
    printf("PBENCH DLC start (delalloc semantics battery)\n");
    t1_append_reopen();
    t2_fsync();
    t3_sparse();
    t4_unaligned();
    t5_truncate();
    t6_mmap_msync();
    t7_two_writers();
    t8_osync();
    t9_unlink_open();
    t10_churn_reread();
    t11_stat_size();
    printf("PBENCH DONE rc=%d\n", fails ? 1 : 0);
    return fails ? 1 : 0;
}
