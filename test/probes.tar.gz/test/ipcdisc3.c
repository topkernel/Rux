/* ipcdisc3.c — which preceding test poisons the p5c fast regime?
 *
 * Runs the p5c shape (unix stream socketpair, write(2) parent, read(2)
 * 64K draining child, unpinned) on a fresh boot, then again after each
 * precursor from the pbench battery prefix (p5a pipe-echo replica,
 * p5b dgram peek+consume replica). When a rerun turns slow, dumps the
 * sched trace of a short window to show which CPU the child runs on.
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>
#include <time.h>
#include <unistd.h>
#include <fcntl.h>
#include <sched.h>
#include <signal.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/wait.h>

typedef unsigned long long u64;
#define REC 74
#define NT 20000

static u64 tsc_hz;
static inline u64 rdtsc_(void)
{
    unsigned lo, hi;
    __asm__ volatile("rdtsc" : "=a"(lo), "=d"(hi));
    return ((u64)hi << 32) | lo;
}
static double us(u64 t) { return (double)t / tsc_hz * 1e6; }

static void calibrate(void)
{
    struct timespec ts0, ts1;
    clock_gettime(CLOCK_MONOTONIC, &ts0);
    u64 t0 = rdtsc_();
    struct timespec req = { 0, 200 * 1000 * 1000 };
    nanosleep(&req, 0);
    clock_gettime(CLOCK_MONOTONIC, &ts1);
    u64 ns = (ts1.tv_sec - ts0.tv_sec) * 1000000000ull
            + (ts1.tv_nsec - ts0.tv_nsec);
    tsc_hz = (rdtsc_() - t0) * 1000000000ull / ns;
}

static int cmp_u64(const void *a, const void *b)
{
    u64 x = *(const u64 *)a, y = *(const u64 *)b;
    return x < y ? -1 : x > y ? 1 : 0;
}

static void wr(const char *path, const char *val)
{
    int fd = open(path, O_WRONLY);
    if (fd < 0) return;
    write(fd, val, strlen(val));
    close(fd);
}

static void dump_trace(int maxlines)
{
    int fd = open("/sys/kernel/debug/tracing/trace", O_RDONLY);
    if (fd < 0) return;
    char buf[2048];
    ssize_t r;
    int lines = 0;
    while (lines < maxlines && (r = read(fd, buf, sizeof(buf))) > 0) {
        ssize_t off = 0;
        while (off < r) {
            char *nl = memchr(buf + off, '\n', r - off);
            ssize_t len = nl ? (nl - (buf + off) + 1) : (r - off);
            ssize_t w = write(1, buf + off, len);
            if (w <= 0) { close(fd); return; }
            off += len;
            lines++;
            if (lines >= maxlines) break;
        }
    }
    close(fd);
}

/* the p5c shape: write(2) parent, read(2) 64K child, unpinned */
static void p5c_shape(const char *tag, int use_write)
{
    int sv[2];
    if (socketpair(AF_UNIX, SOCK_STREAM, 0, sv) < 0) return;
    pid_t pid = fork();
    if (pid < 0) return;
    if (pid == 0) {
        close(sv[0]);
        char buf[65536];
        while (read(sv[1], buf, sizeof(buf)) > 0) ;
        _exit(0);
    }
    close(sv[1]);
    char rec[REC];
    memset(rec, 0xa3, sizeof(rec));
    for (int i = 0; i < 2000; i++)
        if (write(sv[0], rec, REC) != REC) break;
    u64 *t = malloc(NT * sizeof(u64));
    u64 n = 0;
    for (int i = 0; i < (int)NT; i++) {
        u64 t0 = rdtsc_();
        ssize_t r = use_write ? write(sv[0], rec, REC)
                              : sendto(sv[0], rec, REC, 0, 0, 0);
        u64 t1_ = rdtsc_();
        if (r != REC) break;
        t[n++] = t1_ - t0;
    }
    close(sv[0]);
    int st; waitpid(pid, &st, 0);
    if (n) {
        qsort(t, n, sizeof(u64), cmp_u64);
        u64 nbig = 0;
        for (u64 i = 0; i < n; i++) if (us(t[i]) > 100.0) nbig++;
        printf("IPCDISC3 %s n=%llu p10=%.2f med=%.2f p90=%.2f frac>100=%.3f\n",
               tag, n, us(t[n / 10]), us(t[n / 2]), us(t[n * 9 / 10]),
               (double)nbig / n);
        fflush(stdout);
    }
    free(t);
}

/* p5a replica: 1-byte pipe ping-pong with an echo child */
static void p5a_replica(int iters)
{
    int pfd[2];
    if (pipe(pfd) < 0) return;
    pid_t pid = fork();
    if (pid < 0) return;
    if (pid == 0) {
        char c;
        for (;;) {
            if (read(pfd[0], &c, 1) != 1) break;
            if (write(pfd[1], &c, 1) != 1) break;
        }
        _exit(0);
    }
    char c = 7;
    for (int i = 0; i < iters; i++) {
        if (write(pfd[1], &c, 1) != 1) break;
        if (read(pfd[0], &c, 1) != 1) break;
    }
    close(pfd[0]); close(pfd[1]);
    kill(pid, SIGKILL);
    int st; waitpid(pid, &st, 0);
}

/* p5b replica: dgram socketpair, child peek+consume, ctl summary pipe */
static void p5b_replica(int iters)
{
    int sv[2], ctl[2];
    if (socketpair(AF_UNIX, SOCK_DGRAM, 0, sv) < 0) return;
    if (pipe(ctl) < 0) return;
    pid_t pid = fork();
    if (pid < 0) return;
    if (pid == 0) {
        close(sv[0]); close(ctl[0]);
        char buf[512];
        for (;;) {
            ssize_t r = recvfrom(sv[1], buf, sizeof(buf), MSG_PEEK, 0, 0);
            if (r < 0) break;
            if (r == 1 && buf[0] == 'E') { recvfrom(sv[1], buf, sizeof(buf), 0, 0, 0); break; }
            ssize_t r2 = recvfrom(sv[1], buf, sizeof(buf), 0, 0, 0);
            if (r2 < 0) break;
        }
        _exit(0);
    }
    close(sv[1]); close(ctl[1]);
    char rec[REC];
    memset(rec, 0x5a, sizeof(rec));
    for (int i = 0; i < 1000; i++) sendto(sv[0], rec, REC, 0, 0, 0);
    for (int i = 0; i < iters; i++)
        if (sendto(sv[0], rec, REC, 0, 0, 0) != REC) break;
    char end = 'E';
    sendto(sv[0], &end, 1, 0, 0, 0);
    close(sv[0]);
    int st; waitpid(pid, &st, 0);
}

int main(void)
{
    setbuf(stdout, NULL);
    calibrate();
    printf("IPCDISC3 START tsc_hz=%llu\n", tsc_hz);

    p5c_shape("fresh-write", 1);

    p5a_replica(20000);
    p5c_shape("after-p5a-write", 1);

    p5b_replica(5000);
    p5c_shape("after-p5b-write", 1);
    p5c_shape("after-p5b-sendto", 0);

    /* traced short window on whatever regime is current */
    wr("/sys/kernel/debug/tracing/events/sched/sched_waking/enable", "1");
    wr("/sys/kernel/debug/tracing/events/sched/sched_wakeup/enable", "1");
    wr("/sys/kernel/debug/tracing/events/sched/sched_switch/enable", "1");
    p5c_shape("traced-write", 1);
    printf("IPCDISC3 TRACE-DUMP\n");
    dump_trace(120);
    printf("IPCDISC3 DONE\n");
    return 0;
}
