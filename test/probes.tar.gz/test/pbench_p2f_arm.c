/* pbench_p2f_arm.c — wrapper that runs the probe in p2fonly mode (the
 * perf-sched lane's futex wake->run battery: quiet + kernel-hog +
 * user-hog regimes, test/pbench.c b_p2f) and execve's it unchanged.
 * Built static by pbench_boot.py --p2f and staged as /test/pbench_p2f;
 * the boot's init becomes /test/pbench_p2f, so the stock side is the
 * same kernel, same image recipe running the full battery. The argv
 * must come from THIS wrapper: the boot harness always execs init with
 * no argv (pbench_boot.py -append init=...).
 */
#include <unistd.h>

int main(void)
{
    char *argv[] = { "/test/pbench", "p2fonly", 0 };
    char *envp[] = { 0 };
    write(1, "[arm] p2fonly\n", 14);
    execve(argv[0], argv, envp);
    return 127; /* execve failed */
}
