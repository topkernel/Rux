#define _GNU_SOURCE
#include <stdio.h>
#include <sched.h>
#include <signal.h>
#include <sys/wait.h>
#include <errno.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/syscall.h>

static int child(void *a) { return 0; }
int main(void) {
    setbuf(stdout, NULL);
    char *st = malloc(65536);
    unsigned long bases[] = {
        CLONE_THREAD | CLONE_SIGHAND | CLONE_VM | SIGCHLD,
        CLONE_THREAD | CLONE_SIGHAND | CLONE_VM | CLONE_CHILD_CLEARTID | SIGCHLD,
        CLONE_THREAD | CLONE_SIGHAND | CLONE_VM,
        CLONE_THREAD | CLONE_SIGHAND | CLONE_VM | CLONE_CHILD_CLEARTID,
    };
    unsigned long f = CLONE_THREAD | CLONE_SIGHAND | CLONE_VM | CLONE_CHILD_CLEARTID | SIGCHLD;
    /* direct in main */
    {
        int ctid = 0, ptid = 0;
        errno = 0;
        long r = clone(child, st + 65536, f, NULL, &ptid, NULL, &ctid);
        printf("main libc clone: rc=%ld errno=%d\n", r, errno);
        usleep(100000);
    }
    {
        int ctid = 0, ptid = 0;
        errno = 0;
        long r = syscall(SYS_clone, f, st + 65536, &ptid, &ctid, NULL);
        printf("main raw syscall: rc=%ld errno=%d\n", r, errno);
        usleep(100000);
    }
    {
        int ctid = 0, ptid = 0;
        errno = 0;
        long r = clone(child, st + 65536, CLONE_THREAD | CLONE_SIGHAND | CLONE_VM | SIGCHLD, NULL, &ptid, NULL, &ctid);
        printf("main no-cleartid: rc=%ld errno=%d\n", r, errno);
        usleep(100000);
    }
    {
        int ctid = 0, ptid = 0;
        errno = 0;
        long r = clone(child, st + 65536, CLONE_THREAD | CLONE_SIGHAND | CLONE_VM | CLONE_CHILD_CLEARTID, NULL, &ptid, NULL, &ctid);
        printf("main no-sigchld: rc=%ld errno=%d\n", r, errno);
        usleep(100000);
    }
    /* fork first, clone in the forked child */
    {
        pid_t p = fork();
        if (p == 0) {
            /* replicate the preceding PARENT_SETTID case: a CLONE_VM
             * child that raw-exits while sharing our VM */
            pid_t ptid2 = 0;
            errno = 0;
            long r0 = clone(child, st + 65536,
                            CLONE_VM | CLONE_PARENT_SETTID | SIGCHLD,
                            NULL, &ptid2, NULL, NULL);
            printf("pre-case: rc=%ld errno=%d\n", r0, errno);
            usleep(100000);
            int ctid = -1, ptid = 0;
            errno = 0;
            long r = clone(child, st + 65536, f, NULL, &ptid, NULL, &ctid);
            printf("forked-child: rc=%ld errno=%d\n", r, errno);
            usleep(100000);
            _exit(0);
        }
        int st2; waitpid(p, &st2, 0);
    }
    return 0;
}
