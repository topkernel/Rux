// blktrace_x86probe.c — the debug-blktrace lane's x86_64 serial proof.
// Drives the three landed surfaces end-to-end and prints PASS/FAIL
// lines the smoke script greps:
//
//   /proc/slabinfo            — reference geometry + live counters under load
//   /proc/pagetypeinfo        — MUST be absent (blocked-on-design row)
//   /sys/kernel/debug/block/<dev>/enable — 0 at boot, 1/0 toggles, EINVAL
//   /sys/kernel/debug/block/<dev>/trace  — empty before arming, dev-matched
//                                records under arm, silent after disarm
//
// Runs as init (pid 1, root) on a fresh minimal ext4 image (the
// logctl-smoke recipe: mkfs -d staging, host gcc -static).
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>

static int failures = 0;

static void verdict(const char *what, int ok) {
    printf("BLK_PROBE %s: %s\n", what, ok ? "PASS" : "FAIL");
    if (!ok) failures++;
}

static int read_file(const char *path, char *buf, size_t cap) {
    int fd = open(path, O_RDONLY);
    if (fd < 0) return -1;
    ssize_t n = read(fd, buf, cap - 1);
    close(fd);
    if (n < 0) return -1;
    buf[n] = 0;
    return (int)n;
}

static int write_file(const char *path, const char *text) {
    int fd = open(path, O_WRONLY);
    if (fd < 0) return -1;
    int rc = (int)write(fd, text, strlen(text));
    int rc2 = close(fd);
    return (rc < 0 || rc2 < 0) ? -1 : 0;
}

// ------------------------------------------------------------------
// Row 1: /proc/slabinfo — reference 5.15 geometry, live counters.
// ------------------------------------------------------------------

// The per-page object count for each kmalloc class: (4096-16)/S for the
// region layer, which is what the row prints (both layers agree — the
// module doc's verified arithmetic).
struct { long size; long ops; } EXPECT[] = {
    {8, 510}, {16, 255}, {32, 127}, {64, 63}, {128, 31},
    {256, 15}, {512, 7}, {1024, 3}, {2048, 1},
};
#define NEXPECT (long)(sizeof(EXPECT) / sizeof(EXPECT[0]))

#define MAXROWS 16
struct SlabRow {
    char name[32];
    long active, num, objsize, objperslab, pagesperslab;
    long tun[3];
    long slab[3];
};
static struct SlabRow rows[MAXROWS];
static int nrows = 0;

static int parse_slabinfo(void) {
    char buf[8192];
    if (read_file("/proc/slabinfo", buf, sizeof buf) < 0) return -1;
    char *line = strtok(buf, "\n");
    if (!line || strcmp(line, "slabinfo - version: 2.1") != 0) {
        printf("BLK_PROBE slabinfo-raw-line1: [%s]\n", line ? line : "");
        return -2;
    }
    line = strtok(NULL, "\n");
    if (!line || strncmp(line, "# name", 6) != 0) return -3;
    nrows = 0;
    while ((line = strtok(NULL, "\n")) != NULL && nrows < MAXROWS) {
        struct SlabRow *r = &rows[nrows];
        int f = sscanf(line, "%31s %ld %ld %ld %ld %ld : tunables %ld %ld %ld : slabdata %ld %ld %ld",
                       r->name, &r->active, &r->num, &r->objsize,
                       &r->objperslab, &r->pagesperslab,
                       &r->tun[0], &r->tun[1], &r->tun[2],
                       &r->slab[0], &r->slab[1], &r->slab[2]);
        if (f != 12) {
            printf("BLK_PROBE slabinfo-raw-row%d(f=%d): [%s]\n", nrows, f, line);
            return -4;
        }
        nrows++;
    }
    return nrows;
}

static void churn_files(void) {
    char path[64];
    char data[4096];
    memset(data, 'x', sizeof data);
    for (int i = 0; i < 100; i++) {
        snprintf(path, sizeof path, "/tmp/churn.%d", i);
        int fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0600);
        if (fd >= 0) {
            for (int j = 0; j < 2; j++) {
                if (write(fd, data, sizeof data) < 0) break;
            }
            close(fd);
        }
        unlink(path);
    }
}

static void slabinfo_proof(void) {
    // Mode: 0400 like the reference (SLABINFO_RIGHTS).
    struct stat st;
    int mode_ok = stat("/proc/slabinfo", &st) == 0
                  && (st.st_mode & 0777) == 0400;
    verdict("slabinfo-mode-0400", mode_ok);

    int rc = parse_slabinfo();
    verdict("slabinfo-header", rc >= 0);
    if (rc < 0) {
        printf("BLK_PROBE slabinfo-parse-rc: %d\n", rc);
        return;
    }
    // The 8..2048 region classes all carry rows; the 4096 class
    // (objects_per_slab == 0) gets none.
    verdict("slabinfo-rowcount", nrows >= 8 && nrows <= 10);

    // Geometry: every row's objperslab is the class's real per-page
    // object count; tunables are SLUB's zeros; slabdata counts match.
    int geo_ok = 1;
    for (int i = 0; i < nrows; i++) {
        struct SlabRow *r = &rows[i];
        long sz = r->objsize;
        long want = -1;
        for (long k = 0; k < NEXPECT; k++)
            if (EXPECT[k].size == sz) want = EXPECT[k].ops;
        if (want < 0 || r->objperslab != want
            || r->pagesperslab != 1
            || r->tun[0] || r->tun[1] || r->tun[2]
            || r->slab[0] != r->slab[1]
            || r->active > r->num) {
            geo_ok = 0;
            printf("BLK_PROBE slabinfo-badrow: %s ops=%ld want=%ld\n",
                   r->name, r->objperslab, want);
        }
    }
    verdict("slabinfo-geometry", geo_ok);

    // Live counters: file churn must MOVE at least one row (the
    // counters count real allocations, not constants).
    long before_active[MAXROWS], before_num[MAXROWS];
    for (int i = 0; i < nrows; i++) {
        before_active[i] = rows[i].active;
        before_num[i] = rows[i].num;
    }
    churn_files();
    if (parse_slabinfo() < 0) {
        verdict("slabinfo-reparse", 0);
        return;
    }
    int moved = 0;
    for (int i = 0; i < nrows && i < MAXROWS; i++) {
        if (rows[i].active != before_active[i]
            || rows[i].num != before_num[i]) moved = 1;
        if (i < 3)
            printf("BLK_PROBE slabinfo-row: %s %ld %ld %ld %ld %ld\n",
                   rows[i].name, rows[i].active, rows[i].num,
                   rows[i].objsize, rows[i].objperslab,
                   rows[i].pagesperslab);
    }
    verdict("slabinfo-live-counters", moved);
    verdict("slabinfo-reparse", 1);
}

// ------------------------------------------------------------------
// Row 2: /proc/pagetypeinfo must be ABSENT (blocked-on-design: the
// buddy has no migratetype segregation to report).
// ------------------------------------------------------------------
static void pagetypeinfo_proof(void) {
    int fd = open("/proc/pagetypeinfo", O_RDONLY);
    if (fd >= 0) { close(fd); verdict("pagetypeinfo-absent", 0); return; }
    verdict("pagetypeinfo-absent", errno == ENOENT);
}

// ------------------------------------------------------------------
// Row 3: /sys/kernel/debug/block/<dev>/ — per-device arming + readback.
// ------------------------------------------------------------------
static char devdir[128];
static char enable_path[160];
static char trace_path[160];
static long disk_major = -1, disk_minor = -1;

// The disk's major,minor from /proc/diskstats (row whose name matches
// the debugfs dir name).
static void diskstats_lookup(const char *name) {
    char buf[4096];
    if (read_file("/proc/diskstats", buf, sizeof buf) < 0) return;
    char *line = strtok(buf, "\n");
    while (line) {
        long maj, min;
        char nm[64];
        if (sscanf(line, "%ld %ld %63s", &maj, &min, nm) == 3
            && strcmp(nm, name) == 0) {
            disk_major = maj;
            disk_minor = min;
            return;
        }
        line = strtok(NULL, "\n");
    }
}

static int count_trace_lines(void) {
    char *buf = malloc(256 * 1024);
    if (!buf) return -1;
    int n = read_file(trace_path, buf, 256 * 1024);
    int lines = 0;
    if (n > 0) for (char *p = buf; *p; p++) if (*p == '\n') lines++;
    free(buf);
    return lines;
}

// Every readback line must be the tracefs geometry AND carry this
// device's major,minor as the first args field.
static int check_trace_lines(int print_first) {
    char *buf = malloc(256 * 1024);
    if (!buf) return -1;
    int n = read_file(trace_path, buf, 256 * 1024);
    if (n < 0) { free(buf); return -1; }
    char want[32];
    snprintf(want, sizeof want, "%ld,%ld ", disk_major, disk_minor);
    int lines = 0, ok = 1;
    char first_line[256] = "";
    for (char *p = buf; *p; ) {
        char *eol = strchr(p, '\n');
        if (!eol) eol = p + strlen(p);
        size_t len = (size_t)(eol - p);
        if (len > 255) len = 255;
        lines++;
        // Geometry: "comm-pid [cpu] flags sec.usec: event: args" —
        // the colon-space before the event name and the dev prefix
        // after the event name's own colon.
        char *colon = strstr(p, ": block_rq_");
        int geo = colon != NULL && colon > p;
        char *args = NULL;
        if (colon) {
            char *c2 = strchr(colon + 11, ':'); // past "block_rq_"
            if (c2) {
                args = c2 + 1;
                while (*args == ' ') args++;
            }
        }
        int dev = args && strncmp(args, want, strlen(want)) == 0;
        // rwbs and the () cmd field, the reference render's shapes.
        if (!geo || !dev) {
            ok = 0;
            if (lines <= 3) {
                char tmp[256];
                size_t cl = len < 255 ? len : 255;
                memcpy(tmp, p, cl); tmp[cl] = 0;
                printf("BLK_PROBE trace-badline: geo=%d dev=%d [%s]\n",
                       geo, dev, tmp);
            }
        }
        if (print_first && lines == 1) {
            size_t cl = len < 255 ? len : 255;
            memcpy(first_line, p, cl); first_line[cl] = 0;
        }
        p = *eol ? eol + 1 : eol;
    }
    if (print_first && first_line[0])
        printf("BLK_PROBE trace-first: %s\n", first_line);
    free(buf);
    return ok ? lines : -lines;
}

static void io_burst(int nwrites) {
    char data[4096];
    memset(data, 'q', sizeof data);
    int fd = open("/test/io.bin", O_WRONLY | O_CREAT | O_TRUNC, 0600);
    if (fd < 0) fd = open("/io.bin", O_WRONLY | O_CREAT | O_TRUNC, 0600);
    if (fd < 0) {
        printf("BLK_PROBE io-open-err: errno=%d\n", errno);
        return;
    }
    for (int i = 0; i < nwrites; i++) {
        if (write(fd, data, sizeof data) < 0) {
            printf("BLK_PROBE io-write-err: i=%d errno=%d\n", i, errno);
            break;
        }
        if (i % 8 == 7 && fsync(fd) < 0)
            printf("BLK_PROBE io-fsync-err: i=%d errno=%d\n", i, errno);
    }
    if (fsync(fd) < 0)
        printf("BLK_PROBE io-fsync-err: final errno=%d\n", errno);
    close(fd);
    unlink("/test/io.bin");
    unlink("/io.bin");
}

// Every /sys/kernel/debug/block/ child (the surface registers every
// gendisk, like the reference's per-gendisk dirs).
#define MAXDEVS 16
static char dev_names[MAXDEVS][64];
static int ndevs = 0;

static void list_dev_dirs(void) {
    ndevs = 0;
    DIR *d = opendir("/sys/kernel/debug/block");
    if (!d) return;
    struct dirent *e;
    while ((e = readdir(d)) != NULL && ndevs < MAXDEVS) {
        if (e->d_name[0] == '.') continue;
        snprintf(dev_names[ndevs], 64, "%s", e->d_name);
        ndevs++;
    }
    closedir(d);
}

static void block_surface_proof(void) {
    list_dev_dirs();
    verdict("block-dir", ndevs > 0);
    if (ndevs == 0) return;

    // Before arming: EVERY device's trace is empty (the events have
    // never been armed this boot — no block record exists anywhere).
    int all_empty = 1;
    for (int i = 0; i < ndevs; i++) {
        char p[160];
        snprintf(p, sizeof p, "/sys/kernel/debug/block/%s/trace",
                 dev_names[i]);
        char tbuf[256];
        int n = read_file(p, tbuf, sizeof tbuf);
        if (n > 0) all_empty = 0;
    }
    verdict("trace-empty-before-arm", all_empty);

    // Arm through the FIRST dir's enable (the switches are shared —
    // the surface's documented machine-wide arming).
    snprintf(enable_path, sizeof enable_path,
             "/sys/kernel/debug/block/%s/enable", dev_names[0]);

    // enable reads 0 at boot (fresh boot, nothing armed).
    char buf[64];
    int n = read_file(enable_path, buf, sizeof buf);
    verdict("enable-read-0", n > 0 && strcmp(buf, "0\n") == 0);

    // Toggle: 1 -> reads 1; 0 -> reads 0; garbage -> EINVAL.
    verdict("enable-write-1", write_file(enable_path, "1\n") == 0);
    n = read_file(enable_path, buf, sizeof buf);
    verdict("enable-read-1", n > 0 && strcmp(buf, "1\n") == 0);

    // The arm drives the SHARED event switches (tracefs events/
    // block/*/enable read 1 too — the surface's documented divergence).
    n = read_file("/sys/kernel/tracing/events/block/block_rq_issue/enable",
                  buf, sizeof buf);
    verdict("event-switch-armed", n > 0 && strcmp(buf, "1\n") == 0);

    // IO under arm -> records in the readback of the device that
    // serves the filesystem (name it: any /sys/kernel/debug/block
    // dir whose trace now carries lines).
    io_burst(32);
    int picked = -1;
    int c1 = 0;
    for (int i = 0; i < ndevs && picked < 0; i++) {
        snprintf(trace_path, sizeof trace_path,
                 "/sys/kernel/debug/block/%s/trace", dev_names[i]);
        int lines = count_trace_lines();
        if (lines > 0) { picked = i; c1 = lines; }
    }
    verdict("trace-records-under-arm", picked >= 0);
    if (picked < 0) return;
    printf("BLK_PROBE picked-dev: %s\n", dev_names[picked]);
    if (c1 > 0) printf("BLK_PROBE trace-lines: %d\n", c1);

    // The picked device's readback: dev-matched, reference geometry.
    snprintf(devdir, sizeof devdir, "/sys/kernel/debug/block/%s",
             dev_names[picked]);
    const char *nm = dev_names[picked];
    diskstats_lookup(nm);
    verdict("diskstats-match", disk_major >= 0);
    if (disk_major < 0) return;
    printf("BLK_PROBE disk: %ld,%ld\n", disk_major, disk_minor);
    int checked = check_trace_lines(1);
    verdict("trace-geometry-devmatch", checked > 0);

    // The readback and the global trace agree on the block events'
    // content (same renderer; the readback is the filtered view). The
    // global render is oldest-first, 1 MB holds the quiet-guest ring.
    char *gbuf = malloc(1024 * 1024);
    int global_has_block = 0;
    if (gbuf) {
        read_file("/sys/kernel/tracing/trace", gbuf, 1024 * 1024);
        char want[32];
        snprintf(want, sizeof want, "%ld,%ld ", disk_major, disk_minor);
        char *p = gbuf;
        while (p && !global_has_block) {
            p = strstr(p, ": block_rq_");
            if (!p) break;
            char *colon = strchr(p + 11, ':');
            if (colon) {
                char *a = colon + 1;
                while (*a == ' ') a++;
                if (strncmp(a, want, strlen(want)) == 0) global_has_block = 1;
            }
            p = colon;
        }
        free(gbuf);
    }
    verdict("trace-vs-global", global_has_block);

    // Disarm: events go dark, new IO adds no records.
    verdict("enable-write-0", write_file(enable_path, "0\n") == 0);
    n = read_file(enable_path, buf, sizeof buf);
    verdict("enable-read-0-again", n > 0 && strcmp(buf, "0\n") == 0);
    n = read_file("/sys/kernel/tracing/events/block/block_rq_issue/enable",
                  buf, sizeof buf);
    verdict("event-switch-disarmed", n > 0 && strcmp(buf, "0\n") == 0);
    sleep(1);
    int c2 = count_trace_lines();
    io_burst(16);
    sleep(1);
    int c3 = count_trace_lines();
    verdict("trace-silent-after-disarm", c2 == c3);
    printf("BLK_PROBE disarm-counts: %d %d\n", c2, c3);

    // Garbage write rejected (EINVAL), state unchanged.
    int rc = write_file(enable_path, "x\n");
    verdict("enable-einval", rc < 0 && errno == EINVAL);
    n = read_file(enable_path, buf, sizeof buf);
    verdict("enable-state-after-einval", n > 0 && strcmp(buf, "0\n") == 0);
}

int main(void) {
    setvbuf(stdout, NULL, _IONBF, 0);
    printf("BLK_PROBE start (pid %d)\n", (int)getpid());
    slabinfo_proof();
    pagetypeinfo_proof();
    block_surface_proof();
    printf("BLK_PROBE failures: %d\n", failures);
    printf("BLK_PROBE RESULT: %s\n", failures ? "FAIL" : "PASS");
    printf("===BLK-SMOKE-DONE===\n");
    return 0;
}
