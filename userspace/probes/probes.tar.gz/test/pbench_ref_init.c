/* pbench_ref_init.c — PID-1 wrapper for the REFERENCE-kernel column of
 * the pbench dual-kernel rig (item 10, sysmm-2x lane, 2026-11-17).
 *
 * Same shape as the lmbench rig's init_ref.c: the reference distro
 * kernel does not auto-mount /proc for PID 1 and the packed rootfs has
 * no static /dev/console, so this wrapper prepares the environment the
 * pbench probe expects and then execs it (PID 1 preserved — the
 * probe's reboot(RB_POWER_OFF) still ends the boot):
 *
 *   - mount devtmpfs/proc/sysfs
 *   - open /dev/console and dup2 it onto 0/1/2
 *   - exec /test/pbench (the same static musl probe the Rux column
 *     runs; argv[0] carries no state the probe reads)
 */
#include <fcntl.h>
#include <sys/mount.h>
#include <sys/stat.h>
#include <unistd.h>

int main(void)
{
    mkdir("/dev", 0755);
    mkdir("/proc", 0755);
    mkdir("/sys", 0755);
    mkdir("/tmp", 0755);

    mount("devtmpfs", "/dev", "devtmpfs", 0, 0);
    mount("proc", "/proc", "proc", 0, 0);
    mount("sysfs", "/sys", "sysfs", 0, 0);

    int c = open("/dev/console", O_RDWR);
    if (c >= 0) {
        dup2(c, 0);
        dup2(c, 1);
        dup2(c, 2);
        if (c > 2)
            close(c);
    }
    write(1, "REFPB INIT WRAPPER OK\n", 22);

    execl("/test/pbench", "pbench", (char *)0);

    /* exec failed — park; the outer timeout reaps the boot */
    for (;;)
        pause();
}
