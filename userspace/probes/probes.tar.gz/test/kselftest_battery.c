/*
 * kselftest_battery — the reference-kernel-shaped coverage battery.
 *
 * Linux tests syscall/ABI behavior from USERSPACE (kselftest lives in
 * tools/testing/selftests; futex/memfd/mqueue are all userspace dirs)
 * and collects kernel coverage through KCOV from the driving process.
 * This battery is Rux's kselftest analog: a musl-static init binary
 * (init=/test/kselftest_battery) that drives the syscall surface as a
 * REAL process — fork/wait, a futex wake pair across processes, pipes,
 * memfd, mmap/mprotect, AF_UNIX socketpair, file I/O — then triggers
 * the whole-kernel profile dump by writing /proc/sys/kernel/cov_dump
 * (our KCOV-alignment knob), which emits the .profraw as console hex.
 *
 * Output contract: "COV: PASS <name>" / "COV: FAIL <name> (detail)"
 * lines, a final summary, then the coverage trigger.
 */

#define _GNU_SOURCE
#include <sys/syscall.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <stdint.h>
#include <errno.h>
#include <stdlib.h>
#include <stdio.h>

static int g_pass, g_fail;

#define CHECK(name, cond) do {                                       \
    if (cond) { g_pass++; printf("COV: PASS %s\n", name); }          \
    else { g_fail++; printf("COV: FAIL %s (errno=%d)\n", name, errno); } \
} while (0)

#ifndef SYS_futex
#define SYS_futex 98 /* riscv64 __NR_futex */
#endif
#ifndef SYS_memfd_create
#define SYS_memfd_create 279 /* riscv64 */
#endif

#define FUTEX_WAIT 0
#define FUTEX_WAKE 1

/* ---- 1. futex wake pair across processes -------------------------
 * The reference's futex functional tests are exactly this shape: one
 * waiter blocked in FUTEX_WAIT on a shared word, a second process
 * stores the new value and FUTEX_WAKEs. Exercises the wait queue, the
 * wake path and the priority-inheritance key lookup (private mapping).
 */
static void test_futex_pair(void)
{
    int *w = mmap(NULL, 4096, PROT_READ | PROT_WRITE,
                  MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (w == MAP_FAILED) {
        CHECK("futex: shared mmap", 0);
        return;
    }
    *w = 0;

    pid_t pid = fork();
    if (pid == 0) {
        /* child: wait until the word flips (handles spurious wakes) */
        for (int i = 0; i < 1000 && *w == 0; i++) {
            syscall(SYS_futex, w, FUTEX_WAIT, 0, 0, 0, 0);
        }
        _exit(*w == 1 ? 42 : 1);
    }
    /* parent: give the child time to block, then publish + wake */
    usleep(200000);
    *w = 1;
    long nw = syscall(SYS_futex, w, FUTEX_WAKE, 1, 0, 0, 0);
    int status = 0;
    waitpid(pid, &status, 0);
    CHECK("futex: waiter woke with correct value",
          nw >= 0 && WIFEXITED(status) && WEXITSTATUS(status) == 42);
    munmap(w, 4096);
}

/* ---- 2. fork/wait exit-code plumbing ---------------------------- */
static void test_fork_wait(void)
{
    pid_t pid = fork();
    if (pid == 0) {
        _exit(7);
    }
    int status = 0;
    pid_t got = waitpid(pid, &status, 0);
    CHECK("fork/wait: exit code",
          got == pid && WIFEXITED(status) && WEXITSTATUS(status) == 7);
}

/* ---- 3. pipe ---------------------------------------------------- */
static void test_pipe(void)
{
    int pfd[2];
    if (pipe(pfd) < 0) {
        CHECK("pipe: create", 0);
        return;
    }
    const char *msg = "covbat";
    ssize_t n1 = write(pfd[1], msg, strlen(msg));
    char buf[32];
    ssize_t n2 = read(pfd[0], buf, sizeof(buf));
    CHECK("pipe: write+read echo", n1 == (ssize_t)strlen(msg) &&
          n2 == n1 && memcmp(buf, msg, n2) == 0);
    close(pfd[0]);
    close(pfd[1]);
}

/* ---- 4. memfd_create -------------------------------------------- */
static void test_memfd(void)
{
    int fd = (int)syscall(SYS_memfd_create, "covbat", 0);
    if (fd < 0) {
        CHECK("memfd: create", 0);
        return;
    }
    const char *msg = "memfd-payload";
    ssize_t n1 = write(fd, msg, strlen(msg));
    lseek(fd, 0, SEEK_SET);
    char buf[64];
    ssize_t n2 = read(fd, buf, sizeof(buf));
    CHECK("memfd: write+lseek+read",
          n1 == (ssize_t)strlen(msg) && n2 == n1 && memcmp(buf, msg, n2) == 0);
    close(fd);
}

/* ---- 5. mmap anon + mprotect + munmap --------------------------- */
static void test_mmap_protect(void)
{
    char *p = mmap(NULL, 8192, PROT_READ | PROT_WRITE,
                   MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (p == MAP_FAILED) {
        CHECK("mmap: anon window", 0);
        return;
    }
    p[0] = 'R';
    p[8191] = 'R';
    int mp = mprotect(p, 8192, PROT_READ);
    CHECK("mmap/mprotect: window + downgrade", mp == 0 && p[0] == 'R');
    munmap(p, 8192);
}

/* ---- 6. AF_UNIX socketpair echo ---------------------------------- */
static void test_socketpair(void)
{
    int sv[2];
    if (socketpair(AF_UNIX, SOCK_STREAM, 0, sv) < 0) {
        CHECK("socketpair: create", 0);
        return;
    }
    const char *msg = "unix-echo";
    ssize_t n1 = send(sv[0], msg, strlen(msg), 0);
    char buf[64];
    ssize_t n2 = recv(sv[1], buf, sizeof(buf), 0);
    CHECK("socketpair: send/recv echo",
          n1 == (ssize_t)strlen(msg) && n2 == n1 && memcmp(buf, msg, n2) == 0);
    close(sv[0]);
    close(sv[1]);
}

/* ---- 7. file create/write/reopen/read ---------------------------- */
static void test_file_io(void)
{
    const char *path = "/tmp/covbat.bin";
    int fd = open(path, O_CREAT | O_RDWR | O_TRUNC, 0644);
    if (fd < 0) {
        CHECK("file: create", 0);
        return;
    }
    char payload[512];
    for (size_t i = 0; i < sizeof(payload); i++) payload[i] = (char)(i * 7);
    ssize_t n1 = write(fd, payload, sizeof(payload));
    close(fd);

    fd = open(path, O_RDONLY);
    char back[512];
    ssize_t n2 = read(fd, back, sizeof(back));
    close(fd);
    unlink(path);
    CHECK("file: create+write+reopen+read",
          n1 == (ssize_t)sizeof(payload) && n2 == n1 &&
          memcmp(payload, back, sizeof(payload)) == 0);
}

int main(void)
{
    printf("kselftest_battery: start\n");

    test_futex_pair();
    test_fork_wait();
    test_pipe();
    test_memfd();
    test_mmap_protect();
    test_socketpair();
    test_file_io();

    printf("kselftest_battery: %d pass, %d fail\n", g_pass, g_fail);

    /* KCOV-alignment trigger: capture + emit the whole-kernel profile
     * (console hex between [cov-begin]/[cov-end]) — the host pipeline
     * extracts it from this boot log. */
    int fd = open("/proc/sys/kernel/cov_dump", O_WRONLY);
    if (fd < 0) {
        printf("COV: FAIL trigger open (errno=%d)\n", errno);
    } else {
        ssize_t n = write(fd, "1", 1);
        close(fd);
        printf("COV: %s trigger write (n=%zd errno=%d)\n",
               n == 1 ? "PASS" : "FAIL", n, errno);
    }
    printf("kselftest_battery: done\n");
    return g_fail == 0 ? 0 : 1;
}
