/* pollprobe.c — raw-syscall ppoll contract probe for the Rux kernel.
 *
 * Covers the ppoll-fix matrix cases the LTP binaries do not reach:
 *   null0   NULL sigmask + sigsetsize=0 -> must NOT error (glibc poll shape)
 *   null8   NULL sigmask + sigsetsize=8 -> must NOT error
 *   null9k  NULL sigmask + sigsetsize=9999 -> must NOT error (ignored)
 *   mss0v   non-NULL sigmask + ss=0, valid fds -> EINVAL
 *   mss0b   non-NULL sigmask + ss=0, INVALID fds -> EINVAL (not EFAULT:
 *           proves size check runs before any fd processing, ref order)
 *   t0      timeout {0,0} -> ret 0 immediately
 *   t1ms    timeout {0,1e6} -> ret 0, elapsed >= 1ms
 *   t500ms  timeout {0,5e8} -> ret 0, elapsed in [450ms, 2500ms] (off-by-one)
 *   nsec1g  timeout nsec=1e9 -> EINVAL
 *   nsecneg timeout nsec=(u64)-1 -> EINVAL
 *   secneg  timeout sec=-1 (huge u64) -> EINVAL per reference
 *           timespec64_valid (guarded by alarm so a wait shows as EINTR FAIL)
 *   tspflt  timeout pointer unmapped -> EFAULT
 *   mskflt  sigmask pointer unmapped, ss=8 -> EFAULT
 *   ready   data in pipe + timeout 1s -> ret 1 fast (no premature timeout)
 *   intr    NULL timeout (infinite) + SIGUSR1 from child at 200ms -> EINTR
 * One short verdict line per case + final PROBE-SUMMARY. exit 0 iff all pass.
 */
#define _GNU_SOURCE
#include <errno.h>
#include <stdarg.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
#include <sys/syscall.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#ifndef __NR_ppoll
#define __NR_ppoll 271
#endif

struct pfd { int fd; short events; short revents; };
struct ts { int64_t sec; int64_t nsec; };

static int last_errno;

static long raw_ppoll(void *fds, uint64_t nfds, void *tsp, void *mask, uint64_t ss)
{
	long r = syscall(__NR_ppoll, fds, nfds, tsp, mask, ss);
	last_errno = errno;
	return r;
}

#define ERR_IS(e) (r == -1 && last_errno == (e))

static double now_ms(void)
{
	struct timespec t;
	syscall(228, CLOCK_MONOTONIC, &t);
	return t.tv_sec * 1000.0 + t.tv_nsec / 1e6;
}

static int npass, nfail;

static void verdict(const char *name, int ok, const char *fmt, ...)
{
	char detail[160];
	va_list ap;
	va_start(ap, fmt);
	vsnprintf(detail, sizeof(detail), fmt, ap);
	va_end(ap);
	if (ok) {
		npass++;
		printf("P %s\n", name);
	} else {
		nfail++;
		printf("F %s %s\n", name, detail);
	}
	fflush(stdout);
}

static void on_usr1(int s) { (void)s; }
static void on_alrm(int s) { (void)s; }

int main(void)
{
	int pf[2];
	char buf[1] = { 'x' };
	struct ts tsp;
	struct pfd fds;
	uint64_t mask = 0;
	double t0, dt;
	long r;

	if (pipe(pf) != 0)
		return 2;
	/* unmapped user-space pointer: nothing maps 0x30000000 in this static image */
	void *badp = (void *)(uintptr_t)0x30000000UL;

	/* null0: the glibc poll() shape that motivated the fix */
	fds.fd = pf[0]; fds.events = 0x1 /*POLLIN*/; fds.revents = 0;
	tsp.sec = 0; tsp.nsec = 0;
	r = raw_ppoll(&fds, 1, &tsp, NULL, 0);
	verdict("null0", r == 0, "ret=%ld", r);

	/* null8 */
	r = raw_ppoll(&fds, 1, &tsp, NULL, 8);
	verdict("null8", r == 0, "ret=%ld", r);

	/* null9k: reference ignores sigsetsize entirely when mask is NULL */
	r = raw_ppoll(&fds, 1, &tsp, NULL, 9999);
	verdict("null9k", r == 0, "ret=%ld", r);

	/* mss0v: non-NULL mask + wrong size -> EINVAL */
	tsp.sec = 0; tsp.nsec = 0;
	r = raw_ppoll(&fds, 1, &tsp, &mask, 0);
	verdict("mss0v", ERR_IS(EINVAL), "ret=%ld errno=%d", r, last_errno);

	/* mss0b: EINVAL must beat fd processing (bad fds pointer would EFAULT) */
	r = raw_ppoll(badp, 1, &tsp, &mask, 0);
	verdict("mss0b", ERR_IS(EINVAL), "ret=%ld errno=%d want=EINVAL", r, last_errno);

	/* t0 */
	tsp.sec = 0; tsp.nsec = 0;
	t0 = now_ms();
	r = raw_ppoll(&fds, 1, &tsp, NULL, 0);
	dt = now_ms() - t0;
	verdict("t0", r == 0 && dt < 100.0, "ret=%ld dt=%.1f", r, dt);

	/* t1ms */
	tsp.sec = 0; tsp.nsec = 1000000;
	t0 = now_ms();
	r = raw_ppoll(&fds, 1, &tsp, NULL, 0);
	dt = now_ms() - t0;
	verdict("t1ms", r == 0 && dt >= 0.9 && dt < 200.0, "ret=%ld dt=%.1f", r, dt);

	/* t500ms: no early return (off-by-one) */
	tsp.sec = 0; tsp.nsec = 500000000;
	t0 = now_ms();
	r = raw_ppoll(&fds, 1, &tsp, NULL, 0);
	dt = now_ms() - t0;
	verdict("t500ms", r == 0 && dt >= 450.0 && dt < 2500.0, "ret=%ld dt=%.1f", r, dt);

	/* nsec1g */
	tsp.sec = 0; tsp.nsec = 1000000000;
	r = raw_ppoll(&fds, 1, &tsp, NULL, 0);
	verdict("nsec1g", ERR_IS(EINVAL), "ret=%ld errno=%d", r, last_errno);

	/* nsecneg */
	tsp.sec = 0; tsp.nsec = -1;
	r = raw_ppoll(&fds, 1, &tsp, NULL, 0);
	verdict("nsecneg", ERR_IS(EINVAL), "ret=%ld errno=%d", r, last_errno);

	/* secneg: reference timespec64_valid rejects tv_sec<0; alarm guards a hang */
	signal(SIGALRM, on_alrm);
	alarm(3);
	tsp.sec = -1; tsp.nsec = 0;
	t0 = now_ms();
	r = raw_ppoll(&fds, 1, &tsp, NULL, 0);
	dt = now_ms() - t0;
	alarm(0);
	if (ERR_IS(EINTR) && dt >= 2500.0)
		verdict("secneg", 0, "ACCEPTED+waited(alarm3s) ret=%ld errno=%d dt=%.0f", r, last_errno, dt);
	else
		verdict("secneg", ERR_IS(EINVAL) && dt < 500.0, "ret=%ld errno=%d dt=%.1f", r, last_errno, dt);

	/* tspflt */
	tsp.sec = 0; tsp.nsec = 0;
	r = raw_ppoll(&fds, 1, badp, NULL, 0);
	verdict("tspflt", ERR_IS(EFAULT), "ret=%ld errno=%d", r, last_errno);

	/* mskflt */
	r = raw_ppoll(&fds, 1, &tsp, badp, 8);
	verdict("mskflt", ERR_IS(EFAULT), "ret=%ld errno=%d", r, last_errno);

	/* ready: immediate readiness beats the 1s timeout */
	write(pf[1], buf, 1);
	tsp.sec = 1; tsp.nsec = 0;
	t0 = now_ms();
	r = raw_ppoll(&fds, 1, &tsp, NULL, 0);
	dt = now_ms() - t0;
	verdict("ready", r == 1 && dt < 200.0, "ret=%ld dt=%.1f", r, dt);
	(void)!read(pf[0], buf, 1); /* drain */

	/* intr: NULL timeout (infinite) interrupted by SIGUSR1 at ~200ms */
	signal(SIGUSR1, on_usr1);
	pid_t pid = fork();
	if (pid == 0) {
		usleep(200 * 1000);
		kill(getppid(), SIGUSR1);
		_exit(0);
	}
	t0 = now_ms();
	r = raw_ppoll(&fds, 1, NULL, NULL, 0);
	dt = now_ms() - t0;
	int st;
	waitpid(pid, &st, 0);
	verdict("intr", ERR_IS(EINTR) && dt >= 150.0 && dt < 1500.0, "ret=%ld errno=%d dt=%.1f", r, last_errno, dt);

	printf("PROBE-SUMMARY pass=%d fail=%d\n", npass, nfail);
	fflush(stdout);
	return nfail ? 1 : 0;
}
