/* garepro.c — GLib gthreadpool spawn-protocol freeze repro.
 *
 * Mimics GLib 2.80 gthreadpool.c's global spawn machinery with raw
 * glibc pthreads (the same objects glib uses on Linux: GMutex =
 * malloc'd pthread_mutex_t, GCond = pthread_cond_t):
 *
 *   spawn_thread_queue  = GAsyncQueue { mutex M, cond C1, queue }
 *   spawn_thread_cond   = static GCond C2  (bss)
 *   unused_thread_queue = GAsyncQueue { mutex U, cond CU, queue }
 *
 * Protocol participants on M (the mutex that freezes on ub2404):
 *
 *   spawner  (g_thread_pool_spawn_thread, gthreadpool.c:279):
 *     lock M -> pop_unlocked (cond_wait(C1,M) while empty) ->
 *     g_thread_try_new (clone syscall) HOLDING M -> cond_broadcast(C2)
 *     -> unlock M
 *
 *   requester (g_thread_pool_start_thread non-exclusive, :462):
 *     lock M -> push_unlocked (&stack SpawnThreadData) ->
 *     while (!done) cond_wait(C2, M) -> unlock M   [SpawnThreadData
 *     lives on the requester's stack; spawner writes it under M]
 *
 *   worker (g_thread_pool_thread_proxy, :310): shared-pool pop with
 *     0.5s timeout on the pool queue (mutex P, cond CP); on timeout
 *     the worker leaves to the global pool: unused_threads++, pop
 *     U with idle timeout (marker relay dance), exit when NULL.
 *     The worker's push path holds P while calling start_thread ->
 *     nested P -> M (g_thread_pool_push:697).
 *
 * What glib lacks and this probe adds: a shadow ownership ledger.
 * Every M acquire/release (including the release/re-acquire inside
 * cond_wait) is mirrored into per-thread flags, so a frozen word can
 * be classified immediately:
 *
 *   word != 0, no thread believes it holds M
 *       -> PHANTOM: userspace atomicity break or a foreign store to
 *          the word (exit 42) — the kernel-suspect shape
 *   word != 0, exactly one holder whose state is a park point that
 *       per protocol does NOT hold M (or holder parked >15s)
 *       -> OWNER-PARKED: glib-protocol corner / holder wedged in a
 *          syscall while holding (exit 43)
 *   no global progress 30s -> STALL (exit 44)
 *   redzone/page mutation outside the known live fields
 *       -> CANARY: foreign memory write (exit 45)
 *
 * M/C1/U live at fixed mmap'd addresses so the kernel-side
 * RWFRZ-WATCH tracer can be pre-armed from t=0
 * (rwfrzwatch=0x313370100).
 *
 * Build (host x86_64, static glibc):
 *   gcc -static -O2 -pthread -DPROBE_SECS=300 -o garepro garepro.c
 * Verdict lines: GAREPRO-PASS (rc 0), GAREPRO-PHANTOM (42),
 * GAREPRO-OWNER-PARKED (43), GAREPRO-STALL (44), GAREPRO-CANARY (45).
 */

#define _GNU_SOURCE
#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <sched.h>
#include <stdarg.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>
#include <poll.h>

#ifndef PROBE_SECS
#define PROBE_SECS 300
#endif
#ifndef N_PUSHERS
#define N_PUSHERS 6
#endif
#ifndef IDLE_MS
#define IDLE_MS 15000 /* glib default max idle: 15s */
#endif
#define POP_MS 500        /* glib shared-pool pop timeout: 0.5s FIXED */
#define MAX_UNUSED 2      /* glib default max unused threads */
#define REG_MAX 320

/* ---------------- fixed-address observation page ---------------- */
#define PAGE_VA 0x313370000UL
static volatile unsigned char *obs_page;

#define OFF_GUARD0 0x000 /* 0x000-0x0ff quiet */
#define OFF_M 0x100      /* pthread_mutex_t M (40 bytes) */
#define OFF_C1 0x1a0     /* pthread_cond_t C1 (48 bytes) spawn queue cond */
#define OFF_CAN1 0x210   /* 32 quiet bytes */
#define OFF_U 0x300      /* pthread_mutex_t U (global-pool mutex) */
#define OFF_CU 0x3a0     /* pthread_cond_t CU */
#define OFF_CAN2 0x410   /* 32 quiet bytes */
#define OFF_RING 0x800   /* history ring (live, excluded from canary) */
#define RING_N 60
#define RING_BYTES (RING_N * 32) /* struct hring: 32B/slot, 0x800-0xF7F */
#define OFF_TRIP 0xF80   /* register-rewind tripwire block (32B, 0xF80) */
#define OFF_HB2 0xFA0    /* independent-thread witness heartbeat (16B) */

static pthread_mutex_t *M;  /* = (void*)(obs_page + OFF_M) */

/* Register-rewind tripwire: the garepro10 STALL verdict fired with
 * mops STILL GROWING at every ALIVE print — impossible unless the
 * monitor's REGISTER-resident loop state (last_progress_t,
 * last_m_ops, ring_i) went stale, i.e. the thread resumed from an old
 * context snapshot. The page-resident block below (shared memory,
 * immune to register rewinds) shadows exactly that state; the STALL
 * check cross-validates register state vs page state and prints
 * GAREPRO-REG-REWIND when they disagree. */
struct trip { uint64_t seq, prog_abs, mops, ring_i; };
static struct trip *tr; /* obs_page + OFF_TRIP */
/* independent-thread witness: poller0 (a DIFFERENT context) stamps
 * this every poll loop (~30ms). At a monitor verdict, witness.ms
 * fresh + monitor claiming 30s stale = the MONITOR's own context went
 * stale (rewind); witness stale too = genuine total freeze. */
struct hb2 { uint64_t seq, ms; };
static struct hb2 *hb2; /* obs_page + OFF_HB2 */
static uint64_t g_t0;  /* probe start (abs ms) for rel prints */

#if defined(__x86_64__)
static inline uint64_t raw_tsc(void) {
    unsigned lo, hi;
    __asm__ __volatile__("lfence\n rdtsc" : "=a"(lo), "=d"(hi));
    return ((uint64_t)hi << 32) | lo;
}
#else
static inline uint64_t raw_tsc(void) { return 0; }
#endif

/* signal watchdog verdict fired? (set in handler to stop main loop) */
static volatile sig_atomic_t sig_verdict;
static void sig_alarm_handler(int sig);
static pthread_cond_t *C1;  /* spawn queue cond */
static pthread_mutex_t *U;
static pthread_cond_t *CU;
static pthread_cond_t C2;   /* static bss, like GLib's spawn_thread_cond */

/* Quiet ranges for canary checks (offset,len): everything except the
 * live lock/cond words (M 0x100+40, C1 0x1a0+48, U 0x300+40, CU
 * 0x3a0+48), the history ring at 0x800 and the tripwire at 0xF80. */
static const struct { int off, len; } quiet[] = {
    {0x000, 0x100}, {0x128, OFF_C1 - 0x128}, {OFF_C1 + 48, OFF_U - OFF_C1 - 48},
    {OFF_U + 40, OFF_CU - OFF_U - 40}, {OFF_CU + 48, OFF_RING - OFF_CU - 48},
    {OFF_RING + RING_BYTES, OFF_TRIP - OFF_RING - RING_BYTES},
};

/* ---------------- thread registry (shadow ledger) ---------------- */
struct reg {
    long tid;
    char name[16];
    const char *state; /* park point / section */
    int holds_M;
    int holds_U;
    int holds_P;
};
static struct reg registry[REG_MAX];
static _Atomic int reg_cnt;

static __thread struct reg *myreg;

/* global M-op counters (progress) */
static _Atomic long m_ops, tasks_done, spawns_done, worker_exits;
static _Atomic long pools_created, pools_freed;

/* ---------------- tiny helpers ---------------- */
static long tidof(void) { return syscall(SYS_gettid); }
static uint64_t now_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}
static void out(const char *fmt, ...) {
    char buf[512];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(buf, sizeof buf, fmt, ap);
    va_end(ap);
    if (n > 0) {
        ssize_t r = write(1, buf, (size_t)n);
        (void)r;
    }
}
static void reg_thread(const char *name) {
    int i = atomic_fetch_add(&reg_cnt, 1);
    if (i >= REG_MAX) return;
    registry[i].tid = tidof();
    snprintf(registry[i].name, sizeof registry[i].name, "%s", name);
    registry[i].state = "start";
    myreg = &registry[i];
}

/* ---------------- async queue mimic (gasyncqueue.c) ---------------- */
#define QITEMS 4096
struct aq {
    pthread_cond_t *cond;
    int waiting_threads;
    void *items[QITEMS]; /* ring: push at head-index grows down, pop tail */
    int head, tail;      /* items[tail..head) live; length = head-tail */
};
static void aq_push_unlocked(struct aq *q, void *d) {
    q->items[q->head++ % QITEMS] = d;
    if (q->waiting_threads > 0) pthread_cond_signal(q->cond);
}
static int aq_len_unlocked(const struct aq *q) { return q->head - q->tail; }
/* g_async_queue_length(): items - waiting threads (can go negative) */
static int aq_length_unlocked(const struct aq *q) {
    return (q->head - q->tail) - q->waiting_threads;
}
/* pop_intern_unlocked: wait-dance under caller's held mutex. holds_flag
 * points at the caller's ledger flag for THAT mutex (holds_M/P/U) so
 * the shadow ownership stays exact across the internal release and
 * re-acquire. NULL = no ledger. */
static void *aq_pop_intern_unlocked(struct aq *q, pthread_mutex_t *mut,
                                    const char *waitstate,
                                    int64_t deadline_ms /* -1 = forever */,
                                    int *holds_flag) {
    void *rv = NULL;
    if (aq_len_unlocked(q) == 0 && deadline_ms != -2 /* -2 = no wait */) {
        q->waiting_threads++;
        while (aq_len_unlocked(q) == 0) {
            if (deadline_ms < 0) {
                if (myreg) myreg->state = waitstate;
                if (holds_flag) *holds_flag = 0; /* released inside */
                pthread_cond_wait(q->cond, mut);
                if (holds_flag) *holds_flag = 1; /* re-acquired */
                if (myreg) myreg->state = "reacq";
            } else {
                struct timespec ts = {deadline_ms / 1000,
                                      (deadline_ms % 1000) * 1000000};
                if (myreg) myreg->state = waitstate;
                if (holds_flag) *holds_flag = 0;
                int rc = pthread_cond_timedwait(q->cond, mut, &ts);
                if (holds_flag) *holds_flag = 1;
                if (myreg) myreg->state = "reacq";
                if (rc == ETIMEDOUT) break;
            }
        }
        q->waiting_threads--;
    }
    if (aq_len_unlocked(q) > 0)
        rv = q->items[q->tail++ % QITEMS];
    return rv;
}

/* the global spawn queue and global pool queue */
static struct aq spawn_q = {.cond = NULL};
static struct aq unused_q = {.cond = NULL};
static _Atomic int unused_threads;
static _Atomic int kill_unused_threads;
static _Atomic int wakeup_thread_serial;
static void *wakeup_thread_marker = (void *)1;

/* SIGALRM backup watchdog: if the main watchdog is itself wedged (e.g.
 * parked forever in clock_nanosleep), this still fires. Counts 3s
 * alarms with the M word held; after 6 (18s) prints the verdict and
 * exits — the main watchdog would have exited sooner if alive. */
static void sig_alarm_handler(int sig) {
    (void)sig;
    if (sig_verdict) return;
    int word = *(volatile int *)(obs_page + OFF_M);
    static int held_alarms; /* handler context: single-threaded */
    if (word != 0)
        held_alarms++;
    else
        held_alarms = 0;
    if (held_alarms < 6) return;
    sig_verdict = 1;
    int holders = 0;
    long hid = 0;
    const char *hst = "?";
    int n = atomic_load(&reg_cnt);
    if (n > REG_MAX) n = REG_MAX;
    for (int i = 0; i < n; i++)
        if (registry[i].holds_M) {
            holders++;
            hid = registry[i].tid;
            hst = registry[i].state;
        }
    out("GAREPRO-SIG-WATCHDOG main-watchdog-silent word=%d holders=%d "
        "holder=%ld state=%s\n", word, holders, hid, hst);
    int rc = holders == 0 ? 42 : 43;
    _exit(rc);
}

/* ---------------- M wrappers (shadow ledger) ---------------- */
static void M_lock(const char *st) {
    pthread_mutex_lock(M);
    if (myreg) { myreg->holds_M = 1; myreg->state = st; }
    atomic_fetch_add(&m_ops, 1);
}
static void M_unlock(void) {
    if (myreg) { myreg->state = "M-rel"; myreg->holds_M = 0; }
    pthread_mutex_unlock(M);
    atomic_fetch_add(&m_ops, 1);
}
/* cond_wait on C2 with M held (requester) */
static void C2_wait_M(void) {
    if (myreg) { myreg->state = "C2-wait(M-free)"; myreg->holds_M = 0; }
    pthread_cond_wait(&C2, M);
    if (myreg) { myreg->holds_M = 1; myreg->state = "C2-reacq-M"; }
}

/* ---------------- pool (gthreadpool worker side) ---------------- */
struct pool {
    struct aq q;             /* task queue: cond CP, mutex P */
    pthread_mutex_t P;       /* pool queue mutex (glib: g_async_queue_lock) */
    pthread_cond_t poolcond; /* glib pool->cond for free() waiters */
    _Atomic int num_threads;
    int running, immediate, waiting, max_threads;
};
static _Atomic int pools_alive;

static void *wait_for_new_pool(void); /* below */

/* worker thread body — g_thread_pool_thread_proxy */
static void *worker_main(void *arg) {
    struct pool *pool = arg;
    reg_thread("pool");
    pthread_mutex_lock(&pool->P);
    if (myreg) { myreg->holds_P = 1; myreg->state = "P-held"; }
    for (;;) {
        void *task = NULL;
        /* wait_for_new_task: shared pool -> 0.5s timed pop */
        if (pool->running ||
            (!pool->immediate && aq_len_unlocked(&pool->q) > 0)) {
            if (pool->max_threads != -1 &&
                atomic_load(&pool->num_threads) > pool->max_threads) {
                /* superfluous: fall through to global pool */
            } else {
                uint64_t dl = now_ms() + POP_MS;
                task = aq_pop_intern_unlocked(&pool->q, &pool->P,
                                              "CP-task-wait(P-free)",
                                              (int64_t)dl,
                                              myreg ? &myreg->holds_P : NULL);
            }
        }
        if (task && task != wakeup_thread_marker) {
            pthread_mutex_unlock(&pool->P);
            if (myreg) { myreg->holds_P = 0; myreg->state = "task-run"; }
            atomic_fetch_add(&tasks_done, 1);
            /* the "work": 1-8ms busy wait — keeps workers busy so
             * concurrent pushes spill into start_thread (the M dance) */
            {
                uint64_t until = now_ms() + 1 + ((uintptr_t)task & 7);
                while (now_ms() < until) sched_yield();
            }
            pthread_mutex_lock(&pool->P);
            if (myreg) { myreg->holds_P = 1; }
        } else {
            /* leave for the global pool (glib :342-409) */
            int free_pool = 0;
            atomic_fetch_sub(&pool->num_threads, 1);
            if (!pool->running) {
                if (!pool->waiting) {
                    if (atomic_load(&pool->num_threads) == 0)
                        free_pool = 1;
                    else if (aq_len_unlocked(&pool->q) ==
                             -atomic_load(&pool->num_threads)) {
                        /* wakeup_and_stop_all */
                        pool->immediate = 1;
                        for (int i = 0; i < atomic_load(&pool->num_threads); i++)
                            aq_push_unlocked(&pool->q, wakeup_thread_marker);
                    }
                } else if (pool->immediate || aq_len_unlocked(&pool->q) <= 0) {
                    pthread_cond_broadcast(&pool->poolcond);
                }
            }
            atomic_fetch_add(&unused_threads, 1);
            pthread_mutex_unlock(&pool->P);
            if (myreg) { myreg->holds_P = 0; myreg->state = "left-pool"; }
            if (free_pool) {
                pthread_mutex_destroy(&pool->P);
                pthread_cond_destroy(&pool->poolcond);
                free(pool);
                atomic_fetch_add(&pools_freed, 1);
            }
            pool = wait_for_new_pool();
            atomic_fetch_sub(&unused_threads, 1);
            if (!pool) break;
            pthread_mutex_lock(&pool->P);
            if (myreg) { myreg->holds_P = 1; }
        }
    }
    if (myreg) myreg->state = "exited";
    atomic_fetch_add(&worker_exits, 1);
    return NULL;
}

/* wait_for_new_pool (glib :140-223): timeout pop on U + marker relay */
static void *wait_for_new_pool(void) {
    void *pool = NULL;
    int last_serial = atomic_load(&wakeup_thread_serial);
    int relayed = 0;
    for (;;) {
        if (atomic_load(&unused_threads) >= MAX_UNUSED) return NULL;
        uint64_t dl = now_ms() + IDLE_MS;
        pthread_mutex_lock(U);
        if (myreg) { myreg->holds_U = 1; myreg->state = "U-held"; }
        pool = aq_pop_intern_unlocked(&unused_q, U, "CU-pop-wait(U-free)",
                                      (int64_t)dl,
                                      myreg ? &myreg->holds_U : NULL);
        pthread_mutex_unlock(U);
        if (myreg) { myreg->holds_U = 0; }
        if (pool != wakeup_thread_marker) return pool;
        int ser = atomic_load(&wakeup_thread_serial);
        if (last_serial == ser) {
            if (!relayed) {
                pthread_mutex_lock(U);
                aq_push_unlocked(&unused_q, wakeup_thread_marker);
                pthread_mutex_unlock(U);
                relayed = 1;
                usleep(100); /* glib's relay backoff */
            }
        } else {
            if (atomic_fetch_add(&kill_unused_threads, -1) > 0)
                return NULL;
            last_serial = ser;
            relayed = 0;
        }
    }
}

/* ---------------- spawner (g_thread_pool_spawn_thread :279) -------- */
struct spawn_data { /* lives on the REQUESTER'S stack, like glib :460 */
    struct pool *pool;
    pthread_t thread_out; /* written by spawner under M */
    int done;
    int err;
};
static pthread_attr_t detached_attr;
static void *spawner_main(void *arg) {
    (void)arg;
    reg_thread("pool-spawner");
    for (;;) {
        M_lock("spawner:M-held");
        struct spawn_data *sd = aq_pop_intern_unlocked(
            &spawn_q, M, "C1-pop-wait(M-free)", -1,
            myreg ? &myreg->holds_M : NULL);
        /* still holding M: clone the worker (glib :298; glib's thread is
         * created joinable and unref'd by the requester — the detach
         * attribute is the raw-pthreads equivalent, and keeps the
         * spawner from touching sd after M_unlock) */
        if (myreg) myreg->state = "clone-holding-M";
        sd->err = pthread_create(&sd->thread_out, &detached_attr,
                                 worker_main, sd->pool);
        sd->done = 1;
        atomic_fetch_add(&spawns_done, 1);
        if (myreg) myreg->state = "bcast-C2-holding-M";
        pthread_cond_broadcast(&C2); /* glib :303 */
        M_unlock();
    }
    return NULL;
}

/* ---------------- start_thread (glib :415-487) --------------------- */
static int start_thread(struct pool *pool) {
    if (pool->max_threads != -1 &&
        atomic_load(&pool->num_threads) >= pool->max_threads)
        return 1;
    int ok = 0;
    pthread_mutex_lock(U);
    if (myreg) { myreg->holds_U = 1; myreg->state = "U-held"; }
    if (aq_length_unlocked(&unused_q) < 0) {
        aq_push_unlocked(&unused_q, pool);
        ok = 1;
    }
    pthread_mutex_unlock(U);
    if (myreg) myreg->holds_U = 0;
    if (!ok) {
        struct spawn_data sd = {pool, 0, 0, 0};
        M_lock("req:M-held");
        aq_push_unlocked(&spawn_q, &sd);
        while (!sd.done) C2_wait_M();
        M_unlock();
        if (sd.err) return 0; /* sd still valid: read before M_unlock? no —
                                 read AFTER unlock is safe: spawner wrote
                                 sd only under M and is past it */
    }
    atomic_fetch_add(&pool->num_threads, 1); /* glib :484 */
    return 1;
}

/* g_thread_pool_push (:682-715): P held across start_thread */
static void pool_push(struct pool *pool, void *task) {
    pthread_mutex_lock(&pool->P);
    if (myreg) { myreg->holds_P = 1; myreg->state = "P-held"; }
    if (aq_length_unlocked(&pool->q) >= 0) {
        if (!start_thread(pool)) {
            pthread_mutex_unlock(&pool->P);
            if (myreg) myreg->holds_P = 0;
            return; /* spawn error: task dropped (glib keeps it; error
                       path not needed for the freeze shape) */
        }
    }
    aq_push_unlocked(&pool->q, task);
    pthread_mutex_unlock(&pool->P);
    if (myreg) { myreg->holds_P = 0; myreg->state = "pushed"; }
}

static struct pool *pool_new(int max_threads) {
    struct pool *p = calloc(1, sizeof *p);
    pthread_mutex_init(&p->P, NULL);
    pthread_cond_init(&p->poolcond, NULL);
    p->q.cond = &p->poolcond; /* same cond object for queue + pool wait */
    /* NOTE: glib uses queue->cond for pop and pool->cond for free wait;
     * sharing one cond preserves both wake paths with one object. */
    p->running = 1;
    p->max_threads = max_threads;
    atomic_fetch_add(&pools_alive, 1);
    atomic_fetch_add(&pools_created, 1);
    return p;
}

/* simplified g_thread_pool_free(immediate=1, wait=0) */
static void pool_free(struct pool *p) {
    pthread_mutex_lock(&p->P);
    if (myreg) { myreg->holds_P = 1; }
    p->running = 0;
    p->immediate = 1;
    int nt = atomic_load(&p->num_threads);
    if (aq_len_unlocked(&p->q) == -nt || nt == 0) {
        if (nt == 0) {
            pthread_mutex_unlock(&p->P);
            if (myreg) myreg->holds_P = 0;
            pthread_mutex_destroy(&p->P);
            pthread_cond_destroy(&p->poolcond);
            free(p);
            atomic_fetch_sub(&pools_alive, 1);
            atomic_fetch_add(&pools_freed, 1);
            return;
        }
        p->immediate = 1;
        for (int i = 0; i < nt; i++)
            aq_push_unlocked(&p->q, wakeup_thread_marker);
    }
    pthread_mutex_unlock(&p->P);
    if (myreg) myreg->holds_P = 0;
    atomic_fetch_sub(&pools_alive, 1); /* freed by last worker */
}

/* ---------------- pushers, pollers, cleanup ------------------------ */
static void *pusher_main(void *arg) {
    long id = (long)arg;
    char nm[16];
    snprintf(nm, sizeof nm, "pusher%ld", id);
    reg_thread(nm);
    struct pool *pools[8] = {0};
    unsigned seed = (unsigned)(id * 7919 + 13);
    uint64_t next_churn = now_ms() + 50 + (seed % 200);
    for (;;) {
        pools[0] = pools[0] ? pools[0] : pool_new(-1);
        /* burst: 2-6 back-to-back pushes (spawns when all workers are
         * busy), then a lull long enough for workers to idle out of
         * the pool into the global queue and get killed by the marker
         * rounds — the udisksd probe/churn rhythm */
        for (unsigned b = 0, n = 2 + (seed % 5); b < n; b++)
            pool_push(pools[0], (void *)(uintptr_t)(seed++));
        if (now_ms() > next_churn) {
            /* churn: free an old pool, start a new one; sometimes via a
             * second pool to nest different P instances */
            if (pools[1]) { pool_free(pools[1]); pools[1] = NULL; }
            pools[1] = pool_new(-1);
            pool_push(pools[1], (void *)(uintptr_t)(seed++));
            next_churn = now_ms() + 50 + (seed % 300);
        }
        usleep(3000 + (seed % 30000)); /* 3-33ms between bursts */
    }
    return NULL;
}

static int wake_pipe[2];
static struct pool *poller_pool; /* created lazily by first poller */
static pthread_mutex_t poller_pool_mu = PTHREAD_MUTEX_INITIALIZER;
static void *poller_main(void *arg) {
    long id = (long)arg;
    char nm[16];
    snprintf(nm, sizeof nm, "gmain%ld", id);
    reg_thread(nm);
    unsigned seed = (unsigned)(id * 104729 + 7);
    for (;;) {
        struct pollfd pfd = {.fd = wake_pipe[0], .events = POLLIN};
        if (myreg) myreg->state = "poll-pipe";
        poll(&pfd, 1, 30 + (int)(id * 25));
        if (id == 0) { /* the witness heartbeat */
            hb2->seq = hb2->seq + 1;
            hb2->ms = now_ms();
        }
        /* occasionally act like a gmain source: push a task */
        if ((++seed & 15) == 0) {
            pthread_mutex_lock(&poller_pool_mu);
            if (!poller_pool) poller_pool = pool_new(-1);
            pthread_mutex_unlock(&poller_pool_mu);
            if (myreg) myreg->state = "gmain-push";
            pool_push(poller_pool, (void *)(uintptr_t)(seed));
        }
    }
    return NULL;
}

/* cleanup thread: periodic g_thread_pool_stop_unused_threads() mimic
 * (kill markers + serial bump, glib :1045+) */
static void *cleanup_main(void *arg) {
    (void)arg;
    reg_thread("cleanup");
    for (;;) {
        usleep(700000);
        if (myreg) myreg->state = "cleanup-round";
        int unused = atomic_load(&unused_threads);
        atomic_fetch_add(&kill_unused_threads, unused);
        atomic_fetch_add(&wakeup_thread_serial, 1);
        pthread_mutex_lock(U);
        if (myreg) { myreg->holds_U = 1; myreg->state = "U-held"; }
        aq_push_unlocked(&unused_q, wakeup_thread_marker);
        pthread_mutex_unlock(U);
        if (myreg) myreg->holds_U = 0;
        if (myreg) myreg->state = "poll-idle";
        struct pollfd pfd = {.fd = wake_pipe[0], .events = POLLIN};
        poll(&pfd, 1, 100);
    }
    return NULL;
}

/* ---------------- watchdog + verdict ------------------------------- */
struct hring { uint64_t ms_abs; uint64_t mops; int word; int holders; };
static struct hring *ring; /* obs_page + OFF_RING */
static int ring_i;

static int canary_scan(int *off_out) {
    for (unsigned r = 0; r < sizeof quiet / sizeof quiet[0]; r++)
        for (int i = 0; i < quiet[r].len; i += 8) {
            uint64_t v;
            memcpy((void *)&v, (const void *)(obs_page + quiet[r].off + i), 8);
            if (v != 0 && !(quiet[r].off == 0 && v == 0xA5A5A5A5A5A5A5A5ULL))
                { *off_out = quiet[r].off + i; return 1; }
        }
    return 0;
}

static void dump_all(const char *why) {
    out("GAREPRO-DUMP reason=%s time=%llums(rel %llu) word=%d ownerlatch=%ld\n",
        why, (unsigned long long)now_ms(),
        (unsigned long long)(now_ms() - g_t0),
        *(volatile int *)(obs_page + OFF_M), (long)0);
    out("counters m_ops=%ld tasks=%ld spawns=%ld wexit=%ld pools(c/f/a)=%ld/%ld/%d\n",
        atomic_load(&m_ops), atomic_load(&tasks_done),
        atomic_load(&spawns_done), atomic_load(&worker_exits),
        atomic_load(&pools_created), atomic_load(&pools_freed),
        atomic_load(&pools_alive));
    out("tripwire seq=%llu prog_abs=%llu mops=%llu ring_i=%llu (page) "
        "witness seq=%llu ms=%llu age=%lldms tsc=%llu\n",
        (unsigned long long)tr->seq, (unsigned long long)tr->prog_abs,
        (unsigned long long)tr->mops, (unsigned long long)tr->ring_i,
        (unsigned long long)hb2->seq, (unsigned long long)hb2->ms,
        (long long)now_ms() - (long long)hb2->ms,
        (unsigned long long)raw_tsc());
    int n = atomic_load(&reg_cnt);
    if (n > REG_MAX) n = REG_MAX;
    out("threads (%d):\n", n);
    for (int i = 0; i < n; i++)
        out("  tid=%-6ld %-14s M=%d U=%d P=%d state=%s\n",
            registry[i].tid, registry[i].name, registry[i].holds_M,
            registry[i].holds_U, registry[i].holds_P,
            registry[i].state ? registry[i].state : "?");
    out("M word history (oldest first):\n");
    for (int k = 0; k < RING_N; k++) {
        struct hring *h = &ring[(ring_i + k) % RING_N];
        if (h->ms_abs)
            out("  t=%llu mops=%llu word=%d holders=%d\n",
                (unsigned long long)h->ms_abs,
                (unsigned long long)h->mops, h->word, h->holders);
    }
}

int main(void) {
    setvbuf(stdout, NULL, _IONBF, 0);
    /* tid map for the initial thread set (workers come later; the
     * freeze dump lists them) — lets kernel census tids be mapped to
     * roles without waiting for a dump */
    out("GAREPRO-THREADS main=%ld\n", tidof());
    obs_page = mmap((void *)PAGE_VA, 4096, PROT_READ | PROT_WRITE,
                    MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
    if (obs_page == MAP_FAILED) {
        out("GAREPRO-FAIL mmap errno=%d\n", errno);
        return 9;
    }
    memset((void *)obs_page, 0, 4096);
    *(uint64_t *)(obs_page + 0) = 0xA5A5A5A5A5A5A5A5ULL; /* guard */
    M = (pthread_mutex_t *)(obs_page + OFF_M);
    C1 = (pthread_cond_t *)(obs_page + OFF_C1);
    U = (pthread_mutex_t *)(obs_page + OFF_U);
    CU = (pthread_cond_t *)(obs_page + OFF_CU);
    pthread_mutex_init(M, NULL); /* g_mutex_impl_new: default (NORMAL) */
    pthread_cond_init(C1, NULL);
    pthread_cond_init(&C2, NULL);
    pthread_mutex_init(U, NULL);
    pthread_cond_init(CU, NULL);
    ring = (struct hring *)(obs_page + OFF_RING);
    memset((void *)ring, 0, RING_N * sizeof(struct hring));
    tr = (struct trip *)(obs_page + OFF_TRIP);
    memset((void *)tr, 0, sizeof *tr);
    hb2 = (struct hb2 *)(obs_page + OFF_HB2);
    memset((void *)hb2, 0, sizeof *hb2);
    spawn_q.cond = C1;
    unused_q.cond = CU;
    pthread_attr_init(&detached_attr);
    pthread_attr_setdetachstate(&detached_attr, PTHREAD_CREATE_DETACHED);
    if (pipe(wake_pipe)) wake_pipe[0] = wake_pipe[1] = -1;

    reg_thread("main");
    out("GAREPRO-START secs=%d pushers=%d M=%p C1=%p C2=%p U=%p CU=%p\n",
        PROBE_SECS, N_PUSHERS, (void *)M, (void *)C1, (void *)&C2,
        (void *)U, (void *)CU);

    pthread_t th;
    pthread_create(&th, NULL, spawner_main, NULL);
    pthread_detach(th);
    for (long i = 0; i < N_PUSHERS; i++) {
        pthread_create(&th, NULL, pusher_main, (void *)i);
        pthread_detach(th);
    }
    pthread_create(&th, NULL, poller_main, (void *)0);
    pthread_detach(th);
    pthread_create(&th, NULL, poller_main, (void *)1);
    pthread_detach(th);
    pthread_create(&th, NULL, cleanup_main, NULL);
    pthread_detach(th);

    /* tid map: registry entries 1.. = spawner, pushers, gmain, cleanup */
    {
        char map[256];
        int len = snprintf(map, sizeof map, "GAREPRO-THREADS");
        int n = atomic_load(&reg_cnt);
        if (n > 12) n = 12;
        for (int i = 1; i < n; i++)
            len += snprintf(map + len, sizeof map - len, " %s=%ld",
                            registry[i].name, registry[i].tid);
        snprintf(map + len, sizeof map - len, "\n");
        ssize_t r = write(1, map, strlen(map));
        (void)r;
    }
#ifndef ALARM_US
#define ALARM_US 3000000 /* default: one SIGALRM every 3 s */
#endif
#ifndef NO_ALARM
    signal(SIGALRM, sig_alarm_handler);
    ualarm(ALARM_US, ALARM_US);
#endif

    /* watchdog: 250ms tick */
    int phantom_ticks = 0, stable_word_ticks = 0, last_word = 0;
    uint64_t t0 = now_ms(), last_progress_t = t0;
    g_t0 = t0;
    long last_m_ops = 0;
    int beat = 0;
    uint64_t prev_now = t0; /* clock-step detector */
    for (;;) {
        usleep(250000);
        /* page-side state from the PREVIOUS tick (register-rewind
         * cross-check: registers can go stale, the page cannot) */
        uint64_t pg_seq = tr->seq, pg_prog = tr->prog_abs, pg_mops = tr->mops;
        uint64_t now = now_ms();
        if (++beat >= 20) { /* 5s heartbeat: proves watchdog liveness */
            beat = 0;
            out("GAREPRO-ALIVE t=%llu word=%d mops=%ld tasks=%ld\n",
                (unsigned long long)(now - t0),
                *(volatile int *)(obs_page + OFF_M),
                atomic_load(&m_ops), atomic_load(&tasks_done));
        }
        /* backward clock step: the old unsigned STALL compare wrapped
         * on exactly this and fired a bogus 30s verdict instantly */
        if (now + 50 < prev_now)
            out("GAREPRO-CLOCK-BACK prev=%llu now=%llu d=%lld tsc=%llu\n",
                (unsigned long long)prev_now, (unsigned long long)now,
                (long long)now - (long long)prev_now,
                (unsigned long long)raw_tsc());
        prev_now = now;
        int word = *(volatile int *)(obs_page + OFF_M);
        int holders = 0, holder_tid = 0;
        const char *holder_state = NULL;
        int n = atomic_load(&reg_cnt);
        if (n > REG_MAX) n = REG_MAX;
        for (int i = 0; i < n; i++)
            if (registry[i].holds_M) {
                holders++;
                holder_tid = registry[i].tid;
                holder_state = registry[i].state;
            }
        ring[ring_i].ms_abs = now;
        ring[ring_i].mops = (uint64_t)atomic_load(&m_ops);
        ring[ring_i].word = word;
        ring[ring_i].holders = holders;
        ring_i = (ring_i + 1) % RING_N;

        int off;
        if (canary_scan(&off)) {
            dump_all("CANARY");
            out("GAREPRO-CANARY offset=0x%x\n", off);
            return 45;
        }
        if (word != 0 && holders == 0)
            phantom_ticks++;
        else
            phantom_ticks = 0;
        if (phantom_ticks >= 12) { /* 3s of stable phantom */
            dump_all("PHANTOM");
            out("GAREPRO-PHANTOM word=%d for 3s, no holder believes\n", word);
            return 42;
        }
        if (holders > 1) {
            dump_all("DOUBLE");
            out("GAREPRO-DOUBLE-HOLD holders=%d\n", holders);
            return 46;
        }
        if (word == last_word && word != 0)
            stable_word_ticks++;
        else
            stable_word_ticks = 0;
        last_word = word;
        if (stable_word_ticks >= 60) { /* 15s frozen word */
            dump_all("OWNER-PARKED");
            out("GAREPRO-OWNER-PARKED word=%d holder=%ld state=%s\n",
                word, (long)holder_tid, holder_state ? holder_state : "?");
            return 43;
        }
        long mo = atomic_load(&m_ops);
        if (mo != last_m_ops) {
            last_m_ops = mo;
            last_progress_t = now_ms();
        }
        /* publish the shadow AFTER the register update, so the page
         * reflects this tick's adjudication; a rewind between ticks
         * leaves pg_* (read at loop top) telling the true story */
        tr->seq = pg_seq + 1;
        tr->prog_abs = last_progress_t;
        tr->mops = (uint64_t)mo;
        tr->ring_i = (uint64_t)ring_i;
        int64_t reg_stall = (int64_t)(now - last_progress_t);
        int64_t pg_stall = (int64_t)(now - pg_prog);
        /* witness: independent thread (poller0), page-stamped every
         * ~30ms; immune to a monitor-context rewind */
        int64_t wit_age = (int64_t)(now - hb2->ms);
        if (reg_stall > 30000 && (pg_stall <= 30000 || wit_age < 30000)) {
            /* register state claims 30s stale; the page shadow and/or
             * the witness say progress happened recently: the monitor
             * resumed from a stale context snapshot */
            dump_all("REG-REWIND");
            out("GAREPRO-REG-REWIND reg_lastprog=%llu page_lastprog=%llu "
                "reg_mops=%ld page_mops=%llu now=%llu seq=%llu wit_age=%lld\n",
                (unsigned long long)last_progress_t,
                (unsigned long long)pg_prog, last_m_ops,
                (unsigned long long)pg_mops,
                (unsigned long long)now,
                (unsigned long long)pg_seq, (long long)wit_age);
            return 47;
        }
        if (reg_stall > 30000) {
            dump_all("STALL");
            out("GAREPRO-STALL word=%d holders=%d (page+witness agree: "
                "genuine total freeze) wit_age=%lld\n",
                word, holders, (long long)wit_age);
            return 44;
        }
        if ((int64_t)(now - t0) > (int64_t)PROBE_SECS * 1000) {
            dump_all("PASS");
            out("GAREPRO-PASS\n");
            return 0;
        }
    }
}
