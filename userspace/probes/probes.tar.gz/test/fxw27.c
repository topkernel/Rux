#define _GNU_SOURCE
#include <sys/mman.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>
// fxw27 — minimal: fdwrite prefill -> MAPWRITE one page -> msync -> munmap
// -> fd read-back. Which face does the fd read see?
int main(void){
    int fd = open("/dev/shm/fxw27", O_RDWR|O_CREAT|O_TRUNC, 0666);
    if (ftruncate(fd, 0x40000)) return 2;
    // prefill whole file via fd (node + bridge)
    char w[0x1000];
    for (int pg = 0; pg < 0x40; pg++) {
        for (int k=0;k<0x1000;k++) w[k] = 'A' + ((pg*0x1000+k)%26);
        if (pwrite(fd, w, 0x1000, pg*0x1000) != 0x1000) { printf("prefill fail pg=%d\n", pg); return 3; }
    }
    // mapwrite page 0x30 exactly like fsx: own mmap, write, msync, munmap
    long off = 0x3091c, size = 0x1000;
    if (off + size > 0x40000) return 4;
    char *p = mmap(NULL, 0x2000, PROT_READ|PROT_WRITE, MAP_FILE|MAP_SHARED, fd, 0x30000);
    if (p == MAP_FAILED) { printf("mmap fail %d\n", errno); return 5; }
    char *q = p + 0x91c;
    for (long k=0;k<size;k++) q[k] = 'a' + ((off+k)%26);
    if (msync(p, 0x2000, MS_SYNC)) { printf("msync fail %d\n", errno); return 6; }
    munmap(p, 0x2000);
    // read back
    char rb[0x1000];
    int r = pread(fd, rb, 0x1000, 0x30900);
    printf("r=%d byte@3091c=%c (want %c) byte@30900=%c\n",
           r, rb[0x1c], (char)('a'+(0x3091c%26)), rb[0]);
    // and mapread back
    char *m = mmap(NULL, 0x1000, PROT_READ, MAP_FILE|MAP_SHARED, fd, 0x30000);
    if (m != MAP_FAILED) {
        printf("mapread@3091c=%c\n", m[0x91c]);
        munmap(m, 0x1000);
    }
    return 0;
}
