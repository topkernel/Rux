#define _GNU_SOURCE
#include <sys/mman.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
// fsx replica v7 (v6 was over-strict: it verified beyond file_size,
// where the reference kernel SIGBUSes — host fxw24 died rc=135). fsx
// NEVER checks beyond its tracked file_size: writes and verifies stay
// INSIDE size. This replica tracks cur_size and constrains every op
// exactly like fsx: map write / fd write / verify all <= cur_size;
// truncate sets cur_size; model zeroes [off, end) on truncate.
int main(void){
    srand48(777);
    int fd = open("/dev/shm/fxw25", O_RDWR|O_CREAT|O_TRUNC, 0666);
    if (ftruncate(fd, 0x40000)) return 2;
    long cur_size = 0x40000;
    char *p = mmap(NULL, 0x40000, PROT_READ|PROT_WRITE, MAP_FILE|MAP_SHARED, fd, 0);
    static char sizechk[0x40000];
    memset(sizechk, 0, sizeof sizechk);
    int fails = 0;
    for (int i = 0; i < 1000; i++) {
        long op = lrand48() % 6;
        long size = 1 + lrand48() % 0x10000;
        long off = lrand48() % 0x38000;   // BYTE-granular offsets
        if (op == 2) {  // truncate (fsx: file_size = off, may shrink or grow)
            if (ftruncate(fd, off)) fails++;
            if (off < cur_size)
                for (long k=off;k<0x40000;k++) sizechk[k]=0;
            cur_size = off;
        } else if (op == 3) {
            if (msync(p, 0x40000, MS_SYNC)) fails++;
        } else {
            if (off >= cur_size) continue;          // fsx ops stay in size
            if (op >= 4) size = 64;                  // verify window (op 4/5)
            if (off + size > cur_size) continue;
            if (op == 0) {  // map write
                for (long k=0;k<size;k++) p[off+k] = 'A' + ((off+k)%26);
                for (long k=0;k<size;k++) sizechk[off+k] = 'A' + ((off+k)%26);
            } else if (op == 1) {  // fd write
                char w[0x10000];
                for (long k=0;k<size;k++) w[k] = 'C' + ((off+k)%26);
                lseek(fd, off, SEEK_SET);
                if (write(fd, w, size) != size) { printf("fdw fail %d off=%lx sz=%lx\n", errno, off, size); fails++; break; }
                for (long k=0;k<size;k++) sizechk[off+k] = 'C' + ((off+k)%26);
            } else {  // VERIFY both paths at an unaligned offset (in size)
                if (memcmp(p+off, sizechk+off, size) != 0) {
                    printf("MAP-MISMATCH off=%lx i=%d size=%lx\n", off, i, cur_size); fails++;
                    if (fails > 4) break;
                }
                char rb[64];
                lseek(fd, off, SEEK_SET);
                int r = read(fd, rb, size);
                if (r != (int)size || memcmp(rb, sizechk+off, size) != 0) {
                    printf("FD-MISMATCH off=%lx i=%d r=%d size=%lx\n", off, i, r, cur_size); fails++;
                    if (fails > 4) break;
                }
            }
        }
    }
    printf("fails=%d\n", fails);
    return fails > 4 ? 1 : 0;
}
