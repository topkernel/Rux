/*
 * rtbench.c — real-time latency battery (rt-2x lane, run/RT-2X.md).
 *
 * One static musl x86_64 binary that runs IDENTICALLY on the Rux
 * kernel and on the reference kernel (the OHOS 6.6.101 bzImage), so
 * every number is a same-binary pair. Runs as PID 1 (init=/test/rtbench
 * on Rux; init=/test/rtinit wrapper on the reference, which mounts
 * /proc and execs this binary).
 *
 * Metrics (one RTB line each; lower is better unless noted):
 *   cal              TSC calibration vs CLOCK_MONOTONIC_RAW (3x50 ms, med)
 *   t_rel_100us      relative nanosleep(100us) OVERSHOOT x N=10k
 *   t_rel_1ms        relative nanosleep(1ms)   OVERSHOOT x N=10k
 *   t_rel_10ms       relative nanosleep(10ms)  OVERSHOOT x N=5000
 *   t_abs_1ms        ABSTIME sleep-to-deadline LATENESS x N=10k
 *                    (min = timer fire -> user resume floor, the
 *                    interrupt-to-handler observable)
 *   t_abs_10ms       same at 10ms, N=2000
 *   w_futex_xcpu     futex wake->run, waker CPU0 -> waiter CPU1 idle, N=20k
 *   w_futex_xcpu_rt  same, waiter SCHED_FIFO(98), N=20k
 *   w_futex_wakesys  the futex(WAKE) syscall duration itself (waker side)
 *   w_futex_samecpu  wake->run, both threads CPU0 (yield/switch path), N=10k
 *   rt_preempt       FIFO(98) waiter woken by CPU0 while a SCHED_OTHER
 *                    spinner burns its CPU (user mode), N=5000 — the
 *                    wakeup-preemption latency
 *   fair_8x8 / fair_8x16  8 spinners on an 8-CPU rig (uncontended
 *                    placement) / 16 spinners (2x oversubscribed):
 *                    Jain fairness index + max/min spread + total rate
 *                    (higher Jain and lower spread are better)
 *
 * All wake pairs use the sequence-number futex protocol (no lost
 * wakeups, no stale-ready races): waiter publishes seq=V then futex
 * waits on the word while it still equals V; waker waits for V,
 * stamps t0, stores V+1, wakes. If the waiter is descheduled between
 * publish and wait, the kernel value check fails fast and it proceeds
 * with a fresh t0 — the sample stays honest.
 *
 * Timing: rdtsc deltas, calibrated per-run against
 * CLOCK_MONOTONIC_RAW (nr 4) — same convention as pbench.c. For the
 * ABSTIME bench the anchor is CLOCK_MONOTONIC (the sleep clock)
 * captured once as a (mono_ns, tsc) pair. med/p99/p999/max/min/avg in
 * microseconds.
 *
 * Output:  RTB <name> n=<N> med=<us> p99=<us> p999=<us> max=<us>
 *          min=<us> avg=<us> [extra key=val]
 *          RTB DONE rc=0          (last line; then poweroff)
 * A bench that hits an unsupported primitive SKIPs itself.
 *
 * Build: toolchain/x86_64-rux-linux-musl/bin/musl-gcc -static -O2 -pthread
 */
#define _GNU_SOURCE             /* cpu_set_t / CPU_SET in musl sched.h */
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <sched.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

typedef unsigned long long u64;
typedef long long s64;
typedef unsigned int u32;

/* ---------------- tunables ---------------- */
#define N_REL100   10000
#define N_REL1MS   10000
#define N_REL10MS  5000
#define N_ABS1MS   10000
#define N_ABS10MS  2000
#define N_XCPU     20000
#define N_SAMECPU  10000
#define N_RTPREE   5000
#define FAIR_SECS  3
#define FAIR_THR   16

static double g_tsc_hz;         /* 0 = rdtsc unusable */
static int g_ncpu = 1;

/* ---------------- output ---------------- */
static void emit(const char *s)
{
    ssize_t w = write(1, s, strlen(s));
    (void)w;
}

static void fmt_us(char *buf, double ns)
{
    if (ns < 0) { strcpy(buf, "-1"); return; }
    u64 v = (u64)(ns + 0.5);
    u64 whole = v / 1000, frac = v % 1000;
    char fr[4] = { (char)('0' + frac / 100), (char)('0' + (frac / 10) % 10), (char)('0' + frac % 10), 0 };
    char wb[26];
    int i = (int)sizeof(wb) - 1;
    wb[i] = 0;
    if (!whole) wb[--i] = '0';
    while (whole && i > 0) { wb[--i] = (char)('0' + whole % 10); whole /= 10; }
    strcpy(buf, wb + i); strcat(buf, "."); strcat(buf, fr);
}

/* ---------------- clocks ---------------- */
static inline u64 rdtsc_(void)
{
    unsigned lo, hi;
    __asm__ __volatile__("rdtsc" : "=a"(lo), "=d"(hi));
    return ((u64)hi << 32) | lo;
}

static s64 clk_ns(int which)
{
    struct timespec ts;
    syscall(SYS_clock_gettime, which, &ts);
    return (s64)ts.tv_sec * 1000000000LL + ts.tv_nsec;
}
#define MNR_CLK 4               /* CLOCK_MONOTONIC_RAW */

static void sleep_ns(u64 ns)
{
    struct timespec ts = { (time_t)(ns / 1000000000ULL), (long)(ns % 1000000000ULL) };
    clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, 0);
}

/* ---------------- stats ---------------- */
static int cmp_u64(const void *a, const void *b)
{
    u64 x = *(const u64 *)a, y = *(const u64 *)b;
    return x < y ? -1 : (x > y ? 1 : 0);
}

struct pstats { u64 med, p99, p999, min, max; double avg; };

static void stats_of(u64 *t, size_t n, struct pstats *s)
{
    if (!n) { memset(s, 0, sizeof(*s)); return; }
    qsort(t, n, sizeof(u64), cmp_u64);
    s->min = t[0];
    s->med = t[n / 2];
    s->p99 = t[(n * 99) / 100 >= n ? n - 1 : (n * 99) / 100];
    s->p999 = t[(n * 999) / 1000 >= n ? n - 1 : (n * 999) / 1000];
    s->max = t[n - 1];
    double acc = 0;
    for (size_t i = 0; i < n; i++) acc += (double)t[i];
    s->avg = acc / (double)n;
}

static void report(const char *name, u64 *t, size_t n, const char *extra)
{
    struct pstats s;
    stats_of(t, n, &s);
    double k = g_tsc_hz > 0 ? 1e9 / g_tsc_hz : -1;    /* ns per tick */
    char b[640], m[24], p9[24], p99_[24], mx[24], mn[24], av[24];
    if (g_tsc_hz > 0 && n) {
        fmt_us(m, (double)s.med * k);
        fmt_us(p9, (double)s.p99 * k);
        fmt_us(p99_, (double)s.p999 * k);
        fmt_us(mx, (double)s.max * k);
        fmt_us(mn, (double)s.min * k);
        fmt_us(av, s.avg * k);
    } else {
        strcpy(m, "-1"); strcpy(p9, "-1"); strcpy(p99_, "-1");
        strcpy(mx, "-1"); strcpy(mn, "-1"); strcpy(av, "-1");
    }
    int len = snprintf(b, sizeof(b),
                       "RTB %s n=%zu med=%s p99=%s p999=%s max=%s min=%s avg=%s%s%s\n",
                       name, n, m, p9, p99_, mx, mn, av,
                       extra && *extra ? " " : "", extra ? extra : "");
    if (len > 0 && (size_t)len < sizeof(b)) emit(b);
}

static void skip_line(const char *name, const char *why)
{
    char b[256];
    int len = snprintf(b, sizeof(b), "RTB %s SKIP why=%s\n", name, why);
    if (len > 0) emit(b);
}

/* ---------------- calibration ---------------- */
static void calibrate(void)
{
    u64 hz[3];
    int ok = 0;
    for (int r = 0; r < 3; r++) {
        u64 t0 = rdtsc_();
        s64 c0 = clk_ns(MNR_CLK);
        while (clk_ns(MNR_CLK) - c0 < 50000000LL) ; /* ~50 ms */
        s64 c1 = clk_ns(MNR_CLK);
        u64 t1 = rdtsc_();
        s64 dns = c1 - c0;
        if (dns > 1000000LL && t1 > t0)
            hz[ok++] = (u64)((double)(t1 - t0) * 1e9 / (double)dns);
    }
    if (ok == 3) {
        qsort(hz, 3, sizeof(u64), cmp_u64);
        if (hz[1] > 1000000ULL && hz[1] < 20000000000000ULL)
            g_tsc_hz = (double)hz[1];
    }
    char b[128];
    int len = snprintf(b, sizeof(b), "RTB cal tsc_hz=%llu ncpu=%d\n",
                       g_tsc_hz > 0 ? (unsigned long long)g_tsc_hz : 0ULL,
                       g_ncpu);
    if (len > 0) emit(b);
}

/* ---------------- affinity / policy helpers ---------------- */
static int pin_cpu(int cpu)
{
    cpu_set_t set;
    CPU_ZERO(&set);
    CPU_SET(cpu, &set);
    return sched_setaffinity(0, sizeof(set), &set);
}

static int set_fifo(int prio)
{
    struct sched_param sp;
    memset(&sp, 0, sizeof(sp));
    sp.sched_priority = prio;
    /* pid=0 resolves to the TGID on some kernels' thread semantics;
     * address THIS thread by its tid so the policy lands on the waiter */
    pid_t tid = (pid_t)syscall(SYS_gettid);
    long raw = syscall(SYS_sched_setscheduler, tid, SCHED_FIFO, &sp);
    int r = (raw == 0) ? 0 : -1;
    if (raw != 0) {
        char b[96];
        int len = snprintf(b, sizeof(b),
                           "RTB dbg set_fifo tid=%d raw=%ld errno=%d\n",
                           (int)tid, raw, errno);
        if (len > 0) emit(b);
        errno = 0;
        raw = syscall(SYS_sched_setscheduler, 0, SCHED_FIFO, &sp);
        r = (raw == 0) ? 0 : -1;
        if (raw != 0) {
            len = snprintf(b, sizeof(b), "RTB dbg set_fifo0 raw=%ld errno=%d\n",
                           raw, errno);
            if (len > 0) emit(b);
        }
    }
    return r;
}

/* futex op codes (linux/futex.h not shipped in the musl SDK headers) */
#define FBENCH_FUTEX_WAIT 0
#define FBENCH_FUTEX_WAKE 1

static long futex_wake(volatile u32 *uaddr, u32 n)
{
    return syscall(SYS_futex, (u32 *)uaddr, FBENCH_FUTEX_WAKE, n, 0, 0, 0);
}

/* ---------------- T1: relative sleep overshoot ---------------- */
static void bench_rel_sleep(const char *name, u64 ns, int n)
{
    u64 *t = malloc((size_t)n * sizeof(u64));
    if (!t) { skip_line(name, "oom"); return; }
    for (int i = 0; i < 200; i++) { /* warm */
        struct timespec ts = { 0, 1000000 };
        clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, 0);
    }
    for (int i = 0; i < n; i++) {
        u64 c0 = rdtsc_();
        struct timespec ts = { (time_t)(ns / 1000000000ULL), (long)(ns % 1000000000ULL) };
        clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, 0);
        u64 c1 = rdtsc_();
        t[i] = c1 - c0;
    }
    char extra[64];
    snprintf(extra, sizeof(extra), "req=%lluuus", ns / 1000);
    report(name, t, (size_t)n, extra);
    free(t);
}

/* ---------------- T2: absolute-deadline lateness ---------------- */
/* anchor pair captured once: mono_ns0 at tsc0 (CLOCK_MONOTONIC is the
 * clock clock_nanosleep(TIMER_ABSTIME) targets, so deadlines and the
 * post-wake TSC reading share one linear map) */
static s64 g_mono_ns0;
static u64 g_tsc0;

static s64 mono_to_tsc_ticks(s64 mono_ns)
{
    return g_tsc0 + (s64)(((double)(mono_ns - g_mono_ns0)) * g_tsc_hz / 1e9);
}

static void bench_abs_sleep(const char *name, u64 ns, int n)
{
    if (g_tsc_hz <= 0) { skip_line(name, "no-tsc"); return; }
    u64 *t = malloc((size_t)n * sizeof(u64));
    if (!t) { skip_line(name, "oom"); return; }
    for (int i = 0; i < 200; i++) { /* warm */
        struct timespec ts = { 0, 1000000 };
        clock_nanosleep(CLOCK_MONOTONIC, 0, &ts, 0);
    }
    s64 base = clk_ns(CLOCK_MONOTONIC) + 50 * 1000000LL;
    s64 next_dl = base;
    int nv = 0, resyncs = 0;
    for (int i = 0; i < n * 2 && nv < n; i++) {
        next_dl += (s64)ns;
        s64 now = clk_ns(CLOCK_MONOTONIC);
        u64 now_ticks = rdtsc_();
        /* resync on hiccups (next_dl too close or behind): rebase the
         * chain WITHOUT recording that round, so every recorded sample
         * is a full-interval sleep to an absolute deadline */
        if (next_dl < now + 200000LL) {
            next_dl = now + (s64)ns;
            resyncs++;
            continue;
        }
        /* per-round anchor: convert the remaining (deadline - now) MONO
         * ns to TSC ticks from the fresh (mono, tsc) pair — immune to
         * mono-vs-tsc drift over the chain */
        s64 dl_ticks = (s64)now_ticks
            + (s64)(((double)(next_dl - now)) * g_tsc_hz / 1e9);
        struct timespec ts = { (time_t)(next_dl / 1000000000LL), (long)(next_dl % 1000000000LL) };
        clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &ts, 0);
        u64 c1 = rdtsc_();
        t[nv++] = (c1 > (u64)dl_ticks) ? c1 - (u64)dl_ticks : 0;
    }
    char extra[64];
    snprintf(extra, sizeof(extra), "val=lateness resyncs=%d", resyncs);
    report(name, t, (size_t)nv, extra);
    free(t);
}

/* ---------------- W: futex wake->run (seq protocol) ----------------
 * Waiter round: seq++; word=seq; ready=seq; futex_wait(&word, seq).
 * Waker round: spin until ready==seq; t0=rdtsc; word=seq+1;
 * futex_wake. Waiter exits its loop (word != seq), stamps t1, records
 * t1-t0, ack=seq. Stop: same shape with stop=1 — waiter acks without
 * recording.
 */
struct wakepair {
    volatile u32 word;
    volatile u32 ready;
    volatile u32 ack;
    volatile u32 stop;
    char pad[52];
    volatile u64 t0;
    volatile u64 t1;
    u64 *res;
    int n;
    int fifo_waiter;
    int waiter_cpu;
};

static struct wakepair WP __attribute__((aligned(64)));

static long futex_wait(volatile u32 *uaddr, u32 val)
{
    return syscall(SYS_futex, (u32 *)uaddr, FBENCH_FUTEX_WAIT, val, 0, 0, 0);
}

/* stall guard: bail out of a spin instead of wedging the battery */
#define SPIN_GUARD 3000000000ULL

static void *wp_waiter_run(void *arg)
{
    struct wakepair *w = arg;
    pin_cpu(w->waiter_cpu);
    if (w->fifo_waiter && set_fifo(98) != 0) {
        w->n = -1;                /* signal: FIFO unavailable */
        return 0;
    }
    u32 seq = 0;
    for (;;) {
        seq += 2;
        __atomic_store_n(&w->word, seq, __ATOMIC_RELEASE);
        __atomic_store_n(&w->ready, seq, __ATOMIC_RELEASE);
        while (__atomic_load_n(&w->word, __ATOMIC_ACQUIRE) == seq) {
            futex_wait(&w->word, seq);
        }
        if (__atomic_load_n(&w->stop, __ATOMIC_ACQUIRE)) {
            __atomic_store_n(&w->ack, seq, __ATOMIC_RELEASE);
            break;
        }
        u64 t1 = rdtsc_();
        if (w->n < 0) { __atomic_store_n(&w->ack, seq, __ATOMIC_RELEASE); break; }
        w->res[w->n++] = t1 - w->t0;
        __atomic_store_n(&w->ack, seq, __ATOMIC_RELEASE);
    }
    return 0;
}

static int wp_round(struct wakepair *w, u32 seq, u64 *sample, u64 *wakesys)
{
    u64 guard = 0;
    while (__atomic_load_n(&w->ready, __ATOMIC_ACQUIRE) != seq) {
        if (++guard > SPIN_GUARD) return -2; /* waiter stalled */
    }
    /* park delay: give the waiter time to enter the kernel sleep —
     * without it the spinning waker beats the waiter's syscall entry
     * and the wake finds nothing (Rux zero-return race, measured
     * 18k/20k rounds). ~30 us covers an uninstrumented futex_wait
     * entry plus scheduling noise. */
    u64 d0 = rdtsc_();
    while (rdtsc_() - d0 < (u64)(0.00003 * g_tsc_hz))
        ;
    u64 c0 = rdtsc_();
    w->t0 = c0;
    __atomic_store_n(&w->word, seq + 1, __ATOMIC_RELEASE);
    long r = futex_wake(&w->word, 1);
    u64 c1 = rdtsc_();
    if (wakesys) *wakesys = c1 - c0;
    if (r < 0 && errno != 0) {
        /* wake failed hard; waiter will be stuck — bail via stop */
        return -1;
    }
    guard = 0;
    while (__atomic_load_n(&w->ack, __ATOMIC_ACQUIRE) != seq) {
        if (++guard > SPIN_GUARD) return -2;
    }
    if (sample && w->n > 0) *sample = w->res[w->n - 1];
    return (int)r;
}

static void wp_stop(struct wakepair *w)
{
    __atomic_store_n(&w->stop, 1, __ATOMIC_RELEASE);
    /* waiter is parked; arm one more round to release it */
    u32 seq = __atomic_load_n(&w->ready, __ATOMIC_ACQUIRE);
    u64 c0 = rdtsc_();
    w->t0 = c0;
    __atomic_store_n(&w->word, seq + 1, __ATOMIC_RELEASE);
    futex_wake(&w->word, 1);
    /* waiter acks (no sample recorded when stop is set) */
}

static void bench_futex_xcpu(const char *name, int fifo_waiter, int n,
                             int collect_wakesys)
{
    if (g_ncpu < 2) { skip_line(name, "smp<2"); return; }
    u64 *samples = malloc((size_t)n * sizeof(u64));
    u64 *wsys = malloc((size_t)n * sizeof(u64));
    if (!samples || !wsys) { skip_line(name, "oom"); return; }
    memset(&WP, 0, sizeof(WP));
    WP.res = samples;
    WP.n = 0;
    WP.fifo_waiter = fifo_waiter;
    WP.waiter_cpu = 1;

    pthread_t th;
    if (pthread_create(&th, 0, wp_waiter_run, &WP) != 0) {
        skip_line(name, "pthread"); return;
    }
    sleep_ns(50 * 1000000ULL);   /* let the waiter park */
    if (WP.n < 0) {
        pthread_join(th, 0);
        skip_line(name, "sched-fifo"); return;
    }
    pin_cpu(0);

    int nvalid = 0, nwoken = 0, nzero = 0, nerr = 0, fail = 0;
    u32 seq = 0;
    for (int i = 0; i < n; i++) {
        seq += 2;
        u64 s = 0, ws = 0;
        int r = wp_round(&WP, seq, &s, collect_wakesys ? &ws : 0);
        if (r == -1) { fail = 1; break; }
        if (r == -2) { fail = 2; break; }
        if (r > 0) nwoken++;
        else if (r == 0) nzero++;
        else nerr++;
        /* only rounds where the wake found the waiter asleep are true
         * sleep-wake samples; r==0 rounds are the poll-race fast path */
        if (r > 0 && WP.n > 0) {
            samples[nvalid] = s;
            if (collect_wakesys) wsys[nvalid] = ws;
            nvalid++;
        }
    }
    wp_stop(&WP);
    sleep_ns(20 * 1000000ULL);
    pthread_join(th, 0);
    if (WP.n < 0) { skip_line(name, "sched-fifo"); return; }
    if (fail == 1) { skip_line(name, "wake-errno"); return; }
    if (fail) { skip_line(name, "waiter-stall"); return; }
    char extra[96];
    snprintf(extra, sizeof(extra), "woken=%d zero=%d err=%d waiter=%s",
             nwoken, nzero, nerr, fifo_waiter ? "FIFO98" : "OTHER");
    report(name, samples, (size_t)nvalid, extra);
    if (collect_wakesys)
        report("w_futex_wakesys", wsys, (size_t)nvalid, "val=syscall_len");
    free(samples); free(wsys);
}

/* same-CPU: the waker parks on the ack word so the waiter gets the CPU */
static struct wakepair SP __attribute__((aligned(64)));
static volatile u32 g_spark_ready, g_spark_seq;

static void *sp_waiter_run(void *arg)
{
    struct wakepair *w = arg;
    pin_cpu(0);
    u32 seq = 0;
    for (;;) {
        seq += 2;
        __atomic_store_n(&w->word, seq, __ATOMIC_RELEASE);
        __atomic_store_n(&w->ready, seq, __ATOMIC_RELEASE);
        while (__atomic_load_n(&w->word, __ATOMIC_ACQUIRE) == seq) {
            futex_wait(&w->word, seq);
        }
        if (__atomic_load_n(&w->stop, __ATOMIC_ACQUIRE)) {
            __atomic_store_n(&w->ack, seq, __ATOMIC_RELEASE);
            break;
        }
        u64 t1 = rdtsc_();
        w->res[w->n++] = t1 - w->t0;
        __atomic_store_n(&w->ack, seq, __ATOMIC_RELEASE);
        /* release the waker (it parked on g_spark_seq==0 after its
         * futex_wake); then we loop straight back into the next
         * round's park on w->word */
        __atomic_store_n(&g_spark_seq, 1, __ATOMIC_RELEASE);
        futex_wake(&g_spark_seq, 1);
    }
    return 0;
}

static void bench_futex_samecpu(int n)
{
    u64 *samples = malloc((size_t)n * sizeof(u64));
    char *ok = malloc((size_t)n);
    if (!samples || !ok) { skip_line("w_futex_samecpu", "oom"); return; }
    memset(&SP, 0, sizeof(SP));
    SP.res = samples;
    SP.n = 0;
    SP.fifo_waiter = 0;
    SP.waiter_cpu = 0;

    pthread_t th;
    if (pthread_create(&th, 0, sp_waiter_run, &SP) != 0) {
        skip_line("w_futex_samecpu", "pthread"); return;
    }
    sleep_ns(50 * 1000000ULL);
    pin_cpu(0);

    u32 seq = 0;
    int nwoken = 0;
    for (int i = 0; i < n; i++) {
        seq += 2;
        __atomic_store_n(&g_spark_seq, 0, __ATOMIC_RELEASE);
        while (__atomic_load_n(&SP.ready, __ATOMIC_ACQUIRE) != seq)
            ;
        /* park delay: let the waiter reach its kernel sleep first */
        u64 d0 = rdtsc_();
        while (rdtsc_() - d0 < (u64)(0.00003 * g_tsc_hz))
            ;
        u64 c0 = rdtsc_();
        SP.t0 = c0;
        __atomic_store_n(&SP.word, seq + 1, __ATOMIC_RELEASE);
        long r = futex_wake(&SP.word, 1);
        ok[i] = (r > 0);
        if (r > 0) nwoken++;
        /* park so the woken waiter gets this CPU; the waiter releases
         * us through g_spark_seq when its sample is recorded */
        while (__atomic_load_n(&g_spark_seq, __ATOMIC_ACQUIRE) == 0)
            futex_wait(&g_spark_seq, 0);
        while (__atomic_load_n(&SP.ack, __ATOMIC_ACQUIRE) != seq)
            ;
    }
    __atomic_store_n(&SP.stop, 1, __ATOMIC_RELEASE);
    u32 rseq = __atomic_load_n(&SP.ready, __ATOMIC_ACQUIRE);
    SP.t0 = rdtsc_();
    __atomic_store_n(&SP.word, rseq + 1, __ATOMIC_RELEASE);
    futex_wake(&SP.word, 1);
    __atomic_store_n(&g_spark_seq, 1, __ATOMIC_RELEASE);
    futex_wake(&g_spark_seq, 1);
    sleep_ns(20 * 1000000ULL);
    pthread_join(th, 0);
    /* compact: keep only rounds where the wake found the sleeper */
    int total = SP.n, nv = 0;
    if (total > n) total = n;
    for (int i = 0; i < total; i++)
        if (ok[i]) samples[nv++] = samples[i];
    char extra[64];
    snprintf(extra, sizeof(extra), "pair=samecpu woken=%d/%d", nwoken, n);
    report("w_futex_samecpu", samples, (size_t)nv, extra);
    free(samples); free(ok);
}

/* ---------------- RT: FIFO waiter vs user-mode spinner ---------------- */
static struct wakepair RP __attribute__((aligned(64)));
static volatile u32 g_kill_spinner;

static void *rt_spinner(void *arg)
{
    (void)arg;
    pin_cpu(1);
    volatile u64 sink = 0;
    u64 chk = 0;
    while (!__atomic_load_n(&g_kill_spinner, __ATOMIC_ACQUIRE)) {
        for (int k = 0; k < 4096; k++)
            sink += (u64)k;
        chk++;
    }
    return 0;
}

static void bench_rt_preempt(int n)
{
    if (g_ncpu < 2) { skip_line("rt_preempt", "smp<2"); return; }
    u64 *samples = malloc((size_t)n * sizeof(u64));
    if (!samples) { skip_line("rt_preempt", "oom"); return; }
    memset(&RP, 0, sizeof(RP));
    RP.res = samples;
    RP.n = 0;
    RP.fifo_waiter = 1;
    RP.waiter_cpu = 1;

    /* spinner first: CPU1 burns in user mode */
    pthread_t sp, th;
    if (pthread_create(&sp, 0, rt_spinner, 0) != 0) {
        skip_line("rt_preempt", "pthread"); return;
    }
    sleep_ns(50 * 1000000ULL);
    if (pthread_create(&th, 0, wp_waiter_run, &RP) != 0) {
        g_kill_spinner = 1;
        skip_line("rt_preempt", "pthread"); return;
    }
    sleep_ns(50 * 1000000ULL);
    if (RP.n < 0) {
        pthread_join(th, 0);
        __atomic_store_n(&g_kill_spinner, 1, __ATOMIC_RELEASE);
        pthread_join(sp, 0);
        skip_line("rt_preempt", "sched-fifo"); return;
    }
    pin_cpu(0);

    int nvalid = 0, nwoken = 0;
    u64 *wsys = malloc((size_t)n * sizeof(u64));
    if (!wsys) { skip_line("rt_preempt", "oom2"); return; }
    u32 seq = 0;
    for (int i = 0; i < n; i++) {
        seq += 2;
        u64 s = 0, ws = 0;
        int r = wp_round(&RP, seq, &s, &ws);
        if (r < 0) break;
        if (r > 0) nwoken++;
        if (r > 0 && RP.n > nvalid) {
            samples[nvalid] = s;
            wsys[nvalid] = ws;
            nvalid++;
        }
    }
    wp_stop(&RP);
    sleep_ns(20 * 1000000ULL);
    pthread_join(th, 0);
    __atomic_store_n(&g_kill_spinner, 1, __ATOMIC_RELEASE);
    pthread_join(sp, 0);
    if (RP.n < 0) { skip_line("rt_preempt", "sched-fifo"); return; }
    if (nwoken * 2 < n) { skip_line("rt_preempt", "no-wake"); return; }
    char extra[96];
    snprintf(extra, sizeof(extra), "woken=%d/%d waiter=FIFO98 target=user-spinner",
             nwoken, n);
    report("rt_preempt", samples, (size_t)nvalid, extra);
    report("rt_wakesys", wsys, (size_t)nvalid, "val=syscall_len");
    free(samples); free(wsys);
}

/* ---------------- fairness ---------------- */
static volatile u32 g_fair_stop;
static u64 g_fair_counts[FAIR_THR];

static void *fair_spinner(void *arg)
{
    long id = (long)(intptr_t)arg;
    volatile u64 sink = 0;
    u64 iters = 0;
    while (!__atomic_load_n(&g_fair_stop, __ATOMIC_ACQUIRE)) {
        for (int k = 0; k < 1000; k++)
            sink += (u64)k;
        iters++;
    }
    g_fair_counts[id] = iters;
    return 0;
}

static void bench_fair(int nthreads, const char *name)
{
    pthread_t th[FAIR_THR];
    if (nthreads > FAIR_THR) nthreads = FAIR_THR;
    memset(g_fair_counts, 0, sizeof(g_fair_counts));
    g_fair_stop = 0;
    for (int i = 0; i < nthreads; i++)
        pthread_create(&th[i], 0, fair_spinner, (void *)(intptr_t)i);
    sleep_ns((u64)FAIR_SECS * 1000000000ULL);
    __atomic_store_n(&g_fair_stop, 1, __ATOMIC_RELEASE);
    for (int i = 0; i < nthreads; i++)
        pthread_join(th[i], 0);
    double sum = 0, sum2 = 0, mn = 1e30, mx = 0;
    for (int i = 0; i < nthreads; i++) {
        double c = (double)g_fair_counts[i];
        sum += c; sum2 += c * c;
        if (c < mn) mn = c;
        if (c > mx) mx = c;
    }
    double jain = (sum * sum) / ((double)nthreads * sum2);
    char line[256];
    int len = snprintf(line, sizeof(line),
                       "RTB %s n=%d jain=%.4f spread=%.3f total_per_s=%.0f min=%llu max=%llu\n",
                       name, nthreads, jain, mn > 0 ? mx / mn : -1.0,
                       sum / (double)FAIR_SECS,
                       (unsigned long long)mn, (unsigned long long)mx);
    if (len > 0) emit(line);
}

/* ---------------- main ---------------- */
int main(int argc, char **argv)
{
    int quick = (argc > 1 && strcmp(argv[1], "quick") == 0);

    g_ncpu = (int)sysconf(_SC_NPROCESSORS_ONLN);
    if (g_ncpu < 1) g_ncpu = 1;

    emit("RTB rtbench v2 start\n");
    calibrate();

    /* anchor for the ABSTIME bench (CLOCK_MONOTONIC <-> TSC) */
    if (g_tsc_hz > 0) {
        g_mono_ns0 = clk_ns(CLOCK_MONOTONIC);
        g_tsc0 = rdtsc_();
    }

    if (!quick) {
        /* timer precision — pinned to CPU0 (the tick-keeping CPU) */
        pin_cpu(0);
        bench_rel_sleep("t_rel_100us", 100000ULL, N_REL100);
        bench_rel_sleep("t_rel_1ms", 1000000ULL, N_REL1MS);
        bench_rel_sleep("t_rel_10ms", 10000000ULL, N_REL10MS);
        bench_abs_sleep("t_abs_1ms", 1000000ULL, N_ABS1MS);
        bench_abs_sleep("t_abs_10ms", 10000000ULL, N_ABS10MS);

        /* wake->run */
        bench_futex_xcpu("w_futex_xcpu", 0, N_XCPU, 1);
        bench_futex_xcpu("w_futex_xcpu_rt", 1, N_XCPU, 0);
        bench_futex_samecpu(N_SAMECPU);
    }

    /* RT preemption under load */
    bench_rt_preempt(N_RTPREE);

    if (!quick) {
        /* fairness */
        bench_fair(8, "fair_8x8");
        bench_fair(16, "fair_8x16");
    }

    emit("RTB DONE rc=0\n");

    sync();
    sleep_ns(200 * 1000000ULL);
    syscall(SYS_reboot, 0xfee1dead, 672274793, 0x4321fedc);
    _exit(0);
    return 0;
}
