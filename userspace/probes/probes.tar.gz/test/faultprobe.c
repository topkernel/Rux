// faultprobe.c — tight MAP_SHARED file-fault loop for the fs-substrate
// lane's interface-cost measurement (crate-plan 3a rule 2 receipt).
//
// Per filesystem kind (ext4 file, tmpfs file, devfs regular file):
//   round: mmap MAP_SHARED fresh -> write one byte per page (fault it
//   in) -> munmap. ROUNDS rounds of NPAGES pages; per-round total in
// TSC -> ns. Report per-fault ns as the MIN round (scheduling noise
// cut) and the MEDIAN round. Also a re-fault pass with MADV_DONTNEED
// instead of munmap (same page tables torn down, no vma rebuild) as the
// tightest loop.
//
// Every FAULTLOOP line is the measurement; DONE rc=0 at the end.

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <errno.h>
#include <sys/time.h>

typedef unsigned long long u64;
typedef long long s64;

static inline u64 rdtsc_(void)
{
    unsigned int lo, hi;
    __asm__ __volatile__("rdtsc" : "=a"(lo), "=d"(hi));
    return ((u64)hi << 32) | lo;
}

static u64 tsc_hz;

static void calibrate(void)
{
    /* ~250ms of rdtsc pairs against CLOCK_MONOTONIC_RAW is pbench's
     * job; here a 100ms spin against gettimeofday is plenty — we only
     * need ns-per-fault to ~1%. */
    struct timeval a, b;
    u64 t0, t1;
    s64 us = 0;
    gettimeofday(&a, 0);
    t0 = rdtsc_();
    for (;;) {
        gettimeofday(&b, 0);
        us = (s64)(b.tv_sec - a.tv_sec) * 1000000LL + (b.tv_usec - a.tv_usec);
        if (us >= 100000)
            break;
    }
    t1 = rdtsc_();
    tsc_hz = (u64)((double)(t1 - t0) * 1000000.0 / (double)us);
}

#define NPAGES  256
#define ROUNDS  24
#define PSZ     4096

static u64 round_ticks[ROUNDS];

static int cmp_u64(const void *a, const void *b)
{
    u64 x = *(const u64 *)a, y = *(const u64 *)b;
    return x < y ? -1 : x > y ? 1 : 0;
}

/* Fault NPAGES pages of a fresh MAP_SHARED mapping, ROUNDS times.
 * kind: label; fd: backing file (or -1 => anonymous skip).
 * mode: 0 = munmap/mmap per round, 1 = MADV_DONTNEED per round. */
static void run_kind(const char *kind, int fd, int mode)
{
    size_t len = (size_t)NPAGES * PSZ;
    char *p;
    u64 med, min;

    if (fd < 0) {
        printf("FAULTLOOP %s mode=%d SKIP no-backing\n", kind, mode);
        return;
    }
    /* size the file up front (ftruncate also activates the devfs
     * shared backing) so rounds measure FAULTS, not growth. */
    if (ftruncate(fd, (off_t)len) < 0) {
        printf("FAULTLOOP %s mode=%d SKIP ftruncate-errno=%d\n", kind, mode, errno);
        return;
    }

    p = mmap(0, len, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (p == MAP_FAILED) {
        printf("FAULTLOOP %s mode=%d SKIP mmap-errno=%d\n", kind, mode, errno);
        return;
    }
    /* fault once so later rounds are pure re-faults of discarded pages */
    for (int i = 0; i < NPAGES; i++)
        p[(size_t)i * PSZ] = (char)i;

    for (int r = 0; r < ROUNDS; r++) {
        u64 t0 = rdtsc_();
        for (int i = 0; i < NPAGES; i++)
            p[(size_t)i * PSZ] = (char)(i + r);
        u64 t1 = rdtsc_();
        round_ticks[r] = t1 - t0;
        if (mode == 1)
            madvise(p, len, MADV_DONTNEED);
        else {
            munmap(p, len);
            p = mmap(0, len, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
            if (p == MAP_FAILED) {
                printf("FAULTLOOP %s mode=%d SKIP remap-errno=%d\n", kind, mode, errno);
                return;
            }
        }
    }
    qsort(round_ticks, ROUNDS, sizeof(u64), cmp_u64);
    med = round_ticks[ROUNDS / 2];
    min = round_ticks[0];
    printf("FAULTLOOP %s mode=%d n=%d med=%.1fns min=%.1fns\n",
           kind, mode, NPAGES,
           (double)med * 1e9 / (double)tsc_hz / NPAGES,
           (double)min * 1e9 / (double)tsc_hz / NPAGES);
    if (mode == 0)
        munmap(p, len);
}

int main(void)
{
    int fd;

    calibrate();
    printf("FAULTLOOP CAL tsc_hz=%llu\n", tsc_hz);

    /* ext4: the probe's own disk root (/test) */
    fd = open("/test/faultprobe.ext4", O_CREAT | O_RDWR, 0600);
    run_kind("ext4", fd, 0);
    run_kind("ext4", fd, 1);
    close(fd);

    /* tmpfs: /dev/shm (mounted tmpfs on every boot) */
    fd = open("/dev/shm/faultprobe.tmp", O_CREAT | O_RDWR, 0600);
    run_kind("tmpfs", fd, 0);
    run_kind("tmpfs", fd, 1);
    close(fd);

    /* devfs regular file: devtmpfs semantics allow O_CREAT regular
     * files under /dev (the OH __parameters__ workspace class). */
    fd = open("/dev/faultprobe.dev", O_CREAT | O_RDWR, 0600);
    run_kind("devfs", fd, 0);
    run_kind("devfs", fd, 1);
    close(fd);

    printf("FAULTLOOP DONE rc=0\n");
    return 0;
}
