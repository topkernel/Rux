/*
 * perf_sample.c — kernel tick-sampling recorder for the in-tree
 * perf_event_open software-clock sampler (kernel/core/src/perf/mod.rs).
 *
 * What it does (the "syscall trigger" arm of the sampling enablement
 * path — the kernel ships the sampler dormant; nothing samples until a
 * privileged caller opens + enables an event, so default kernels stay
 * at one relaxed load per tick):
 *
 *   1. open one per-CPU cpu-clock SAMPLING event per CPU
 *      (pid=-1, cpu=N, PERF_COUNT_SW_CPU_CLOCK, period = 1 ms (1000 Hz
 *      requested; the kernel floors at one tick, so a KERNEL_HZ=100
 *      kernel coalesces to 100 Hz), exclude_user + exclude_idle so the
 *      report is kernel-code-only),
 *   2. mmap the per-event ring buffer (perf_event_mmap_page protocol),
 *   3. enable the events, then fork+exec the pbench load as a child,
 *   4. drain every ring for the sampling window, appending the records
 *      (PERF wire format, verbatim) to a perf.data file,
 *   5. disable, fsync, print the PERFSAMPLE summary, power off.
 *
 * The dump file follows the reference perf.data container layout
 * (perf_file_header "PERFILE2" + one attr + data section of ring-format
 * records) — no invented format; scripts/perf_report.py parses it, and
 * a reference perf could too.
 *
 * Output markers (the boot driver keys on these):
 *   PERFSAMPLE OPEN cpus=N events=M period_ms=P
 *   PERFSAMPLE WINDOW seconds=S records=K lost=L bytes=B
 *   PERFSAMPLE DONE rc=0
 *
 * Usage (as init on the probe rootfs): init=/test/perfsample
 *   argv[1] = window seconds (default 45; MUST stay below the pbench
 *   battery duration — ~35 s floor on x86 KVM — so the recorder kills
 *   pbench before its final reboot), argv[2] = output path (default
 *   /test/perf.data), argv[3] = load path (default /test/pbench, empty
 *   string = no load).
 *
 * Build (x86_64): toolchain/x86_64-rux-linux-musl/bin/musl-gcc
 *                 -static -O2 -o perfsample test/perf_sample.c
 * Build (riscv64): riscv64-linux-gnu-gcc -static -nostdlib
 *                 -march=rv64gc_zicsr -I toolchain/riscv64-rux-linux-musl
 *                 -o perfsample test/perf_sample.c \
 *                 toolchain/riscv64-rux-linux-musl/lib/{crt1.o,libc.a} -lgcc
 */
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

typedef unsigned long long u64;

/* ---- arch syscall numbers (the kernel's x86_64 table maps 298 ->
 * internal 241; riscv64/aarch64 pass asm-generic 241 natively) ---- */
#if defined(__x86_64__)
#define NR_PERF_EVENT_OPEN 298
#else
#define NR_PERF_EVENT_OPEN 241 /* asm-generic */
#endif

/* ---- uapi perf_event.h constants (the slice the kernel honors) ---- */
#define PERF_TYPE_SOFTWARE 1
#define PERF_COUNT_SW_CPU_CLOCK 0

#define PERF_SAMPLE_IP (1ULL << 0)
#define PERF_SAMPLE_TID (1ULL << 1)
#define PERF_SAMPLE_TIME (1ULL << 2)
#define PERF_SAMPLE_CALLCHAIN (1ULL << 5)
#define PERF_SAMPLE_ID (1ULL << 6)
#define PERF_SAMPLE_CPU (1ULL << 7)
#define PERF_SAMPLE_PERIOD (1ULL << 8)
#define PERF_SAMPLE_IDENTIFIER (1ULL << 16)

/* attr.flags1 bitfield bits. */
#define FLAG_EXCLUDE_USER (1ULL << 4)
#define FLAG_EXCLUDE_IDLE (1ULL << 7)

#define PERF_RECORD_EXIT 4
#define PERF_RECORD_LOST 2
#define PERF_RECORD_FORK 7
#define PERF_RECORD_SAMPLE 9
#define IOC_ENABLE 0x2400
#define IOC_DISABLE 0x2401

/* The 64-byte VER0 attr (everything this port reads fits there). */
struct pattr {
    uint32_t type;
    uint32_t size;
    uint64_t config;
    uint64_t sample_period;
    uint64_t sample_type;
    uint64_t read_format;
    uint64_t flags1;
    uint32_t wakeup_events;
    uint32_t bp_type;
    uint64_t bp_addr;
    uint64_t bp_len;
    uint64_t branch_sample_type;
    uint64_t sample_regs_user;
    uint32_t sample_stack_user;
    uint32_t clockid;
    uint64_t sample_regs_intr;
    uint32_t aux_watermark;
    uint32_t reserved2;
};

/* perf_event_mmap_page field offsets (kernel + userspace agree). */
#define MP_DATA_HEAD 1024
#define MP_DATA_TAIL 1032
#define MP_DATA_SIZE 1048
#define PAGE_SIZE 4096

#define MAX_CPUS 8
#define RING_PAGES 128 /* 512 KiB data area per CPU, power of two */
#define MAX_REC (8 + 8 * 8 + 8 + 40 * 8 + 64) /* header+fields+max chain */

/* The perf.data container (reference perf_file_header, 104 bytes). */
static const char PERF_MAGIC[8] = { 0x50, 0x45, 0x52, 0x46, 0x49, 0x4c,
                                    0x45, 0x32 }; /* "PERFILE2" LE */

struct pfile_header {
    uint64_t magic;
    uint64_t size; /* sizeof(this) = 104 */
    uint64_t attr_size; /* sizeof(attr) written = 64 */
    uint64_t attrs_size;
    uint64_t attrs_offset;
    uint64_t data_size;
    uint64_t data_offset;
    uint64_t event_types_size;
    uint64_t event_types_offset;
    uint64_t ids_size;
    uint64_t ids_offset;
    uint64_t sample_type; /* compat words */
    uint64_t read_format;
};

#define HDR_SIZE 104
#define ATTRS_OFFSET 104
#define DATA_OFFSET (ATTRS_OFFSET + 64 + 8) /* one attr + one id */

/* ---- state ---- */
static int g_nfds;
static int g_fd[MAX_CPUS];
static uint8_t *g_ring[MAX_CPUS];
static uint64_t g_tail[MAX_CPUS];
static int g_out_fd = -1;
static uint64_t g_bytes; /* data-section bytes appended */
static uint64_t g_recs, g_lost, g_other;
static const uint64_t g_sample_type =
    PERF_SAMPLE_IP | PERF_SAMPLE_TID | PERF_SAMPLE_TIME | PERF_SAMPLE_ID |
    PERF_SAMPLE_CPU | PERF_SAMPLE_PERIOD | PERF_SAMPLE_CALLCHAIN;

static long pe_open(struct pattr *a, int pid, int cpu, int group_fd,
                    u64 flags)
{
    return syscall(NR_PERF_EVENT_OPEN, a, pid, cpu, group_fd, flags);
}

static double secs_since(const struct timespec *t0)
{
    struct timespec now;
    clock_gettime(CLOCK_MONOTONIC, &now);
    return (double)(now.tv_sec - t0->tv_sec) +
           (double)(now.tv_nsec - t0->tv_nsec) / 1e9;
}

static void msleep(int ms)
{
    struct timespec ts = { .tv_sec = 0, .tv_nsec = (long)ms * 1000000L };
    nanosleep(&ts, NULL);
}

/* Copy `n` bytes from the ring at byte offset `off` (wrapping) into a
 * linear buffer — the data area is npages discrete pages, so a record
 * can straddle a page boundary. */
static void ring_copy(const uint8_t *ring, uint64_t off, uint8_t *dst,
                      size_t n)
{
    uint64_t data_size;
    memcpy(&data_size, ring + MP_DATA_SIZE, 8);
    for (size_t i = 0; i < n; i++) {
        uint64_t pos = (off + i) % data_size;
        /* page 0 is the metadata page; data pages start at ring+4096 */
        dst[i] = ring[PAGE_SIZE + pos];
    }
}

/* Drain one event's ring into the output file. Returns records moved. */
static int drain(int i)
{
    uint8_t *ring = g_ring[i];
    if (!ring)
        return 0;
    uint64_t head;
    memcpy(&head, ring + MP_DATA_HEAD, 8); /* kernel-published, release */
    int moved = 0;
    static uint8_t buf[MAX_REC];
    while (g_tail[i] < head) {
        uint16_t size;
        ring_copy(ring, g_tail[i] + 6, (uint8_t *)&size, 2);
        if (size < 8 || size > MAX_REC) {
            /* corrupt — bail out of this ring, do not chase garbage */
            fprintf(stderr, "PERFSAMPLE bad record size=%u cpu=%d\n", size,
                    i);
            break;
        }
        ring_copy(ring, g_tail[i], buf, size);
        if (write(g_out_fd, buf, size) != (ssize_t)size) {
            perror("PERFSAMPLE write");
            break;
        }
        g_bytes += size;
        g_recs++;
        uint32_t type;
        memcpy(&type, buf, 4);
        if (type == PERF_RECORD_LOST)
            g_lost++;
        else if (type != PERF_RECORD_SAMPLE && type != PERF_RECORD_FORK &&
                 type != PERF_RECORD_EXIT)
            g_other++;
        g_tail[i] += size;
        moved++;
    }
    if (moved) {
        /* publish the tail so the kernel reclaims ring space */
        volatile uint64_t *tp = (volatile uint64_t *)(ring + MP_DATA_TAIL);
        *tp = g_tail[i];
    }
    return moved;
}

static void write_header(u64 data_size)
{
    struct pfile_header h;
    memset(&h, 0, sizeof(h));
    memcpy(&h.magic, PERF_MAGIC, 8);
    h.size = HDR_SIZE;
    h.attr_size = 64;
    h.attrs_size = 64 + 8;
    h.attrs_offset = ATTRS_OFFSET;
    h.data_size = data_size;
    h.data_offset = DATA_OFFSET;
    h.sample_type = g_sample_type;
    lseek(g_out_fd, 0, SEEK_SET);
    if (write(g_out_fd, &h, sizeof(h)) != (ssize_t)sizeof(h))
        perror("PERFSAMPLE header write");
}

static void poweroff(void)
{
    syscall(SYS_reboot, 0xfee1dead, 672274793, 0x4321FEDC); /* POWER_OFF */
}

int main(int argc, char **argv)
{
    int seconds = 45;
    const char *out_path = "/test/perf.data";
    const char *load = "/test/pbench";
    /* Window control: argv[1] wins; else the first integer in
     * /test/perfsample.conf (the boot driver stages it — the kernel
     * passes no argv to init). */
    do {
        int cfd = open("/test/perfsample.conf", O_RDONLY);
        if (cfd < 0)
            break;
        char buf[64];
        long n = read(cfd, buf, sizeof(buf) - 1);
        close(cfd);
        if (n > 0) {
            buf[n] = 0;
            seconds = atoi(buf);
        }
    } while (0);
    if (argc > 1)
        seconds = atoi(argv[1]);
    if (argc > 2)
        out_path = argv[2];
    if (argc > 3)
        load = argv[3];
    if (seconds < 1)
        seconds = 1;

    /* ---- 1. one sampling event per CPU, disabled until armed ---- */
    struct pattr a;
    memset(&a, 0, sizeof(a));
    a.type = PERF_TYPE_SOFTWARE;
    a.size = 64;
    a.config = PERF_COUNT_SW_CPU_CLOCK;
    /* 1 ms (1000 Hz) requested for function-level hotmap resolution.
     * The kernel floors the effective period at one tick (TICK_NS =
     * 1e9/KERNEL_HZ): at the standard KERNEL_HZ=100 this coalesces to
     * 100 Hz tick-rate sampling (documented behavior), so hotmap
     * sampling boots run a kernel_hz=1000 build to get real 1 ms
     * observations. At most one sample per observation either way. */
    a.sample_period = 1 * 1000 * 1000;
    a.sample_type = g_sample_type;
    a.flags1 = FLAG_EXCLUDE_USER | FLAG_EXCLUDE_IDLE;
    a.wakeup_events = 1;

    for (int cpu = 0; cpu < MAX_CPUS; cpu++) {
        long fd = pe_open(&a, -1, cpu, -1, 0);
        if (fd < 0) {
            if (cpu == 0) {
                fprintf(stderr,
                        "PERFSAMPLE open cpu0 failed errno=%d\n", errno);
                printf("PERFSAMPLE DONE rc=1\n");
                return 1;
            }
            break; /* past the last CPU */
        }
        void *m = mmap(NULL, (1 + RING_PAGES) * PAGE_SIZE,
                       PROT_READ | PROT_WRITE, MAP_SHARED, (int)fd, 0);
        if (m == MAP_FAILED) {
            fprintf(stderr, "PERFSAMPLE mmap cpu%d errno=%d\n", cpu,
                    errno);
            close((int)fd);
            break;
        }
        g_fd[g_nfds] = (int)fd;
        g_ring[g_nfds] = (uint8_t *)m;
        g_tail[g_nfds] = 0;
        g_nfds++;
    }
    if (g_nfds == 0) {
        printf("PERFSAMPLE DONE rc=1\n");
        return 1;
    }
    printf("PERFSAMPLE OPEN cpus=%d events=%d period_us=%llu\n", g_nfds,
           g_nfds, (unsigned long long)(a.sample_period / 1000));
    fflush(stdout);

    /* ---- 2. output file: container header first (data size patched at
     * close; records stream in as they drain, so a hard poweroff leaves
     * a valid prefix) ---- */
    g_out_fd = open(out_path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (g_out_fd < 0) {
        fprintf(stderr, "PERFSAMPLE open %s errno=%d\n", out_path, errno);
        printf("PERFSAMPLE DONE rc=1\n");
        return 1;
    }
    write_header(0);
    /* the single attr section: attr (64 B) + id word */
    uint8_t aid[72];
    memset(aid, 0, sizeof(aid));
    memcpy(aid, &a, 64);
    u64 ev_id = 1;
    memcpy(aid + 64, &ev_id, 8);
    lseek(g_out_fd, ATTRS_OFFSET, SEEK_SET);
    if (write(g_out_fd, aid, sizeof(aid)) != (ssize_t)sizeof(aid)) {
        perror("PERFSAMPLE attr write");
    }
    lseek(g_out_fd, DATA_OFFSET, SEEK_SET);

    /* ---- 3. enable everything, then spawn the load ---- */
    for (int i = 0; i < g_nfds; i++) {
        if (ioctl(g_fd[i], IOC_ENABLE, 0) != 0)
            fprintf(stderr, "PERFSAMPLE enable fd%d errno=%d\n", i, errno);
    }

    pid_t child = 0;
    if (load && load[0]) {
        child = fork();
        if (child == 0) {
            execl(load, "pbench", "/test", "/test/pbench-results.txt",
                  (char *)NULL);
            /* only reached when the load is missing */
            fprintf(stderr, "PERFSAMPLE exec %s errno=%d\n", load, errno);
            _exit(127);
        }
        printf("PERFSAMPLE LOAD pid=%d path=%s\n", (int)child, load);
        fflush(stdout);
    }

    /* ---- 4. the sampling window: drain every ring, then stop ---- */
    struct timespec t0;
    clock_gettime(CLOCK_MONOTONIC, &t0);
    while (secs_since(&t0) < (double)seconds) {
        msleep(10);
        for (int i = 0; i < g_nfds; i++)
            drain(i);
    }
    for (int i = 0; i < g_nfds; i++) {
        ioctl(g_fd[i], IOC_DISABLE, 0);
        drain(i); /* final sweep */
    }
    if (child > 0) {
        /* The load had its window; stop it before the dump write so the
         * tail of the file is quiet. SIGKILL only — do NOT waitpid():
         * if pbench's battery ran to completion it called
         * reboot(POWER_OFF) and its task never reaches a reapable exit
         * on this kernel (observed: the parent's wait4 parks forever,
         * WAIT4-PARK diagnostic nch=1 nz=0), and init is protected from
         * the reboot path's SIGTERM, so the only safe move is to not
         * care. The zombie is reaped by nobody; we power off below.
         * NOTE: the window must be SHORTER than the pbench battery
         * (~35 s floor on x86 KVM) so the kill lands while pbench is
         * still running — if the battery wins the race its reboot path
         * runs concurrently with our dump write. */
        kill(child, SIGKILL);
    }

    write_header(g_bytes);
    fsync(g_out_fd);
    close(g_out_fd);
    printf("PERFSAMPLE WINDOW seconds=%d records=%llu lost=%llu bytes=%llu "
           "other=%llu\n",
           seconds, (unsigned long long)g_recs, (unsigned long long)g_lost,
           (unsigned long long)g_bytes, (unsigned long long)g_other);
    fflush(stdout);
    fsync(1);

    /* ---- 5. tear the events down and hand the machine back ---- */
    for (int i = 0; i < g_nfds; i++) {
        munmap(g_ring[i], (1 + RING_PAGES) * PAGE_SIZE);
        close(g_fd[i]);
    }
    printf("PERFSAMPLE DONE rc=0\n");
    fflush(stdout);
    msleep(200);
    poweroff();
    return 0;
}
