/* mkprobe.c — minimal reproducer for the p6 tree-build mkdir EIO seen on
 * pbench r20head boots (mkdir /test/pbench-tree returned -5/EIO in 2/3
 * head boots, 0/3 base boots). Replicates p6_build_tree's exact sequence:
 * mkdir the tree dir, create P6 files with 4K writes, unlink, rmdir —
 * 50 rounds, reporting every non-EEXIST mkdir/open error.
 */
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/stat.h>

#define P6_FILES 32

int main(void) {
    char dir[300], path[300];
    char data[4096];
    unsigned int seed = 999;
    size_t i;
    for (i = 0; i < sizeof(data); i++) { seed = seed * 1103515245u + 12345u; data[i] = (char)(seed >> 16); }
    int fails = 0;
    /* Pre-phase: mimic the pbench pre-state — ~24 MB of fault-file writes
     * (p3 rows) before the p6 tree build, on the same 192M fs geometry. */
    int prefd = open("/test/faultfile", O_CREAT | O_WRONLY | O_TRUNC, 0644);
    if (prefd >= 0) {
        for (i = 0; i < 6000; i++) {
            if (write(prefd, data, sizeof(data)) != (ssize_t)sizeof(data)) {
                printf("MKFAIL pre write i=%zu errno=%d\n", i, errno); fails++; break;
            }
        }
        close(prefd);
    } else {
        printf("MKFAIL pre open errno=%d\n", errno); fails++;
    }
    for (int round = 0; round < 50; round++) {
        snprintf(dir, sizeof(dir), "/test/pbench-tree");
        if (mkdir(dir, 0755) < 0 && errno != EEXIST) {
            printf("MKFAIL round=%d mkdir errno=%d\n", round, errno);
            fails++;
            continue;
        }
        int ok = 1;
        for (long f = 0; f < P6_FILES; f++) {
            snprintf(path, sizeof(path), "%s/f%04ld", dir, f);
            int fd = open(path, O_CREAT | O_WRONLY | O_TRUNC, 0644);
            if (fd < 0) { printf("MKFAIL round=%d open %s errno=%d\n", round, path, errno); fails++; ok = 0; break; }
            if (write(fd, data, sizeof(data)) != (ssize_t)sizeof(data)) {
                printf("MKFAIL round=%d write %s errno=%d\n", round, path, errno); fails++; ok = 0; close(fd); break;
            }
            close(fd);
        }
        for (long f = 0; f < P6_FILES && ok; f++) {
            snprintf(path, sizeof(path), "%s/f%04ld", dir, f);
            unlink(path);
        }
        if (rmdir(dir) < 0 && errno != ENOENT) {
            printf("MKFAIL round=%d rmdir errno=%d\n", round, errno);
            fails++;
        }
    }
    printf("MKLOOP-DONE fails=%d\n", fails);
    return 0;
}
