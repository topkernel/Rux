/* logctl_x86probe.c — log-control lane guest probe (x86_64, as init).
 *
 * One binary, two boots (a guest reset does not clear RAM, so the
 * pstore region keeps the last panic's console record):
 *
 * boot 1 (the knob/kmsg checks, then a deliberate crash):
 *   - /proc/sys/kernel/printk reads the four live numbers and takes a
 *     single-number write (console_loglevel only);
 *   - at console_loglevel 3 a KERN_INFO /dev/kmsg marker is stored in
 *     the ring (read back through /dev/kmsg) but never emitted to the
 *     serial console; after restoring 6 the same write emits;
 *   - syslog(2) action 8 moves the same value the file reads;
 *   - /proc/kmsg: reference syslog shape (`<N>[SSSSS.MMMMMM] `), fill
 *     reads (>= 2 records in one read), destructive consumption
 *     (window 2 never re-serves window 1's head), single-reader EBUSY.
 *
 * boot 2: the pstore console record resurfaces — the panic banner must
 * be the reference shape `Kernel panic - not syncing: <message>` with
 * the message INLINE (no standalone `PANIC:` line).
 *
 * Built static (host gcc targets the amd64 guest directly) and staged
 * as /test/lx by test/logctl-smoke.sh; the driver asserts the LX/LX2
 * lines against the serial log.
 */
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/syscall.h>
#include <unistd.h>

static int pmsg(const char *s) { return (int)write(1, s, strlen(s)); }

static int read_file(const char *path, char *buf, int cap)
{
    int fd = open(path, O_RDONLY);
    int n;
    if (fd < 0) return -1;
    n = (int)read(fd, buf, cap - 1);
    close(fd);
    if (n < 0) return -1;
    buf[n] = '\0';
    return n;
}

/* Read /proc/sys/kernel/printk and return the first number. */
static int printk_first(void)
{
    char buf[64];
    int v = -1;
    if (read_file("/proc/sys/kernel/printk", buf, sizeof(buf)) < 0)
        return -1;
    v = 0;
    for (int i = 0; buf[i] >= '0' && buf[i] <= '9'; i++)
        v = v * 10 + (buf[i] - '0');
    return v;
}

static void dump_printk(const char *tag)
{
    char buf[64];
    int n = read_file("/proc/sys/kernel/printk", buf, sizeof(buf));
    pmsg("LX: ");
    pmsg(tag);
    pmsg("=");
    if (n <= 0) { pmsg("<unreadable>\n"); return; }
    write(1, buf, (size_t)n); /* raw: tabs and trailing newline as-is */
}

static int write_file(const char *path, const char *data)
{
    int fd = open(path, O_WRONLY);
    int n;
    if (fd < 0) return -1;
    n = (int)write(fd, data, strlen(data));
    close(fd);
    return n;
}

/* One /dev/kmsg record: seek to the next seq, write `text` at `level`,
 * read exactly that record back. Returns 1 if the read-back contains
 * `needle`. `readback` 0 skips the read (console-emit assertions). */
static int kmsg_xch(const char *text, const char *needle, int readback)
{
    int fd = open("/dev/kmsg", O_RDWR | O_NONBLOCK);
    char line[512];
    int ok = 0;
    if (fd < 0) return 0;
    if (lseek(fd, 0, SEEK_END) < 0) { close(fd); return 0; }
    if (write(fd, text, strlen(text)) < 0) { close(fd); return 0; }
    if (readback) {
        ssize_t n = read(fd, line, sizeof(line) - 1);
        if (n > 0) {
            line[n] = '\0';
            ok = strstr(line, needle) != NULL;
        }
    } else {
        ok = 1;
    }
    close(fd);
    return ok;
}

/* Reference syslog header: `<N>[SSSSS.MMMMMM] ` — N in 0..7, seconds
 * right-aligned to 5 columns, 6-digit microseconds, `] `. */
static int line_shape_ok(const char *s)
{
    int i;
    if (!(s[0] == '<' && s[1] >= '0' && s[1] <= '7' && s[2] == '>' &&
          s[3] == '['))
        return 0;
    for (i = 4; i < 9; i++)
        if (!((s[i] >= '0' && s[i] <= '9') || s[i] == ' '))
            return 0;
    if (s[9] != '.') return 0;
    for (i = 10; i < 16; i++)
        if (!(s[i] >= '0' && s[i] <= '9'))
            return 0;
    return s[16] == ']' && s[17] == ' ';
}

int main(void)
{
    char km1[4096], km2[4096];
    char head1[32];
    int n1, n2, i, lines, shape_ok, rc;

    /* Boot 2? The pstore console record from boot 1's panic exists. */
    {
        char rec[8192];
        int fd = open("/sys/fs/pstore/console-ramoops-0", O_RDONLY);
        if (fd >= 0) {
            int n = (int)read(fd, rec, sizeof(rec) - 1);
            close(fd);
            if (n > 0) {
                int banner = 0, old = 0, end = 0;
                rec[n] = '\0';
                pmsg("===LX2: pstore record resurfaced===\n");
                write(1, rec, (size_t)n);
                pmsg("===LX2: record end===\n");
                for (i = 0; i < n; i++) {
                    if (!strncmp(rec + i, "Kernel panic - not syncing: sysrq", 33))
                        banner++;
                    if (!strncmp(rec + i, "\nPANIC: ", 8))
                        old++;
                    if (!strncmp(rec + i, "---[ end Kernel panic - not syncing ]---", 40))
                        end++;
                }
                rc = dprintf(1, "LX2: banner_inline=%d\n", banner); (void)rc;
                rc = dprintf(1, "LX2: old_panic_line=%d\n", old); (void)rc;
                rc = dprintf(1, "LX2: end_marker=%d\n", end); (void)rc;
                pmsg("===LX2: done===\n");
                for (;;) pause();
            }
        }
    }

    pmsg("===LX1: logctl probe start===\n");

    /* (1) the four numbers, tab-separated, live first number. */
    dump_printk("printk0");

    /* (2) single-number write lowers the live console_loglevel. */
    if (write_file("/proc/sys/kernel/printk", "3") < 0)
        pmsg("LX: write3_failed=1\n");
    dump_printk("printk_after3");

    /* (3) below-console record: stored, NOT emitted. The marker string
     * never goes to stdout, so its only path to the serial is the
     * console emit. */
    rc = dprintf(1, "LX: ring_has_quiet=%d\n",
                 kmsg_xch("LXQUIET: below-console marker",
                          "LXQUIET: below-console marker", 1)); (void)rc;

    /* (4) restore; the same write now emits to the serial console. */
    if (write_file("/proc/sys/kernel/printk", "6") < 0)
        pmsg("LX: write6_failed=1\n");
    dump_printk("printk_restored");
    kmsg_xch("LXLOUD: above-console marker", NULL, 0);
    pmsg("LX: loud_written=1\n");

    /* (5) syslog(2) action 8 moves the value the file reads. */
    {
        long r = syscall(SYS_syslog, 8, NULL, 4);
        int first = printk_first();
        rc = dprintf(1, "LX: syslog_ret=%ld first_after=%d\n", r, first); (void)rc;
        rc = dprintf(1, "LX: syslog_consistent=%d\n", first == 4); (void)rc;
        syscall(SYS_syslog, 8, NULL, 6); /* restore */
    }

    /* (6) /proc/kmsg: shape, fill, single-reader, destructive. */
    {
        int fd = open("/proc/kmsg", O_RDONLY);
        int fd2;
        if (fd < 0) {
            pmsg("LX: kmsg_open_failed=1\n");
            return 1;
        }
        /* single-reader gate while open */
        fd2 = open("/proc/kmsg", O_RDONLY);
        rc = dprintf(1, "LX: km_second_open_ebusy=%d\n",
                     fd2 < 0 && errno == EBUSY); (void)rc;
        if (fd2 >= 0) close(fd2);

        n1 = (int)read(fd, km1, sizeof(km1) - 1);
        close(fd);
        if (n1 <= 0) {
            pmsg("LX: km1_empty=1\n");
            return 1;
        }
        km1[n1] = '\0';
        lines = 1; shape_ok = line_shape_ok(km1);
        for (i = 0; i < n1; i++)
            if (km1[i] == '\n' && i + 1 < n1) {
                lines++;
                if (!line_shape_ok(km1 + i + 1)) shape_ok = 0;
            }
        rc = dprintf(1, "LX: km1_records=%d\n", lines); (void)rc;
        rc = dprintf(1, "LX: km1_shape_ok=%d\n", shape_ok); (void)rc;
        rc = dprintf(1, "LX: km_pid_deco=%d\n",
                     strstr(km1, "pid(") != NULL); (void)rc;
        rc = dprintf(1, "LX: km_fill_ge2=%d\n", lines >= 2); (void)rc;
        for (i = 0; i < 31 && km1[i]; i++) head1[i] = km1[i];
        head1[i] = '\0';
        rc = dprintf(1, "LX: km1_head=%.31s\n", head1); (void)rc;

        /* window 2: a fresh marker, then only new records come back. */
        kmsg_xch("LXD: window-two marker", NULL, 0);
        fd = open("/proc/kmsg", O_RDONLY);
        n2 = fd >= 0 ? (int)read(fd, km2, sizeof(km2) - 1) : -1;
        if (fd >= 0) close(fd);
        if (n2 <= 0) {
            pmsg("LX: km2_empty=1\n");
            return 1;
        }
        km2[n2] = '\0';
        rc = dprintf(1, "LX: km2_has_lxd=%d\n",
                     strstr(km2, "LXD: window-two marker") != NULL); (void)rc;
        rc = dprintf(1, "LX: km2_has_km1head=%d\n",
                     n2 >= i && !strncmp(km2, head1, (size_t)i)); (void)rc;
    }

    /* (7) deliberate crash: panic=3 on the cmdline reboots the guest. */
    pmsg("===LX1: crashing via sysrq c===\n");
    if (write_file("/proc/sysrq-trigger", "c") < 0) {
        pmsg("LX1: sysrq write failed\n");
        return 1;
    }
    for (;;) pause();
    return 0;
}
