#define _GNU_SOURCE
#include <sys/mman.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <time.h>
// fsx replica v6: the check fsx actually does — its GOOD_BUF vs
// (mapped byte | fd byte) at RANDOM offsets INCLUDING unaligned ones,
// after its ops: MMAP READ, MMAP WRITE, fd WRITE, fd READ (fsx calls
// these map_read/map_write/read/write), TRUNCATE to random size,
// msync — with sizes up to 65536 and file cap 256KB, offsets NOT
// page-aligned (fsx offsets are byte-granular!).
int main(void){
    srand48(777);
    int fd = open("/dev/shm/fxw24", O_RDWR|O_CREAT|O_TRUNC, 0666);
    if (ftruncate(fd, 0x40000)) return 2;
    char *p = mmap(NULL, 0x40000, PROT_READ|PROT_WRITE, MAP_FILE|MAP_SHARED, fd, 0);
    static char sizechk[0x40000];
    memset(sizechk, 0, sizeof sizechk);
    int fails = 0;
    for (int i = 0; i < 1000; i++) {
        long op = lrand48() % 6;
        long size = 1 + lrand48() % 0x10000;
        long off = lrand48() % 0x38000;   // BYTE-granular offsets!
        if (off + size > 0x40000) continue;
        if (op == 0) {  // map write
            for (long k=0;k<size;k++) p[off+k] = 'A' + ((off+k)%26);
            for (long k=0;k<size;k++) sizechk[off+k] = 'A' + ((off+k)%26);
        } else if (op == 1) {  // fd write
            char w[0x10000];
            for (long k=0;k<size;k++) w[k] = 'C' + ((off+k)%26);
            lseek(fd, off, SEEK_SET);
            if (write(fd, w, size) != size) { printf("fdw fail %d\n", errno); fails++; break; }
            for (long k=0;k<size;k++) sizechk[off+k] = 'C' + ((off+k)%26);
        } else if (op == 2) {  // truncate
            if (ftruncate(fd, off)) fails++;
            for (long k=off;k<0x40000;k++) sizechk[k]=0;
            // file grew back? no — fsx keeps its own size bookkeeping; keep simple
        } else if (op == 3) {
            if (msync(p, 0x40000, MS_SYNC)) fails++;
        } else {  // VERIFY both paths at an unaligned offset
            long vlen = 64;
            if (off + vlen > 0x40000) continue;
            if (memcmp(p+off, sizechk+off, vlen) != 0) {
                printf("MAP-MISMATCH off=%lx i=%d\n", off, i); fails++;
                if (fails > 4) break;
            }
            char rb[64];
            lseek(fd, off, SEEK_SET);
            int r = read(fd, rb, vlen);
            if (r != vlen || memcmp(rb, sizechk+off, vlen) != 0) {
                printf("FD-MISMATCH off=%lx i=%d r=%d\n", off, i, r); fails++;
                if (fails > 4) break;
            }
        }
    }
    printf("fails=%d\n", fails);
    return 0;
}
