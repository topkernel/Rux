#define _GNU_SOURCE
#include <sys/mman.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
#include <stdarg.h>
// fxw29 — faithful replica of LTP 20240524 fsx-linux (the REWRITE):
// ops READ/WRITE/TRUNCATE/MAPREAD/MAPWRITE; WRITE pattern 'a'+r%10,
// MAPWRITE pattern 'l'+r%10; shadow buffer model; MAPWRITE ftruncate-
// extends first, memcpy, MS_SYNC, munmap. Path: argv[1] (ext4 face).
#define MAXSZ 0x40000
static char shadow[MAXSZ];
static long file_size;
static int fd, fails;
static long long ops;
static char ring[50][96]; static int rn;
static void ring_push(const char *f, ...){
    va_list ap; va_start(ap, f);
    vsnprintf(ring[rn%50], 96, f, ap);
    va_end(ap); rn++;
}
static void ring_dump(void){
    printf("---- ring ----\n");
    for (int k=rn-50<0?0:rn-50; k<rn; k++) printf("%s", ring[k%50]);
}
static void check(const char *tag, long off, const char *got, long n){
    long k=0; while (k<n && got[k]==shadow[off+k]) k++;
    if (k<n || n==0) {
        if (k<n) { printf("%s off=%lx i=%lld bad+%ld exp=%d got=%d fsz=%lx\n",
                        tag, off, ops, k, (unsigned char)shadow[off+k], (unsigned char)got[k], file_size); ring_dump(); }
        fails++;
    }
}
int main(int argc, char **argv){
    const char *path = argc>1?argv[1]:"/tmp/fxw29";
    srandom(777);
    fd = open(path, O_RDWR|O_CREAT|O_TRUNC, 0666);
    if (fd<0 || ftruncate(fd,0)) return 1;
    file_size = 0;
    for (ops=0; ops<2000 && fails<6; ops++) {
        int op = random()%5;
        long size = 1 + random()%0x10000;
        long off = random()%0x38000;
        if (off+size > MAXSZ) continue;
        ring_push("TRACE i=%lld op=%d off=%lx sz=%lx fsz=%lx\n", ops, op, off, size, file_size);
        if (op==1) { // WRITE
            static char b[0x10000+16];
            for (long k=0;k<size;k++){ char c='a'+random()%10; b[k]=c; shadow[off+k]=c; }
            lseek(fd, off, SEEK_SET);
            if (write(fd, b, size)!=size){ printf("wfail\n"); fails++; break; }
            if (off+size>file_size) file_size=off+size;
        } else if (op==2) { // TRUNCATE
            if (ftruncate(fd, off)) fails++;
            memset(shadow+off, 0, MAXSZ-off);
            file_size = off;
        } else if (op==0) { // READ+verify
            if (off+size>file_size) continue;
            static char rb[0x10000+16];
            int r = pread(fd, rb, size, off);
            if (r!=size) { printf("READ short r=%d off=%lx sz=%lx fsz=%lx\n", r, off, size, file_size); ring_dump(); fails++; }
            else check("RD", off, rb, size);
        } else if (op==4) { // MAPREAD+verify
            if (off+size>file_size) continue;
            long mo=off&~0xfffL, ml=((off+size-mo)+0xfffL)&~0xfffL;
            char *p=mmap(NULL,ml,PROT_READ,MAP_FILE|MAP_SHARED,fd,mo);
            if (p==MAP_FAILED){printf("mrfail %d\n",errno);fails++;break;}
            check("MR", off, p+(off-mo), size);
            munmap(p,ml);
        } else { // MAPWRITE
            if (off+size>file_size){ if (ftruncate(fd,off+size)){printf("tgfail\n");fails++;break;} file_size=off+size; }
            static char b[0x10000+16];
            for (long k=0;k<size;k++){ char c='l'+random()%10; b[k]=c; shadow[off+k]=c; }
            long mo=off&~0xfffL, ml=((off+size-mo)+0xfffL)&~0xfffL;
            char *p=mmap(NULL,ml,PROT_READ|PROT_WRITE,MAP_FILE|MAP_SHARED,fd,mo);
            if (p==MAP_FAILED){printf("mwfail %d\n",errno);fails++;break;}
            memcpy(p+(off-mo), b, size);
            if (msync(p,ml,MS_SYNC)){printf("msfail %d\n",errno);fails++;break;}
            munmap(p,ml);
        }
    }
    printf("fails=%d fsz=%lx\n", fails, file_size);
    return fails?1:0;
}
