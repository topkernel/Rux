#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/wait.h>

int main(void) {
    setbuf(stdout, NULL);
    int ps = getpagesize();
    size_t size = ps * 3;
    int fd = open("mc04file", O_CREAT | O_RDWR, 0600);
    ftruncate(fd, size);
    fsync(fd);
    char *ptr = mmap(NULL, size, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0);
    if (ptr == MAP_FAILED) { perror("mmap"); return 1; }
    /* warm the cache ourselves in-process first */
    pid_t p = fork();
    if (p == 0) {
        int r = mlock(ptr, size);
        printf("child mlock rc=%d\n", r);
        unsigned char cv[3];
        int cr = mincore(ptr, size, cv);
        printf("child mincore rc=%d vec=%d %d %d\n", cr, cv[0]&1, cv[1]&1, cv[2]&1);
        _exit(0);
    }
    int st; waitpid(p, &st, 0);
    unsigned char vec[3];
    int r = mincore(ptr, size, vec);
    printf("mincore rc=%d vec=%d %d %d\n", r, vec[0]&1, vec[1]&1, vec[2]&1);
    /* also mincore a FRESH mapping in the parent (untouched) */
    char *p2 = mmap(NULL, size, PROT_READ, MAP_PRIVATE, fd, 0);
    unsigned char v2[3];
    r = mincore(p2, size, v2);
    printf("fresh-map mincore rc=%d vec=%d %d %d\n", r, v2[0]&1, v2[1]&1, v2[2]&1);
    /* read one page and re-check */
    volatile char c0 = p2[0]; (void)c0;
    r = mincore(p2, size, v2);
    printf("after-touch mincore rc=%d vec=%d %d %d\n", r, v2[0]&1, v2[1]&1, v2[2]&1);
    return 0;
}
