// mmitrace.c — two-sided mmi syscall-stream capture (oh-launch, mouse
// endgame). Runs IDENTICALLY on the reference OHOS kernel and on Rux:
// as a root init service (the key_enable slot, /system/bin/key_enable),
// started early in the boot (param job on bootevent.param_watcher.
// started — before multimodalinput's spawn), it
//
//   1. mounts tracefs at /sys/kernel/tracing (EBUSY = already there),
//   2. grows the ring (buffer_size_kb),
//   3. polls /proc for a task whose comm == "multimodalinput" — that
//      pid is the service tgid,
//   4. writes the tgid to set_event_pid (both kernels: only that
//      process tree records events),
//   5. arms raw_syscalls:sys_enter + sys_exit,
//   6. drains trace_pipe (O_NONBLOCK poll loop; complete lines only)
//      into /data/local/mmitrace/<tag>.txt until the window closes,
//      printing MMT-* progress lines to stdout (console -> serial),
//   7. disarms, final-drains, writes a DONE marker with counts, exits.
//
// The host diff of the two <tag>.txt streams (the same trace text
// format on both kernels) names the first divergent syscall after the
// last common one — the mouse-chain conviction method.
//
// Usage: key_enable <tag> [window_secs=100] [target_comm=multimodalinput]

#define _GNU_SOURCE
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdarg.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mount.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#define TRACEDIR "/sys/kernel/tracing"
#define OUTDIR "/data/local/mmitrace"

static const char *g_tag = "mm";
static int g_window = 100;

static void logf_(const char *fmt, ...)
{
    char buf[256];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    if (n > 0)
    {
        write(1, "MMT-", 4);
        write(1, buf, (size_t)n);
        if (buf[n - 1] != '\n')
            write(1, "\n", 1);
    }
}

static int write_file(const char *path, const char *text)
{
    int fd = open(path, O_WRONLY);
    if (fd < 0)
        return -1;
    ssize_t n = write(fd, text, strlen(text));
    close(fd);
    return (n == (ssize_t)strlen(text)) ? 0 : -1;
}

static int read_file(const char *path, char *buf, size_t cap)
{
    int fd = open(path, O_RDONLY);
    if (fd < 0)
        return -1;
    ssize_t n = read(fd, buf, cap - 1);
    close(fd);
    if (n < 0)
        return -1;
    buf[n] = 0;
    return (int)n;
}

/* Find the first pid whose /proc/<pid>/comm matches the prefix. With
 * census != NULL, collect up to 64 distinct comms (debug census). */
static int find_comm_census(const char *want, char census[][24], int *ncens)
{
    DIR *d = opendir("/proc");
    if (!d)
        return -1;
    struct dirent *e;
    int found = -1, ndir = 0;
    size_t len = strlen(want);
    while ((e = readdir(d)))
    {
        if (e->d_name[0] < '0' || e->d_name[0] > '9')
            continue;
        ndir++;
        char path[64], comm[32];
        snprintf(path, sizeof(path), "/proc/%s/comm", e->d_name);
        int n = read_file(path, comm, sizeof(comm));
        if (n <= 0)
            continue;
        if (comm[n - 1] == '\n')
            comm[n - 1] = 0;
        if (census && *ncens < 64)
        {
            int dup = 0;
            for (int i = 0; i < *ncens; i++)
                if (strcmp(census[i], comm) == 0)
                {
                    dup = 1;
                    break;
                }
            if (!dup)
                snprintf(census[(*ncens)++], 24, "%s:%s", comm, e->d_name);
        }
        if (found < 0 && strncmp(comm, want, len) == 0)
            found = atoi(e->d_name);
    }
    closedir(d);
    if (census && *ncens < 64)
        snprintf(census[(*ncens)++], 24, "TOTAL:%d", ndir);
    return found;
}

static int find_comm(const char *want)
{
    return find_comm_census(want, NULL, NULL);
}

/* Sweep the pid space by DIRECT LOOKUP (/proc/N/comm, one open per
 * pid) — bypasses readdir entirely. Two purposes: (1) resilience —
 * the readdir listing (64-cap era) hid live tasks, while lookup by
 * pid answers for ANY task in the kernel's table, thread or leader;
 * (2) diagnostics — the openable count vs the same round's readdir
 * count decides "listing bug" vs "table membership bug" in one boot. */
static int sweep_direct(const char *want, int maxpid, int *openable_out)
{
    int openable = 0;
    size_t len = strlen(want);
    for (int p = 2; p < maxpid; p++)
    {
        char path[40], comm[32];
        snprintf(path, sizeof(path), "/proc/%d/comm", p);
        int fd = open(path, O_RDONLY);
        if (fd < 0)
            continue;
        openable++;
        int n = read(fd, comm, sizeof(comm) - 1);
        close(fd);
        if (n <= 0)
            continue;
        comm[n] = 0;
        if (comm[n - 1] == '\n')
            comm[n - 1] = 0;
        if (strncmp(comm, want, len) == 0)
        {
            logf_("direct sweep HIT pid=%d comm=%s (openable=%d so far)",
                  p, comm, openable);
            if (openable_out)
                *openable_out = openable;
            return p;
        }
    }
    logf_("direct sweep done: openable=%d no hit", openable);
    if (openable_out)
        *openable_out = openable;
    return -1;
}


/* List the thread ids of a process via /proc/<tgid>/task (both
 * kernels expose it). Returns the count written; 1..cap. */
static int list_tids(int tgid, int *tids, int cap)
{
    char path[64];
    snprintf(path, sizeof(path), "/proc/%d/task", tgid);
    DIR *d = opendir(path);
    if (!d)
        return 0;
    struct dirent *e;
    int n = 0;
    while ((e = readdir(d)) && n < cap)
    {
        if (e->d_name[0] < '0' || e->d_name[0] > '9')
            continue;
        int t = atoi(e->d_name);
        if (t > 0)
            tids[n++] = t;
    }
    closedir(d);
    if (n == 0)
        tids[n++] = tgid;
    return n;
}

/* Write the pid set to set_event_pid. mode 'R' (Rux): the tgid alone
 * (the kernel matches tid OR tgid, whole tree forever). mode 'L'
 * (reference/Linux): tgid + every current tid — the reference matches
 * task pids only, and threads spawned later need a refresh. */
static void write_pid_filter(int tgid, char mode)
{
    char text[256];
    if (mode == 'R')
    {
        snprintf(text, sizeof(text), "%d", tgid);
    }
    else
    {
        int tids[48];
        int n = list_tids(tgid, tids, 48);
        int off = 0;
        off += snprintf(text + off, sizeof(text) - (size_t)off, "%d", tgid);
        for (int i = 0; i < n; i++)
        {
            if (tids[i] == tgid)
                continue;
            off += snprintf(text + off, sizeof(text) - (size_t)off, " %d", tids[i]);
        }
    }
    write_file(TRACEDIR "/set_event_pid", text);
}

/* Line assembler: only complete lines reach the output file, so a
 * chunk boundary can never split or duplicate a record. */
static char lbuf[512];
static size_t lbuf_n;
static long g_lines, g_bytes;

static void feed(int out, const char *buf, size_t n)
{
    for (size_t i = 0; i < n; i++)
    {
        lbuf[lbuf_n++] = buf[i];
        if (buf[i] == '\n' || lbuf_n == sizeof(lbuf))
        {
            if (out >= 0)
            {
                write(out, lbuf, lbuf_n);
                g_bytes += (long)lbuf_n;
            }
            g_lines++;
            lbuf_n = 0;
        }
    }
}

int main(int argc, char **argv)
{
    g_tag = argc > 1 ? argv[1] : "mm";
    g_window = argc > 2 ? atoi(argv[2]) : 100;
    const char *comm = argc > 3 ? argv[3] : "multimodalinput";
    /* mode arg: 'R' = Rux kernel filter (tgid matches the tree),
     * 'L' = reference kernel (tid list + periodic refresh). */
    char mode = argc > 4 ? argv[4][0] : 'R';

    mkdir(OUTDIR, 0755);
    signal(SIGPIPE, SIG_IGN);
    setvbuf(stdout, NULL, _IOLBF, 0);
    logf_("start tag=%s window=%ds comm=%s pid=%d", g_tag, g_window,
          comm, getpid());

    mkdir("/sys", 0755);
    mkdir("/sys/kernel", 0755);
    mkdir(TRACEDIR, 0755);
    if (mount("tracefs", TRACEDIR, "tracefs", 0, NULL) != 0 && errno != EBUSY)
        logf_("mount tracefs errno=%d (continuing — may be auto-mounted)",
              errno);
    else
        logf_("tracefs at %s", TRACEDIR);

    logf_("step: reading tracing_on");
    char probe[64];
    if (read_file(TRACEDIR "/tracing_on", probe, sizeof(probe)) < 0)
    {
        logf_("FATAL tracing_on unreadable errno=%d", errno);
        return 3;
    }
    logf_("step: tracing_on ok, writing buffer_size_kb");
    write_file(TRACEDIR "/buffer_size_kb", "8192");
    logf_("step: buffer ok, polling /proc");

    int tgid = -1;
    for (int i = 0; i < 150 && tgid < 0; i++)
    {
        if (i == 0 || i == 5)
        {
            static char cens[64][24];
            int ncens = 0;
            find_comm_census("", cens, &ncens);
            for (int k = 0; k < ncens; k += 2)
            {
                char line[64];
                int off = snprintf(line, sizeof(line), "%s", cens[k]);
                if (k + 1 < ncens)
                    snprintf(line + off, sizeof(line) - (size_t)off,
                             " | %s", cens[k + 1]);
                logf_("census %s", line);
            }
        }
        if (i % 10 == 0)
            logf_("poll round %d", i);
        tgid = find_comm(comm);
        if (tgid < 0 && (i % 5) == 4)
        {
            /* readdir missed for ~10s: sweep by direct lookup. The
             * openable count in the log line names the divergence —
             * openable >> readdir count = listing-layer bug;
             * no comm hit at all = table-membership bug. */
            int openable = -1;
            tgid = sweep_direct(comm, 8192, &openable);
        }
        if (tgid < 0)
        {
            struct timespec ts = {2, 0};
            nanosleep(&ts, NULL);
        }
    }
    if (tgid < 0)
    {
        logf_("FATAL target comm never appeared");
        return 3;
    }
    /* The comm match may land on a thread (Rux lists tids in /proc);
     * resolve the process via /proc/<pid>/status Tgid: (both kernels
     * carry it), so the reference's tid-only set_event_pid still
     * captures the whole service through its tgid==tid leader. */
    {
        char path[64], status[2048];
        snprintf(path, sizeof(path), "/proc/%d/status", tgid);
        int n = read_file(path, status, sizeof(status));
        if (n > 0)
        {
            char *tg = strstr(status, "Tgid:");
            if (tg)
            {
                int t = atoi(tg + 5);
                if (t > 0 && t != tgid)
                {
                    logf_("comm match %d is a thread — tgid=%d", tgid, t);
                    tgid = t;
                }
            }
        }
    }
    logf_("target tgid=%d", tgid);

    write_pid_filter(tgid, mode);
    logf_("pid filter written (mode=%c)", mode);

    write_file(TRACEDIR "/trace", ""); /* clear */
    write_file(TRACEDIR "/events/raw_syscalls/sys_enter/enable", "1");
    write_file(TRACEDIR "/events/raw_syscalls/sys_exit/enable", "1");
    write_file(TRACEDIR "/tracing_on", "1");
    logf_("armed raw_syscalls enter+exit, filter=%d", tgid);

    /* readbacks: name a silently-failed write (set_event_pid, the
     * enables) in the log instead of discovering it as lines=0. */
    {
        char rb[160];
        int n = read_file(TRACEDIR "/set_event_pid", rb, sizeof(rb) - 1);
        if (n > 0) { rb[n] = 0; logf_("rb set_event_pid=[%s]", rb); }
        else logf_("rb set_event_pid FAILED errno=%d", errno);
        n = read_file(TRACEDIR "/events/raw_syscalls/sys_enter/enable", rb, sizeof(rb) - 1);
        if (n > 0) { rb[n] = 0; logf_("rb sys_enter.enable=[%s]", rb); }
        else logf_("rb sys_enter.enable FAILED errno=%d", errno);
        n = read_file(TRACEDIR "/tracing_on", rb, sizeof(rb) - 1);
        if (n > 0) { rb[n] = 0; logf_("rb tracing_on=[%s]", rb); }
    }

    char outpath[128];
    snprintf(outpath, sizeof(outpath), "%s/%s.txt", OUTDIR, g_tag);
    int out = open(outpath, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (out < 0)
        logf_("FATAL out %s errno=%d", outpath, errno);
    int pipefd = open(TRACEDIR "/trace_pipe", O_RDONLY | O_NONBLOCK);
    if (pipefd < 0)
        logf_("FATAL trace_pipe errno=%d", errno);

    char buf[65536];
    time_t t0 = time(NULL);
    long report = 5;
    while (time(NULL) - t0 < g_window)
    {
        ssize_t n = read(pipefd, buf, sizeof(buf));
        if (n > 0)
            feed(out, buf, (size_t)n);
        else if (n == 0 || (n < 0 && (errno == EAGAIN || errno == EWOULDBLOCK)))
        {
            /* empty (EOF on a plain-file rendering) or would-block:
             * both mean "nothing new right now" — poll cadence. */
            struct timespec ts = {0, 200 * 1000 * 1000};
            nanosleep(&ts, NULL);
        }
        else if (n < 0)
        {
            logf_("trace_pipe read errno=%d", errno);
            break;
        }
        long el = (long)(time(NULL) - t0);
        if (el >= report)
        {
            if (mode == 'L')
                write_pid_filter(tgid, 'L'); /* new threads join the set */
            logf_("t=%lds lines=%ld bytes=%ld", el, g_lines, g_bytes);
            /* ring control: the NON-consuming `trace` file (fresh open
             * regenerates) reports how many bytes the kernel has in
             * its rings RIGHT NOW. ring>>0 with lines=0 convicts the
             * consume path; ring=0 with lines=0 convicts the filter or
             * the arming. */
            if (el % 20 == 0)
            {
                int tf = open(TRACEDIR "/trace", O_RDONLY);
                if (tf >= 0)
                {
                    long tot = 0;
                    ssize_t rn;
                    while ((rn = read(tf, buf, sizeof(buf))) > 0)
                        tot += rn;
                    close(tf);
                    logf_("ring t=%lds content=%ld bytes", el, tot);
                }
                else
                    logf_("ring open errno=%d", errno);
            }
            if (out >= 0)
                fsync(out);
            report += 5;
            if (g_bytes > 400L * 1024 * 1024)
            {
                logf_("cap reached — stopping early");
                break;
            }
        }
    }

    write_file(TRACEDIR "/events/raw_syscalls/sys_enter/enable", "0");
    write_file(TRACEDIR "/events/raw_syscalls/sys_exit/enable", "0");
    write_file(TRACEDIR "/tracing_on", "0");
    ssize_t n;
    while ((n = read(pipefd, buf, sizeof(buf))) > 0)
        feed(out, buf, (size_t)n);
    if (out >= 0)
    {
        fsync(out);
        close(out);
    }
    sync(); /* push /data dirty pages out — the rig may kill the VM */
    logf_("DONE tag=%s tgid=%d lines=%ld bytes=%ld file=%s", g_tag, tgid,
          g_lines, g_bytes, outpath);
    return 0;
}
