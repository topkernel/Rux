#define _GNU_SOURCE
#include <sys/mman.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
// fxw26 — replica of LTP 20240524 fsx-linux REWRITE shape: every MAP op
// is its OWN mmap -> touch -> msync(MS_SYNC) -> munmap; a MAPWRITE that
// ends past file size first ftruncate()s the file larger (the rewrite's
// "File size changed" path). fd write/read are plain. Model tracks bytes.
static char good[256*1024];
int main(void){
    srand48(777);
    long cur_size = 0;
    int fd = open("/dev/shm/fxw26", O_RDWR|O_CREAT|O_TRUNC, 0666);
    int fails = 0;
    for (int i = 0; i < 2000 && fails < 6; i++) {
        long op = lrand48() % 5;
        long size = 1 + lrand48() % 0x10000;
        long off = lrand48() % 0x38000;
        if (off + size > 0x40000) continue;
        if (op == 0) {  // MAPWRITE (own mapping, grow-extend first)
            if (off + size > cur_size) {
                if (ftruncate(fd, off + size)) { printf("TRGROW fail\n"); fails++; break; }
                cur_size = off + size;
            }
            long mo = off & ~0xfffL, ml = ((off+size-mo)+0xfffL) & ~0xfffL;
            char *p = mmap(NULL, ml, PROT_READ|PROT_WRITE, MAP_FILE|MAP_SHARED, fd, mo);
            if (p == MAP_FAILED) { printf("MW mmap fail %d off=%lx\n", errno, off); fails++; break; }
            char *q = p + (off-mo);
            for (long k=0;k<size;k++) q[k] = 'a' + ((off+k)%26);
            for (long k=0;k<size;k++) good[off+k] = 'a' + ((off+k)%26);
            if (msync(p, ml, MS_SYNC)) { printf("MW msync fail %d\n", errno); fails++; break; }
            munmap(p, ml);
        } else if (op == 1) {  // fd write
            if (off + size > cur_size) {
                if (ftruncate(fd, off + size)) { printf("TRGROW2 fail\n"); fails++; break; }
                cur_size = off + size;
            }
            static char w[0x10000+16];
            for (long k=0;k<size;k++) w[k] = 'A' + ((off+k)%26);
            if (pwrite(fd, w, size, off) != size) { printf("FDW fail %d\n", errno); fails++; break; }
            for (long k=0;k<size;k++) good[off+k] = 'A' + ((off+k)%26);
        } else if (op == 2) {  // truncate
            if (ftruncate(fd, off)) fails++;
            if (off < cur_size) memset(good+off, 0, 0x40000-off);
            cur_size = off;
        } else if (op == 3) {  // fd read + verify
            if (off + size > cur_size) continue;
            static char rb[0x10000+16];
            int r = pread(fd, rb, size, off);
            if (r != size || memcmp(rb, good+off, size)) {
                long k=0; if (r==size) while (k<size && rb[k]==good[off+k]) k++;
                printf("FD-MISMATCH off=%lx i=%d r=%d cursz=%lx bad=%lx exp=%c got=%c\n",
                       off, i, r, cur_size, off+k,
                       (k<size&&r==size)?good[off+k]:'?',
                       (k<size&&r==size)?rb[k]:'?');
                fails++;
            }
        } else {  // MAPREAD (own mapping) + verify
            if (off + size > cur_size) continue;
            long mo = off & ~0xfffL, ml = ((off+size-mo)+0xfffL) & ~0xfffL;
            char *p = mmap(NULL, ml, PROT_READ, MAP_FILE|MAP_SHARED, fd, mo);
            if (p == MAP_FAILED) { printf("MR mmap fail %d off=%lx\n", errno, off); fails++; break; }
            char *q = p + (off-mo);
            if (memcmp(q, good+off, size)) {
                long k=0; while (k<size && q[k]==good[off+k]) k++;
                printf("MAP-MISMATCH off=%lx i=%d bad=%lx exp=%c got=%c cursz=%lx\n", off, i, off+k, good[off+k], q[k], cur_size);
                fails++;
            }
            munmap(p, ml);
        }
    }
    printf("fails=%d cursz=%lx\n", fails, cur_size);
    return fails?1:0;
}
