// rtlock_deadlock.c — SleepMutex rt-handoff state-order reproducer
// (oh-launch lane; the rt-r6 0b12e6e18 release() bug).
//
// VFS-MUTATION (kernel/src/fs/vfs.rs) is a new_rt SleepMutex since
// rt-r6: every mkdir/rmdir takes it. On the buggy release(), a
// release that found an RT-class waiter parked ran the hi-priority
// handoff wake BEFORE the state machine freed the lock and returned
// early — the mutex stayed `locked` with owner = the departed
// releaser forever, the woken waiter's handoff token spend failed
// forever, and every later mutation syscall parked permanently (the
// OH boot wedge at wallpaper SA:3705: init blocked >120 s holding
// VFS-MUTATION; the oh-launch bisect 017bf556b..e9a0c1749).
//
// Topology: 4 CFS churn threads + 1 SCHED_FIFO churn thread hammer
// mkdir+rmdir of per-thread names in ONE shared directory — constant
// VFS-MUTATION contention. Progress line every 2 s with per-thread
// counts. The canary verdict: every live counter must keep advancing
// every interval; on the buggy kernel the first rt-handoff release
// freezes ALL counters at once (everyone queues behind the stuck
// lock) and VFS-MUTATION-STALL lines appear on serial.
//
// Verdict:
//   RTLOCK-PASS   every interval advanced every live counter
//   RTLOCK-FAIL   a counter froze >= FROZE_INTVL intervals (wedge)
// Usage: rtlock_deadlock [seconds=20]

#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <sched.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <time.h>
#include <unistd.h>

#define NCFS 4
#define RT_PRIO 10
#define INTVL_SEC 2
#define FROZE_INTVL 2 /* fail after 2 stalled intervals (>= 4 s) */

static volatile uint64_t counts[NCFS + 1];
static volatile int stop;

static void *churn(void *arg)
{
    long id = (long)arg;
    char path[128];
    uint64_t i = 0;
    for (;;)
    {
        snprintf(path, sizeof(path), "/rtlock/d%ld_%llu", id,
                 (unsigned long long)(i++ % 4));
        if (mkdir(path, 0777) == 0 || errno == EEXIST)
            rmdir(path);
        counts[id]++;
        if (stop)
            return NULL;
    }
}

int main(int argc, char **argv)
{
    int secs = argc > 1 ? atoi(argv[1]) : 20;
    mkdir("/rtlock", 0777);

    pthread_t th[NCFS + 1];
    for (long i = 0; i < NCFS; i++)
        pthread_create(&th[i], NULL, churn, (void *)i);
    /* RT churn thread: becomes the rt-handoff trigger the moment it
     * parks on the contended VFS-MUTATION. */
    pthread_attr_t a;
    pthread_attr_init(&a);
    pthread_attr_setschedpolicy(&a, SCHED_FIFO);
    struct sched_param sp = {.sched_priority = RT_PRIO};
    pthread_attr_setschedparam(&a, &sp);
    pthread_attr_setinheritsched(&a, PTHREAD_EXPLICIT_SCHED);
    int rc = pthread_create(&th[NCFS], &a, churn, (void *)(long)NCFS);
    int rt_ok = (rc == 0);
    if (!rt_ok)
        fprintf(stderr, "note: SCHED_FIFO thread create rc=%d (%s) — "
                        "running CFS-only (reproducer weakened)\n",
                rc, strerror(rc));

    uint64_t last[NCFS + 1] = {0};
    int froze[NCFS + 1] = {0};
    int fail = 0;
    int nint = secs / INTVL_SEC;
    for (int t = 0; t <= nint; t++)
    {
        printf("RTLOCK-PROG t=%d cfs=%llu,%llu,%llu,%llu rt=%llu%s\n",
               t * INTVL_SEC,
               (unsigned long long)counts[0],
               (unsigned long long)counts[1],
               (unsigned long long)counts[2],
               (unsigned long long)counts[3],
               (unsigned long long)counts[NCFS],
               rt_ok ? "" : "(off)");
        fflush(stdout);
        if (t == nint)
            break;
        sleep(INTVL_SEC);
        for (int i = 0; i <= NCFS; i++)
        {
            int live = (i < NCFS) || rt_ok;
            if (!live)
                continue;
            if (counts[i] == last[i])
            {
                if (++froze[i] >= FROZE_INTVL)
                {
                    printf("RTLOCK-FAIL thread %d frozen at %llu "
                           "(rt-handoff left the lock held)\n",
                           i, (unsigned long long)counts[i]);
                    fflush(stdout);
                    fail = 1;
                }
            }
            else
                froze[i] = 0;
            last[i] = counts[i];
        }
        if (fail)
            break;
    }
    if (!fail)
    {
        stop = 1;
        printf("RTLOCK-PASS all counters advanced for %d s\n", secs);
        fflush(stdout);
    }
    /* A FAIL wedges the churn threads in D-state; exiting PID 1 with
     * them parked still prints the verdict (serial is the contract). */
    return fail ? 1 : 0;
}
