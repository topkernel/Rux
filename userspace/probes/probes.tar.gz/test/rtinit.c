/* rtinit.c — PID-1 wrapper for the reference-kernel column of the
 * rtbench rig (run/rtboot.sh REF arm). Mirrors lmbench's init_ref.c:
 * the reference kernel (the OHOS 6.6.101 bzImage) does not pre-mount
 * /proc and the packed rootfs has no /dev/console — this wrapper
 * prepares the minimal environment rtbench expects and execs it
 * (PID 1 preserved so rtbench's reboot(RB_POWER_OFF) ends the boot).
 */
#include <fcntl.h>
#include <sys/mount.h>
#include <sys/stat.h>
#include <unistd.h>

int main(void)
{
    mkdir("/dev", 0755);
    mkdir("/proc", 0755);
    mkdir("/sys", 0755);
    mkdir("/tmp", 0755);

    mount("devtmpfs", "/dev", "devtmpfs", 0, 0);
    mount("proc", "/proc", "proc", 0, 0);
    mount("sysfs", "/sys", "sysfs", 0, 0);

    int c = open("/dev/console", O_RDWR);
    if (c >= 0) {
        dup2(c, 0);
        dup2(c, 1);
        dup2(c, 2);
        if (c > 2)
            close(c);
    }
    write(1, "RTINIT WRAPPER OK\n", 18);

    execl("/test/rtbench", "rtbench", (char *)0);

    /* exec failed — park; the outer timeout reaps the boot */
    for (;;)
        pause();
    return 0;
}
