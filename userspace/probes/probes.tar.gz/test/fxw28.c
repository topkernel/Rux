#define _GNU_SOURCE
#include <sys/mman.h>
#include <fcntl.h>
#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <stdlib.h>
// fxw28 — ext4-face minimal replica of the LTP fsx failure sequence:
// prefill via fd -> truncate -> fd write (extends) -> MAPWRITE -> fd read.
// The mapwrite window and read offset mirror the captured failure.
static char good[0x40000];
int main(int argc, char **argv){
    const char *path = argc > 1 ? argv[1] : "/tmp/fxw28";
    int fd = open(path, O_RDWR|O_CREAT|O_TRUNC, 0666);
    if (fd < 0) { printf("open fail %d\n", errno); return 1; }
    if (ftruncate(fd, 0x40000)) return 2;
    // 1. prefill whole file via fd
    char w[0x1000];
    for (int pg = 0; pg < 0x40; pg++) {
        for (int k=0;k<0x1000;k++) w[k] = 'A' + ((pg*0x1000+k)%26);
        if (pwrite(fd, w, 0x1000, pg*0x1000) != 0x1000) return 3;
        for (int k=0;k<0x1000;k++) good[pg*0x1000+k] = w[k];
    }
    // 2. truncate to 236240
    if (ftruncate(fd, 236240)) return 4;
    memset(good+236240, 0, 0x40000-236240);
    // 3. fd write [94904, 259132) extends
    {
        long off = 94904, n = 259132-94904;
        static char b[0x20000];
        for (long k=0;k<n;k++) b[k] = 'C' + ((off+k)%26);
        if (pwrite(fd, b, n, off) != n) { printf("fdw fail %d\n", errno); return 5; }
        for (long k=0;k<n;k++) good[off+k] = b[k];
    }
    // 4. mapwrite [126976, 255348)
    {
        long off = 126976, size = 128372;
        long mo = off, ml = (size + 0xfff) & ~0xfffL;
        char *p = mmap(NULL, ml, PROT_READ|PROT_WRITE, MAP_FILE|MAP_SHARED, fd, mo);
        if (p == MAP_FAILED) { printf("mw mmap fail %d\n", errno); return 6; }
        for (long k=0;k<size;k++) p[k] = 'a' + ((off+k)%26);
        for (long k=0;k<size;k++) good[off+k] = 'a' + ((off+k)%26);
        if (msync(p, ml, MS_SYNC)) { printf("msync fail %d\n", errno); return 7; }
        munmap(p, ml);
    }
    // 5. fd read at 178824
    {
        char rb[64];
        int r = pread(fd, rb, 64, 178824);
        long k = 0; while (k < 64 && k < r && rb[k] == good[178824+k]) k++;
        printf("r=%d byte=%c want=%c bad_at+%ld\n", r, rb[0], good[178824], k);
    }
    return 0;
}
