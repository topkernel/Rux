/* tsleep.c — timed-wait completion probe (glib-mutex lane).
 *
 * The garepro repro wedges with EVERY thread parked in a short timed
 * wait that never completes (usleep 3-33ms, cond timed-pop 500ms,
 * poll 30-100ms). This probe isolates the primitive with NO locks, no
 * clones, no pool machinery — just groups of threads looping one
 * timed wait each, with per-group counters:
 *
 *   G1 usleep(20ms) x8         (clock_nanosleep relative)
 *   G2 poll(pipe, 25ms) x4     (poll timeout path)
 *   G3 clock_nanosleep abs 15ms x4 (TIMER_ABSTIME re-arm style)
 *   G4 futex_wait(15ms) x4     (futex timeout path, ETIMEDOUT loop)
 *   G5 timerfd 10ms read x2    (timerfd expiry + read wake)
 *
 * Monitor prints TSLEEP-TICK every 1s with per-group totals. A group
 * whose total freezes >3s while others still move =>
 * TSLEEP-DEAD-G<n> (rc 40+n). Everything frozen => TSLEEP-DEAD-ALL
 * (rc 47). Clean end => TSLEEP-PASS (rc 0). SIGALRM backup watchdog
 * covers a wedged monitor.
 *
 * CLOCK-STEP FORENSICS (tsleep1 boot: the monitor's `t < next` gate
 * wedged — CLOCK_MONOTONIC stepped BACKWARD; the SIG-WATCHDOG fired
 * with all group counters still advancing). The monitor now records
 * (mono, raw TSC, cpu) every 10 ms cadence step and prints
 * TSLEEP-CLOCK-BACK / TSLEEP-TSC-BACK with both sides' values when a
 * step is seen, and RESYNCS its print cadence to the new clock domain
 * so it keeps printing through the jump instead of wedging.
 *
 * gcc -static -O2 -pthread -DPROBE_SECS=240 -o tsleep tsleep.c
 */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <poll.h>
#include <stdarg.h>
#include <pthread.h>
#include <sched.h>
#include <signal.h>
#include <stdatomic.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>
#include <linux/futex.h>

/* raw TSC + cpu forensics (x86_64 build only; harmless stub elsewhere) */
#if defined(__x86_64__)
static inline uint64_t raw_tsc(void) {
    unsigned lo, hi;
    __asm__ __volatile__("lfence\n rdtsc" : "=a"(lo), "=d"(hi));
    return ((uint64_t)hi << 32) | lo;
}
#else
static inline uint64_t raw_tsc(void) { return 0; }
#endif
static inline int cpu_here(void) { return sched_getcpu(); }

#ifndef PROBE_SECS
#define PROBE_SECS 240
#endif
#define NG 5
static _Atomic long gcnt[NG];
static _Atomic int gthreads[NG];
static _Atomic uint64_t heartbeat; /* monitor bumps every 10ms cadence step */

static long tidof(void) { return syscall(SYS_gettid); }
static uint64_t now_ms(void) {
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (uint64_t)ts.tv_sec * 1000 + ts.tv_nsec / 1000000;
}
static void out(const char *fmt, ...) {
    char buf[512];
    va_list ap;
    va_start(ap, fmt);
    int n = vsnprintf(buf, sizeof buf, fmt, ap);
    va_end(ap);
    if (n > 0) {
        ssize_t r = write(1, buf, (size_t)n);
        (void)r;
    }
}

static int wake_pipe[2];
static volatile sig_atomic_t sig_fired;

static void sig_handler(int sig) {
    (void)sig;
    /* Report and CONTINUE: the first tsleep2-style total freeze (~0.5s)
     * recovered — killing at the first alarm destroyed the timeline.
     * Exit only after 10 consecutive silent alarms (20s) of a truly
     * wedged monitor. */
    static int silent_alarms;
    static uint64_t last_hb;
    uint64_t hb = atomic_load(&heartbeat);
    if (hb != last_hb) {
        last_hb = hb;
        silent_alarms = 0;
        return;
    }
    sig_fired = 1;
    out("TSLEEP-SIG-WATCHDOG #%d monitor-silent g1=%ld g2=%ld g3=%ld g4=%ld g5=%ld "
        "mono_now=%llu tsc_now=%llu cpu_now=%d\n",
        ++silent_alarms,
        atomic_load(&gcnt[0]), atomic_load(&gcnt[1]),
        atomic_load(&gcnt[2]), atomic_load(&gcnt[3]),
        atomic_load(&gcnt[4]),
        (unsigned long long)now_ms(), (unsigned long long)raw_tsc(),
        cpu_here());
    if (silent_alarms >= 10)
        _exit(48);
}

static void *g1_usleep(void *arg) {
    (void)arg;
    atomic_fetch_add(&gthreads[0], 1);
    for (;;) {
        usleep(20000);
        atomic_fetch_add(&gcnt[0], 1);
    }
    return NULL;
}
static void *g2_poll(void *arg) {
    (void)arg;
    atomic_fetch_add(&gthreads[1], 1);
    for (;;) {
        struct pollfd pfd = {.fd = wake_pipe[0], .events = POLLIN};
        poll(&pfd, 1, 25);
        atomic_fetch_add(&gcnt[1], 1);
    }
    return NULL;
}
static void *g3_abssleep(void *arg) {
    (void)arg;
    atomic_fetch_add(&gthreads[2], 1);
    for (;;) {
        struct timespec ts;
        clock_gettime(CLOCK_MONOTONIC, &ts);
        ts.tv_nsec += 15000000;
        if (ts.tv_nsec >= 1000000000) { ts.tv_sec++; ts.tv_nsec -= 1000000000; }
        clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &ts, NULL);
        atomic_fetch_add(&gcnt[2], 1);
    }
    return NULL;
}
static void *g4_futex(void *arg) {
    (void)arg;
    atomic_fetch_add(&gthreads[3], 1);
    uint32_t word = 1; /* never woken: pure timeout path */
    for (;;) {
        struct timespec ts = {0, 15000000};
        syscall(SYS_futex, &word, FUTEX_WAIT_PRIVATE, 1, &ts, NULL, 0);
        atomic_fetch_add(&gcnt[3], 1);
    }
    return NULL;
}
static void *g5_timerfd(void *arg) {
    (void)arg;
    atomic_fetch_add(&gthreads[4], 1);
    int tfd = syscall(SYS_timerfd_create, CLOCK_MONOTONIC, 0);
    struct itimerspec its = {{0, 10000000}, {0, 10000000}};
    syscall(SYS_timerfd_settime, tfd, 0, &its, NULL);
    uint64_t exp;
    for (;;) {
        ssize_t r = read(tfd, &exp, sizeof exp);
        if (r <= 0) break;
        atomic_fetch_add(&gcnt[4], 1);
    }
    return NULL;
}

int main(void) {
    setvbuf(stdout, NULL, _IONBF, 0);
    if (pipe(wake_pipe)) { out("TSLEEP-FAIL pipe\n"); return 9; }
    fcntl(wake_pipe[0], F_SETFL, O_NONBLOCK);
    out("TSLEEP-START secs=%d tid=%ld\n", PROBE_SECS, tidof());

    pthread_t th;
    pthread_attr_t da;
    pthread_attr_init(&da);
    pthread_attr_setdetachstate(&da, PTHREAD_CREATE_DETACHED);
    for (int i = 0; i < 8; i++) pthread_create(&th, &da, g1_usleep, NULL);
    for (int i = 0; i < 4; i++) pthread_create(&th, &da, g2_poll, NULL);
    for (int i = 0; i < 4; i++) pthread_create(&th, &da, g3_abssleep, NULL);
    for (int i = 0; i < 4; i++) pthread_create(&th, &da, g4_futex, NULL);
    for (int i = 0; i < 2; i++) pthread_create(&th, &da, g5_timerfd, NULL);

    signal(SIGALRM, sig_handler);
    ualarm(2000000, 2000000); /* backup: monitor silent 10x2s => exit */

    uint64_t t0 = now_ms();
    long last[NG] = {0};
    uint64_t last_move[NG];
    for (int i = 0; i < NG; i++) last_move[i] = t0;
    uint64_t next = t0 + 1000;
    /* clock-step forensics: (mono,tsc,cpu) of the previous cadence step */
    uint64_t prev_mono = t0, prev_tsc = raw_tsc();
    int prev_cpu = cpu_here();
    uint64_t mono_hi = t0; /* high-water mark of CLOCK_MONOTONIC */
    int back_events = 0;
    for (;;) {
        usleep(10000); /* 10ms monitor cadence */
        uint64_t t = now_ms();
        uint64_t tsc = raw_tsc();
        int cpu = cpu_here();
        atomic_fetch_add(&heartbeat, 1);
        /* monitor starvation: a cadence step that landed >500ms after
         * the previous one (sleep overshoot or scheduler strand) */
        if (t - prev_mono > 500 && t >= prev_mono) {
            out("TSLEEP-MONITOR-GAP d=%llu tsc_d=%lld cpu_prev=%d cpu_now=%d "
                "g1=%ld g2=%ld g3=%ld g4=%ld g5=%ld\n",
                (unsigned long long)(t - prev_mono),
                (long long)tsc - (long long)prev_tsc, prev_cpu, cpu,
                atomic_load(&gcnt[0]), atomic_load(&gcnt[1]),
                atomic_load(&gcnt[2]), atomic_load(&gcnt[3]),
                atomic_load(&gcnt[4]));
        }
        /* backward-step detection at 10ms granularity: mono below the
         * previous step's reading (or below the all-time high-water
         * mark), and TSC direction tells which side stepped */
        if (t + 50 < prev_mono || (t + 50 < mono_hi && prev_mono >= mono_hi)) {
            out("TSLEEP-CLOCK-BACK #%d prev=%llu now=%llu d=%lld "
                "tsc_prev=%llu tsc_now=%llu d_tsc=%lld cpu_prev=%d cpu_now=%d\n",
                ++back_events, (unsigned long long)prev_mono,
                (unsigned long long)t, (long long)t - (long long)prev_mono,
                (unsigned long long)prev_tsc, (unsigned long long)tsc,
                (long long)tsc - (long long)prev_tsc, prev_cpu, cpu);
            next = t + 1000; /* resync print cadence to the new domain */
        }
        if (tsc + 1000 < prev_tsc) {
            out("TSLEEP-TSC-BACK #%d tsc_prev=%llu tsc_now=%llu "
                "mono_prev=%llu mono_now=%llu cpu_prev=%d cpu_now=%d\n",
                ++back_events, (unsigned long long)prev_tsc,
                (unsigned long long)tsc, (unsigned long long)prev_mono,
                (unsigned long long)t, prev_cpu, cpu);
        }
        if (t > mono_hi) mono_hi = t;
        prev_mono = t; prev_tsc = tsc; prev_cpu = cpu;
        if (t < next) continue;
        next = t + 1000;
        long c[NG];
        for (int i = 0; i < NG; i++) c[i] = atomic_load(&gcnt[i]);
        out("TSLEEP-TICK t=%llu g1=%ld g2=%ld g3=%ld g4=%ld g5=%ld "
            "tsc=%llu cpu=%d\n",
            (unsigned long long)(t - t0), c[0], c[1], c[2], c[3], c[4],
            (unsigned long long)tsc, cpu);
        if ((int64_t)(t - t0) < 5000) continue; /* warmup before death checks */
        int alive = 0, dead = 0, first_dead = -1;
        for (int i = 0; i < NG; i++) {
            if (c[i] != last[i]) {
                last[i] = c[i];
                last_move[i] = t;
            }
            if ((int64_t)(t - last_move[i]) < 3000) alive++;
            else { dead++; if (first_dead < 0) first_dead = i; }
        }
        if (dead == NG) {
            out("TSLEEP-DEAD-ALL t=%llu\n", (unsigned long long)(t - t0));
            return 47;
        }
        if (dead > 0 && atomic_load(&gthreads[first_dead]) > 0) {
            out("TSLEEP-DEAD-G%d t=%llu (others alive=%d)\n",
                first_dead + 1, (unsigned long long)(t - t0), alive);
            return 40 + first_dead + 1;
        }
        if ((int64_t)(t - t0) > (int64_t)PROBE_SECS * 1000) {
            out("TSLEEP-PASS backs=%d\n", back_events);
            return 0;
        }
    }
}
