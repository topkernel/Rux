/* getdents_probe.c — functional semantics probe for the incremental
 * ext4 readdir (getdents lane, 2026-11-17).
 *
 * Runs as init on the pbench-shaped ext4 rootfs image and exercises
 * getdents64 on a directory the probe itself creates (our ext4 writer:
 * "." / ".." on disk, >=12B tail folding) plus the image's static /etc
 * (reference-mkfs-written dirents):
 *
 *   A. full walk, small buffer: exact entry set, no dups, "." first,
 *      ".." second, d_off monotonic non-zero, d_type sane
 *   B. d_ino truth: "." ino == stat(dir).st_ino, ".." ino == stat(parent)
 *   C. restart: lseek(fd,0,SEEK_SET) re-reads an identical stream
 *   D. seekdir: lseek(fd, saved_d_off, SEEK_SET) resumes with no loss
 *      and no duplicate
 *   E. mutation mid-walk: unlink between calls — walk still terminates
 *      with a sane superset/subset, no wedge, no dup of deleted name
 *   F. EOF: final call returns 0 exactly; repeated calls stay 0
 *   G. EINVAL: 1-byte buffer with entries remaining
 *   H. big-dir walk (4096 files) sanity + per-call progress
 *
 * Prints "GDPROBE <case> PASS/FAIL ..." lines and exits via reboot()
 * so the pbench-style driver sees rc markers.
 */
#define _GNU_SOURCE
#include <dirent.h>
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/reboot.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <unistd.h>
#include <stdarg.h>

struct linux_dirent64 {
    unsigned long long d_ino;
    unsigned long long d_off;
    unsigned short d_reclen;
    unsigned char d_type;
    char d_name[];
};

static int fails;

static void report(const char *casE, int ok, const char *fmt, ...)
{
    va_list ap;
    printf("GDPROBE %s %s ", casE, ok ? "PASS" : "FAIL");
    va_start(ap, fmt);
    vprintf(fmt, ap);
    va_end(ap);
    printf("\n");
    if (!ok)
        fails++;
}

static int walk_collect(int fd, char buf[32768],
                        unsigned long long *offs, char names[][256],
                        unsigned char *types, int maxn, int *nout)
{
    /* Walks from the CURRENT position using the given buffer.  Returns
     * 0 ok, -1 errno trouble. */
    int n = 0;
    for (;;) {
        ssize_t k = syscall(SYS_getdents64, fd, buf, 32768);
        if (k < 0)
            return -1;
        if (k == 0)
            break;
        ssize_t off = 0;
        while (off < k) {
            struct linux_dirent64 *d = (void *)(buf + off);
            if (d->d_reclen < 19 || off + d->d_reclen > k) {
                printf("GDPROBE parse bad reclen=%u at off=%zd k=%zd\n",
                       d->d_reclen, off, k);
                return -2;
            }
            if (n < maxn) {
                offs[n] = d->d_off;
                types[n] = d->d_type;
                snprintf(names[n], 256, "%s", d->d_name);
            }
            n++;
            off += d->d_reclen;
        }
    }
    *nout = n;
    return 0;
}

static int mk_tree(const char *dir, int nfiles)
{
    if (mkdir(dir, 0755) < 0 && errno != EEXIST)
        return -1;
    char p[512];
    for (int i = 0; i < nfiles; i++) {
        snprintf(p, sizeof(p), "%s/file%05d.txt", dir, i);
        int fd = open(p, O_CREAT | O_WRONLY | O_TRUNC, 0644);
        if (fd < 0)
            return -1;
        if (write(fd, "x", 1) != 1)
            return -1;
        close(fd);
    }
    return 0;
}

int main(void)
{
    static char buf[32768];
    static char smallbuf[512];
    static char names[8192][256];
    static unsigned long long offs[8192];
    static unsigned char types[8192];
    int n = 0;

    if (mkdir("/work", 0755) < 0 && errno != EEXIST) { }

    /* ---------- A: full walk, exact set ---------- */
    if (mk_tree("/work/gdtree", 1000) < 0) {
        report("A-setup", 0, "mk_tree failed");
        goto out;
    }
    int fd = open("/work/gdtree", O_RDONLY | O_DIRECTORY);
    if (fd < 0) {
        report("A", 0, "open dir failed");
        goto out;
    }
    int rc = walk_collect(fd, buf, offs, names, types, 8192, &n);
    if (rc != 0) {
        report("A", 0, "walk rc=%d errno=%d", rc, errno);
        close(fd);
        goto out;
    }
    int ok = (n == 1002); /* . .. + 1000 files */
    report("A-count", ok, "n=%d (want 1002)", n);
    ok = !strcmp(names[0], ".") && !strcmp(names[1], "..");
    report("A-dots-first", ok, "n0=%s n1=%s", names[0], names[1]);
    ok = 1;
    for (int i = 1; i < n; i++)
        if (offs[i] <= offs[i - 1])
            ok = 0;
    report("A-doff-monotonic", ok, "first=%llu last=%llu", offs[0], offs[n - 1]);
    /* no duplicates (beyond dots) */
    ok = 1;
    for (int i = 2; i < n && ok; i++)
        for (int j = i + 1; j < n; j++)
            if (!strcmp(names[i], names[j]))
                ok = 0;
    report("A-no-dups", ok, "");
    /* d_type: DT_REG(4) for files, DT_DIR(2) for dots */
    ok = (types[0] == DT_DIR && types[1] == DT_DIR && types[2] == DT_REG
          && types[n - 1] == DT_REG);
    report("A-dtype", ok, "t0=%u t2=%u tlast=%u", types[0], types[2], types[n - 1]);

    /* ---------- B: d_ino truth ---------- */
    struct stat st, stp;
    if (stat("/work/gdtree", &st) == 0 && stat("/work", &stp) == 0) {
        /* re-read just the first two entries */
        lseek(fd, 0, SEEK_SET);
        ssize_t k = syscall(SYS_getdents64, fd, buf, 32768);
        struct linux_dirent64 *d0 = (void *)buf;
        struct linux_dirent64 *d1 = (void *)(buf + d0->d_reclen);
        unsigned long long ino0 = d0->d_ino, ino1 = d1->d_ino;
        if (d1->d_name[0] != '.' || d1->d_name[1] != '.' || d1->d_name[2]) {
            /* d1 may not be ".." if block layout differs; search buf */
            ssize_t off = 0;
            while (off < k) {
                struct linux_dirent64 *d = (void *)(buf + off);
                if (!strcmp(d->d_name, ".."))
                    ino1 = d->d_ino;
                off += d->d_reclen;
            }
        }
        ok = (ino0 == (unsigned long long)st.st_ino);
        report("B-dot-ino", ok, "d_ino(.)=%llu st_ino=%llu", ino0,
               (unsigned long long)st.st_ino);
        ok = (ino1 == (unsigned long long)stp.st_ino);
        report("B-dotdot-ino", ok, "d_ino(..)=%llu parent st_ino=%llu", ino1,
               (unsigned long long)stp.st_ino);
    } else {
        report("B", 0, "stat failed errno=%d", errno);
    }

    /* ---------- C: restart determinism ---------- */
    lseek(fd, 0, SEEK_SET);
    static char names2[8192][256];
    static unsigned long long offs2[8192];
    static unsigned char types2[8192];
    int n2 = 0;
    rc = walk_collect(fd, buf, offs2, names2, types2, 8192, &n2);
    ok = (rc == 0 && n2 == n);
    for (int i = 0; ok && i < n; i++)
        if (strcmp(names[i], names2[i]) || offs[i] != offs2[i])
            ok = 0;
    report("C-restart", ok, "n2=%d", n2);

    /* ---------- D: seekdir resume ---------- */
    /* pick entry 500; its resume point is offs[500] (offset of next) */
    lseek(fd, 0, SEEK_SET);
    /* drain exactly 501 entries using a small buffer loop */
    int seen = 0;
    unsigned long long resume = 0;
    while (seen < 501) {
        ssize_t k = syscall(SYS_getdents64, fd, smallbuf, sizeof(smallbuf));
        if (k <= 0) { seen = -1; break; }
        ssize_t off = 0;
        while (off < k) {
            struct linux_dirent64 *d = (void *)(smallbuf + off);
            if (seen == 500)
                resume = d->d_off;
            seen++;
            off += d->d_reclen;
        }
    }
    /* seen overshoots within the final 512B batch; resume is recorded at
     * the exact 501st entry, which is what the comparison needs. */
    ok = (seen >= 501 && resume == offs[500]);
    report("D-setup", ok, "seen=%d resume=%llu offs[500]=%llu", seen, resume, offs[500]);
    /* seek there, walk the rest; must equal names[501..n) */
    if (lseek(fd, (off_t)resume, SEEK_SET) == (off_t)resume) {
        int n3 = 0;
        static char names3[8192][256];
        static unsigned long long offs3[8192];
        static unsigned char types3[8192];
        rc = walk_collect(fd, buf, offs3, names3, types3, 8192, &n3);
        ok = (rc == 0 && n3 == n - 501);
        for (int i = 0; ok && i < n3; i++)
            if (strcmp(names3[i], names[501 + i]))
                ok = 0;
        report("D-resume", ok, "n3=%d want=%d first=%s expfirst=%s", n3, n - 501,
               n3 > 0 ? names3[0] : "-", names[501]);
    } else {
        report("D-resume", 0, "lseek to d_off failed");
    }

    /* ---------- E: mutation mid-walk ---------- */
    lseek(fd, 0, SEEK_SET);
    /* consume half */
    seen = 0;
    while (seen < 500) {
        ssize_t k = syscall(SYS_getdents64, fd, buf, 32768);
        if (k <= 0) break;
        ssize_t off = 0;
        while (off < k) {
            struct linux_dirent64 *d = (void *)(buf + off);
            off += d->d_reclen;
            seen++;
        }
    }
    unlink("/work/gdtree/file00007.txt");
    int mut_n = 0;
    static char names4[8192][256];
    static unsigned long long offs4[8192];
    static unsigned char types4[8192];
    rc = walk_collect(fd, buf, offs4, names4, types4, 8192, &mut_n);
    ok = (rc == 0);
    /* no duplicate names in the post-mutation tail, deleted name gone
     * from the tail (it was already consumed) */
    for (int i = 0; ok && i < mut_n; i++)
        for (int j = i + 1; ok && j < mut_n; j++)
            if (!strcmp(names4[i], names4[j]))
                ok = 0;
    report("E-mutation", ok, "rc=%d tail=%d", rc, mut_n);

    /* ---------- F: EOF stability ---------- */
    lseek(fd, 0, SEEK_SET);
    walk_collect(fd, buf, offs, names, types, 8192, &n);
    ssize_t k1 = syscall(SYS_getdents64, fd, buf, 32768);
    ssize_t k2 = syscall(SYS_getdents64, fd, buf, 32768);
    ok = (k1 == 0 && k2 == 0);
    report("F-eof", ok, "k1=%zd k2=%zd", k1, k2);

    /* ---------- G: EINVAL on tiny buffer ---------- */
    lseek(fd, 0, SEEK_SET);
    errno = 0;
    long r = syscall(SYS_getdents64, fd, buf, 1);
    ok = (r == -1 && errno == EINVAL);
    report("G-einval", ok, "r=%ld errno=%d", r, errno);
    close(fd);

    /* ---------- H: bigger dir (4096) ---------- */
    if (mk_tree("/work/gdtree2", 4096) == 0) {
        int fd2 = open("/work/gdtree2", O_RDONLY | O_DIRECTORY);
        int nh = 0, calls = 0;
        if (fd2 >= 0) {
            for (;;) {
                ssize_t k = syscall(SYS_getdents64, fd2, buf, 32768);
                if (k <= 0)
                    break;
                calls++;
                ssize_t off = 0;
                while (off < k) {
                    struct linux_dirent64 *d = (void *)(buf + off);
                    off += d->d_reclen;
                    nh++;
                }
            }
            close(fd2);
            ok = (nh == 4098);
            report("H-bigdir", ok, "n=%d calls=%d (want 4098)", nh, calls);
        }
    }

    /* ---------- I: image static dir (fs root, reference-mkfs-written) ---------- */
    {
        DIR *d = opendir("/");
        int cnt = 0, dots = 0;
        struct dirent *de;
        if (d) {
            while ((de = readdir(d)) != NULL) {
                if (!strcmp(de->d_name, ".") || !strcmp(de->d_name, ".."))
                    dots++;
                cnt++;
            }
            closedir(d);
        }
        ok = (cnt >= 4 && dots == 2);
        report("I-etc-glibc", ok, "cnt=%d dots=%d errno=%d", cnt, dots, errno);
    }

out:
    printf("GDPROBE DONE fails=%d\n", fails);
    /* power off so the driver sees a clean end */
    reboot(0x4321fedc);
    return 0;
}
