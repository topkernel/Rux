// vdso_probe.c — CLOCK_MONOTONIC sanity hunter (vdso-clock lane).
//
// Three independent read sources, compared every iteration:
//   A: DIRECT __vdso_clock_gettime call (parsed from AT_SYSINFO_EHDR —
//      the unambiguous fast path; no libc policy in between)
//   B: raw syscall(SYS_clock_gettime)  (the kernel track)
//   C: glibc clock_gettime             (what cyclictest actually uses)
//
// Validations:
//   - per-source monotonicity (reads may not go backward)
//   - forward-jump guard (a read may not jump ahead by > JUMP_GUARD_NS
//     over the previous — the "far-future deadline" poison class)
//   - cross-source agreement |A-B|, |C-B| <= XGUARD_NS (50 ms = the
//     published interpolation bound; healthy is ~us)
//
// On any violation: forensic snapshot of the vDSO data page
// (seq/cycle_last/base_mono_nom/mult/max_interp_tsc) + our own rdtsc,
// so the page state at the moment of garbage is captured.
//
// One summary line per second. Usage: vdso_probe [secs] [pin] [mode]
//   secs: run duration (default 60)   pin: 1=pin CPU0 (default), 0=free
//   mode: t=tight loop (default), s=1ms sleep per iter (cyclictest-like)

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sched.h>
#include <sys/syscall.h>
#include <sys/auxv.h>
#include <stdint.h>
#include <elf.h>
#include <sys/mman.h>
#include <sys/time.h>
#include <errno.h>
#include <pthread.h>

typedef int (*vdso_cgt_t)(clockid_t, struct timespec *);

static vdso_cgt_t vdso_cgt;
static unsigned long ehdr;
static volatile uint32_t *dseq;
static volatile uint64_t *d_cycle_last;   // +8
static volatile uint64_t *d_base;         // +16  base_mono_nom
static volatile uint64_t *d_epoch;        // +24
static volatile uint64_t *d_mult;         // +40
static volatile uint32_t *d_res;          // +48
static volatile uint64_t *d_bound;        // +52  max_interp_tsc

static inline uint64_t rdtsc_o(void) {
    uint32_t lo, hi;
    asm volatile("lfence\n rdtsc" : "=a"(lo), "=d"(hi) :: "memory");
    return ((uint64_t)hi << 32) | lo;
}

static uint32_t sysv_hash(const char *s) {
    uint32_t h = 0;
    for (; *s; s++) {
        h = (h << 4) + (uint8_t)*s;
        uint32_t g = h & 0xf0000000u;
        if (g) h ^= g >> 24;
        h &= ~g;
    }
    return h;
}

static void *vdso_sym(unsigned long base, const char *name) {
    Elf64_Ehdr *e = (Elf64_Ehdr *)base;
    if (memcmp(e->e_ident, ELFMAG, SELFMAG)) return NULL;
    Elf64_Phdr *ph = (Elf64_Phdr *)(base + e->e_phoff);
    Elf64_Dyn *dyn = NULL;
    for (int i = 0; i < e->e_phnum; i++)
        if (ph[i].p_type == PT_DYNAMIC) { dyn = (Elf64_Dyn *)(base + ph[i].p_vaddr); break; }
    if (!dyn) return NULL;
    uint32_t *hash = NULL;
    const char *strtab = NULL;
    Elf64_Sym *symtab = NULL;
    for (Elf64_Dyn *d = dyn; d->d_tag != DT_NULL; d++) {
        if (d->d_tag == DT_HASH) hash = (uint32_t *)(base + d->d_un.d_ptr);
        else if (d->d_tag == DT_STRTAB) strtab = (const char *)(base + d->d_un.d_ptr);
        else if (d->d_tag == DT_SYMTAB) symtab = (Elf64_Sym *)(base + d->d_un.d_ptr);
    }
    if (!hash || !strtab || !symtab) return NULL;
    uint32_t nbucket = hash[0], nchain = hash[1];
    uint32_t *buckets = &hash[2];
    uint32_t *chain = &buckets[nbucket];
    for (uint32_t i = buckets[sysv_hash(name) % nbucket]; i; i = chain[i]) {
        if (i >= nchain) return NULL;
        if (!strcmp(strtab + symtab[i].st_name, name))
            return (void *)(base + symtab[i].st_value);
    }
    return NULL;
}

#define JUMP_GUARD_NS 2000000000ULL   // 2 s forward jump = poison
#define XGUARD_NS     50000000ULL     // 50 ms cross-source bound

static uint64_t ts2ns(const struct timespec *ts) {
    return (uint64_t)ts->tv_sec * 1000000000ULL + (uint64_t)ts->tv_nsec;
}

static void snap_page(char *out, size_t n) {
    uint32_t seq = *dseq, seq2;
    uint64_t cl, base, mult, bound, tsc;
    do {
        seq = *dseq;
        cl = *d_cycle_last; base = *d_base; mult = *d_mult; bound = *d_bound;
        tsc = rdtsc_o();
        seq2 = *dseq;
    } while ((seq & 1) || (seq != seq2));
    int64_t delta = (int64_t)(tsc - cl);
    uint64_t nom = base + (uint64_t)((( (__uint128_t)(tsc - cl)) * mult) >> 32);
    snprintf(out, n,
             "PAGE seq=%u cl=%llu base=%llu mult=%llu bound=%llu tsc=%llu "
             "delta=%lld delta_over_bound=%d nom_now=%llu",
             seq, (unsigned long long)cl, (unsigned long long)base,
             (unsigned long long)mult, (unsigned long long)bound,
             (unsigned long long)tsc, (long long)delta,
             delta < 0 ? -1 : ((uint64_t)delta > bound),
             (unsigned long long)nom);
}

// cyclictest-like FIFO mode: mlockall + SCHED_FIFO 98, absolute
// clock_nanosleep 1 ms grid, latency = now - intended. Catches the
// far-future-deadline freeze class and negative latencies exactly the
// way cyclictest sees them (all three read sources per wake).
static int fifo_mode(long secs) {
    if (mlockall(MCL_CURRENT | MCL_FUTURE))
        puts("VDSO-PROBE mlock-failed");
    struct sched_param sp = { .sched_priority = 98 };
    if (sched_setscheduler(0, SCHED_FIFO, &sp))
        printf("VDSO-PROBE fifo-failed errno=%d (continuing)\n", errno);

    uint64_t iters = 0, viol = 0;
    int64_t min_lat = INT64_MAX, max_lat = INT64_MIN;
    double avg_lat = 0;
    struct timespec tsA, tsB, tsC, next;
    vdso_cgt(CLOCK_MONOTONIC, &next);
    uint64_t next_ns = ts2ns(&next) + 1000000;
    time_t t0 = time(NULL);

    for (;;) {
        if (time(NULL) - t0 >= secs) break;
        next.tv_sec = next_ns / 1000000000ULL;
        next.tv_nsec = next_ns % 1000000000ULL;
        clock_nanosleep(CLOCK_MONOTONIC, TIMER_ABSTIME, &next, NULL);
        next_ns += 1000000;

        int rcA = vdso_cgt(CLOCK_MONOTONIC, &tsA);
        int rcB = syscall(SYS_clock_gettime, CLOCK_MONOTONIC, &tsB);
        clock_gettime(CLOCK_MONOTONIC, &tsC);
        iters++;
        uint64_t a = ts2ns(&tsA), b = ts2ns(&tsB), c = ts2ns(&tsC);
        int64_t la = (int64_t)(a - next_ns + 1000000);
        int64_t lb = (int64_t)(b - next_ns + 1000000);
        if (la < min_lat) min_lat = la;
        if (la > max_lat) max_lat = la;
        avg_lat += (double)lb;

        int bad = 0;
        if (rcA) { printf("VDSO-VIOL rcA=%d\n", rcA); bad = 1; }
        if (la < -1000000LL || la > 2000000000LL) bad = 1;   // <-1ms or >2s: poison class
        if (lb < -1000000LL || lb > 2000000000LL) bad = 1;
        uint64_t ab = a > b ? a - b : b - a;
        if (ab > XGUARD_NS) bad = 1;
        if (bad) {
            viol++;
            char pg[256]; snap_page(pg, sizeof pg);
            printf("VDSO-VIOL n=%llu wake latA=%lld latB=%lld A=%llu B=%llu C=%llu next=%llu %s\n",
                   (unsigned long long)viol, (long long)la, (long long)lb,
                   (unsigned long long)a, (unsigned long long)b,
                   (unsigned long long)c, (unsigned long long)next_ns, pg);
        }
        if ((iters % 100000) == 0)
            printf("VDSO-SEC t=%ld iters=%llu viol=%llu minlat=%lld maxlat=%lld avgb=%.0f\n",
                   (long)(time(NULL) - t0), (unsigned long long)iters,
                   (unsigned long long)viol, (long long)min_lat,
                   (long long)max_lat, avg_lat / (double)iters);
    }
    printf("VDSO-DONE mode=fifo iters=%llu viol=%llu minlat=%lld maxlat=%lld avgb=%.0f\n",
           (unsigned long long)iters, (unsigned long long)viol,
           (long long)min_lat, (long long)max_lat, avg_lat / (double)iters);
    return viol ? 2 : 0;
}

// watchdog mode: tight rdtsc loop detecting TSC BACKWARD jumps (the
// vCPU TAC-smash class) + concurrent page-cycle_last backward moves.
// Directly answers: does the guest TSC ever read < previous on this rig?
static int watch_mode(long secs) {
    uint64_t prev = rdtsc_o(), iters = 0, events = 0, cl_events = 0;
    uint64_t prev_cl = *d_cycle_last;
    uint64_t worst = 0;
    time_t t0 = time(NULL), t_next = t0 + 5;
    for (;;) {
        if (time(NULL) - t0 >= secs) break;
        uint64_t t = rdtsc_o();
        iters++;
        if (t < prev) {
            events++;
            uint64_t mag = prev - t;
            if (mag > worst) worst = mag;
            char pg[256]; snap_page(pg, sizeof pg);
            printf("VDSO-TSCBACK n=%llu mag=%llu (%.1f us at 4.29GHz) %s\n",
                   (unsigned long long)events, (unsigned long long)mag,
                   (double)mag / 4292.0, pg);
        }
        prev = t;
        uint64_t cl = *d_cycle_last;
        if (cl < prev_cl) {
            cl_events++;
            printf("VDSO-CLBACK n=%llu cl %llu -> %llu seq=%u\n",
                   (unsigned long long)cl_events,
                   (unsigned long long)prev_cl, (unsigned long long)cl, *dseq);
        }
        prev_cl = cl;
        if (time(NULL) >= t_next) {
            t_next += 5;
            printf("VDSO-SEC t=%ld iters=%llu tscback=%llu worst=%llu clback=%llu\n",
                   (long)(time(NULL) - t0), (unsigned long long)iters,
                   (unsigned long long)events, (unsigned long long)worst,
                   (unsigned long long)cl_events);
        }
    }
    printf("VDSO-DONE mode=watch iters=%llu tscback=%llu worst=%llu (%.1f us) clback=%llu\n",
           (unsigned long long)iters, (unsigned long long)events,
           (unsigned long long)worst, (double)worst / 4292.0,
           (unsigned long long)cl_events);
    return events ? 2 : 0;
}

// cross-CPU skew mode: two threads pinned to CPU 0/1, each tight-looping
// rdtsc. Detects (a) self-backward TSC per CPU, (b) the page cycle_last
// running AHEAD of the local TSC (the wrap-trigger condition for local
// readers), (c) the PEER CPU's TSC running ahead (vCPU TSC-offset skew).
// This is the direct falsifier for the invariant-TSC assumption the
// unified track is built on.
struct shared { volatile uint64_t tsc[2]; volatile uint64_t stop; };
static struct shared *sh;

static void *xthread(void *arg) {
    int cpu = (int)(long)arg;
    cpu_set_t s; CPU_ZERO(&s); CPU_SET(cpu, &s);
    sched_setaffinity(0, sizeof(s), &s);
    uint64_t prev = rdtsc_o();
    uint64_t self_back = 0, cl_ahead = 0, peer_ahead = 0;
    uint64_t worst_self = 0, worst_cl = 0, worst_peer = 0;
    uint64_t iters = 0;
    time_t t0 = time(NULL);
    while (!sh->stop) {
        uint64_t peer_old = sh->tsc[cpu ^ 1];
        uint64_t t = rdtsc_o();
        uint64_t peer_new = sh->tsc[cpu ^ 1];
        sh->tsc[cpu] = t;
        iters++;
        if (t < prev) {
            self_back++;
            if (prev - t > worst_self) worst_self = prev - t;
            printf("VDSO-SELFBACK cpu=%d n=%llu mag=%llu\n", cpu,
                   (unsigned long long)self_back,
                   (unsigned long long)(prev - t));
        }
        prev = t;
        // seq-guarded cl-vs-t: cl loaded BEFORE t, both inside a stable
        // seq window — a cl exceeding the LATER t is genuinely published
        // in the future relative to this CPU's TSC (the wrap trigger).
        uint32_t s1 = *dseq;
        if (!(s1 & 1)) {
            uint64_t cl = *d_cycle_last;
            uint64_t t2 = rdtsc_o();
            uint32_t s2 = *dseq;
            if (s1 == s2 && cl > t2) {
            cl_ahead++;
            if (cl - t2 > worst_cl) worst_cl = cl - t2;
            printf("VDSO-CLAHEAD cpu=%d n=%llu cl=%llu t=%llu mag=%llu seq=%u mult=%llu\n",
                   cpu, (unsigned long long)cl_ahead,
                   (unsigned long long)cl, (unsigned long long)t2,
                   (unsigned long long)(cl - t2), *dseq,
                   (unsigned long long)*d_mult);
            }
        }
        if (peer_old > t && peer_new > t && peer_new > peer_old) {
            peer_ahead++;
            if (peer_old - t > worst_peer) worst_peer = peer_old - t;
            printf("VDSO-PEERAHEAD cpu=%d peer=%d n=%llu peer_tsc=%llu my_tsc=%llu mag=%llu\n",
                   cpu, cpu ^ 1, (unsigned long long)peer_ahead,
                   (unsigned long long)peer_old,
                   (unsigned long long)t,
                   (unsigned long long)(peer_old - t));
        }
        if ((iters % 50000000) == 0)
            printf("VDSO-SEC cpu=%d t=%ld iters=%llu selfback=%llu/%llu clahead=%llu/%llu peerahead=%llu/%llu\n",
                   cpu, (long)(time(NULL) - t0), (unsigned long long)iters,
                   (unsigned long long)self_back, (unsigned long long)worst_self,
                   (unsigned long long)cl_ahead, (unsigned long long)worst_cl,
                   (unsigned long long)peer_ahead, (unsigned long long)worst_peer);
    }
    printf("VDSO-XDONE cpu=%d iters=%llu selfback=%llu worst=%llu clahead=%llu worst=%llu (%.1f us) peerahead=%llu worst=%llu (%.1f us)\n",
           cpu, (unsigned long long)iters, (unsigned long long)self_back,
           (unsigned long long)worst_self, (unsigned long long)cl_ahead,
           (unsigned long long)worst_cl, (double)worst_cl / 4292.0,
           (unsigned long long)peer_ahead, (unsigned long long)worst_peer,
           (double)worst_peer / 4292.0);
    return NULL;
}

static int cross_mode(long secs) {
    pthread_t th[2];
    sh = mmap(NULL, 4096, PROT_READ | PROT_WRITE,
              MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    sh->stop = 0;
    pthread_create(&th[0], NULL, xthread, (void *)0);
    pthread_create(&th[1], NULL, xthread, (void *)1);
    sleep(secs);
    sh->stop = 1;
    pthread_join(th[0], NULL);
    pthread_join(th[1], NULL);
    return 0;
}

int main(int argc, char **argv) {
    long secs = argc > 1 ? atol(argv[1]) : 60;
    int pin = argc > 2 ? atoi(argv[2]) : 1;
    int sleepy = (argc > 3 && argv[3][0] == 's');
    int fifo = (argc > 3 && argv[3][0] == 'f');
    int watch = (argc > 3 && argv[3][0] == 'w');
    int cross = (argc > 3 && argv[3][0] == 'x');

    ehdr = getauxval(AT_SYSINFO_EHDR);
    if (!ehdr) { puts("VDSO-PROBE no AT_SYSINFO_EHDR"); return 1; }
    vdso_cgt = (vdso_cgt_t)vdso_sym(ehdr, "__vdso_clock_gettime");
    if (!vdso_cgt) { puts("VDSO-PROBE no __vdso_clock_gettime"); return 1; }
    unsigned long data = (ehdr & ~0xFFFUL) - 0x1000;
    dseq = (uint32_t *)data;
    d_cycle_last = (uint64_t *)(data + 8);
    d_base = (uint64_t *)(data + 16);
    d_epoch = (uint64_t *)(data + 24);
    d_mult = (uint64_t *)(data + 40);
    d_res = (uint32_t *)(data + 48);
    d_bound = (uint64_t *)(data + 52);

    if (pin) {
        cpu_set_t s; CPU_ZERO(&s); CPU_SET(0, &s);
        if (sched_setaffinity(0, sizeof(s), &s))
            puts("VDSO-PROBE pin-failed (continuing unpinned)");
    }

    printf("VDSO-PROBE start secs=%ld pin=%d mode=%s ehdr=%lx data=%lx\n",
           secs, pin,
           fifo ? "fifo"
                 : (watch ? "watch"
                          : (cross ? "cross" : (sleepy ? "sleep" : "tight"))),
           ehdr, data);
    if (fifo) return fifo_mode(secs);
    if (watch) return watch_mode(secs);
    if (cross) return cross_mode(secs);
    {   // one-time page snapshot
        char b[256]; snap_page(b, sizeof b);
        printf("VDSO-PROBE init %s\n", b);
    }

    uint64_t prevA = 0, prevB = 0, prevC = 0;
    uint64_t iters = 0, viol = 0;
    uint64_t maxAB = 0, maxCB = 0;          // worst cross-source gaps
    int64_t worst_back_A = 0, worst_back_B = 0, worst_back_C = 0;
    uint64_t worst_fwd_A = 0, worst_fwd_B = 0;
    struct timespec tsA, tsB, tsC;
    struct timespec sl = { .tv_sec = 0, .tv_nsec = 1000000 };

    time_t t0 = time(NULL);
    time_t t_next = t0 + 1;
    for (;;) {
        time_t now = time(NULL);
        if (now - t0 >= secs) break;
        if (now >= t_next) {
            t_next = now + 1;
            printf("VDSO-SEC t=%ld iters=%llu viol=%llu maxAB=%llu maxCB=%llu "
                   "backA=%lld backB=%lld backC=%lld fwdA=%llu fwdB=%llu\n",
                   (long)(now - t0), (unsigned long long)iters,
                   (unsigned long long)viol, (unsigned long long)maxAB,
                   (unsigned long long)maxCB, (long long)worst_back_A,
                   (long long)worst_back_B, (long long)worst_back_C,
                   (unsigned long long)worst_fwd_A,
                   (unsigned long long)worst_fwd_B);
        }

        int rcA = vdso_cgt(CLOCK_MONOTONIC, &tsA);
        int rcB = syscall(SYS_clock_gettime, CLOCK_MONOTONIC, &tsB);
        clock_gettime(CLOCK_MONOTONIC, &tsC);
        iters++;

        uint64_t a = ts2ns(&tsA), b = ts2ns(&tsB), c = ts2ns(&tsC);
        int bad = 0;
        if (rcA != 0) { printf("VDSO-VIOL rcA=%d\n", rcA); bad = 1; }
        if (a < prevA) { worst_back_A = (int64_t)(prevA - a); bad = 1; }
        if (b < prevB) { worst_back_B = (int64_t)(prevB - b); bad = 1; }
        if (c < prevC) { worst_back_C = (int64_t)(prevC - c); bad = 1; }
        if (a - prevA > JUMP_GUARD_NS) { worst_fwd_A = a - prevA; bad = 1; }
        if (b - prevB > JUMP_GUARD_NS) { worst_fwd_B = b - prevB; bad = 1; }
        uint64_t ab = a > b ? a - b : b - a;
        uint64_t cb = c > b ? c - b : b - c;
        if (ab > maxAB) maxAB = ab;
        if (cb > maxCB) maxCB = cb;
        if (ab > XGUARD_NS || cb > XGUARD_NS) bad = 1;

        if (bad) {
            viol++;
            char pg[256]; snap_page(pg, sizeof pg);
            printf("VDSO-VIOL n=%llu A=%llu B=%llu C=%llu prevA=%llu prevB=%llu prevC=%llu %s\n",
                   (unsigned long long)viol, (unsigned long long)a,
                   (unsigned long long)b, (unsigned long long)c,
                   (unsigned long long)prevA, (unsigned long long)prevB,
                   (unsigned long long)prevC, pg);
        }
        prevA = a; prevB = b; prevC = c;
        if (sleepy) nanosleep(&sl, NULL);
    }
    printf("VDSO-DONE iters=%llu viol=%llu maxAB=%llu maxCB=%llu "
           "backA=%lld backB=%lld backC=%lld fwdA=%llu fwdB=%llu\n",
           (unsigned long long)iters, (unsigned long long)viol,
           (unsigned long long)maxAB, (unsigned long long)maxCB,
           (long long)worst_back_A, (long long)worst_back_B,
           (long long)worst_back_C, (unsigned long long)worst_fwd_A,
           (unsigned long long)worst_fwd_B);
    return viol ? 2 : 0;
}
