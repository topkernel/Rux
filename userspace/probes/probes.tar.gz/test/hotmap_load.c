/*
 * hotmap_load.c — generic multi-case load for hotmap sampling windows
 * (p23-hotmap lane). Injected as /test/pbench into COPIES of the
 * lmbench / geekbench test images: the perf_sample recorder (init)
 * execs /test/pbench as its child, so this wrapper defines what the
 * sampling window measures.
 *
 * Behavior: read lines from /test/hotmap_load.conf (one argv per line,
 * whitespace-separated, '#' comments); for each line fork+exec+wait.
 * "cd <dir>" lines set the cwd for the following cases. When the list
 * is exhausted, restart from the top (short benchmark cases fill the
 * whole sampling window). Never exits on its own — the recorder
 * SIGKILLs it at window end (a repeat run just adds samples).
 *
 * stderr/stdout go to the serial console (fd 1/2 as inherited).
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

#define MAXLINE 512
#define MAXARG 16

int main(void)
{
    static char lines[64][MAXLINE];
    int nlines = 0;

    FILE *f = fopen("/test/hotmap_load.conf", "r");
    if (f) {
        char buf[MAXLINE];
        while (nlines < 64 && fgets(buf, sizeof(buf), f)) {
            buf[strcspn(buf, "\r\n")] = 0;
            char *p = buf;
            while (*p == ' ' || *p == '\t')
                p++;
            if (*p == 0 || *p == '#')
                continue;
            snprintf(lines[nlines], MAXLINE, "%s", p);
            nlines++;
        }
        fclose(f);
    }
    printf("HOTMAPLOAD cases=%d\n", nlines);
    fflush(stdout);
    if (nlines == 0) {
        /* nothing configured: idle so the window still samples the
         * recorder's own steady state rather than a dead machine */
        for (;;)
            pause();
    }

    for (;;) {
        for (int i = 0; i < nlines; i++) {
            char *save = NULL;
            char *tok = strtok_r(lines[i], " \t", &save);
            if (!tok)
                continue;
            /* "cd /dir" — set cwd for the following cases (geekbench
             * needs its payload directory) */
            if (strcmp(tok, "cd") == 0) {
                char *dir = strtok_r(NULL, " \t", &save);
                if (dir && chdir(dir) != 0)
                    printf("HOTMAPLOAD cd-fail %s\n", dir);
                continue;
            }
            char *argv[MAXARG];
            int argc = 0;
            argv[argc++] = tok;
            while ((tok = strtok_r(NULL, " \t", &save)) != NULL &&
                   argc < MAXARG - 1) {
                argv[argc++] = tok;
            }
            argv[argc] = NULL;
            pid_t pid = fork();
            if (pid == 0) {
                execv(argv[0], argv);
                /* exec failed: say so once per case, then exit; the
                 * parent's loop keeps the window busy */
                printf("HOTMAPLOAD exec-fail %s\n", argv[0]);
                fflush(stdout);
                _exit(127);
            }
            int st = 0;
            waitpid(pid, &st, 0);
        }
    }
}
