// cowrace2.c — COW/fork RACE probe (oh-crash lane, 50th agent; shape per
// coordinator's regression analysis of the lb246 mallocng crash family).
//
// The mallocng crash is a RACE whose hit rate grew with fork/spawn
// density (image ondemand->false patch). The sequential content probe
// (cow_int.c) passes; this one hammers the racing shapes at high rate:
//
//   A fork-storm + mallocng arena churn: parent maintains a forest of
//     small chunks (24..504 B — mallocng smallbin zone), forks
//     short-lived children that verify every chunk, dirty their own
//     copies, churn the allocator, and exit; the parent re-verifies
//     after each reap and keeps allocating/freeing (native_heap group
//     mmaps + munmaps at rate). ROUNDS iterations.
//   B concurrent-writer fork race: writer threads dirty a shared
//     checkerboard arena continuously while the main thread forks;
//     each child verifies page-tag consistency of every page
//     (garbage/foreign content = corruption; generation mixes are
//     legal race semantics), and the parent verifies the same after
//     the writers stop.
//   C file-backed mmap + fork: private RW mapping of a freshly written
//     file, dirtied, forked; child verifies content; parent verifies
//     after child exit (PCACHE COW coherence).
//   D bio pressure: a pwrite+fsync storm on a scratch file runs on its
//     own thread THROUGHOUT phases A-C (drives the write-plan/bio paths
//     concurrently with every fork above — the regression window's bio
//     closure commits are the dated kernel-side suspects).
//
// Output: COWRACE2-A-OK/FAIL ... COWRACE2-PASS/FAIL, exit 0/1.
// Build: x86_64 musl static, -pthread.

#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <sys/wait.h>

#ifndef ROUNDS
#define ROUNDS 600
#endif

#define PAGE 4096u
#define NCHUNK 512

static unsigned char *chunks[NCHUNK];
static uint32_t cseed[NCHUNK];
static uint16_t clen[NCHUNK];

/* ---- phase A: fork-storm + mallocng arena churn ---- */

static int verify_chunks(const char *who)
{
    int bad = 0;
    for (int i = 0; i < NCHUNK; i++) {
        if (!chunks[i]) continue;
        for (uint32_t j = 0; j < clen[i]; j++) {
            unsigned char want = (unsigned char)(cseed[i] ^ (i + j));
            if (chunks[i][j] != want) {
                bad++;
                if (bad < 4)
                    printf("COWRACE2-DETAIL %s chunk=%d off=%u want=%02x got=%02x\n",
                           who, i, j, want, chunks[i][j]);
                break;
            }
        }
    }
    return bad;
}

static void churn_alloc(int i)
{
    uint32_t len = 24 + ((i * 7919 + 13) % 480);
    chunks[i] = malloc(len);
    if (!chunks[i]) { printf("COWRACE2-A-FAIL alloc %d\n", i); exit(1); }
    clen[i] = len;
    cseed[i] = (uint32_t)(i * 2654435761u) | 1u;
    for (uint32_t j = 0; j < len; j++)
        chunks[i][j] = (unsigned char)(cseed[i] ^ (i + j));
}

static void phase_a(void)
{
    for (int i = 0; i < NCHUNK; i++) churn_alloc(i);
    int child_bad_total = 0, parent_bad_total = 0;
    for (int r = 0; r < ROUNDS; r++) {
        /* mutate a few chunks between forks (fresh dirty pages for COW) */
        for (int k = 0; k < 8; k++) {
            int i = (r * 31 + k * 97) % NCHUNK;
            free(chunks[i]);
            churn_alloc(i);
        }
        pid_t c = fork();
        if (c < 0) { printf("COWRACE2-A-FAIL fork r=%d\n", r); exit(1); }
        if (c == 0) {
            int bad = verify_chunks("child-a");
            /* churn the child's inherited arena */
            void *tmp[64];
            for (int k = 0; k < 64; k++) { tmp[k] = malloc(32 + (k * 37) % 448); if (tmp[k]) memset(tmp[k], 0x33, 32); }
            for (int k = 0; k < 64; k += 2) free(tmp[k]);
            _exit(bad ? 1 : 0);
        }
        int st;
        waitpid(c, &st, 0);
        if (!WIFEXITED(st) || WEXITSTATUS(st) != 0) child_bad_total++;
        parent_bad_total += verify_chunks("parent-a");
        if ((r % 100) == 99) printf("COWRACE2-A-ROUND %d\n", r + 1);
    }
    if (child_bad_total || parent_bad_total)
        printf("COWRACE2-A-FAIL child_bad_rounds=%d parent_bad_chunks=%d rounds=%d\n",
               child_bad_total, parent_bad_total, ROUNDS);
    else
        printf("COWRACE2-A-OK rounds=%d chunks=%d storm-clean\n", ROUNDS, NCHUNK);
}

/* ---- phase B: concurrent-writer fork race ---- */

#define BPAGES 1024u            /* 4 MiB arena */
static uint32_t *b_arena;
static volatile int b_run;

static inline uint32_t bpat(uint32_t p, uint32_t gen)
{
    uint32_t x = (p * 2654435761u) ^ (gen * 2246822519u) ^ 0x42u;
    x ^= x >> 16; x *= 0x7feb352du; x ^= x >> 15; x *= 0x846ca68bu; x ^= x >> 16;
    return x | 1u;
}

static void *b_writer(void *arg)
{
    long id = (long)arg;
    uint32_t gen = 0;
    while (b_run) {
        for (uint32_t p = 0; p < BPAGES && b_run; p++)
            for (uint32_t w = 0; w < PAGE / 4; w++)
                b_arena[p * (PAGE / 4) + w] = bpat(p, gen);
        gen = (gen + 1) & 15;
        (void)id;
    }
    return NULL;
}

/* tag-consistency: every word must decode to THIS page for SOME gen */
static int b_check(const char *who, int *torn_out)
{
    int bad = 0, torn = 0;
    static uint32_t vals[16];
    for (uint32_t p = 0; p < BPAGES; p++) {
        for (uint32_t g = 0; g < 16; g++) vals[g] = bpat(p, g);
        int page_bad = 0, page_gens = 0;
        for (uint32_t w = 0; w < PAGE / 4; w++) {
            uint32_t v = b_arena[p * (PAGE / 4) + w];
            int ok = 0;
            for (uint32_t g = 0; g < 16; g++)
                if (v == vals[g]) { page_gens |= 1 << g; ok = 1; break; }
            if (!ok) {
                page_bad++;
                if (bad + page_bad < 4)
                    printf("COWRACE2-DETAIL %s page=%u word=%u val=%08x no-decode\n",
                           who, p, w, v);
            }
        }
        if (page_bad) bad += page_bad;
        else if (__builtin_popcount((unsigned)page_gens) > 1) torn++;
    }
    *torn_out = torn;
    return bad;
}

#define BW 3
static void phase_b(void)
{
    b_arena = mmap(NULL, BPAGES * PAGE, PROT_READ | PROT_WRITE,
                   MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (b_arena == MAP_FAILED) { printf("COWRACE2-B-FAIL mmap\n"); exit(1); }
    for (uint32_t p = 0; p < BPAGES; p++)
        for (uint32_t w = 0; w < PAGE / 4; w++)
            b_arena[p * (PAGE / 4) + w] = bpat(p, 0);

    pthread_t th[BW];
    b_run = 1;
    for (long i = 0; i < BW; i++)
        if (pthread_create(&th[i], NULL, b_writer, (void *)i) != 0) {
            printf("COWRACE2-B-FAIL pthread\n"); exit(1);
        }
    usleep(30000);              /* writers at full speed */

    int corrupt_children = 0, corrupt_parent = 0, torn_c = 0, torn_p = 0;
    for (int r = 0; r < 200; r++) {
        pid_t c = fork();
        if (c == 0) {
            int t, bad = b_check("child-b", &t);
            _exit(bad ? 1 : 0);
        }
        int st; waitpid(c, &st, 0);
        if (!WIFEXITED(st) || WEXITSTATUS(st) != 0) corrupt_children++;
    }
    b_run = 0;
    for (int i = 0; i < BW; i++) pthread_join(th[i], NULL);
    corrupt_parent = b_check("parent-b", &torn_p);
    (void)torn_c;
    if (corrupt_children || corrupt_parent)
        printf("COWRACE2-B-FAIL corrupt_children=%d corrupt_parent_words=%d\n",
               corrupt_children, corrupt_parent);
    else
        printf("COWRACE2-B-OK forks=200 writers=%d tag-clean (torn_parent_pages=%d legal)\n",
               BW, torn_p);
    munmap(b_arena, BPAGES * PAGE);
}

/* ---- phase C: file-backed mmap + fork ---- */

#define CBYTES (4u << 20)
static void phase_c(void)
{
    int fd = open("/cowrace2.scratch", O_RDWR | O_CREAT | O_TRUNC, 0600);
    if (fd < 0) { printf("COWRACE2-C-FAIL open\n"); return; }
    if (ftruncate(fd, CBYTES) != 0) { printf("COWRACE2-C-FAIL ftruncate\n"); close(fd); return; }
    /* fill the file with the expected pattern */
    uint32_t *tmp = malloc(PAGE);
    for (uint32_t p = 0; p < CBYTES / PAGE; p++) {
        for (uint32_t w = 0; w < PAGE / 4; w++) tmp[w] = bpat(p | 0x80000000u, 5);
        if (write(fd, tmp, PAGE) != (ssize_t)PAGE) { printf("COWRACE2-C-FAIL write\n"); close(fd); return; }
    }
    free(tmp);

    uint32_t *m = mmap(NULL, CBYTES, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0);
    if (m == MAP_FAILED) { printf("COWRACE2-C-FAIL mmap\n"); close(fd); return; }
    /* dirty EVERY page privately (PCACHE COW state before fork) */
    for (uint32_t p = 0; p < CBYTES / PAGE; p++)
        for (uint32_t w = 0; w < PAGE / 4; w++)
            m[p * (PAGE / 4) + w] = bpat(p | 0x80000000u, 6);

    int bad = 0;
    pid_t c = fork();
    if (c == 0) {
        for (uint32_t p = 0; p < CBYTES / PAGE && !bad; p++)
            for (uint32_t w = 0; w < PAGE / 4; w++)
                if (m[p * (PAGE / 4) + w] != bpat(p | 0x80000000u, 6)) {
                    bad = 1;
                    printf("COWRACE2-DETAIL child-c page=%u word=%u got=%08x\n",
                           p, w, m[p * (PAGE / 4) + w]);
                    break;
                }
        _exit(bad ? 1 : 0);
    }
    int st; waitpid(c, &st, 0);
    int child_bad = (!WIFEXITED(st) || WEXITSTATUS(st) != 0);
    for (uint32_t p = 0; p < CBYTES / PAGE && !bad; p++)
        for (uint32_t w = 0; w < PAGE / 4; w++)
            if (m[p * (PAGE / 4) + w] != bpat(p | 0x80000000u, 6)) {
                bad = 1;
                printf("COWRACE2-DETAIL parent-c page=%u word=%u got=%08x\n",
                       p, w, m[p * (PAGE / 4) + w]);
                break;
            }
    if (bad || child_bad)
        printf("COWRACE2-C-FAIL parent_bad=%d child_bad=%d\n", bad, child_bad);
    else
        printf("COWRACE2-C-OK pages=%u pcache-cow-clean\n", CBYTES / PAGE);
    munmap(m, CBYTES);
    close(fd);
    unlink("/cowrace2.scratch");
}

/* ---- phase D driver: bio pressure thread (runs during A/B/C) ---- */

static volatile int d_run;
static uint64_t d_ops;
static void *d_storm(void *arg)
{
    (void)arg;
    int fd = open("/cowrace2.bio", O_RDWR | O_CREAT | O_TRUNC, 0600);
    if (fd < 0) return NULL;
    char buf[4096];
    memset(buf, 0x5a, sizeof buf);
    off_t off = 0;
    while (d_run) {
        if (pwrite(fd, buf, sizeof buf, off) != (ssize_t)sizeof buf) break;
        off = (off + sizeof buf) % (1u << 20);
        d_ops++;
        if ((d_ops & 0x3f) == 0)
            if (fsync(fd) != 0) break;
    }
    close(fd);
    unlink("/cowrace2.bio");
    return NULL;
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    printf("COWRACE2-START rounds=%d\n", ROUNDS);
    pthread_t bio;
    d_run = 1;
    if (pthread_create(&bio, NULL, d_storm, NULL) != 0)
        printf("COWRACE2-WARN bio-thread off\n");
    phase_a();
    phase_b();
    phase_c();
    d_run = 0;
    pthread_join(bio, NULL);
    printf("COWRACE2-D-OK bio-ops=%lu (fsync every 64)\n", (unsigned long)d_ops);
    printf("COWRACE2-PASS\n");
    return 0;
}
