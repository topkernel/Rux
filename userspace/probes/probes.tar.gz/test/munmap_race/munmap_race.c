// munmap_race.c — direct repro for the chunked-munmap vs mmap race
// (oh-crash lane, 50th agent; the mallocng hole-write root cause).
//
// Mechanism under test (kernel divergence from Linux 6.6):
//   Our AddressSpace::munmap is CHUNKED (VMA-lock convoy bound): it
//   drops the vma_write guard every 1 MiB and re-derives the next
//   overlapping VMA from the LIVE tree each chunk. A racing mmap's
//   atomic pick+insert can therefore land INSIDE the still-pending
//   munmap range (lowest-fit placement prefers the just-freed chunk!);
//   a LATER munmap chunk then removes the fresh VMA and zaps its PTEs —
//   the racing mmap already RETURNED that address, so userspace writes
//   into a hole -> SIGSEGV (the mallocng alloc_group group-stamp crash
//   family, rip inside ld-musl, cr2 between FFRT-zone mappings).
//   Linux holds mmap_lock (write) across the WHOLE do_munmap, so the
//   interleave is impossible there.
//
// Probe shape:
//   munmapper thread: mmap(4 MiB) + touch + munmap, in a tight loop
//     (drives multi-chunk munmaps at maximum rate).
//   keeper threads:   mmap small regions (4..64 KiB, anon RW), write a
//     stamp IMMEDIATELY at return, keep them live in a slot table, and
//     continuously touch (read+write) every kept mapping's first/last
//     page under a SIGSEGV handler that catches the fault address and
//     names the victim mapping.
//
// Verdict:
//   MUNMAP-RACE-CAUGHT <addr> <slot-size> <stamp>   -> rc 1 (bug live)
//   MUNMAP-RACE-PASS kept=<n> rounds=<n> faults=0   -> rc 0 (clean)
//
// Control: the same binary must PASS on the reference kernel (Linux
// mmap_lock serializes munmap vs mmap; verified on the host).
//
// Build: x86_64 musl static, -pthread.

#include <pthread.h>
#include <setjmp.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>

#ifndef SECS
#define SECS 8
#endif

#define NSLOTS 96

static struct slot {
    volatile unsigned char *p;
    size_t len;
    uint64_t stamp;
    volatile int live;
} slots[NSLOTS];

static volatile sig_atomic_t caught;
/* Per-thread fault catcher state: multiple keeper threads touch
 * concurrently, and a shared jmp buf would cross-longjmp. */
static __thread sigjmp_buf fault_jmp;
static volatile unsigned char *fault_p;

/* armed: a touch/stamp region is active in THIS thread — longjmp back.
 * Unarmed: the fault hit outside any guarded region (e.g. the very
 * stamping loop). Async-safe self-report via write(2) + _exit. */
static __thread int armed;

static void segv_handler(int sig, siginfo_t *si, void *uc)
{
    (void)sig; (void)uc;
    fault_p = (volatile unsigned char *)si->si_addr;
    caught = 1;
    if (armed) {
        siglongjmp(fault_jmp, 1);
    }
    /* Unarmed fault: report and die — async-safe only. */
    char buf[64];
    int n = 0;
    const char *pre = "MUNMAP-RACE-CAUGHT addr=0x";
    while (pre[n]) { buf[n] = pre[n]; n++; }
    unsigned long v = (unsigned long)si->si_addr;
    for (int k = 60; k >= 0; k -= 4) {
        unsigned d = (v >> k) & 0xf;
        if (d || n > 26 || k == 0) buf[n++] = d < 10 ? '0' + d : 'a' + d - 10;
    }
    buf[n++] = '\n';
    write(2, buf, n);
    _exit(1);
}

/* touch a byte under the fault catcher; returns 0 ok, -1 faulted */
static int touch(volatile unsigned char *p)
{
    armed = 1;
    if (sigsetjmp(fault_jmp, 1) == 0) {
        *p = (unsigned char)(*p + 1);
        armed = 0;
        return 0;
    }
    armed = 0;
    return -1;
}

static volatile int run;
static volatile uint64_t mun_rounds, keep_maps;

static void *munmapper(void *arg)
{
    (void)arg;
    const size_t big = 4u << 20;
    while (run) {
        char *b = mmap(NULL, big, PROT_READ | PROT_WRITE,
                       MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (b == MAP_FAILED) continue;
        for (size_t o = 0; o < big; o += 4096) b[o] = 1;
        munmap(b, big);
        mun_rounds++;
    }
    return NULL;
}

#define KKEEP 3
static void *keeper(void *arg)
{
    long id = (long)arg;
    /* Slots are PARTITIONED per keeper: two keepers sharing a slot
     * would munmap/touch the same mapping concurrently and manufacture
     * faults that are the probe's own race, not the kernel's (the
     * host-control false positive). */
    int i0 = (int)id * (NSLOTS / KKEEP);
    int i1 = i0 + NSLOTS / KKEEP;
    unsigned rng = (unsigned)(id * 2654435761u + 7u);
    while (run) {
        rng = rng * 1103515245 + 12345;
        int i = i0 + (rng >> 8) % (i1 - i0);
        struct slot *s = &slots[i];
        /* replace slot i with a fresh mapping */
        if (s->live) {
            /* verify before dropping (the fault catcher reports it) */
            if (touch(s->p) != 0) {
                /* caught — handler already set fault_p; report outside */
                caught = 2;
            }
            munmap((void *)s->p, s->len);
            s->live = 0;
        }
        rng = rng * 1103515245 + 12345;
        size_t len = 4096u << ((rng >> 9) % 5);   /* 4K..64K */
        unsigned char *p = mmap(NULL, len, PROT_READ | PROT_WRITE,
                                MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (p == MAP_FAILED) continue;
        uint64_t stamp = ((uint64_t)p >> 4) ^ 0x5a5a5a5a5a5a5a5aull;
        /* stamp EVERY page immediately after return — this is the write
         * that dies into the hole when the race hits */
        armed = 1;
        if (sigsetjmp(fault_jmp, 1) != 0) {
            armed = 0;
            caught = 1;   /* fault_p named by the handler */
            return NULL;
        }
        for (size_t o = 0; o < len; o += 4096)
            *(volatile uint64_t *)(p + o) = stamp;
        armed = 0;
        s->p = p; s->len = len; s->stamp = stamp; s->live = 1;
        keep_maps++;
    }
    return NULL;
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_sigaction = segv_handler;
    sa.sa_flags = SA_SIGINFO;
    if (sigaction(SIGSEGV, &sa, NULL) != 0 || sigaction(SIGBUS, &sa, NULL) != 0) {
        printf("MUNMAP-RACE-FAIL sigaction\n");
        return 1;
    }
    printf("MUNMAP-RACE-START secs=%d\n", SECS);
    run = 1;
    pthread_t mun, keep[3];
    pthread_create(&mun, NULL, munmapper, NULL);
    for (long i = 0; i < 3; i++)
        pthread_create(&keep[i], NULL, keeper, (void *)i);

    for (int s = 0; s < SECS && !caught; s++)
        usleep(1000000);
    run = 0;
    pthread_join(mun, NULL);
    for (int i = 0; i < 3; i++) pthread_join(keep[i], NULL);

    if (caught) {
        /* fault_p names the address; find the slot */
        int hit = -1;
        for (int i = 0; i < NSLOTS; i++)
            if (slots[i].live && fault_p >= slots[i].p
                && fault_p < slots[i].p + slots[i].len)
                hit = i;
        printf("MUNMAP-RACE-CAUGHT addr=%p slot=%d len=%zu stamp=%llx mode=%d\n",
               (void *)fault_p, hit,
               hit >= 0 ? slots[hit].len : 0,
               hit >= 0 ? (unsigned long long)slots[hit].stamp : 0ull,
               (int)caught);
        return 1;
    }
    int kept = 0;
    for (int i = 0; i < NSLOTS; i++) if (slots[i].live) kept++;
    printf("MUNMAP-RACE-PASS kept=%d mun_rounds=%lu keep_maps=%lu\n",
           kept, (unsigned long)mun_rounds, (unsigned long)keep_maps);
    return 0;
}
