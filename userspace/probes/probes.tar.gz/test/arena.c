// arena.c — FFRT arena demand-paging probe (x86_64; runs on any Linux).
//
// Replicates the OpenHarmony FFRT arena pattern end to end:
//   1. a big PROT_NONE anonymous reserve (mmap NULL, 2GB, NORESERVE);
//   2. fixed-address carving of RW pages inside it (MAP_FIXED |
//      MAP_ANONYMOUS), including MAP_FIXED_NOREPLACE;
//   3. guard-page flips via mprotect (RW -> PROT_NONE -> RW);
//   4. a SIGSEGV handler that installs the touched page with
//      mmap(page, PAGE, RW, MAP_FIXED|MAP_ANONYMOUS) and returns,
//      letting the faulting instruction retry — the suspected FFRT
//      worker loop shape (cr2=0x7ff10049a1f1 just past the arena top);
//   5. the mmi_service face: clock_gettime(CLOCK_MONOTONIC, tp) with
//      tp inside a not-yet-installed arena page — the store faults
//      inside libc/vDSO code, not probe code (rip-family 0x3fbf089ac6);
//   6. boundary pages: first page, last page, and ONE PAGE PAST the
//      reserve top (the exact gx1/gx5 cr2 shape);
//   7. mprotect-based guard->RW handler variant (the other FFRT idiom);
//   8. mremap(MREMAP_MAYMOVE|MREMAP_FIXED) slice fill (CFI-shadow idiom);
//   9. explicit high fixed addresses (0x7ff0_xxxx_x000 class) and hint
//      honoring past the arena top.
//
// Every check prints "ARENA T<n> <name>: PASS/FAIL detail". The final
// line is ARENA-PASS or ARENA-FAIL. Exit code 0 iff all passed.
//
// The handler never loops: if its mmap/mprotect fails it prints the
// errno and _exit()s — a fault loop is reported as a FAIL, not hung.

#define _GNU_SOURCE
#include <errno.h>
#include <setjmp.h>
#include <signal.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/auxv.h>
#include <sys/mman.h>
#include <time.h>
#include <unistd.h>

#define PAGE   4096UL
#define PGN(x) ((unsigned long)(x) & ~(PAGE - 1))

#define RESERVE_SZ 0x80000000UL /* 2GB, hilogd/CFFI reserve class */

static unsigned long arena;      /* reserve base */
static unsigned long arena_end;  /* reserve end (base + 2GB) */
static int fails;
static int tno;

/* ---- SEGV-handler demand paging state (T5-T7) ---- */
static volatile unsigned long install_count;
static volatile unsigned long handler_fail_errno;
static volatile unsigned long last_si_code;
static volatile unsigned long last_si_addr;
/* mode: 0 = mmap MAP_FIXED install, 1 = mprotect RW upgrade */
static volatile int handler_mode;

static struct sigaction sa_default;
static volatile unsigned long handler_entries;
static void arena_handler(int sig, siginfo_t *si, void *uc)
{
    (void)uc;
    last_si_code = (unsigned long)si->si_code;
    last_si_addr = (unsigned long)si->si_addr;
    handler_entries++;
    if (handler_entries <= 8) {
        char eb[96];
        int n = snprintf(eb, sizeof(eb),
                         "ARENA HANDLER-ENTRY #%lu addr=%p code=%lu\n",
                         handler_entries, si->si_addr,
                         (unsigned long)si->si_code);
        write(2, eb, n);
    }
    if (sig != SIGSEGV)
        _exit(9);
    unsigned long page = PGN(si->si_addr);
    void *ret;
    if (handler_mode == 0) {
        ret = mmap((void *)page, PAGE, PROT_READ | PROT_WRITE,
                   MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
        if (ret == (void *)page && handler_entries <= 8) {
            /* prove the mapping is writable FROM the handler */
            *(volatile unsigned long *)page = 0x70707;
            char eb[96];
            int n = snprintf(eb, sizeof(eb),
                             "ARENA HANDLER-MMAP-OK #%lu page=%#lx store_ok=%d\n",
                             handler_entries, page,
                             *(volatile unsigned long *)page == 0x70707);
            write(2, eb, n);
        }
    } else {
        int rc = mprotect((void *)page, PAGE, PROT_READ | PROT_WRITE);
        ret = rc == 0 ? (void *)page : MAP_FAILED;
    }
    if (ret == MAP_FAILED) {
        /* the suspected Rux failure: handler mmap fails -> the very
         * fault loop seen on OH. Report and die instead of looping. */
        handler_fail_errno = (unsigned long)errno;
        static const char msg[] = "ARENA HANDLER-FAIL: mmap/mprotect in SEGV handler errno=";
        write(2, msg, sizeof(msg) - 1);
        char eb[24];
        int n = snprintf(eb, sizeof(eb), "%lu addr=%p\n",
                         handler_fail_errno, si->si_addr);
        write(2, eb, n);
        _exit(2);
    }
    install_count++;
}

static void check(int cond, const char *name, const char *fmt, ...)
{
    va_list ap;
    printf("ARENA T%d %s: %s ", ++tno, name, cond ? "PASS" : "FAIL");
    va_start(ap, fmt);
    vprintf(fmt, ap);
    va_end(ap);
    printf("\n");
    if (!cond)
        fails++;
}

/* expected-fault machinery (probe-internal faults, not handler-fed) */
static __thread sigjmp_buf fjmp;
static __thread volatile sig_atomic_t fok;
static void probe_fault(int sig, siginfo_t *si, void *uc)
{
    (void)sig; (void)si; (void)uc;
    if (fok)
        siglongjmp(fjmp, 1);
    write(2, "ARENA UNEXPECTED-SIGSEGV\n", 25);
    _exit(3);
}
static int store_faults(volatile unsigned long *p)
{
    fok = 1;
    if (sigsetjmp(fjmp, 1) == 0) {
        *p = 0x5a5a5a5a5a5a5a5aUL;
        fok = 0;
        return 0;
    }
    fok = 0;
    return 1;
}
static int read_faults(volatile const unsigned long *p)
{
    fok = 1;
    if (sigsetjmp(fjmp, 1) == 0) {
        unsigned long v = *p;
        (void)v;
        fok = 0;
        return 0;
    }
    fok = 0;
    return 1;
}

int main(void)
{
    setvbuf(stdout, NULL, _IOLBF, 0);

    /* The probe-internal expected-fault handler is installed around
     * specific tests; the FFRT-style arena handler is swapped in for
     * the demand-paging tests. */
    struct sigaction sa_probe = {0};
    sa_probe.sa_sigaction = probe_fault;
    sa_probe.sa_flags = SA_SIGINFO | SA_NODEFER;
    sigemptyset(&sa_probe.sa_mask);
    struct sigaction sa_arena = {0};
    memset(&sa_default, 0, sizeof(sa_default));
    sa_default.sa_handler = SIG_DFL;
    sa_arena.sa_sigaction = arena_handler;
    sa_arena.sa_flags = SA_SIGINFO;
    sigemptyset(&sa_arena.sa_mask);

    printf("ARENA pid=%ld page=%lu vdso=%#lx\n", (long)getpid(), PAGE,
           (unsigned long)getauxval(AT_SYSINFO_EHDR));

    /* ---- T1: the reserve ---- */
    void *r = mmap(NULL, RESERVE_SZ, PROT_NONE,
                   MAP_PRIVATE | MAP_ANONYMOUS | MAP_NORESERVE, -1, 0);
    check(r != MAP_FAILED, "reserve",
          "mmap(NULL,2GB,PROT_NONE) = %p errno=%d", r, errno);
    if (r == MAP_FAILED)
        return 1;
    arena = (unsigned long)r;
    arena_end = arena + RESERVE_SZ;
    printf("ARENA base=%#lx end=%#lx\n", arena, arena_end);

    /* ---- T2: fixed carve inside the reserve (first usable page +1MB,
     *          2 pages RW) ---- */
    unsigned long carve = PGN(arena + 0x100000);
    void *c = mmap((void *)carve, 2 * PAGE, PROT_READ | PROT_WRITE,
                   MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
    int carve_ok = c == (void *)carve;
    if (carve_ok) {
        *(volatile unsigned long *)carve = 0x1111;
        *(volatile unsigned long *)(carve + 2 * PAGE - 8) = 0x2222;
        carve_ok = *(volatile unsigned long *)carve == 0x1111
            && *(volatile unsigned long *)(carve + 2 * PAGE - 8) == 0x2222;
    }
    check(carve_ok, "fixed-carve", "MAP_FIXED 2p rw at %#lx: ret=%p", carve, c);

    /* ---- T3: MAP_FIXED_NOREPLACE ---- */
    errno = 0;
    void *nr = mmap((void *)carve, PAGE, PROT_READ | PROT_WRITE,
                    MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED_NOREPLACE, -1, 0);
    int eexist = nr == MAP_FAILED && errno == EEXIST;
    check(eexist, "noreplace-overlap", "ret=%p errno=%d (want EEXIST)", nr, errno);
    unsigned long free_p = 0x7ffc00000000UL;
    errno = 0;
    nr = mmap((void *)free_p, PAGE, PROT_READ | PROT_WRITE,
              MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED_NOREPLACE, -1, 0);
    int nrfree = nr == (void *)free_p;
    if (nrfree)
        *(volatile unsigned long *)free_p = 0x33;
    check(nrfree, "noreplace-free", "ret=%p errno=%d (want %#lx)", nr, errno, free_p);
    if (nr != MAP_FAILED)
        munmap(nr, PAGE);

    /* ---- T4: guard flip RW -> PROT_NONE -> RW inside the carve ---- */
    unsigned long guard = carve + PAGE; /* second carved page */
    int g1 = mprotect((void *)guard, PAGE, PROT_NONE) == 0;
    sigaction(SIGSEGV, &sa_probe, NULL);
    int g2 = g1 && store_faults((volatile unsigned long *)guard);
    int g3 = g1 && read_faults((volatile const unsigned long *)guard);
    sigaction(SIGSEGV, &sa_default, NULL);
    int g4 = mprotect((void *)guard, PAGE, PROT_READ | PROT_WRITE) == 0;
    if (g4)
        *(volatile unsigned long *)guard = 0x4444;
    int g5 = g4 && *(volatile unsigned long *)guard == 0x4444;
    check(g1 && g2 && g3 && g4 && g5, "guard-flip",
          "mp=%d/%d store_faults=%d read_faults=%d rw_restore=%d store_ok=%d",
          g1, g4, g2, g3, g4, g5);

    /* ---- T4b: VMA-split mprotect — RW region of 4 pages, guard the
     * middle 2, neighbors must survive ---- */
    unsigned long reg = PGN(arena + 0x300000);
    void *rr = mmap((void *)reg, 4 * PAGE, PROT_READ | PROT_WRITE,
                    MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
    int s1 = rr == (void *)reg;
    *(volatile unsigned long *)(reg) = 0xa1;
    *(volatile unsigned long *)(reg + 3 * PAGE) = 0xa4;
    int s2 = mprotect((void *)(reg + PAGE), 2 * PAGE, PROT_NONE) == 0;
    sigaction(SIGSEGV, &sa_probe, NULL);
    int s3 = s2 && store_faults((volatile unsigned long *)(reg + PAGE));
    int s4 = s2 && store_faults((volatile unsigned long *)(reg + 2 * PAGE - 8));
    int s5 = !store_faults((volatile unsigned long *)reg); /* head alive */
    int s6 = !store_faults((volatile unsigned long *)(reg + 3 * PAGE)); /* tail alive */
    sigaction(SIGSEGV, &sa_default, NULL);
    check(s1 && s2 && s3 && s4 && s5 && s6, "split-guard",
          "map=%d mp=%d mid=%d/%d head_ok=%d tail_ok=%d", s1, s2, s3, s4, s5, s6);

    /* ---- T4c: munmap middle page, neighbors alive, then MAP_FIXED
     * refill the hole (FFRT worker-stack teardown/idiom) ---- */
    int m1 = munmap((void *)(reg + PAGE), PAGE) == 0;
    sigaction(SIGSEGV, &sa_probe, NULL);
    int m2 = m1 && store_faults((volatile unsigned long *)(reg + PAGE));
    int m3 = !store_faults((volatile unsigned long *)reg);
    int m4 = !store_faults((volatile unsigned long *)(reg + 3 * PAGE));
    sigaction(SIGSEGV, &sa_default, NULL);
    void *rf = mmap((void *)(reg + PAGE), PAGE, PROT_READ | PROT_WRITE,
                    MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
    int m5 = rf == (void *)(reg + PAGE);
    if (m5)
        *(volatile unsigned long *)(reg + PAGE) = 0xb2;
    check(m1 && m2 && m3 && m4 && m5, "munmap-split-refill",
          "munmap=%d hole_faults=%d head_ok=%d tail_ok=%d refill=%p", m1, m2, m3, m4, rf);

    /* ---- T4d: same MAP_FIXED carve + store from MAIN flow (no signal
     * involved) — discriminates signal-context mmap from plain mmap ---- */
    unsigned long pre = PGN(arena + 0xa00000);
    void *pr = mmap((void *)pre, PAGE, PROT_READ | PROT_WRITE,
                    MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
    int prok = pr == (void *)pre;
    if (prok)
        *(volatile unsigned long *)pre = 0x55;
    check(prok && *(volatile unsigned long *)pre == 0x55,
          "mainflow-fixed-carve", "ret=%p store_ok=%d", pr, prok);

    /* ---- T5: SEGV-handler demand paging inside the reserve ---- */
    handler_mode = 0;
    install_count = 0;
    handler_fail_errno = 0;
    handler_entries = 0;
    sigaction(SIGSEGV, &sa_arena, NULL);
    unsigned long wbase = PGN(arena + 0x400000);
    /* touch 33 sequential pages INCLUDING the reserve's first page and
     * the last page (boundary faces), plus one straddling unaligned
     * store (cr2 mid-page like 0x...a1f1) */
    volatile unsigned long *wp;
    int wok = 1;
    wp = (volatile unsigned long *)arena;
    *wp = 0x100;                     /* very first page of the reserve */
    wok &= *wp == 0x100;
    for (unsigned long i = 0; i < 32; i++) {
        wp = (volatile unsigned long *)(wbase + i * PAGE + 0x1f1);
        *wp = i + 1;
        wok &= *wp == i + 1;
    }
    wp = (volatile unsigned long *)(arena_end - PAGE + 8);
    *wp = 0xdead;                    /* very last page */
    wok &= *wp == 0xdead;
    unsigned long want = 1 /* first */ + 32 /* body */ + 1 /* last */;
    sigaction(SIGSEGV, &sa_default, NULL);
    check(wok && install_count == want && handler_fail_errno == 0,
          "handler-mmap-demand",
          "stores_ok=%d installed=%lu (want %lu) si_code(first observed)=%lu",
          wok, install_count, want, last_si_code);

    /* ---- T6: one page PAST the top (the gx1/gx5 cr2 shape) ---- */
    handler_mode = 0;
    install_count = 0;
    sigaction(SIGSEGV, &sa_arena, NULL);
    volatile unsigned long *past = (volatile unsigned long *)(arena_end + 0x123);
    *past = 0x77;
    int pok = *past == 0x77;
    sigaction(SIGSEGV, &sa_default, NULL);
    check(pok && install_count == 1 && handler_fail_errno == 0,
          "handler-past-top",
          "store_past_end=%d installed=%lu si_code=%lu", pok, install_count,
          last_si_code);

    /* ---- T7: mprotect-mode handler (guard->RW on touch) ---- */
    handler_mode = 1;
    install_count = 0;
    /* re-guard a page inside the still-PROT_NONE reserve */
    unsigned long gpage = PGN(arena + 0x500000);
    /* mprotect over PROT_NONE reserve -> needs coverage; it IS covered
     * (reserve VMA), so this just re-flags it (no-op semantics-wise). */
    mprotect((void *)gpage, PAGE, PROT_NONE);
    sigaction(SIGSEGV, &sa_arena, NULL);
    volatile unsigned long *gp = (volatile unsigned long *)gpage;
    *gp = 0x88;
    int gok = *gp == 0x88;
    sigaction(SIGSEGV, &sa_default, NULL);
    check(gok && install_count == 1 && handler_fail_errno == 0,
          "handler-mprotect-mode",
          "store=%d installed=%lu errno=%lu", gok, install_count,
          handler_fail_errno);

    /* ---- T8: the mmi_service face — clock_gettime storing into an
     * arena page from libc/vDSO code ---- */
    handler_mode = 0;
    install_count = 0;
    sigaction(SIGSEGV, &sa_arena, NULL);
    struct timespec *ts = (struct timespec *)(PGN(arena + 0x600000) + 0x6d0);
    int t1rc = clock_gettime(CLOCK_MONOTONIC, ts);
    /* Snapshot the fields WHILE the handler is still armed — a fault
     * on the read must be handler-fixable, not process-fatal. */
    long ts_sec = -1;
    long ts_nsec = -1;
    if (t1rc == 0) {
        ts_sec = ts->tv_sec;
        ts_nsec = ts->tv_nsec;
    }
    int tok = t1rc == 0 && ts_nsec != 0;
    /* second call on the SAME page must not re-fault */
    struct timespec ts2;
    int t2rc = clock_gettime(CLOCK_MONOTONIC, &ts2);
    sigaction(SIGSEGV, &sa_default, NULL);
    check(tok && t2rc == 0 && install_count == 1,
          "clock_gettime-arena-tp",
          "rc=%d installed=%lu ts=%ld.%09ld si_code=%lu", t1rc,
          install_count, ts_sec, ts_nsec, last_si_code);

    /* ---- T8b: does musl's own vDSO lookup resolve our kernel vDSO?
     * (musl __vdsosym: PT_DYNAMIC -> DT_STRTAB/DT_SYMTAB/DT_HASH,
     * linear walk over nchain symbols; calls __vdso_clock_gettime
     * IN USER MODE — the exact OH mmi_service crash path shape.) ---- */
    {
        unsigned long eh = getauxval(AT_SYSINFO_EHDR);
        unsigned long base = 0, dynv = 0;
        if (eh) {
            unsigned long phoff = *(unsigned long *)(eh + 32);
            unsigned phentsize = *(unsigned short *)(eh + 54);
            unsigned phnum = *(unsigned short *)(eh + 56);
            for (unsigned i = 0; i < phnum; i++) {
                unsigned long ph = eh + phoff + (unsigned long)i * phentsize;
                unsigned ptype = *(unsigned *)(ph);
                if (ptype == 1) /* PT_LOAD */
                    base = eh + *(unsigned long *)(ph + 8) /*p_offset*/
                           - *(unsigned long *)(ph + 16) /*p_vaddr*/;
                else if (ptype == 2) /* PT_DYNAMIC */
                    dynv = eh + *(unsigned long *)(ph + 8);
            }
        }
        unsigned long strs = 0, syms = 0, hash = 0, found = 0;
        if (dynv && base) {
            for (unsigned long *d = (unsigned long *)dynv; d[0]; d += 2) {
                if (d[0] == 5) strs = base + d[1];
                if (d[0] == 6) syms = base + d[1];
                if (d[0] == 4) hash = base + d[1];
            }
        }
        if (strs && syms && hash) {
            /* DT_HASH words are 32-bit: [nbucket, nchain, buckets...,
             * chains...] — a 64-bit read of word[1] runs into the
             * buckets and the sym walk then leaves the table. */
            unsigned nchain = ((unsigned *)hash)[1];
            for (unsigned i = 0; i < nchain; i++) {
                unsigned char *sym = (unsigned char *)syms + i * 24;
                unsigned nameoff = *(unsigned *)(sym);
                unsigned char info = sym[4];
                unsigned short shndx = *(unsigned short *)(sym + 6);
                if ((info & 0xf) != 2 /* STT_FUNC */) continue;
                if ((info >> 4) != 1 /* STB_GLOBAL */) continue;
                if (!shndx) continue;
                if (strcmp((char *)strs + nameoff, "__vdso_clock_gettime")) continue;
                found = base + *(unsigned long *)(sym + 8);
                break;
            }
        }
        int vdso_ok = 0;
        if (found) {
            /* call it exactly like musl would, with a pointer into a
             * not-yet-installed arena page — the mmi_service shape */
            handler_mode = 0;
            install_count = 0;
            handler_entries = 0;
            sigaction(SIGSEGV, &sa_arena, NULL);
            struct timespec *vts = (struct timespec *)(PGN(arena + 0xb00000) + 0x330);
            int (*vdso_cgt)(int, void *) = (void *)found;
            int vrc = vdso_cgt(CLOCK_MONOTONIC, vts);
            vdso_ok = vrc == 0 && vts->tv_nsec >= 0;
            sigaction(SIGSEGV, &sa_default, NULL);
        }
        check(!eh || vdso_ok, "vdso-resolve-and-call",
              "eh=%#lx found=%#lx call_ok=%d", eh, found, vdso_ok);
    }

    /* ---- T9: hint honoring just past the arena (non-fixed) ---- */
    unsigned long hint = arena_end + 0x1000000;
    errno = 0;
    void *h = mmap((void *)hint, 0x100000, PROT_READ | PROT_WRITE,
                   MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    int hok2 = h == (void *)hint;
    if (hok2)
        *(volatile unsigned long *)hint = 0x99;
    check(hok2, "hint-past-arena", "mmap(hint=%#lx) = %p errno=%d", hint, h, errno);
    if (h != MAP_FAILED && !hok2)
        munmap(h, 0x100000);

    /* ---- T10: mremap MAYMOVE|FIXED slice fill (CFI-shadow idiom) ---- */
    unsigned long slice = PGN(arena + 0x700000);
    size_t slen = 4 * PAGE;
    void *tmp = mmap(NULL, slen, PROT_READ | PROT_WRITE,
                     MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    int c1 = tmp != MAP_FAILED;
    if (c1)
        memcpy(tmp, "SLICE-ORIG", 11);
    int c2 = c1 && mprotect(tmp, slen, PROT_READ) == 0;
    void *mv = c2 ? mremap(tmp, slen, slen,
                           MREMAP_MAYMOVE | MREMAP_FIXED, (void *)slice)
                  : MAP_FAILED;
    int c3 = mv == (void *)slice;
    sigaction(SIGSEGV, &sa_probe, NULL);
    int c4 = c3 && memcmp((void *)slice, "SLICE-ORIG", 11) == 0;
    int c5 = c3 && store_faults((volatile unsigned long *)(slice + 0x100)); /* R only */
    sigaction(SIGSEGV, &sa_default, NULL);
    check(c1 && c2 && c3 && c4 && c5, "mremap-fixed-fill",
          "tmp=%p mp=%d mv=%p read_ok=%d store_faults=%d", tmp, c2, mv, c4, c5);

    /* ---- T11: explicit high fixed addresses (FFRT 0x7ff0 class) ---- */
    unsigned long hi1 = 0x7ff000000000UL;
    void *f1 = mmap((void *)hi1, 2 * PAGE, PROT_READ | PROT_WRITE,
                    MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
    int f1ok = f1 == (void *)hi1;
    if (f1ok)
        *(volatile unsigned long *)hi1 = 0xcafe;
    unsigned long hi2 = 0x7ffd00000000UL; /* near-stack class address */
    void *f2 = mmap((void *)hi2, PAGE, PROT_READ | PROT_WRITE,
                    MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
    int f2ok = f2 == (void *)hi2;
    if (f2ok)
        *(volatile unsigned long *)hi2 = 0xbabe;
    check(f1ok && f2ok, "high-fixed", "0x7ff000000000->%p 0x7ffd00000000->%p",
          f1, f2);

    /* ---- T12: unaligned MAP_FIXED must EINVAL; unaligned hint is
     * rounded down and honored (Linux masks, never errors) ---- */
    errno = 0;
    void *u1 = mmap((void *)(hi1 + 0x803), PAGE, PROT_READ,
                    MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
    int u1_errno = errno;
    int u1ok = u1 == MAP_FAILED && u1_errno == EINVAL;
    errno = 0;
    unsigned long ua_hint = arena_end + 0x800000 + 0x777; /* unaligned, FREE */
    void *u2 = mmap((void *)ua_hint, PAGE, PROT_READ | PROT_WRITE,
                    MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    int u2ok = u2 == (void *)PGN(ua_hint);
    check(u1ok && u2ok, "align-semantics",
          "fixed+0x803: ret=%p errno=%d (want EINVAL); hint+0x777: ret=%p (want %#lx)",
          u1, u1_errno, u2, PGN(ua_hint));
    if (u2 != MAP_FAILED)
        munmap(u2, PAGE);

    /* ---- T13: conflicting non-fixed hint falls back, never fails ---- */
    errno = 0;
    void *cf = mmap((void *)carve, PAGE, PROT_READ | PROT_WRITE,
                    MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    int cfok = cf != MAP_FAILED && cf != (void *)carve;
    check(cfok, "conflict-hint-fallback", "hint=%#lx ret=%p errno=%d", carve, cf, errno);
    if (cf != MAP_FAILED)
        munmap(cf, PAGE);

    /* ---- T14: churn — repeated fixed carve/unmap on one page
     * (worker-stack alloc/free loop, 512 iterations) ---- */
    unsigned long ch = PGN(arena + 0x900000);
    int chok = 1;
    for (int i = 0; i < 512; i++) {
        void *p = mmap((void *)ch, PAGE, PROT_READ | PROT_WRITE,
                       MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
        if (p != (void *)ch) { chok = 0; break; }
        *(volatile unsigned long *)ch = (unsigned long)i;
        if (*(volatile unsigned long *)ch != (unsigned long)i) { chok = 0; break; }
        if (munmap((void *)ch, PAGE) != 0) { chok = 0; break; }
    }
    check(chok, "fixed-churn-512", "carve+store+unmap x512 at %#lx", ch);

    printf("ARENA %s (fails=%d)\n", fails ? "ARENA-FAIL" : "ARENA-PASS", fails);
    return fails ? 1 : 0;
}
