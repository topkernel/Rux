// cow_int.c — COW/fork CONTENT-INTEGRITY probe (oh-crash lane, 50th agent).
//
// Hunt: the OH userspace crash storm's mallocng family (rip inside
// ld-musl mallocng, chunk-metadata write through a garbage register
// chain, 20 ms after a fork) is consistent with the child (or parent)
// inheriting a page whose CONTENT is wrong after fork/COW — a lost
// dirty page, a stale frame, or two writers sharing one frame after a
// refcount error. This probe pins fork/COW content semantics directly:
//
//   P1 fork-time snapshot: parent fills PAGES of anonymous memory with a
//      per-page/per-word checkerboard, forks; child verifies every word.
//      Any mismatch = the child inherited wrong content (lost dirty page
//      or torn COW copy).
//   P2 parent writes AFTER fork must NOT leak into the child: parent
//      scribbles a different pattern over everything; child re-verifies
//      the original pattern (COW must have diverted the parent's writes
//      to private copies).
//   P3 child writes must NOT corrupt the parent: child scribbles; parent
//      verifies its own view is intact.
//   P4 adversarial: a writer thread mutates every page continuously
//      WHILE the main thread forks. Child checks (a) every word still
//      decodes to its page tag (garbage/foreign content = corruption;
//      mixed generations within a page are legal race semantics and are
//      only counted), (b) double-read stability: the child's view of a
//      page must not change between two reads after fork (parent writes
//      must go to the parent's private copies from the child's first
//      instruction on).
//   P5 mallocng-shaped: parent mallocs thousands of small chunks with
//      per-chunk checksums, forks; child verifies all chunks, exercises
//      its own malloc/free, re-verifies; parent re-verifies after reap.
//
// Output contract (serial):
//   COWINT-P{n}-OK [detail]
//   COWINT-P{n}-FAIL phase detail...
//   COWINT-PASS / COWINT-FAIL (final verdict; exit code 0/1)
//
// Build: x86_64 musl static, -pthread (P4 writer thread).

#include <pthread.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/wait.h>

#define PAGE 4096u
#define PAGES 4096u              /* 16 MiB region */
#define REGION_BYTES (PAGE * PAGES)

/* word pattern: tag identifies the page + phase; stored in EVERY word */
static inline uint32_t wpat(uint32_t page, uint32_t phase, uint32_t gen)
{
    /* bijective mix so neighboring pages/words differ loudly */
    uint32_t x = (page * 2654435761u) ^ (phase * 40503u) ^ (gen * 2246822519u);
    x ^= x >> 16; x *= 0x7feb352du; x ^= x >> 15; x *= 0x846ca68bu; x ^= x >> 16;
    /* keep it nonzero: a zero word where a pattern belongs reads as a
     * "lost page" (fresh anonymous zero page) — the classic lost-dirty
     * signature — and must fail the check */
    return x | 1u;
}

static void fill_region(uint32_t *r, uint32_t phase, uint32_t gen)
{
    for (uint32_t p = 0; p < PAGES; p++)
        for (uint32_t w = 0; w < PAGE / 4; w++)
            r[p * (PAGE / 4) + w] = wpat(p, phase, gen);
}

/* returns number of mismatching pages; prints the first few details */
static int verify_region(const uint32_t *r, uint32_t phase, uint32_t gen,
                         const char *who)
{
    int bad_pages = 0;
    for (uint32_t p = 0; p < PAGES; p++) {
        uint32_t want = wpat(p, phase, gen);
        int bad = 0;
        for (uint32_t w = 0; w < PAGE / 4; w++) {
            if (r[p * (PAGE / 4) + w] != want) { bad = 1; break; }
        }
        if (bad) {
            if (bad_pages < 4)
                printf("COWINT-DETAIL %s page=%u want=%08x got[0]=%08x got[1]=%08x got[mid]=%08x\n",
                       who, p, want,
                       r[p * (PAGE / 4)], r[p * (PAGE / 4) + 1],
                       r[p * (PAGE / 4) + PAGE / 8]);
            bad_pages++;
        }
    }
    return bad_pages;
}

/* P4 decode check: every word must decode to THIS page's tag for some
 * generation (0..GEN_MAX). Anything else = corruption. Per-page valid
 * values are precomputed once (wpat is a bijection in gen for fixed
 * page/phase). */
#define GEN_MAX 64
static int check_p4_page(const uint32_t *r, uint32_t p, uint32_t *gens_out)
{
    uint32_t vals[GEN_MAX + 1];
    for (uint32_t g = 0; g <= GEN_MAX; g++) vals[g] = wpat(p, 4, g);
    int bad = 0;
    uint32_t seen_gens = 0;
    for (uint32_t w = 0; w < PAGE / 4; w++) {
        uint32_t v = r[p * (PAGE / 4) + w];
        int ok = 0;
        for (uint32_t g = 0; g <= GEN_MAX; g++) {
            if (v == vals[g]) { seen_gens |= 1u << (g & 31); ok = 1; break; }
        }
        if (!ok) {
            if (bad < 2)
                printf("COWINT-DETAIL p4-page=%u word=%u val=%08x (no page-tag decode)\n",
                       p, w, v);
            bad++;
        }
    }
    *gens_out = seen_gens;
    return bad; /* >0 words that decode to nothing = corruption */
}

static void p1(void)
{
    uint32_t *r = mmap(NULL, REGION_BYTES, PROT_READ | PROT_WRITE,
                       MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (r == MAP_FAILED) { printf("COWINT-P1-FAIL mmap\n"); exit(1); }
    fill_region(r, 1, 0);
    pid_t c = fork();
    if (c == 0) {
        int bad = verify_region(r, 1, 0, "child-p1");
        printf("COWINT-P1-%s child bad_pages=%d/%u\n", bad ? "FAIL" : "OK", bad, PAGES);
        _exit(bad ? 1 : 0);
    }
    int st; waitpid(c, &st, 0);
    int bad = verify_region(r, 1, 0, "parent-p1");
    if (bad || !WIFEXITED(st) || WEXITSTATUS(st) != 0)
        printf("COWINT-P1-FAIL parent bad=%d st=%x\n", bad, st);
    else
        printf("COWINT-P1-OK pages=%u snapshot-intact both-sides\n", PAGES);
    munmap(r, REGION_BYTES);
}

static void p2_p3(void)
{
    uint32_t *r = mmap(NULL, REGION_BYTES, PROT_READ | PROT_WRITE,
                       MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (r == MAP_FAILED) { printf("COWINT-P2-FAIL mmap\n"); exit(1); }
    fill_region(r, 2, 0);
    int pipe_pc[2], pipe_cp[2];          /* parent->child, child->parent */
    if (pipe(pipe_pc) || pipe(pipe_cp)) { printf("COWINT-P2-FAIL pipe\n"); exit(1); }
    pid_t c = fork();
    if (c == 0) {
        close(pipe_pc[1]); close(pipe_cp[0]);
        char b;
        /* wait for parent to finish scribbling (P2) */
        if (read(pipe_pc[0], &b, 1) != 1) { printf("COWINT-P2-FAIL pipe-read\n"); _exit(1); }
        int bad = verify_region(r, 2, 0, "child-p2");
        printf("COWINT-P2-%s child bad_pages=%d (parent writes leaked)\n", bad ? "FAIL" : "OK", bad);
        /* P3: child scribbles, then tells the parent to verify */
        fill_region(r, 3, 7);
        if (write(pipe_cp[1], "x", 1) != 1) _exit(1);
        /* keep the mapping alive until the parent is done verifying */
        if (read(pipe_pc[0], &b, 1) != 1) _exit(1);
        _exit(bad ? 1 : 0);
    }
    close(pipe_pc[0]); close(pipe_cp[1]);
    /* P2: parent scribbles over EVERYTHING with a different pattern */
    fill_region(r, 2, 9);
    if (write(pipe_pc[1], "x", 1) != 1) { printf("COWINT-P2-FAIL pipe-write\n"); }
    char b;
    if (read(pipe_cp[0], &b, 1) != 1) { printf("COWINT-P3-FAIL pipe-read\n"); exit(1); }
    /* the parent's expected content is its OWN last scribble (2,9) */
    int bad = verify_region(r, 2, 9, "parent-p3");
    printf("COWINT-P3-%s parent bad_pages=%d (child writes leaked)\n", bad ? "FAIL" : "OK", bad);
    write(pipe_pc[1], "x", 1);
    int st; waitpid(c, &st, 0);
    (void)st;
    munmap(r, REGION_BYTES);
}

/* P4 writer thread */
static uint32_t *p4_r;
static volatile int p4_run;
static void *p4_writer(void *arg)
{
    (void)arg;
    uint32_t gen = 0;
    while (p4_run) {
        for (uint32_t p = 0; p < PAGES && p4_run; p++)
            for (uint32_t w = 0; w < PAGE / 4; w++)
                p4_r[p * (PAGE / 4) + w] = wpat(p, 4, gen);
        gen++;
        if (gen > GEN_MAX) gen = 0;
    }
    return NULL;
}

static void p4(void)
{
    pthread_t th;
    p4_r = mmap(NULL, REGION_BYTES, PROT_READ | PROT_WRITE,
                MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (p4_r == MAP_FAILED) { printf("COWINT-P4-FAIL mmap\n"); exit(1); }
    fill_region(p4_r, 4, 0);
    p4_run = 1;
    if (pthread_create(&th, NULL, p4_writer, NULL) != 0) {
        printf("COWINT-P4-FAIL pthread_create\n"); exit(1);
    }
    /* let the writer get well under way, then fork mid-write */
    usleep(20000);
    pid_t c = fork();
    if (c == 0) {
        /* child: the writer thread does NOT exist here (fork keeps only
         * the calling thread) — our view must be frozen from now on */
        int corrupt = 0, torn = 0, unstable = 0;
        uint32_t g;
        for (uint32_t p = 0; p < PAGES; p++) {
            int b = check_p4_page(p4_r, p, &g);
            if (b) corrupt += b;
            else if (__builtin_popcount(g) > 1) torn++; /* legal, count only */
        }
        /* double-read stability: snapshot page 0 & a few others, wait,
         * re-compare — the child's frames are private after fork; the
         * parent's continuing writes must never show up here */
        static uint32_t snap0[PAGE / 4], snapN[PAGE / 4];
        uint32_t probes[] = { 0, 1, PAGES / 2, PAGES - 1 };
        memcpy(snap0, &p4_r[0], PAGE);
        memcpy(snapN, &p4_r[(PAGES / 2) * (PAGE / 4)], PAGE);
        usleep(50000);                    /* parent writer keeps running */
        if (memcmp(snap0, &p4_r[0], PAGE) != 0) unstable++;
        if (memcmp(snapN, &p4_r[(PAGES / 2) * (PAGE / 4)], PAGE) != 0) unstable++;
        printf("COWINT-P4-%s child corrupt_words=%d torn_pages=%d unstable=%d\n",
               (corrupt || unstable) ? "FAIL" : "OK", corrupt, torn, unstable);
        _exit((corrupt || unstable) ? 1 : 0);
    }
    /* parent: writer keeps going through the child's checks */
    usleep(80000);
    p4_run = 0;
    pthread_join(th, NULL);
    int st; waitpid(c, &st, 0);
    if (!WIFEXITED(st) || WEXITSTATUS(st) != 0)
        printf("COWINT-P4-FAIL parent st=%x\n", st);
    else
        printf("COWINT-P4-OK parent writer-raced fork clean\n");
    munmap(p4_r, REGION_BYTES);
}

/* P5 mallocng-shaped: chunk forest with checksums across fork */
#define NCHUNK 4096
struct chk { uint32_t idx; uint32_t seed; uint16_t len; uint16_t sum; };
static uint32_t chash(const void *p, uint32_t n)
{
    const unsigned char *b = p; uint32_t h = 0x9e3779b9u;
    for (uint32_t i = 0; i < n; i++) { h ^= b[i] + 0x5bf03635u; h *= 2654435761u; }
    return h;
}
static unsigned char *chunks[NCHUNK];
static struct chk heads[NCHUNK];

static int verify_chunks(const char *who)
{
    int bad = 0;
    for (int i = 0; i < NCHUNK; i++) {
        if (!chunks[i]) continue;
        struct chk h = heads[i];
        for (uint32_t j = 0; j < h.len; j++)
            if (chunks[i][j] != (unsigned char)(h.seed ^ (h.idx + j)))
                { bad++; if (bad < 4) printf("COWINT-DETAIL %s chunk=%d off=%u want=%02x got=%02x\n", who, i, j, (unsigned char)(h.seed ^ (h.idx + j)), chunks[i][j]); break; }
    }
    return bad;
}

static void p5(void)
{
    srand(12345);
    for (int i = 0; i < NCHUNK; i++) {
        uint32_t len = 24 + (rand() % 480);       /* 24..503 B — mallocng smallbin zone */
        chunks[i] = malloc(len);
        if (!chunks[i]) { printf("COWINT-P5-FAIL alloc %d\n", i); exit(1); }
        heads[i].idx = i; heads[i].seed = (uint32_t)(i * 2654435761u) | 1u;
        heads[i].len = len;
        for (uint32_t j = 0; j < len; j++)
            chunks[i][j] = (unsigned char)(heads[i].seed ^ (i + j));
        heads[i].sum = 0;
    }
    pid_t c = fork();
    if (c == 0) {
        int bad = verify_chunks("child-p5a");
        /* exercise the child's allocator over the SAME arena pages */
        void *tmp[512];
        for (int k = 0; k < 512; k++) { uint32_t l = 16 + ((k * 7919) % 992); tmp[k] = malloc(l); if (tmp[k]) memset(tmp[k], 0x5a, l); }
        for (int k = 0; k < 512; k += 2) free(tmp[k]);
        for (int k = 0; k < 256; k++) { uint32_t l = 32 + ((k * 104729) % 800); tmp[k] = malloc(l); if (tmp[k]) memset(tmp[k], 0xa5, l); }
        int bad2 = verify_chunks("child-p5b");
        printf("COWINT-P5-%s child bad=%d bad-after-churn=%d\n",
               (bad || bad2) ? "FAIL" : "OK", bad, bad2);
        _exit((bad || bad2) ? 1 : 0);
    }
    int st; waitpid(c, &st, 0);
    int bad = verify_chunks("parent-p5");
    if (bad || !WIFEXITED(st) || WEXITSTATUS(st) != 0)
        printf("COWINT-P5-FAIL parent bad=%d st=%x\n", bad, st);
    else
        printf("COWINT-P5-OK chunks=%d intact across fork+churn\n", NCHUNK);
}

#ifndef LOOPS
#define LOOPS 1
#endif

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    for (int loop = 0; loop < LOOPS; loop++) {
        printf("COWINT-START loop=%d/%d pages=%u region=%uMiB\n",
               loop + 1, LOOPS, PAGES, REGION_BYTES >> 20);
        p1();
        p2_p3();
        p4();
        p5();
    }
    printf("COWINT-DONE\n");
    return 0;
}
