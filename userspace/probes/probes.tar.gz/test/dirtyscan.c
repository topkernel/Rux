/* dirtyscan.c — dirty-page-recycler hunter (PID 1, never exits).
 *
 * OH lane leg-22 handoff (2026-10-26): a fresh anon page in a loaded
 * module's bss slack (beyond phdr memsz, addressed by nothing in the
 * module) arrived carrying foreign data — string fragments + a live
 * pointer. The fault paths audit (both arches) zeroes every demand
 * page, so the surviving mechanisms are:
 *   (a) a frame handed out twice (premature free / map-without-alloc)
 *       — the foreign bytes are the second owner's legit writes;
 *   (b) a path that maps without the fault-path zeroing (MAP_FIXED
 *       replace / teardown corner);
 *   (c) a post-map wild writer into user frames.
 * (a) and (c) are the wild-write engine's user-memory face; (b) is a
 * silent corruption family. All three are USER-VISIBLE: a fresh anon
 * page must read back zero, and a page the process wrote must keep its
 * bytes. This probe checks both continuously under recycler pressure.
 *
 * Phases (2-3 random per cycle + a guard scan every cycle):
 *   fresh     mmap anon, READ-scan every byte (demand-zero check)
 *   fixed     fill, MAP_FIXED anon over it, scan (replace check)
 *   dontneed  fill, MADV_DONTNEED, scan (zap check)
 *   remap     fill, munmap, fresh mmap, scan (recycle check)
 *   churn     fork children that memset ASCII donor tags + die
 *             (recognizable strings land in the recycler pool)
 *   cow       fork children that touch the guard region + die
 *             (COW resolution must preserve parent bytes)
 *   prot      fill, PROT_NONE round-trip, scan (marker re-present)
 *   guard     persistent magic-filled region, partial re-scan every
 *             cycle — any drift = stolen frame / wild writer, with the
 *             foreign bytes as evidence
 *
 * Heartbeat "DIRTYSCAN-BEAT <i> <phase> ..." so the sweep sees liveness
 * (wedge >300s w/o a beat = hang). Hits print DIRTYHIT / GUARDHIT with
 * hex context (fleet-classify promotes them to CRITICAL).
 *
 * Build: run/fleet/bin/riscv64-musl-gcc -static -O1 -o dirtyscan dirtyscan.c
 */
#define _GNU_SOURCE
#include <errno.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#define PAGE 4096UL
#define MiB (1024UL * 1024UL)

#define GUARD_SIZE (48UL * MiB)
#define GUARD_MAGIC 0xD1E7B0BACAFE0000UL

static unsigned long seed = 0xD1715CA5UL;
static inline unsigned long rnd(void) {
    seed = seed * 6364136223846793005UL + 1442695040888963407UL;
    return seed >> 17;
}

static char *guard;
static unsigned long guard_pages;
static unsigned long cycle;
static unsigned long dirty_hits, guard_hits, churn_forks;

/* Print 4 qwords around `p` as hex + ascii context lines. */
static void dump_ctx(const void *p)
{
    const uintptr_t a = ((uintptr_t)p) & ~7UL;
    const unsigned char *q = (const unsigned char *)(a - 16);
    printf("  DIRTYHIT-CTX va=%p ", (void *)q);
    for (int i = 0; i < 64; i++) {
        unsigned char c = q[i];
        printf("%02x", c);
        if (i % 16 == 15) putchar(' ');
    }
    printf("\n  ascii: ");
    for (int i = 0; i < 64; i++) {
        unsigned char c = q[i + 0];
        putchar((c >= 0x20 && c < 0x7f) ? c : '.');
    }
    putchar('\n');
}

/* Scan a [start, start+len) range byte-by-byte; every byte must be 0.
 * Reports at most 8 hits per region (evidence cap), returns hit count. */
static int scan_zero(const char *start, size_t len, const char *phase)
{
    int nhit = 0;
    const char *p = start, *end = start + len;
    while (p < end) {
        /* word-at-a-time fast path, byte tail */
        while (p + 8 <= end && *(const uint64_t *)p == 0) p += 8;
        while (p < end && *p == 0) p++;
        if (p >= end) break;
        if (nhit < 8) {
            printf("DIRTYHIT phase=%s va=%p off=%zu val=%02x cyc=%lu\n",
                   phase, (void *)p, (size_t)(p - start),
                   (unsigned char)*p, cycle);
            dump_ctx(p);
            fflush(stdout);
        }
        nhit++;
        p += PAGE; /* one report per page */
    }
    return nhit;
}

/* Guard region layout: qword j of page n = GUARD_MAGIC ^ (n * 2654435761UL + j). */
static inline uint64_t guard_qw(unsigned long page, unsigned long j)
{
    return GUARD_MAGIC ^ (page * 2654435761UL + j);
}

static void guard_fill(void)
{
    for (unsigned long n = 0; n < guard_pages; n++) {
        uint64_t *pg = (uint64_t *)(guard + n * PAGE);
        for (unsigned long j = 0; j < PAGE / 8; j++)
            pg[j] = guard_qw(n, j);
    }
}

/* Verify q0 + q1 + last qword of every page in [a,b). Full drift dump
 * for the first mismatching page. Returns bad-page count. */
static int guard_verify(unsigned long a, unsigned long b)
{
    int bad = 0;
    for (unsigned long n = a; n < b; n++) {
        uint64_t *pg = (uint64_t *)(guard + n * PAGE);
        unsigned long probe[3] = {0, 1, PAGE / 8 - 1};
        for (int k = 0; k < 3; k++) {
            uint64_t want = guard_qw(n, probe[k]);
            uint64_t got = pg[probe[k]];
            if (got != want) {
                if (bad < 4) {
                    printf("GUARDHIT va=%p page=%lu qw=%lu expected=%016lx actual=%016lx cyc=%lu\n",
                           (void *)&pg[probe[k]], n, probe[k], want, got, cycle);
                    dump_ctx(&pg[probe[k]]);
                    fflush(stdout);
                }
                bad++;
                break;
            }
        }
    }
    return bad;
}

static void ph_fresh(void)
{
    size_t sz = (4 + rnd() % 13) * MiB; /* 4..16 MiB */
    char *p = mmap(NULL, sz, PROT_READ | PROT_WRITE,
                   MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (p == MAP_FAILED) return;
    dirty_hits += scan_zero(p, sz, "fresh");
    munmap(p, sz);
}

static void ph_fixed(void)
{
    size_t sz = (2 + rnd() % 6) * MiB;
    char *p = mmap(NULL, sz, PROT_READ | PROT_WRITE,
                   MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (p == MAP_FAILED) return;
    memset(p, 0xA5, sz);
    char *q = mmap(p, sz, PROT_READ | PROT_WRITE,
                   MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
    if (q == p)
        dirty_hits += scan_zero(p, sz, "fixed");
    munmap(p, sz);
}

static void ph_dontneed(void)
{
    size_t sz = (2 + rnd() % 6) * MiB;
    char *p = mmap(NULL, sz, PROT_READ | PROT_WRITE,
                   MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (p == MAP_FAILED) return;
    memset(p, 0x5C, sz);
    if (madvise(p, sz, MADV_DONTNEED) == 0)
        dirty_hits += scan_zero(p, sz, "dontneed");
    munmap(p, sz);
}

static void ph_remap(void)
{
    size_t sz = (2 + rnd() % 6) * MiB;
    char *p = mmap(NULL, sz, PROT_READ | PROT_WRITE,
                   MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (p == MAP_FAILED) return;
    memset(p, 0x3C, sz);
    munmap(p, sz);
    char *q = mmap(NULL, sz, PROT_READ | PROT_WRITE,
                   MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (q == MAP_FAILED) return;
    dirty_hits += scan_zero(q, sz, "remap");
    munmap(q, sz);
}

/* Children fill private regions with ASCII donor tags — if any tag ever
 * resurfaces in a fresh scan or the guard, the recycler handed out a
 * dirty frame and the tag names the donor process. */
static void ph_churn(void)
{
    int n = 2 + (rnd() % 3);
    for (int c = 0; c < n; c++) {
        pid_t pid = fork();
        if (pid == 0) {
            size_t sz = (2 + rnd() % 6) * MiB;
            char *p = mmap(NULL, sz, PROT_READ | PROT_WRITE,
                           MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
            if (p != MAP_FAILED) {
                for (size_t o = 0; o < sz; o += PAGE) {
                    snprintf(p + o, PAGE,
                             "DIRTYSCAN-CHURN cyc=%lu child=%d page=%zu "
                             "ptr=%p end=ENDTAG-ENDTAG",
                             cycle, getpid(), o / PAGE, (void *)(p + o));
                }
                munmap(p, sz);
            }
            _exit(0);
        } else if (pid > 0) {
            churn_forks++;
        }
    }
    /* reap without blocking the cycle */
    while (waitpid(-1, NULL, WNOHANG) > 0) ;
}

/* COW churn: children touch guard pages (read + write-back-same), the
 * parent's bytes must survive every resolution. */
static void ph_cow(void)
{
    int n = 2 + (rnd() % 3);
    for (int c = 0; c < n; c++) {
        pid_t pid = fork();
        if (pid == 0) {
            unsigned long a = rnd() % guard_pages;
            unsigned long b = a + 32;
            if (b > guard_pages) b = guard_pages;
            for (unsigned long pg = a; pg < b; pg++) {
                uint64_t *w = (uint64_t *)(guard + pg * PAGE);
                /* read-modify-write the SAME value: COW copies, write is
                 * invisible to the verifier (volatile so -O1 keeps the
                 * store — it IS the point of the phase) */
                volatile uint64_t *vw = w;
                for (unsigned long j = 0; j < PAGE / 8; j += 64)
                    vw[j] = vw[j];
            }
            _exit(0);
        }
    }
    while (waitpid(-1, NULL, WNOHANG) > 0) ;
}

static void ph_prot(void)
{
    char *p = mmap(NULL, 2 * MiB, PROT_READ | PROT_WRITE,
                   MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (p == MAP_FAILED) return;
    memset(p, 0xE7, 2 * MiB);
    mprotect(p, 2 * MiB, PROT_NONE);
    mprotect(p, 2 * MiB, PROT_READ | PROT_WRITE);
    /* content must SURVIVE (not the phase's zero rule) */
    for (size_t o = 0; o < 2 * MiB; o += PAGE) {
        if (p[o] != (char)0xE7) {
            printf("DIRTYHIT phase=prot-lost va=%p off=%zu val=%02x cyc=%lu\n",
                   (void *)(p + o), o, (unsigned char)p[o], cycle);
            dump_ctx(p + o);
            fflush(stdout);
            dirty_hits++;
            break;
        }
    }
    munmap(p, 2 * MiB);
}

int main(void)
{
    setvbuf(stdout, NULL, _IOLBF, 0);
    seed ^= (unsigned long)getpid() * 6364136223846793005UL;

    guard = mmap(NULL, GUARD_SIZE, PROT_READ | PROT_WRITE,
                 MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (guard == MAP_FAILED) {
        printf("DIRTYSCAN-FATAL guard mmap errno=%d\n", errno);
        for (;;) pause();
    }
    guard_pages = GUARD_SIZE / PAGE;
    guard_fill();

    printf("DIRTYSCAN-START guard=%lu pages pid=%d\n", guard_pages, getpid());

    static const char *phases[] =
        {"fresh", "fixed", "dontneed", "remap", "churn", "cow", "prot"};
    unsigned long beat = 0, scanned = 0;

    for (cycle = 1;; cycle++) {
        /* 2-3 random phases per cycle */
        int n = 2 + (rnd() % 2);
        const char *last = "none";
        for (int i = 0; i < n; i++) {
            int k = rnd() % 7;
            last = phases[k];
            switch (k) {
            case 0: ph_fresh(); break;
            case 1: ph_fixed(); break;
            case 2: ph_dontneed(); break;
            case 3: ph_remap(); break;
            case 4: ph_churn(); break;
            case 5: ph_cow(); break;
            case 6: ph_prot(); break;
            }
        }

        /* guard: verify a random 1/8th every cycle, full pass every 8th */
        unsigned long a, b;
        if (cycle % 8 == 0) { a = 0; b = guard_pages; }
        else {
            a = (rnd() % guard_pages) & ~7UL;
            b = a + guard_pages / 8;
            if (b > guard_pages) b = guard_pages;
        }
        guard_hits += guard_verify(a, b);
        scanned += b - a;

        if (cycle % 16 == 0) {
            printf("DIRTYSCAN-BEAT %lu %s cyc=%lu scanned=%lu dirty=%lu "
                   "guardbad=%lu forks=%lu\n",
                   ++beat, last, cycle, scanned, dirty_hits, guard_hits,
                   churn_forks);
        }
    }
}
