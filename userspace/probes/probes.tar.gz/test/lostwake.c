/*
 * lostwake.c — seconds-scale lost-wake reproducer (wake-fastrepro lane).
 *
 * Forensic shape (OH boots): parked INTERRUPTIBLE threads (binder reads /
 * epoll_wait) got wake_up_process()==TRUE but were later found unlinked
 * from the runqueue without ever running; a re-wake worked instantly.
 * Victims accumulated under: service spawn/kill cycles (init SIGKILLs),
 * futex/epoll park-wake churn, timer wakeups, binder IPC.
 *
 * This probe rebuilds that interleaving surface on the minimal rootfs,
 * with userspace self-reporting:
 *
 *   surface A  futex ping-pong     — 8 parkers, waker bursts every 150 ms
 *   surface B  epoll_wait park     — 6 parkers on private pipes, waker
 *                                     writes; 10 s timeout catches the
 *                                     never-revived case
 *   surface C  nanosleep(50 ms)    — timer-wakeup latency (stamp = the
 *                                     expected expiry, set pre-sleep)
 *   surface D  kill-cycle          — 3 service children, each with futex
 *                                     + epoll parker threads and its own
 *                                     burst waker; the reaper SIGKILLs
 *                                     one every ~150 ms and respawns
 *                                     (init's service churn). Kill→waitpid
 *                                     latency is reported (KILLSLOW) —
 *                                     SIGKILL must wake parked threads
 *                                     immediately.
 *   surface E  fork+exit storm     — ~150 short-lived children/s; child
 *                                     measures fork→first-instruction gap
 *   surface F  setitimer           — 10 ms ITIMER_REAL periodic; a
 *                                     sampler flags >1 s delivery gaps
 *
 * Handshake per slot (shared mmap, inherited by children):
 *   state: 0=IDLE 1=PARKED 2=WAKE_ISSUED
 *   waker (or the parker, for self-armed surfaces) stamps wake_at right
 *   before issuing the wake, state->WAKE_ISSUED. The parker on resume
 *   measures now-wake_at; >1 s prints "LW: LOSTWAKE". The waker RE-wakes
 *   WAKE_ISSUED slots every burst (re-wake works per forensics) WITHOUT
 *   restamping, so the eventual revival reports the full strand window.
 *   A slot stuck in WAKE_ISSUED >5 s prints LW: LOSTWAKE-STUCK (main
 *   process surfaces only — service slots are exempt because SIGKILL
 *   legitimately freezes them; the KILLSLOW line covers that path).
 *
 * usage: lostwake [secs]        (default 30; 0 = run forever)
 * output: "LW:" lines on serial; final "LW: DONE" then parks forever
 * (the boot driver kills QEMU on that marker — PID1 must not exit).
 */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/epoll.h>
#include <sys/mman.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

/* ---- tunables (compile-time overridable) ---- */
#ifndef N_FUTEX
#define N_FUTEX 8
#endif
#ifndef N_EPOLL
#define N_EPOLL 6
#endif
#ifndef N_UNIX
#define N_UNIX 4
#endif
#ifndef N_RR
#define N_RR 3
#endif
#ifndef N_NANO
#define N_NANO 4
#endif
#ifndef N_SVC
#define N_SVC 3
#endif
#ifndef BURST_MS
#define BURST_MS 150
#endif
#ifndef KILL_MS
#define KILL_MS 150
#endif
#ifndef NANO_MS
#define NANO_MS 50
#endif
#ifndef LOST_MS
#define LOST_MS 1000
#endif
#ifndef STUCK_MS
#define STUCK_MS 5000
#endif
#ifndef FORK_DELAY_US
#define FORK_DELAY_US 6500
#endif
#ifndef ITIMER_US
#define ITIMER_US 100000 /* 100 ms: 10x above a 100 Hz tick floor so a
                          * coarse-but-healthy timer cadence cannot fake
                          * a >1 s silence (host WSL2 smoke taught this) */
#endif

#define S_FUTEX 0
#define S_EPOLL 1
#define S_NANO 2
#define S_SVCFUTEX 3
#define S_SVCEPOLL 4
#define S_FORK 5
#define S_ITIMER 6
#define S_KILL 7
#define S_UNIX 8
#define S_SVCUNIX 9
#define S_RR 10
#define NSURF 11
static const char *surf_name[NSURF] = {
    "futex", "epoll", "nano", "svcfutex", "svcepoll", "forkrun", "itimer",
    "kill", "unix", "svcunix", "rrexec",
};

#define MAXSLOTS 48
struct slot {
    volatile int state;         /* 0 idle, 1 parked, 2 wake-issued */
    volatile unsigned long long wake_at; /* ns: intended wake time */
    volatile long tid;
    int surf;
    int stuck_reported;
    unsigned long parks, episodes, resumes;
    unsigned long long max_gap;
};
static struct slot *SL; /* shared mmap table */

#define SL_FUTEX0 0
#define SL_EPOLL0 8
#define SL_NANO0 16
#define SL_ITIMER 20
#define SL_FORK 21
#define SL_UNIX0 22 /* 4 slots: 22..25 */
#define SL_SVC0 32 /* 4 slots per service child (futex, futex, epoll, unix) */

static volatile int stop_flag;

/* surface toggles (argv[2], default all): f=futex p=epoll n=nano
 * s=svc-killcycle k=forkstorm i=itimer */
static int en_futex = 1, en_epoll = 1, en_nano = 1, en_svc = 1,
           en_fork = 1, en_itimer = 1, en_unix = 1, en_rr = 1;

/* waker liveness (ns of the last burst that issued wakes for the
 * surface) — stuck lines carry waker_age_ms so a strand can be told
 * apart from a stranded waker */
static volatile unsigned long long last_burst_futex, last_burst_epoll,
    last_burst_svc;
volatile unsigned long long last_fork_cycle;

static unsigned long long now_ns(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000000000ULL + ts.tv_nsec;
}
static long tid_self(void) { return syscall(SYS_gettid); }

static long futex_wait(volatile int *uaddr, int val)
{
    return syscall(SYS_futex, (long)uaddr, 0 /* FUTEX_WAIT */, val,
                   0L, 0L, 0L);
}
static long futex_wake(volatile int *uaddr, int n)
{
    return syscall(SYS_futex, (long)uaddr, 1 /* FUTEX_WAKE */, n,
                   0L, 0L, 0L);
}

static void report_resume(struct slot *s, const char *why)
{
    unsigned long long t = now_ns();
    /* saturating: a stamp in the future (clock re-read ordering on the
     * self-armed surfaces) is not a negative gap — clamp like the stuck
     * scan does (gap_ms=18446744073709 ghost lines) */
    unsigned long long gap = t > s->wake_at ? t - s->wake_at : 0;
    s->state = 0;
    s->stuck_reported = 0;
    s->resumes++;
    if (gap > s->max_gap)
        s->max_gap = gap;
    if (gap > LOST_MS * 1000000ULL) {
        s->episodes++;
        printf("LW: LOSTWAKE tid=%ld surf=%s gap_ms=%llu why=%s\n",
               s->tid, surf_name[s->surf], gap / 1000000ULL, why);
        fflush(stdout);
    }
}

static void park_arm(struct slot *s)
{
    s->tid = tid_self();
    s->state = 1;
    s->parks++;
}

/* arm a self-timed surface: stamp the intended wake time, then park */
static void park_arm_stamped(struct slot *s, unsigned long long wake_at)
{
    park_arm(s);
    s->wake_at = wake_at;
    s->state = 2;
}

/* ---- surface A: futex ping-pong parkers ---- */
static volatile int futx_word[N_FUTEX];
struct futex_arg { struct slot *s; int idx; };
static void *futex_parker(void *ap)
{
    struct futex_arg *a = ap;
    for (;;) {
        if (stop_flag)
            break;
        park_arm(a->s);
        int val = futx_word[a->idx];
        long r = futex_wait(&futx_word[a->idx], val);
        if (r < 0 && (errno == EAGAIN || errno == EINTR)) {
            if (a->s->state == 2)
                report_resume(a->s, errno == EAGAIN ? "eagain" : "eintr");
            continue;
        }
        if (a->s->state == 2)
            report_resume(a->s, "wake");
        else
            a->s->state = 0; /* spurious */
    }
    return NULL;
}

/* ---- surface B: epoll parkers on private pipes ---- */
struct epoll_arg { struct slot *s; int epfd; int rfd; int wfd; };
static struct epoll_arg epar[N_EPOLL];

static void drain_nb(int fd)
{
    char buf[64];
    while (read(fd, buf, sizeof buf) > 0)
        ;
}

static void *epoll_parker(void *ap)
{
    struct epoll_arg *a = ap;
    struct epoll_event evs[4];
    for (;;) {
        if (stop_flag)
            break;
        park_arm(a->s);
        int n = epoll_wait(a->epfd, evs, 4, 10000);
        if (n < 0 && errno == EINTR) {
            if (a->s->state == 2)
                report_resume(a->s, "eintr");
            continue;
        }
        if (a->s->state == 2)
            report_resume(a->s, n > 0 ? "ready" : "timeout");
        else
            a->s->state = 0;
        if (n > 0)
            drain_nb(a->rfd);
    }
    return NULL;
}

/* ---- surface C: nanosleep parkers ---- */
static void *nano_parker(void *ap)
{
    struct slot *s = ap;
    for (;;) {
        if (stop_flag)
            break;
        park_arm_stamped(s, now_ns() + NANO_MS * 1000000LL);
        struct timespec r = { 0, NANO_MS * 1000000L }, rem;
        for (;;) {
            if (nanosleep(&r, &rem) == 0)
                break;
            if (errno == EINTR) {
                r = rem;
                continue;
            }
            break;
        }
        report_resume(s, "expiry");
    }
    return NULL;
}

/* ---- surface G: unix-socket recv parkers (wake-fastrepro s2) ----
 * Mirrors the OH forensic shape directly: readers parked in IPC reads
 * (blocking recv on AF_UNIX stream pairs — the peer.lock / send-path
 * spinlock sites the referee's outermost-acquire list names), woken by
 * sends in bursts, plus kill-cycle variants inside service children.
 */
struct unix_arg { struct slot *s; int rfd; int wfd; };
static struct unix_arg uarg[N_UNIX];

static void *unix_parker(void *ap)
{
    struct unix_arg *a = ap;
    char buf[16];
    for (;;) {
        if (stop_flag)
            break;
        park_arm(a->s);
        ssize_t n = recv(a->rfd, buf, sizeof buf, 0);
        if (n < 0 && errno == EINTR) {
            if (a->s->state == 2)
                report_resume(a->s, "eintr");
            continue;
        }
        if (a->s->state == 2)
            report_resume(a->s, n > 0 ? "data" : "eof");
        else
            a->s->state = 0;
    }
    return NULL;
}

/* socketpair create/close churn: exercises unix socket alloc/teardown
 * (peer table, name registry) under the same load */
static void *unix_churn(void *unused)
{
    (void)unused;
    for (;;) {
        if (stop_flag)
            break;
        int sp[2];
        if (socketpair(AF_UNIX, SOCK_STREAM, 0, sp) == 0) {
            char c = 'z';
            write(sp[0], &c, 1);
            read(sp[1], &c, 1);
            close(sp[0]);
            close(sp[1]);
        }
        usleep(2000);
    }
    return NULL;
}

/* ---- surface H: ressched-mimic (wake-fastrepro leak hunt) ----
 * OH's resource_schedule_executor (pid 327 on the control boots) leaks
 * a base PREEMPT_OFFSET while alternating recvfrom/recvmsg on sockets
 * whose peers are services being SIGKILLed. Reproduce that exact shape:
 * reader threads alternate recvfrom/recvmsg on SOCK_DGRAM pairs; the
 * DATAGRAM SENDER lives in a short-lived forked child that sends a few
 * packets, parks, and is SIGKILLed by the reader's re-fork cycle. If
 * the pc=1 face lands here, the collision-free WAKE-HEAL-ORIGIN print
 * names the guard's file:line directly. */
struct rr_arg { struct slot *s; int rfd; volatile int peer_pid; };
static struct rr_arg rarg[N_RR];
static ssize_t recvmsg_stub(int fd, void *buf, size_t len);

static void *rr_reader(void *ap)
{
    struct rr_arg *a = ap;
    char buf[64];
    struct sockaddr_un sa;
    socklen_t salen;
    for (;;) {
        if (stop_flag)
            break;
        /* (re)spawn a sender child if the previous one is gone */
        if (a->peer_pid <= 0 || kill(a->peer_pid, 0) < 0) {
            int sp[2];
            if (socketpair(AF_UNIX, SOCK_DGRAM, 0, sp) < 0) {
                usleep(50000);
                continue;
            }
            a->rfd = sp[0];
            pid_t pid = fork();
            if (pid == 0) {
                close(sp[0]);
                signal(SIGALRM, SIG_DFL);
                alarm(20); /* orphan time-bomb (host smoke safety) */
                for (int i = 0; i < 4; i++) {
                    char c = 'r';
                    /* stamp the SHARED slot right before the packet:
                     * the reader measures its resume against this */
                    a->s->wake_at = now_ns();
                    a->s->state = 2;
                    __sync_synchronize();
                    send(sp[1], &c, 1, 0);
                    usleep(30000);
                }
                pause(); /* killed by parent below */
                _exit(0);
            }
            close(sp[1]);
            a->peer_pid = pid;
        }
        park_arm(a->s);
        /* alternate the two syscalls OH's pid-327 loop shows */
        ssize_t n;
        if (a->s->parks & 1)
            n = recvfrom(a->rfd, buf, sizeof buf, 0,
                         (struct sockaddr *)&sa, &salen);
        else
            n = recvmsg_stub(a->rfd, buf, sizeof buf);
        if (n < 0 && errno == EINTR) {
            if (a->s->state == 2)
                report_resume(a->s, "eintr");
            continue;
        }
        if (a->s->state == 2)
            report_resume(a->s, n > 0 ? "data" : "eof");
        else
            a->s->state = 0;
        if (n <= 0) {
            /* EOF/error: the peer died — reap it and respawn next round */
            if (a->peer_pid > 0) {
                kill(a->peer_pid, SIGKILL);
                waitpid(a->peer_pid, NULL, 0);
                a->peer_pid = -1;
            }
            close(a->rfd);
            a->rfd = -1;
            usleep(2000);
        } else {
            /* keep the kill-cycle pressure: retire the sender after a
             * few exchanges so the reader re-forks against churn */
            if ((a->s->parks & 7) == 7 && a->peer_pid > 0) {
                kill(a->peer_pid, SIGKILL);
                waitpid(a->peer_pid, NULL, 0);
                a->peer_pid = -1;
                close(a->rfd);
                a->rfd = -1;
            }
        }
    }
    return NULL;
}

static ssize_t recvmsg_stub(int fd, void *buf, size_t len)
{
    struct iovec iov = { .iov_base = buf, .iov_len = len };
    struct msghdr msg;
    memset(&msg, 0, sizeof msg);
    msg.msg_iov = &iov;
    msg.msg_iovlen = 1;
    return recvmsg(fd, &msg, 0);
}

/* ---- main-process waker: bursts every BURST_MS ---- */
static struct slot *futx_slots[N_FUTEX];
static volatile unsigned long long last_burst_unix;

static void *waker_thread(void *unused)
{
    (void)unused;
    int scan = 0;
    for (;;) {
        if (stop_flag)
            break;
        usleep(BURST_MS * 1000);
        if (en_futex)
            last_burst_futex = now_ns();
        for (int i = 0; i < N_FUTEX; i++) {
            struct slot *s = futx_slots[i];
            if (s->state == 1) {
                s->wake_at = now_ns();
                __sync_synchronize();
                s->state = 2;
            }
            futx_word[i]++; /* generation bump (lost-wake revival aid) */
            futex_wake(&futx_word[i], 1);
        }
        if (en_epoll)
            last_burst_epoll = now_ns();
        for (int i = 0; i < N_EPOLL; i++) {
            struct slot *s = epar[i].s;
            if (s->state == 1) {
                s->wake_at = now_ns();
                __sync_synchronize();
                s->state = 2;
            }
            char c = 'x';
            write(epar[i].wfd, &c, 1);
        }
        if (en_unix) {
            last_burst_unix = now_ns();
            for (int i = 0; i < N_UNIX; i++) {
                struct slot *s = uarg[i].s;
                if (s->state == 1) {
                    s->wake_at = now_ns();
                    __sync_synchronize();
                    s->state = 2;
                }
                char c = 'u';
                send(uarg[i].wfd, &c, 1, 0);
            }
        }
        /* stuck scan every ~4 bursts, main-process surfaces only */
        if (++scan % 4 == 0) {
            unsigned long long t = now_ns();
            for (int i = 0; i < 29; i++) {
                struct slot *s = &SL[i];
                /* wake_at < t: self-armed surfaces stamp a FUTURE expiry
                 * (nanosleep); those are not stuck until the expiry has
                 * actually passed by the threshold */
                if (s->state == 2 && !s->stuck_reported &&
                    s->wake_at < t &&
                    t - s->wake_at > STUCK_MS * 1000000ULL) {
                    s->stuck_reported = 1;
                    unsigned long long wb =
                        (s->surf == S_FUTEX) ? last_burst_futex :
                        (s->surf == S_EPOLL) ? last_burst_epoll :
                        (s->surf == S_UNIX) ? last_burst_unix :
                        (s->surf == S_FORK) ? last_fork_cycle : t;
                    printf("LW: LOSTWAKE-STUCK tid=%ld surf=%s stuck_ms=%llu waker_age_ms=%llu%s\n",
                           s->tid, surf_name[s->surf],
                           (t - s->wake_at) / 1000000ULL,
                           (t - wb) / 1000000ULL,
                           (t - wb) < 1000000000ULL ? " WAKER-LIVE" : "");
                    fflush(stdout);
                }
            }
        }
    }
    return NULL;
}

/* ---- surface F: itimer + sampler ---- */
static volatile unsigned long sigalrm_count;
static void sigalrm_handler(int sig)
{
    (void)sig;
    sigalrm_count++;
}
static void *itimer_thread(void *unused)
{
    (void)unused;
    struct itimerval it = {
        .it_interval = { 0, ITIMER_US * 1000 },
        .it_value = { 0, ITIMER_US * 1000 },
    };
    setitimer(ITIMER_REAL, &it, NULL);
    while (!stop_flag)
        usleep(20000);
    struct itimerval z = { { 0, 0 }, { 0, 0 } };
    setitimer(ITIMER_REAL, &z, NULL);
    return NULL;
}
static void *itimer_sampler(void *ap)
{
    struct slot *s = ap;
    s->tid = tid_self();
    unsigned long last = sigalrm_count;
    unsigned long long last_move = now_ns();
    for (;;) {
        if (stop_flag)
            break;
        usleep(20000);
        unsigned long cur = sigalrm_count;
        if (cur != last) {
            last = cur;
            last_move = now_ns();
            s->resumes++;
        } else {
            unsigned long long gap = now_ns() - last_move;
            if (gap > s->max_gap)
                s->max_gap = gap;
            if (gap > LOST_MS * 1000000ULL) {
                s->episodes++;
                s->stuck_reported = 1; /* one report per stall */
                printf("LW: LOSTWAKE tid=%ld surf=itimer gap_ms=%llu why=silent\n",
                       s->tid, gap / 1000000ULL);
                fflush(stdout);
                last_move = now_ns();
            }
        }
    }
    return NULL;
}

/* ---- surface E: fork+exit storm ---- */
static void *fork_storm(void *ap)
{
    struct slot *s = ap;
    for (;;) {
        if (stop_flag)
            break;
        last_fork_cycle = now_ns();
        s->wake_at = now_ns(); /* intended child start time */
        s->parks++;
        s->state = 2;
        pid_t pid = fork();
        if (pid == 0) {
            unsigned long long gap = now_ns() - s->wake_at;
            if (gap > LOST_MS * 1000000ULL)
                printf("LW: LOSTWAKE tid=%ld surf=forkrun gap_ms=%llu why=startrun\n",
                       tid_self(), gap / 1000000ULL);
            _exit(0);
        }
        int status;
        waitpid(pid, &status, 0);
        s->state = 0;
        s->resumes++;
        usleep(FORK_DELAY_US);
    }
    return NULL;
}

/* ---- surface D: service children + reaper ---- */
/* child-local state (post-fork COW copies) */
static volatile int svc_futex_word;
static int svc_self_idx = -1;          /* which service slot group is mine */
static int svc_ep_wr = -1;             /* my epoll parker's pipe write end */
static int svc_un_wr = -1;             /* my unix parker's socketpair peer */

struct svc_park_arg { struct slot *s; int kind; int epfd; int rfd; };
/* kind: 0/1 = futex, 2 = epoll, 3 = unix recv */
#define SVC_KIND_FUTEX0 0
#define SVC_KIND_FUTEX1 1
#define SVC_KIND_EPOLL 2
#define SVC_KIND_UNIX 3

static void *svc_parker(void *ap)
{
    struct svc_park_arg *a = ap;
    struct epoll_event evs[4];
    char buf[16];
    for (;;) {
        park_arm(a->s);
        if (a->kind == SVC_KIND_EPOLL) {
            int n = epoll_wait(a->epfd, evs, 4, 10000);
            if (n < 0 && errno == EINTR) {
                if (a->s->state == 2)
                    report_resume(a->s, "eintr");
                continue;
            }
            if (a->s->state == 2)
                report_resume(a->s, n > 0 ? "ready" : "timeout");
            else
                a->s->state = 0;
            if (n > 0)
                drain_nb(a->rfd);
        } else if (a->kind == SVC_KIND_UNIX) {
            ssize_t n = recv(a->rfd, buf, sizeof buf, 0);
            if (n < 0 && errno == EINTR) {
                if (a->s->state == 2)
                    report_resume(a->s, "eintr");
                continue;
            }
            if (a->s->state == 2)
                report_resume(a->s, n > 0 ? "data" : "eof");
            else
                a->s->state = 0;
        } else {
            int val = svc_futex_word;
            long r = futex_wait(&svc_futex_word, val);
            if (r < 0 && (errno == EAGAIN || errno == EINTR)) {
                if (a->s->state == 2)
                    report_resume(a->s, errno == EAGAIN ? "eagain" : "eintr");
                continue;
            }
            if (a->s->state == 2)
                report_resume(a->s, "wake");
            else
                a->s->state = 0;
        }
    }
    return NULL;
}

static void *svc_waker(void *unused)
{
    (void)unused;
    for (;;) {
        usleep(BURST_MS * 1000);
        for (int k = 0; k < 4; k++) {
            struct slot *s = &SL[SL_SVC0 + svc_self_idx * 4 + k];
            if (s->state == 1) {
                s->wake_at = now_ns();
                __sync_synchronize();
                s->state = 2;
            }
        }
        svc_futex_word++;
        futex_wake(&svc_futex_word, 3);
        if (svc_ep_wr >= 0) {
            char c = 'y';
            write(svc_ep_wr, &c, 1);
        }
        if (svc_un_wr >= 0) {
            char c = 'v';
            send(svc_un_wr, &c, 1, 0);
        }
    }
    return NULL;
}

static void svc_child_main(int idx)
{
    svc_self_idx = idx;
    /* orphan time-bomb: if the reaper dies, self-terminate instead of
     * parking forever (protects host smoke runs and wedged guests) */
    signal(SIGALRM, SIG_DFL);
    alarm(30);
    pthread_t th[4], w;
    struct svc_park_arg args[4];
    for (int i = 0; i < 4; i++) {
        struct slot *s = &SL[SL_SVC0 + idx * 4 + i];
        args[i].s = s;
        args[i].kind = i;
        if (i == SVC_KIND_EPOLL) {
            int p[2];
            if (pipe(p) < 0)
                _exit(1);
            fcntl(p[0], F_SETFL, O_NONBLOCK);
            int ep = epoll_create1(0);
            struct epoll_event ev = { .events = EPOLLIN, .data.fd = p[0] };
            epoll_ctl(ep, EPOLL_CTL_ADD, p[0], &ev);
            args[i].epfd = ep;
            args[i].rfd = p[0];
            svc_ep_wr = p[1];
        } else if (i == SVC_KIND_UNIX) {
            int sp[2];
            if (socketpair(AF_UNIX, SOCK_STREAM, 0, sp) < 0)
                _exit(1);
            args[i].rfd = sp[0];
            svc_un_wr = sp[1];
        }
        pthread_create(&th[i], NULL, svc_parker, &args[i]);
    }
    pthread_create(&w, NULL, svc_waker, NULL);
    for (int i = 0; i < 4; i++)
        pthread_join(th[i], NULL); /* SIGKILL ends this child */
    _exit(0);
}

static void *reaper_thread(void *unused)
{
    (void)unused;
    pid_t svcs[N_SVC];
    int rot = 0;
    for (int i = 0; i < N_SVC; i++)
        svcs[i] = -1;
    for (;;) {
        if (stop_flag)
            break;
        usleep(KILL_MS * 1000);
        /* spawn missing services */
        for (int i = 0; i < N_SVC; i++) {
            if (svcs[i] < 0) {
                for (int k = 0; k < 4; k++) {
                    struct slot *s = &SL[SL_SVC0 + i * 4 + k];
                    memset((void *)s, 0, sizeof *s);
                    s->surf = k == SVC_KIND_EPOLL ? S_SVCEPOLL :
                              k == SVC_KIND_UNIX ? S_SVCUNIX : S_SVCFUTEX;
                }
                pid_t pid = fork();
                if (pid == 0)
                    svc_child_main(i);
                svcs[i] = pid;
            }
        }
        /* kill+reap one (round-robin) */
        int v = rot++ % N_SVC;
        if (svcs[v] > 0) {
            unsigned long long tk = now_ns();
            kill(svcs[v], SIGKILL);
            int status;
            while (waitpid(svcs[v], &status, 0) < 0 && errno == EINTR)
                ;
            unsigned long long gap = now_ns() - tk;
            if (gap > LOST_MS * 1000000ULL) {
                printf("LW: LOSTWAKE tid=%d surf=kill gap_ms=%llu why=sigkill-reap\n",
                       svcs[v], gap / 1000000ULL);
                fflush(stdout);
            }
            svcs[v] = -1;
        }
    }
    for (int i = 0; i < N_SVC; i++)
        if (svcs[i] > 0) {
            kill(svcs[i], SIGKILL);
            waitpid(svcs[i], NULL, 0);
        }
    return NULL;
}

/* ---- heartbeat / report ---- */
static unsigned long surf_lost[NSURF];

static void report_totals(const char *tag)
{
    unsigned long long tot_parks = 0, tot_resumes = 0, max_gap = 0;
    int max_surf = 0;
    memset(surf_lost, 0, sizeof surf_lost);
    for (int i = 0; i < MAXSLOTS; i++) {
        struct slot *s = &SL[i];
        tot_parks += s->parks;
        tot_resumes += s->resumes;
        surf_lost[s->surf] += s->episodes;
        if (s->max_gap > max_gap) {
            max_gap = s->max_gap;
            max_surf = s->surf;
        }
    }
    printf("LW: HB %s parks=%llu resumes=%llu max_gap_ms=%llu(%s)\n",
           tag, tot_parks, tot_resumes, max_gap / 1000000ULL,
           surf_name[max_surf]);
    fflush(stdout);
}

/* read lw.* config tokens from /proc/cmdline (init gets no argv) */
static void read_cmdline_cfg(int *secs, char *surfs, size_t surfsz)
{
    int fd = open("/proc/cmdline", O_RDONLY);
    if (fd < 0)
        return;
    char buf[1024];
    ssize_t n = read(fd, buf, sizeof buf - 1);
    close(fd);
    if (n <= 0)
        return;
    buf[n] = 0;
    char *p = strstr(buf, "lw.secs=");
    if (p)
        *secs = atoi(p + 8);
    p = strstr(buf, "lw.surfs=");
    if (p) {
        char *d = surfs;
        for (p += 9; *p && *p != ' ' && d < surfs + surfsz - 1; p++)
            *d++ = *p;
        *d = 0;
    }
}

int main(int argc, char **argv)
{
    int secs = argc > 1 ? atoi(argv[1]) : 30;
    char surfs[16] = "";
    if (argc <= 1)
        read_cmdline_cfg(&secs, surfs, sizeof surfs);
    const char *spec = argc > 2 ? argv[2] : surfs;
    if (spec[0] == '-')
        spec = ""; /* stray option, run all surfaces */
    if (spec && spec[0]) {
        /* surface subset spec: letters f p n s k i */
        en_futex = en_epoll = en_nano = en_svc = en_fork = en_itimer = 0;
        for (const char *c = spec; *c; c++) {
            switch (*c) {
            case 'f': en_futex = 1; break;
            case 'p': en_epoll = 1; break;
            case 'n': en_nano = 1; break;
            case 's': en_svc = 1; break;
            case 'k': en_fork = 1; break;
            case 'i': en_itimer = 1; break;
            case 'u': en_unix = 1; break;
            case 'r': en_rr = 1; break;
            default: break;
            }
        }
    }
    setvbuf(stdout, NULL, _IONBF, 0);

    SL = mmap(NULL, sizeof(struct slot) * MAXSLOTS,
              PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (SL == MAP_FAILED) {
        printf("LW: mmap shared table failed\n");
        return 1;
    }
    memset(SL, 0, sizeof(struct slot) * MAXSLOTS);

    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = sigalrm_handler;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = 0; /* NO SA_RESTART: parkers see real EINTR churn */
    sigaction(SIGALRM, &sa, NULL);
    signal(SIGPIPE, SIG_IGN);

    printf("LW: BOOT pid=%d tid=%ld surfaces=%s%s%s%s%s%s%s%s\n",
           getpid(), tid_self(),
           en_futex ? "f" : "", en_epoll ? "p" : "", en_nano ? "n" : "",
           en_svc ? "s" : "", en_fork ? "k" : "", en_itimer ? "i" : "",
           en_unix ? "u" : "", en_rr ? "r" : "");

    pthread_t th_futex[N_FUTEX], th_epoll[N_EPOLL], th_nano[N_NANO];
    struct futex_arg fargs[N_FUTEX];

    for (int i = 0; i < N_FUTEX; i++) {
        futx_slots[i] = &SL[SL_FUTEX0 + i];
        SL[SL_FUTEX0 + i].surf = S_FUTEX;
        fargs[i].s = &SL[SL_FUTEX0 + i];
        fargs[i].idx = i;
        if (en_futex)
            pthread_create(&th_futex[i], NULL, futex_parker, &fargs[i]);
    }
    for (int i = 0; i < N_EPOLL; i++) {
        if (!en_epoll)
            break;
        int p[2];
        if (pipe(p) < 0) {
            printf("LW: pipe failed\n");
            return 1;
        }
        fcntl(p[0], F_SETFL, O_NONBLOCK);
        int ep = epoll_create1(0);
        struct epoll_event ev = { .events = EPOLLIN, .data.fd = p[0] };
        epoll_ctl(ep, EPOLL_CTL_ADD, p[0], &ev);
        epar[i].s = &SL[SL_EPOLL0 + i];
        epar[i].epfd = ep;
        epar[i].rfd = p[0];
        epar[i].wfd = p[1];
        SL[SL_EPOLL0 + i].surf = S_EPOLL;
        pthread_create(&th_epoll[i], NULL, epoll_parker, &epar[i]);
    }
    for (int i = 0; i < N_NANO; i++) {
        SL[SL_NANO0 + i].surf = S_NANO;
        if (en_nano)
            pthread_create(&th_nano[i], NULL, nano_parker, &SL[SL_NANO0 + i]);
    }
    /* unix recv parkers (surface G) */
    pthread_t th_unix[N_UNIX], th_uchurn;
    for (int i = 0; i < N_UNIX; i++) {
        int sp[2];
        if (socketpair(AF_UNIX, SOCK_STREAM, 0, sp) < 0) {
            printf("LW: socketpair failed\n");
            return 1;
        }
        uarg[i].s = &SL[SL_UNIX0 + i];
        uarg[i].rfd = sp[0];
        uarg[i].wfd = sp[1];
        SL[SL_UNIX0 + i].surf = S_UNIX;
        if (en_unix)
            pthread_create(&th_unix[i], NULL, unix_parker, &uarg[i]);
    }
    if (en_unix)
        pthread_create(&th_uchurn, NULL, unix_churn, NULL);
    /* ressched-mimic readers (surface H) */
    pthread_t th_rr[N_RR];
    for (int i = 0; i < N_RR; i++) {
        rarg[i].s = &SL[26 + i];
        rarg[i].rfd = -1;
        rarg[i].peer_pid = -1;
        SL[26 + i].surf = S_RR;
        if (en_rr)
            pthread_create(&th_rr[i], NULL, rr_reader, &rarg[i]);
    }

    pthread_t th_it, th_its, th_fork, th_waker, th_reaper;
    if (en_itimer) {
        SL[SL_ITIMER].surf = S_ITIMER;
        pthread_create(&th_it, NULL, itimer_thread, NULL);
        pthread_create(&th_its, NULL, itimer_sampler, &SL[SL_ITIMER]);
    }
    SL[SL_FORK].surf = S_FORK;
    if (en_fork)
        pthread_create(&th_fork, NULL, fork_storm, &SL[SL_FORK]);
    pthread_create(&th_waker, NULL, waker_thread, NULL);
    if (en_svc)
        pthread_create(&th_reaper, NULL, reaper_thread, NULL);

    unsigned long long t0 = now_ns();
    int last_hb = 0;
    for (;;) {
        usleep(100000);
        int el = (int)((now_ns() - t0) / 1000000000ULL);
        if (el >= last_hb + 5) {
            last_hb = el;
            report_totals("tick");
        }
        if (secs > 0 && el >= secs)
            break;
    }
    stop_flag = 1;
    sleep(1); /* let threads finish their last cycle */
    report_totals("final");
    printf("LW: RESULT");
    for (int i = 0; i < NSURF; i++)
        printf(" %s=%lu", surf_name[i], surf_lost[i]);
    printf("\n");
    printf("LW: DONE\n");
    fflush(stdout);
    for (;;)
        pause(); /* PID1 must not exit; driver kills QEMU here */
    return 0;
}
