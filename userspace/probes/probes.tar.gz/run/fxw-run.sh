#!/bin/bash
# fxw-run.sh — boot the lane kernel on the LTP iso image and run one fxw
# probe (tmpfs MAP_SHARED coherence). Mounts tmpfs on /dev/shm first
# (init=/bin/sh boots no mounts).
# Usage: run/fxw-run.sh <bzImage> <tag> <probe> [extra guest cmd]
set -u
cd /home/william/rux-agents/ltp-fsx
K="${1:?kernel}"; TAG="${2:?tag}"; PROBE="${3:?probe}"
IMG=run/r4ltp-iso.img
LOG=run/fxw-$TAG.log
FIFO=run/fxw-$TAG.fifo
CMD="mkdir -p /dev/shm; mount -t tmpfs none /dev/shm; /$PROBE; echo FXW-RC=\$?"
rm -f "$FIFO" "$LOG"; mkfifo "$FIFO"
exec 3<>"$FIFO"
(
  sleep 40
  printf '\n' >&3; sleep 2
  printf '%s\n' "$CMD" >&3
) &
FEEDER=$!
timeout --kill-after=10 160 qemu-system-x86_64 -M q35 -accel kvm -cpu max -m 2G -smp 2 \
  -display none -serial stdio -monitor none -no-reboot -snapshot \
  -drive file="${IMG}",if=none,id=rootfs,format=raw,file.locking=off \
  -device virtio-blk-pci,drive=rootfs \
  -kernel "$K" \
  -append "root=/dev/vda rw init=/bin/sh console=ttyS0" \
  < "$FIFO" > "$LOG" 2>&1
RC=$?
kill $FEEDER 2>/dev/null; exec 3>&-; rm -f "$FIFO"
echo "== $TAG (qemu rc=$RC) =="
tr -d '\0' < "$LOG" | tail -25
