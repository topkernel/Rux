/* mremap storm: glibc realloc on mmap-class chunks drives mremap; a
 * move that corrupts neighbors (stale PTEs, wrong copy length,
 * overlapping placement) zeroes/garbages OTHER live chunks — the
 * gnome-shell heap-metadata class. N big chunks, each with a canary
 * header+crc body; realloc-grow/shrink storm on half of them while
 * verifying the other half every round. */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>

#define NCH 32
static unsigned char *ch[NCH];
static size_t csz[NCH];
static int fails;

static uint32_t h32(uint32_t x){ x^=x>>16; x*=0x7feb352d; x^=x>>15; x*=0x846ca68b; x^=x>>16; return x; }

static void fill(int i)
{
    size_t sz = csz[i];
    *(uint64_t *)ch[i] = 0xC0FFEE1234567890ULL ^ i;
    uint32_t crc = 0;
    for (size_t k = 8; k < sz; k += 4) {
        uint32_t v = h32((uint32_t)(i * 7919 + k));
        *(uint32_t *)(ch[i] + k) = v;
        crc = h32(crc ^ v);
    }
    *(uint32_t *)(ch[i] + sz - 4) = crc;
}

static int check(int i, const char *phase)
{
    size_t sz = csz[i];
    if (*(uint64_t *)ch[i] != (0xC0FFEE1234567890ULL ^ (unsigned)i)) {
        printf("HDR-BAD %s ch=%d\n", phase, i); return 1;
    }
    uint32_t crc = 0;
    for (size_t k = 8; k < sz - 4; k += 4) {
        uint32_t v = *(uint32_t *)(ch[i] + k);
        if (v != h32((uint32_t)(i * 7919 + k))) {
            printf("BODY-BAD %s ch=%d off=%zu\n", phase, i, k); return 1;
        }
        crc = h32(crc ^ v);
    }
    if (*(uint32_t *)(ch[i] + sz - 4) != crc) {
        uint32_t got = *(uint32_t *)(ch[i] + sz - 4);
        printf("CRC-BAD %s ch=%d at=%p got=%08x want=%08x\n",
               phase, i, ch[i] + sz - 4, got, crc);
        /* who wrote it: scan every chunk's expected crc */
        for (int j = 0; j < NCH; j++) {
            uint32_t cj = 0;
            for (size_t k = 8; k < csz[j]; k += 4)
                cj = h32(cj ^ h32((uint32_t)(j * 7919 + k)));
            if (cj == got)
                printf("  MATCHES crc of chunk %d (range %p-%p)\n",
                       j, ch[j], ch[j] + csz[j]);
        }
        return 1;
    }
    return 0;
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    /* >MMAP_THRESHOLD so glibc backs these with mmap + mremap on realloc */
    for (int i = 0; i < NCH; i++) {
        csz[i] = (2UL << 20) + i * 0x31000;
        ch[i] = malloc(csz[i]);
        if (!ch[i]) { printf("OOM %d\n", i); return 2; }
        fill(i);
    }
    printf("MREMAP: %d chunks staged\n", NCH);

    pthread_t th[2];
    extern void *pressure(void *);
    /* realloc storm on even chunks; odd chunks verified every 3 rounds */
    for (int r = 0; r < 8; r++) {
        for (int i = 0; i < NCH; i += 2) {
            size_t nsz = csz[i] + (r % 2 ? 0x210000 : -0x180000);
            unsigned char *n = realloc(ch[i], nsz);
            if (n) { ch[i] = n; csz[i] = nsz; fill(i); }
        }
        /* range-disjointness self-check: any two chunks overlapping */
        for (int a = 0; a < NCH && !fails; a++)
            for (int b = a + 1; b < NCH && !fails; b++) {
                uintptr_t s1 = (uintptr_t)ch[a], e1 = s1 + csz[a];
                uintptr_t s2 = (uintptr_t)ch[b], e2 = s2 + csz[b];
                if (s1 < e2 && s2 < e1) {
                    printf("CHUNK-OVERLAP %d(%p-%p) vs %d(%p-%p)\n",
                           a, ch[a], ch[a] + csz[a], b, ch[b], ch[b] + csz[b]);
                    fails++;
                }
            }
        for (int i = 1; i < NCH; i += 2)
            fails += check(i, "storm");
        printf("mremap-round %d fails=%d\n", r, fails);
        if (fails) break;
    }
    printf("MREMAP-DONE fails=%d\n", fails);
    return fails ? 1 : 0;
}
