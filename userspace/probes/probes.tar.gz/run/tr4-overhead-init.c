/*
 * tr4-overhead-init.c — one clean enabled-overhead differential for
 * the round-4 lock: family, on a quiet host: a tight pwrite loop
 * (open once, 64-byte writes at a fixed offset — EXT4-BIGLOCK
 * acquire+release per write, ~2 records/op) with ONLY
 * lock_acquire+lock_release armed, min-of-7, events-off baseline.
 *
 * Build: gcc -static -O2 -o init run/tr4-overhead-init.c
 * Boot:  same image shape as tr4-kvm-proof.sh
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>

static void put(const char *path, const char *text)
{
    int fd = open(path, O_WRONLY);
    if (fd >= 0) {
        write(fd, text, strlen(text));
        close(fd);
    }
}

static long long now_ns(void)
{
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec * 1000000000LL + t.tv_nsec;
}

static long long bench(int n)
{
    char buf[64];
    memset(buf, 'x', sizeof(buf));
    int fd = open("/bench.dat", O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0)
        return -1;
    long long t0 = now_ns();
    for (int i = 0; i < n; i++)
        pwrite(fd, buf, sizeof(buf), 0);
    long long dt = now_ns() - t0;
    close(fd);
    unlink("/bench.dat");
    return dt;
}

static long count_acquire(void)
{
    int fd = open("/sys/kernel/tracing/trace", O_RDONLY);
    static char big[400000];
    ssize_t r = fd >= 0 ? read(fd, big, sizeof(big) - 1) : -1;
    if (fd >= 0)
        close(fd);
    if (r < 0)
        r = 0;
    big[r] = 0;
    long count = 0;
    for (char *p = big; (p = strstr(p, "lock_acquire:")) != NULL; p++)
        count++;
    return count;
}

int main(void)
{
    char msg[256];
    put("/sys/kernel/tracing/tracing_on", "1");
    long long off[7], on[7];
    long recs = 0;
    for (int rep = 0; rep < 7; rep++) {
        put("/sys/kernel/tracing/events/enable", "0");
        off[rep] = bench(1000);
        put("/sys/kernel/tracing/events/lock/lock_acquire/enable", "1");
        put("/sys/kernel/tracing/events/lock/lock_release/enable", "1");
        put("/sys/kernel/tracing/trace", "\n");
        on[rep] = bench(1000);
        put("/sys/kernel/tracing/events/enable", "0");
        recs = count_acquire();
        put("/sys/kernel/tracing/trace", "\n");
    }
    put("/sys/kernel/tracing/tracing_on", "0");
    long long mn(long long *v) { long long m = v[0]; for (int i=1;i<7;i++) if (v[i]<m) m=v[i]; return m; }
    long long o = mn(off), n = mn(on);
    int len = snprintf(msg, sizeof(msg),
                       "OVRDBG: off-min=%lld on-min=%lld delta=%lld ns/op"
                       " records(window)=%ld (~%ld rec/op)\n",
                       o, n, (n - o) / 1000, recs, recs / 1000);
    write(1, msg, len);
    while (1) {
        struct timespec ts = { 60, 0 };
        nanosleep(&ts, NULL);
    }
    return 0;
}
