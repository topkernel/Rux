/* mmap-audit probe: after every kernel-chosen mmap, parse /proc/self/maps
 * and assert global disjointness. Catches double-allocation and placement
 * inside live VMAs (thread stacks, arenas) regardless of who owns them. */
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/mman.h>
#include <unistd.h>
#include <fcntl.h>

#define MAXV 8192
static uintptr_t vs[MAXV], ve[MAXV];
static volatile int nv, bad, checked;

static int snapshot_maps(void)
{
    char buf[131072];
    int fd = open("/proc/self/maps", O_RDONLY);
    if (fd < 0) return -1;
    int n = read(fd, buf, sizeof(buf) - 1);
    close(fd);
    if (n <= 0) return -1;
    buf[n] = 0;
    int c = 0;
    char *p = buf;
    while (c < MAXV) {
        uintptr_t s, e;
        if (sscanf(p, "%lx-%lx", &s, &e) != 2) break;
        vs[c] = s; ve[c] = e; c++;
        p = strchr(p, '\n');
        if (!p) break;
        p++;
    }
    return c;
}

static void audit(const char *phase, uintptr_t news, uintptr_t newe)
{
    int c = snapshot_maps();
    if (c <= 0) return;
    __sync_fetch_and_add(&checked, 1);
    for (int i = 0; i < c; i++)
        for (int j = i + 1; j < c; j++)
            if (vs[i] < ve[j] && vs[j] < ve[i]) {
                int already = __sync_fetch_and_add(&bad, 0);
                if (!already) {
                    printf("MAPS-OVERLAP %s: %lx-%lx vs %lx-%lx (new=%lx-%lx)\n",
                           phase, vs[i], ve[i], vs[j], ve[j], news, newe);
                    for (int k = 0; k < c; k++)
                        if (vs[k] < newe + 0x200000 && ve[k] + 0x200000 > news)
                            printf("  near %lx-%lx\n", vs[k], ve[k]);
                    __sync_fetch_and_add(&bad, 1);
                }
                return;
            }
}

static void *churn(void *arg)
{
    (void)arg;
    char tag[16];
    snprintf(tag, sizeof tag, "t%d", (int)(uintptr_t)arg);
    for (int i = 0; i < 400 && !bad; i++) {
        size_t sz = 0x100000 + (i % 5) * 0x47000;
        void *m = mmap(NULL, sz, PROT_READ | PROT_WRITE,
                       MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (m == MAP_FAILED) continue;
        memset(m, 7, 4096);
        audit(tag, (uintptr_t)m, (uintptr_t)m + sz);
        munmap(m, sz);
    }
    return NULL;
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    audit("init", 0, 0);
    pthread_t th[4];
    for (int i = 0; i < 4; i++)
        pthread_create(&th[i], NULL, churn, (void *)(uintptr_t)i);
    for (int i = 0; i < 4; i++) pthread_join(th[i], NULL);
    audit("final", 0, 0);
    printf("AUDIT-DONE checked=%d bad=%d\n", checked, bad);
    return bad ? 1 : 0;
}
