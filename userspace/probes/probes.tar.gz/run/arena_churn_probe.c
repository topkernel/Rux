/* arena-churn probe: brk/mmap lifecycle under threaded malloc.
 *
 * Reproduces the GNOME-x86 fontconfig FcInit crash class: a valid heap
 * pointer read finds its VMA gone (vma NONE at 0x5555...) while other
 * threads allocate/free/exit. Main thread owns N objects and verifies
 * them before/after every churn phase; any munmap/brk/VMA-surgery bug
 * shows as SEGV or checksum drift. Exit code = failures.
 */
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <unistd.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <unistd.h>
#include <errno.h>

#define NOBJ 4096
#define OBJSZ 512

static unsigned char *objs[NOBJ];
static volatile int stop;
static int fails;

static void verify(const char *phase)
{
    for (int i = 0; i < NOBJ; i++) {
        for (int j = 0; j < OBJSZ; j++) {
            if (objs[i][j] != (unsigned char)(i ^ j)) {
                printf("CORRUPT phase=%s obj=%d off=%d got=%02x want=%02x\n",
                       phase, i, j, objs[i][j], (unsigned char)(i ^ j));
                fails++;
                return;
            }
        }
    }
}

/* malloc/free churn + thread exit: glibc builds thread arenas via mmap
 * and tears them down (munmap) when the thread dies. */
static void *churn(void *arg)
{
    unsigned seed = (unsigned)(uintptr_t)arg;
    for (int i = 0; i < 4000 && !stop; i++) {
        size_t sz = 64 + (seed = seed * 1103515245 + 12345) % 65536;
        unsigned char *p = malloc(sz);
        if (!p) continue;
        memset(p, 0x5a, sz);
        free(p);
    }
    return NULL;
}

/* raw mmap/munmap pressure: VMA tree churn adjacent to the heap. */
static void *mapper(void *arg)
{
    unsigned seed = (unsigned)(uintptr_t)arg * 7919u;
    for (int i = 0; i < 2000 && !stop; i++) {
        size_t sz = 0x100000 + ((seed = seed * 1103515245 + 12345) % 0x400000);
        void *m = mmap(NULL, sz, PROT_READ | PROT_WRITE,
                       MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (m == MAP_FAILED) continue;
        memset(m, 1, 4096);
        munmap(m, sz);
    }
    return NULL;
}

/* brk shrink hammer: grow and shrink the main heap while readers run. */
static void *brkhammer(void *arg)
{
    (void)arg;
    unsigned char *base = sbrk(0);
    for (int i = 0; i < 300 && !stop; i++) {
        if (sbrk(0x210000) == (void *)-1) break;      /* +2.1MB */
        memset(base, 2, 4096);
        if (sbrk(-0x200000) == (void *)-1) break;     /* -2MB */
        usleep(200);
    }
    return NULL;
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    for (int i = 0; i < NOBJ; i++) {
        objs[i] = malloc(OBJSZ);
        if (!objs[i]) { printf("OOM at %d\n", i); return 2; }
        memset(objs[i], i ^ 0, OBJSZ);
        for (int j = 0; j < OBJSZ; j++) objs[i][j] = (unsigned char)(i ^ j);
    }
    printf("arena1: %d objs live, heap top %p\n", NOBJ, sbrk(0));
    verify("initial");

    for (int round = 0; round < 6; round++) {
        pthread_t th[16];
        /* churn threads that EXIT each round (arena teardown) */
        for (int i = 0; i < 8; i++)
            pthread_create(&th[i], NULL, churn, (void *)(uintptr_t)(i + 1 + round * 100));
        for (int i = 8; i < 12; i++)
            pthread_create(&th[i], NULL, mapper, (void *)(uintptr_t)i);
        pthread_create(&th[12], NULL, brkhammer, NULL);
        for (int i = 0; i < 13; i++) pthread_join(th[i], NULL);
        verify("post-round");
        printf("arena-round %d ok\n", round);
    }
    /* COW storm: fork children that churn their copy while the parent
     * keeps verifying ITS objects — catches COW-write faults zeroing
     * parent heap pages (glibc metadata corruption class). */
    for (int round = 0; round < 4 && !fails; round++) {
        pid_t kids[6];
        for (int c = 0; c < 6; c++) {
            pid_t p = fork();
            if (p == 0) {
                for (int i = 0; i < 200; i++) {
                    size_t sz = 4096 + (i % 16) * 512;
                    void *m = malloc(sz);
                    if (m) { memset(m, c + 1, sz); free(m); }
                }
                _exit(0);
            }
            kids[c] = p;
        }
        /* parent WRITES its own objects while children run — forces the
         * parent-side COW-write fault on every shared heap page (the
         * blind spot: verify-after-wait never faults the parent). */
        for (int t = 0; t < 30; t++) {
            for (int i = 0; i < NOBJ; i++) objs[i][t % OBJSZ] ^= 0xA5;
            for (int i = 0; i < NOBJ; i++) objs[i][t % OBJSZ] ^= 0xA5;
        }
        for (int c = 0; c < 6; c++) wait(NULL);
        verify("post-cow");
        printf("cow-round %d ok\n", round);
    }
    stop = 1;
    printf("ARENA-DONE fails=%d\n", fails);
    return fails ? 1 : 0;
}
