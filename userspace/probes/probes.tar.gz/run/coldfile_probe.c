/* coldfile: for never-touched files, mmap-cold-read md5 vs pread md5.
 * The pread (second) is ground truth — it cannot come from a stale
 * zero-fill. Any mismatch = the file-backed mmap cold fill served
 * wrong bytes (the gio empty-symbol / ld.so NULL family). */
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <dirent.h>

static uint32_t h32(uint32_t x){ x^=x>>16; x*=0x7feb352d; x^=x>>15; x*=0x846ca68b; x^=x>>16; return x; }
static uint32_t hashbuf(const unsigned char*p, size_t n, uint32_t seed){
    uint32_t h=seed; for(size_t i=0;i<n;i+=4){ uint32_t v=0; size_t k=n-i<4?n-i:4; memcpy(&v,p+i,k); h=h32(h^v);} return h;
}
static void dump_maps_head(void)
{
    char buf[16384];
    int fd = open("/proc/self/maps", O_RDONLY);
    if (fd < 0) { printf("MAPS: unavailable\n"); return; }
    int n = read(fd, buf, sizeof(buf) - 1);
    close(fd);
    if (n <= 0) return;
    buf[n] = 0;
    printf("MAPS-BEGIN\n%sMAPS-END\n", buf);
}

int main(void){
    setvbuf(stdout,NULL,_IONBF,0);
    dump_maps_head();
    const char *dirs[]={"/bin","/sbin","/usr/bin","/lib"};
    int tested=0, bad=0;
    for(unsigned d=0; d<sizeof(dirs)/sizeof(dirs[0]) && tested<60; d++){
        DIR *dp=opendir(dirs[d]); if(!dp) continue;
        struct dirent *de;
        while((de=readdir(dp)) && tested<60){
            if(de->d_name[0]=='.') continue;
            char path[256]; snprintf(path,sizeof path,"%s/%s",dirs[d],de->d_name);
            int fd=open(path,O_RDONLY); if(fd<0) continue; printf("OPEN %s fd=%d\n",path,fd);
            off_t sz=lseek(fd,0,SEEK_END); if(sz<4096||sz>4*1024*1024){close(fd);continue;}
            void*m=mmap(NULL,sz,PROT_READ,MAP_PRIVATE,fd,0);
            if(m==MAP_FAILED){close(fd);continue;}
            uint32_t hm=hashbuf(m,sz,0x1234);
            unsigned char*b=malloc(sz);
            ssize_t got=pread(fd,b,sz,0);
            uint32_t hp= got==sz ? hashbuf(b,sz,0x1234) : 0xDEAD;
            if(hm!=hp){
                printf("COLD-BAD %s mmaphash=%08x preadhash=%08x\n",path,hm,hp);
                for(int pg=0; pg*4096+8<(int)sz && pg<10; pg++){
                    int same=1;
                    for(int k=0;k<8;k++)
                        if(((unsigned char*)m)[pg*4096+k]!=b[pg*4096+k]){same=0;break;}
                    if(!same){
                        printf("  pg%d mmap:",pg);
                        for(int k=0;k<8;k++) printf(" %02x",((unsigned char*)m)[pg*4096+k]);
                        printf("  pread:");
                        for(int k=0;k<8;k++) printf(" %02x",b[pg*4096+k]);
                        printf("\n");
                    }
                }
                bad++;
            }
            free(b); munmap(m,sz); close(fd); tested++;
        }
        closedir(dp);
    }
    printf("COLD-DONE tested=%d bad=%d\n",tested,bad);
    return bad?1:0;
}
