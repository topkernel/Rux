/* swap roundtrip: 192MB patterned anon region + pressure churn to force
 * kswapd reclaim/swap-out, then verify EVERY page. Catches swap-in
 * refill corruption (wrong/zero data) — the delayed heap-metadata
 * destruction class behind the gnome-shell trim face and the fmv
 * RSVD-bit PTE panic. */
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <sys/mman.h>
#include <unistd.h>

#define REGION (192UL << 20)
#define PS 4096UL
#define NPAGES (REGION / PS)

static uint32_t h32(uint32_t x){ x^=x>>16; x*=0x7feb352d; x^=x>>15; x*=0x846ca68b; x^=x>>16; return x; }

static void fill_region(unsigned char *base, unsigned iter)
{
    for (unsigned p = 0; p < NPAGES; p++) {
        uint32_t seed = h32(p * 2654435761u + iter);
        for (unsigned k = 0; k < PS; k += 4)
            *(uint32_t *)(base + p * PS + k) = h32(seed + k);
    }
}

static long verify_region(unsigned char *base, unsigned iter)
{
    long bad = 0;
    for (unsigned p = 0; p < NPAGES; p++) {
        uint32_t seed = h32(p * 2654435761u + iter);
        for (unsigned k = 0; k < PS; k += 4) {
            uint32_t want = h32(seed + k);
            uint32_t got = *(uint32_t *)(base + p * PS + k);
            if (got != want) {
                if (bad < 5)
                    printf("SWAPRT-BAD page=%u off=%u got=%08x want=%08x\n",
                           p, k, got, want);
                bad++;
                break; /* one line per page */
            }
        }
    }
    return bad;
}

static void pressure(volatile unsigned char **sink)
{
    size_t sz = 64UL << 20;
    unsigned char *m = mmap(NULL, sz, PROT_READ | PROT_WRITE,
                            MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (m == MAP_FAILED) return;
    for (size_t k = 0; k < sz; k += PS) m[k] = 1;
    *sink = m;
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    unsigned char *base = mmap(NULL, REGION, PROT_READ | PROT_WRITE,
                               MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (base == MAP_FAILED) { printf("SWAPRT: mmap fail\n"); return 2; }
    int fails = 0;
    for (unsigned iter = 0; iter < 3; iter++) {
        fill_region(base, iter);
        printf("SWAPRT iter=%u filled\n", iter);
        /* REAL pressure: dirty 1.2GB (most of RAM) so kswapd MUST
         * reclaim the patterned region (swap-out) — the shell's actual
         * environment; the old 3x64MB never forced any reclaim. */
        for (int round = 0; round < 18; round++) {
            volatile unsigned char *sink = NULL;
            pressure(&sink);
            usleep(50000);
            if (sink) munmap((void *)sink, 64UL << 20);
        }
        printf("SWAPRT iter=%u verifying\n", iter);
        long bad = verify_region(base, iter);
        printf("SWAPRT iter=%u bad=%ld\n", iter, bad);
        fails += (int)bad;
    }
    printf("SWAPRT-DONE fails=%d\n", fails);
    return fails ? 1 : 0;
}
