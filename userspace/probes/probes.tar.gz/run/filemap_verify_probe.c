/* filemap-verify: mmap a large patterned file and verify EVERY byte,
 * under concurrent memory pressure (anon churn forcing page-cache
 * eviction/refill). Catches zero-refill of file-backed pages. */
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/mman.h>

#define CHUNK 0x1000
static int fails;

static uint32_t h(uint32_t x){ x^=x>>16; x*=0x7feb352d; x^=x>>15; x*=0x846ca68b; x^=x>>16; return x; }

static void *pressure(void *arg)
{
    (void)arg;
    for (int i = 0; i < 400; i++) {
        size_t sz = 8UL << 20;
        void *m = mmap(NULL, sz, PROT_READ | PROT_WRITE,
                       MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (m == MAP_FAILED) continue;
        memset(m, 9, sz);          /* dirty 8MB — page-cache pressure */
        munmap(m, sz);
    }
    return NULL;
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    const char *path = "/test/pbench";
    int fd = open(path, O_RDONLY);
    if (fd < 0) { printf("FMV: open fail\n"); return 2; }
    off_t sz = lseek(fd, 0, SEEK_END);
    printf("FMV: file %s size %ld\n", path, (long)sz);

    void *base = mmap(NULL, sz, PROT_READ, MAP_PRIVATE, fd, 0);
    if (base == MAP_FAILED) { printf("FMV: mmap fail\n"); return 2; }

    pthread_t th[2];
    for (int i = 0; i < 2; i++) pthread_create(&th[i], NULL, pressure, NULL);

    /* ground truth via pread, verify via the mapping, page by page */
    unsigned char *buf = malloc(CHUNK);
    long bad_pages = 0, first_bad = -1;
    for (off_t off = 0; off < sz; off += CHUNK) {
        size_t n = sz - off < CHUNK ? (size_t)(sz - off) : CHUNK;
        if (pread(fd, buf, n, off) != (ssize_t)n) { printf("FMV: pread fail @%ld\n",(long)off); fails++; break; }
        if (memcmp(buf, (char *)base + off, n) != 0) {
            bad_pages++; if (first_bad < 0) first_bad = off;
            if (bad_pages <= 3)
                printf("FMV-MISMATCH off=%ld mmap[0..8]=", (long)off),
                fflush(stdout);
        }
    }
    for (int i = 0; i < 2; i++) pthread_join(th[i], NULL);
    printf("FMV-DONE bad_pages=%ld first=%ld size=%ld\n",
           bad_pages, first_bad, (long)sz);
    return (bad_pages || fails) ? 1 : 0;
}
