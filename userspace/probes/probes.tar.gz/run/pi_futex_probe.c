/* PI-futex conformance probe (guest, static musl, runs as init).
 *
 * Mirrors the three upstream futextest requeue_pi cases (functional
 * handoff, mismatched-ops EINVAL pair, signal-restart face) plus the
 * LOCK_PI/TRYLOCK_PI/UNLOCK_PI errno contract and the owner-died
 * takeover. Raw syscalls only; processes (fork) on MAP_SHARED words
 * with the SHARED flavor (no FUTEX_PRIVATE_FLAG) — the cross-process
 * physical-key path.
 *
 * Prints one PI-x PASS/FAIL line per check; exit code = failures.
 */
#include <stdint.h>
#include <stdio.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>

static int fails;
#define CHECK(cond, name) do { \
    if (cond) printf("PI-%s PASS\n", name); \
    else { printf("PI-%s FAIL (errno=%d)\n", name, errno); fails++; } \
} while (0)

#define FUTEX_WAIT              0
#define FUTEX_WAKE              1
#define FUTEX_CMP_REQUEUE       4
#define FUTEX_LOCK_PI           6
#define FUTEX_UNLOCK_PI         7
#define FUTEX_TRYLOCK_PI        8
#define FUTEX_WAIT_REQUEUE_PI   11
#define FUTEX_CMP_REQUEUE_PI    12

/* The 4th futex slot is the timeout pointer — or the nr_requeue count
 * for the requeue ops (futex ABI overloading). */
static long ftx(volatile uint32_t *uaddr, int op, uint32_t val,
                void *to, uint32_t *uaddr2, uint32_t val3)
{
    return syscall(SYS_futex, (uint32_t *)uaddr, op, val, to, uaddr2, val3);
}

static void msleep(int ms)
{
    struct timespec ts = { ms / 1000, (ms % 1000) * 1000000L };
    nanosleep(&ts, NULL);
}

/* dl: absolute CLOCK_MONOTONIC deadline now+ms. */
static struct timespec dl(long ms)
{
    struct timespec now, out;
    clock_gettime(CLOCK_MONOTONIC, &now);
    out.tv_sec = now.tv_sec + ms / 1000;
    out.tv_nsec = now.tv_nsec + (ms % 1000) * 1000000L;
    if (out.tv_nsec >= 1000000000L) {
        out.tv_sec++; out.tv_nsec -= 1000000000L;
    }
    return out;
}

static void pi_sigusr1(int sig) { (void)sig; }

static uint32_t *words;   /* [0]=f1 condvar  [1]=f2 PI lock */
#define F1 (&words[0])
#define F2 (&words[1])

/* ---- 1. requeue_pi functional: waiter ends up OWNING the PI lock --- */
static void t_functional(void)
{
    struct timespec d;
    *F1 = 0; *F2 = 0;
    /* sleeper A (chain head: will be SYNC-WOKEN, owns nothing) */
    pid_t a = fork();
    if (a == 0) {
        d = dl(4000);
        long r = ftx(F1, FUTEX_WAIT_REQUEUE_PI, 0, &d, F2, 0);
        _exit(r == 0 ? 0 : 1);
    }
    msleep(120);
    /* sleeper B (second: requeued onto F2, must OWN it after handoff) */
    pid_t b = fork();
    if (b == 0) {
        d = dl(4000);
        long r = ftx(F1, FUTEX_WAIT_REQUEUE_PI, 0, &d, F2, 0);
        if (r == 0 && *F2 == (uint32_t)getpid()) {
            ftx(F2, FUTEX_UNLOCK_PI, 0, NULL, NULL, 0);
            _exit(0);
        }
        _exit(1);
    }
    msleep(150);
    d = dl(1000);
    long l = ftx(F2, FUTEX_LOCK_PI, 0, &d, NULL, 0);
    CHECK(l == 0 && *F2 == (uint32_t)getpid(), "lockpi-take");
    /* nr_wake=1 (head A woken), nr_requeue=1 (B moved to F2's PI queue) */
    long r = ftx(F1, FUTEX_CMP_REQUEUE_PI, 1, (void *)1, F2, 0);
    CHECK(r >= 0, "cmprequeuepi-ret");
    /* B now queues on F2 owned by us — hand it over */
    long u2 = ftx(F2, FUTEX_UNLOCK_PI, 0, NULL, NULL, 0);
    CHECK(u2 == 0, "requeuepi-unlock");
    int sa = -1, sb = -1;
    waitpid(a, &sa, 0);
    waitpid(b, &sb, 0);
    CHECK(WIFEXITED(sa) && WEXITSTATUS(sa) == 0, "requeuepi-woken");
    CHECK(WIFEXITED(sb) && WEXITSTATUS(sb) == 0, "requeuepi-own");
    CHECK(*F2 == 0, "requeuepi-word-clean");
}

/* ---- 2. mismatched ops: both pairings are EINVAL ------------------- */
static void t_mismatch(void)
{
    struct timespec d;
    *F1 = 0; *F2 = 0;
    pid_t w = fork();
    if (w == 0) {                       /* plain WAIT on F1 */
        ftx(F1, FUTEX_WAIT, 0, NULL, NULL, 0);
        _exit(0);
    }
    msleep(150);
    long r = ftx(F1, FUTEX_CMP_REQUEUE_PI, 1, (void *)1, F2, 0);
    CHECK(r == -1 && errno == EINVAL, "mismatch-plain-waiter");
    ftx(F1, FUTEX_WAKE, 1, NULL, NULL, 0);
    waitpid(w, NULL, 0);

    /* reverse: requeue_pi waiter, plain CMP_REQUEUE mover */
    w = fork();
    if (w == 0) {
        d = dl(3000);
        ftx(F1, FUTEX_WAIT_REQUEUE_PI, 0, &d, F2, 0);
        _exit(0);
    }
    msleep(150);
    r = ftx(F1, FUTEX_CMP_REQUEUE, 1, (void *)1, F2, 0);
    CHECK(r == -1 && errno == EINVAL, "mismatch-plain-mover");
    ftx(F1, FUTEX_WAKE, 1, NULL, NULL, 0);
    waitpid(w, NULL, 0);
}

/* ---- 3. signal-restart face: EINTR after requeue, word consistent -- */
static void t_signal(void)
{
    struct timespec d;
    *F1 = 0; *F2 = 0;
    pid_t a = fork();
    if (a == 0) {
        d = dl(4000);
        ftx(F1, FUTEX_WAIT_REQUEUE_PI, 0, &d, F2, 0);
        _exit(0);
    }
    msleep(120);
    pid_t b = fork();
    if (b == 0) {
        signal(SIGUSR1, pi_sigusr1);
        d = dl(4000);
        long r = ftx(F1, FUTEX_WAIT_REQUEUE_PI, 0, &d, F2, 0);
        _exit(r == -1 && errno == EINTR ? 0 : 1);
    }
    msleep(150);
    d = dl(1000);
    ftx(F2, FUTEX_LOCK_PI, 0, &d, NULL, 0);
    ftx(F1, FUTEX_CMP_REQUEUE_PI, 1, (void *)1, F2, 0);
    msleep(100);
    kill(b, SIGUSR1);                   /* the requeued sleeper */
    int sa = -1, sb = -1;
    waitpid(a, &sa, 0);
    waitpid(b, &sb, 0);
    CHECK(WIFEXITED(sb) && WEXITSTATUS(sb) == 0, "signal-eintr");
    long u = ftx(F2, FUTEX_UNLOCK_PI, 0, NULL, NULL, 0);
    CHECK(u == 0 && *F2 == 0, "signal-word-consistent");
}

/* ---- 4. LOCK_PI errno contract ------------------------------------- */
static void t_contract(void)
{
    struct timespec d;
    int st = -1;
    *F2 = 0;
    d = dl(500);
    long l = ftx(F2, FUTEX_LOCK_PI, 0, &d, NULL, 0);
    CHECK(l == 0 && *F2 == (uint32_t)getpid(), "lockpi-fast");

    d = dl(300);
    long sl = ftx(F2, FUTEX_LOCK_PI, 0, &d, NULL, 0);
    CHECK(sl == -1 && errno == EDEADLK, "lockpi-self-deadlock");
    ftx(F2, FUTEX_UNLOCK_PI, 0, NULL, NULL, 0);

    /* non-owner unlock */
    pid_t w = fork();
    if (w == 0) {
        long c = ftx(F2, FUTEX_LOCK_PI, 0, NULL, NULL, 0);
        (void)c;
        _exit(0);
    }
    waitpid(w, NULL, 0);

    /* contended: child takes it, we time out */
    *F2 = 0;
    w = fork();
    if (w == 0) {
        d = dl(3000);
        long c = ftx(F2, FUTEX_LOCK_PI, 0, &d, NULL, 0);
        if (c != 0) _exit(1);
        msleep(600);                    /* stay ALIVE holding it */
        _exit(0);
    }
    msleep(150);                        /* child holds it */
    d = dl(150);
    long tl = ftx(F2, FUTEX_LOCK_PI, 0, &d, NULL, 0);
    CHECK(tl == -1 && errno == ETIMEDOUT, "lockpi-timeout");
    long u = ftx(F2, FUTEX_UNLOCK_PI, 0, NULL, NULL, 0); /* not ours */
    CHECK(u == -1 && errno == EPERM, "unlockpi-foreign");
    waitpid(w, &st, 0);
    CHECK(WIFEXITED(st) && WEXITSTATUS(st) == 0, "lockpi-child-held");

    /* handoff: child holds; we block; child unlocks into us */
    *F2 = 0;
    w = fork();
    if (w == 0) {
        d = dl(3000);
        long c = ftx(F2, FUTEX_LOCK_PI, 0, &d, NULL, 0);
        if (c != 0) _exit(1);
        msleep(200);
        long uu = ftx(F2, FUTEX_UNLOCK_PI, 0, NULL, NULL, 0);
        _exit(uu == 0 ? 0 : 1);
    }
    msleep(100);
    d = dl(3000);
    long h = ftx(F2, FUTEX_LOCK_PI, 0, &d, NULL, 0);
    CHECK(h == 0 && *F2 == (uint32_t)getpid(), "lockpi-handoff");
    ftx(F2, FUTEX_UNLOCK_PI, 0, NULL, NULL, 0);
    waitpid(w, &st, 0);

    /* trylock on a held lock */
    *F2 = 0;
    w = fork();
    if (w == 0) {
        d = dl(2000);
        long c = ftx(F2, FUTEX_LOCK_PI, 0, &d, NULL, 0);
        _exit(c == 0 ? 0 : 1);
    }
    msleep(150);
    long t = ftx(F2, FUTEX_TRYLOCK_PI, 0, NULL, NULL, 0);
    CHECK(t == -1 && errno == EAGAIN, "trylockpi-eagain");
    kill(w, SIGKILL);
    waitpid(w, &st, 0);
}

/* ---- 5. owner died: holder exits, taker gets EOWNERDEAD ------------ */
static void t_owner_died(void)
{
    struct timespec d;
    *F2 = 0;
    pid_t w = fork();
    if (w == 0) {
        d = dl(3000);
        long c = ftx(F2, FUTEX_LOCK_PI, 0, &d, NULL, 0);
        _exit(c == 0 ? 0 : 1);          /* holds it, then exits */
    }
    msleep(150);
    d = dl(1000);
    long x = ftx(F2, FUTEX_LOCK_PI, 0, &d, NULL, 0);
    CHECK(x == -1 && errno == EOWNERDEAD, "owner-died-eownerdead");
    CHECK(*F2 & 0x40000000u, "owner-died-bit");
    ftx(F2, FUTEX_UNLOCK_PI, 0, NULL, NULL, 0);
}

/* ---- 6. timeout + value-mismatch faces on WAIT_REQUEUE_PI ---------- */
static void t_timeout(void)
{
    struct timespec d;
    *F1 = 0; *F2 = 0;
    d = dl(120);
    long r = ftx(F1, FUTEX_WAIT_REQUEUE_PI, 0, &d, F2, 0);
    CHECK(r == -1 && errno == ETIMEDOUT, "wrqpi-timeout");
    *F1 = 7;                            /* value mismatch -> EAGAIN */
    d = dl(120);
    r = ftx(F1, FUTEX_WAIT_REQUEUE_PI, 0, &d, F2, 0);
    CHECK(r == -1 && errno == EAGAIN, "wrqpi-eagain");
}

int main(void)
{
    words = mmap(NULL, 4096, PROT_READ | PROT_WRITE,
                 MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (words == MAP_FAILED) {
        printf("PI-mmap FAIL\n");
        return 1;
    }
    t_functional();
    t_mismatch();
    t_signal();
    t_contract();
    t_owner_died();
    t_timeout();
    printf("PI-DONE fails=%d\n", fails);
    return fails ? 1 : 0;
}
