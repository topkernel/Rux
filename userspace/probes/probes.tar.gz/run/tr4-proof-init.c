/*
 * tr4-proof-init.c — dfx-trace round 4 serial proof driver (PID 1).
 *
 * Round-4 flow (lock: + tcp:/sock: families, x86_64+KVM):
 *
 *   P0  boot state: set_event/tracing_on BEFORE any userspace write
 *       (boot B/C with dfx=syncguard / dfx=tcptrace: the alias
 *       pre-arms exactly its family).
 *   P1  catalog: the ten round-4 events in available_events; the
 *       format files of lock_acquire, lock_contended,
 *       contention_begin, tcp_retransmit_skb, inet_sock_set_state;
 *       group arming ("lock", "tcp", "sock") and a per-event enable.
 *   P2  lock records: a real contention workload (4 children
 *       hammering create+write+unlink on one directory — the
 *       VFS_MUTATION_LOCK / EXT4-BIGLOCK SleepMutex pair) produces
 *       lock_acquire/lock_release on the fast path and
 *       lock_contended/lock_acquired on the slow path, plus
 *       contention_begin/contention_end from contended spinlock
 *       acquires (GRQ under fork/wake churn) — lines in the
 *       reference print geometry.
 *   P3  net records: a loopback TCP lifecycle (listener + client on
 *       127.0.0.1) drives inet_sock_set_state through
 *       LISTEN/SYN_SENT/SYN_RECV/ESTABLISHED/close states and
 *       tcp_destroy_sock at the destroy funnel; a blackhole connect
 *       (no listener on loopback — Rux emits no RST) drives SYN
 *       retransmits (tcp_retransmit_skb); a refused connect via the
 *       slirp gateway drives tcp_receive_reset.
 *   P4  enabled-vs-disabled differentials (events-off baseline,
 *       min-of-3): the single-process churn loop with the lock family
 *       armed (records/op counted from the trace), and the loopback
 *       connection loop with sock+tcp armed.
 *   P5  trace_pipe drain (live consume, begin-left=0).
 *
 * Build: gcc -static -O2 -o init run/tr4-proof-init.c
 * Image: mkfs.ext4 + debugfs write as /init
 * Boot:  -append "root=/dev/vda rw init=/init console=ttyS0 [dfx=...]"
 */

#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <time.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/ioctl.h>
#include <errno.h>

static const char *T = "/sys/kernel/tracing";

static void say(const char *s) { write(1, s, strlen(s)); }

static void dump_file(const char *path, long max_bytes)
{
    char buf[2048];
    int fd = open(path, O_RDONLY);
    say("\n--- ");
    say(path);
    say(" ---\n");
    if (fd < 0) {
        say("(open failed)\n");
        return;
    }
    long total = 0;
    ssize_t r;
    while (total < max_bytes && (r = read(fd, buf, sizeof(buf))) > 0) {
        if (total + r > max_bytes)
            r = max_bytes - total;
        write(1, buf, r);
        total += r;
    }
    close(fd);
    if (total >= max_bytes)
        say("...\n(truncated)\n");
}

static void put(const char *path, const char *text)
{
    int fd = open(path, O_WRONLY);
    if (fd < 0) {
        say("(write open failed: ");
        say(path);
        say(")\n");
        return;
    }
    write(fd, text, strlen(text));
    close(fd);
}

static long long now_ns(void)
{
    struct timespec t;
    clock_gettime(CLOCK_MONOTONIC, &t);
    return t.tv_sec * 1000000000LL + t.tv_nsec;
}

/* count lines containing `needle` in a file; optionally print up to
 * `samples` whole matching lines */
static long count_lines(const char *path, const char *needle, int samples)
{
    int fd = open(path, O_RDONLY);
    if (fd < 0)
        return -1;
    static char big[600000];
    ssize_t r = read(fd, big, sizeof(big) - 1);
    close(fd);
    if (r < 0)
        r = 0;
    big[r] = 0;
    long count = 0;
    const char *p = big;
    int shown = 0;
    while ((p = strstr(p, needle)) != NULL) {
        if (shown < samples) {
            const char *ls = p;
            while (ls > big && ls[-1] != '\n')
                ls--;
            const char *eol = strchr(p, '\n');
            if (eol) {
                write(1, "    > ", 6);
                write(1, ls, (eol - ls) + 1);
                shown++;
            }
        }
        count++;
        p++;
    }
    return count;
}

/* one churn op: create, write, close, unlink in the shared directory */
static void churn_op(int i)
{
    char path[64];
    char buf[64];
    int n = snprintf(path, sizeof(path), "/churn/tr4-%d.dat", i);
    (void)n;
    int fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd >= 0) {
        memset(buf, 'x', sizeof(buf));
        write(fd, buf, sizeof(buf));
        close(fd);
    }
    unlink(path);
}

static long long bench_churn(int n)
{
    long long t0 = now_ns();
    for (int i = 0; i < n; i++)
        churn_op(i);
    return now_ns() - t0;
}

/* The contention workload: `procs` children hammering the shared
 * directory (the SleepMutex big locks serialize them; the scheduler
 * GRQ spinlock sees churn too). Runs for `ms` milliseconds. */
static void churn_storm(int procs, int ms)
{
    for (int c = 0; c < procs; c++) {
        pid_t p = fork();
        if (p == 0) {
            long long end = now_ns() + (long long)ms * 1000000LL;
            int i = 0;
            while (now_ns() < end)
                churn_op(i++);
            _exit(0);
        }
    }
    struct timespec ts = { ms / 1000 + 1, 0 };
    nanosleep(&ts, NULL);
}

/* one loopback TCP lifecycle: listener accepts one connection, echoes
 * a byte, both sides close. Returns 0 on success. */
static int lo_lifecycle(void)
{
    int ls = socket(AF_INET, SOCK_STREAM, 0);
    if (ls < 0)
        return -1;
    struct sockaddr_in a;
    memset(&a, 0, sizeof(a));
    a.sin_family = AF_INET;
    a.sin_port = htons(9090);
    a.sin_addr.s_addr = htonl(0x7f000001);
    int one = 1;
    setsockopt(ls, SOL_SOCKET, SO_REUSEADDR, &one, sizeof(one));
    if (bind(ls, (struct sockaddr *)&a, sizeof(a)) < 0 || listen(ls, 4) < 0) {
        close(ls);
        return -1;
    }
    pid_t srv = fork();
    if (srv == 0) {
        struct sockaddr_in ca;
        socklen_t cl = sizeof(ca);
        int cs = accept(ls, (struct sockaddr *)&ca, &cl);
        if (cs >= 0) {
            char b;
            if (read(cs, &b, 1) == 1)
                write(cs, &b, 1);
            close(cs);
        }
        close(ls);
        _exit(0);
    }
    close(ls);
    int cs = socket(AF_INET, SOCK_STREAM, 0);
    if (connect(cs, (struct sockaddr *)&a, sizeof(a)) < 0) {
        close(cs);
        waitpid(srv, NULL, 0);
        return -1;
    }
    char b = 'z';
    write(cs, &b, 1);
    read(cs, &b, 1);
    close(cs);
    waitpid(srv, NULL, 0);
    return 0;
}

static long long bench_lo_lifecycle(int n)
{
    long long t0 = now_ns();
    for (int i = 0; i < n; i++)
        lo_lifecycle();
    return now_ns() - t0;
}

/* Install a default route via the slirp gateway (SIOCADDRT, root) so
 * off-subnet SYNs actually leave the guest — without it Rux drops
 * them at route lookup and no retransmit ever fires. */
static int add_default_route(void)
{
    int s = socket(AF_INET, SOCK_DGRAM, 0);
    if (s < 0)
        return -999;
    /* struct rtentry (LP64): pad1@0, dst@8, gateway@24, genmask@40,
     * flags@56. sockaddr: family@+0, addr@+4 (BE). */
    unsigned char rt[112];
    memset(rt, 0, sizeof(rt));
    unsigned short af = AF_INET;
    memcpy(rt + 8, &af, 2);        /* dst family */
    /* dst 0.0.0.0 (already zero) */
    memcpy(rt + 24, &af, 2);       /* gateway family */
    rt[28] = 10; rt[29] = 0; rt[30] = 2; rt[31] = 2; /* 10.0.2.2 */
    memcpy(rt + 40, &af, 2);       /* genmask family */
    /* genmask 0.0.0.0 (already zero) */
    unsigned short flags = 0x0002; /* RTF_GATEWAY */
    memcpy(rt + 56, &flags, 2);
    long r = ioctl(s, 0x890B /* SIOCADDRT */, rt);
    close(s);
    {
        char msg[80];
        int n = snprintf(msg, sizeof(msg), "SIOCADDRT rc=%ld (0 = route in)\n", r);
        write(1, msg, n);
    }
    return (int)r;
}

/* blackhole connect: a non-routable address via the slirp gateway —
 * nothing answers (the host's own SYN retries go nowhere within the
 * window), so the guest's SYN retransmits on RTO. A loopback closed
 * port does NOT work as a blackhole: Rux answers it with an RST (the
 * reference behavior for an unlistened port). */
static void blackhole_connect(void)
{
    int cs = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in a;
    memset(&a, 0, sizeof(a));
    a.sin_family = AF_INET;
    a.sin_port = htons(45678);
    a.sin_addr.s_addr = htonl(0x0a636363); /* 10.99.99.99 */
    fcntl(cs, F_SETFL, O_NONBLOCK);
    connect(cs, (struct sockaddr *)&a, sizeof(a)); /* EINPROGRESS */
    struct timespec ts = { 4, 0 };
    nanosleep(&ts, NULL); /* ~3 RTO retransmits at 1s default */
    close(cs);
}

/* refused connect via the slirp gateway: the host answers RST, the
 * guest records tcp_receive_reset (needs -netdev user at boot). */
static void refused_connect(void)
{
    int cs = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in a;
    memset(&a, 0, sizeof(a));
    a.sin_family = AF_INET;
    a.sin_port = htons(9);
    a.sin_addr.s_addr = htonl(0x0a000202); /* 10.0.2.2 */
    fcntl(cs, F_SETFL, O_NONBLOCK);
    connect(cs, (struct sockaddr *)&a, sizeof(a));
    struct timespec ts = { 2, 0 };
    nanosleep(&ts, NULL);
    close(cs);
}

int main(void)
{
    say("===TR4-PROOF-INIT-START===\n");
    mkdir("/churn", 0755);

    /* P0: boot state BEFORE any userspace write */
    say("\n[P0] boot state:\n");
    dump_file("/sys/kernel/tracing/tracing_on", 64);
    dump_file("/sys/kernel/tracing/set_event", 2048);

    /* P1: catalog + formats + group arming */
    say("\n[P1] round-4 catalog (lock:/tcp:/sock: rows):\n");
    {
        int fd = open("/sys/kernel/tracing/available_events", O_RDONLY);
        static char buf[16384];
        ssize_t r = fd >= 0 ? read(fd, buf, sizeof(buf) - 1) : -1;
        if (fd >= 0)
            close(fd);
        if (r < 0)
            r = 0;
        buf[r] = 0;
        const char *names[] = {
            "lock:lock_acquire", "lock:lock_acquired", "lock:lock_contended",
            "lock:lock_release", "lock:contention_begin", "lock:contention_end",
            "tcp:tcp_retransmit_skb", "tcp:tcp_receive_reset",
            "tcp:tcp_destroy_sock", "sock:inet_sock_set_state",
        };
        int found = 0;
        for (unsigned i = 0; i < sizeof(names) / sizeof(names[0]); i++) {
            const char *p = buf;
            int hit = 0;
            while ((p = strstr(p, names[i])) != NULL) {
                hit = 1;
                break;
            }
            if (hit) {
                found++;
            } else {
                say("MISS ");
                say(names[i]);
                say("\n");
            }
        }
        char msg[96];
        int n = snprintf(msg, sizeof(msg), "AVAIL10 %d/10\n", found);
        write(1, msg, n);
    }
    dump_file("/sys/kernel/tracing/events/lock/lock_acquire/format", 2048);
    dump_file("/sys/kernel/tracing/events/lock/lock_contended/format", 1024);
    dump_file("/sys/kernel/tracing/events/lock/contention_begin/format", 1024);
    dump_file("/sys/kernel/tracing/events/tcp/tcp_retransmit_skb/format", 2048);
    dump_file("/sys/kernel/tracing/events/sock/inet_sock_set_state/format", 2048);
    put("/sys/kernel/tracing/set_event", "lock");
    say("\n[P1] after 'echo lock > set_event':\n");
    dump_file("/sys/kernel/tracing/set_event", 512);
    dump_file("/sys/kernel/tracing/events/lock/enable", 16);
    /* per-event enable: only lock_contended on, acquire stays off */
    put("/sys/kernel/tracing/events/lock/lock_contended/enable", "1");
    dump_file("/sys/kernel/tracing/events/lock/lock_contended/enable", 16);
    dump_file("/sys/kernel/tracing/events/lock/lock_acquire/enable", 16);
    put("/sys/kernel/tracing/events/lock/lock_contended/enable", "0");
    put("/sys/kernel/tracing/set_event", "!lock");
    put("/sys/kernel/tracing/set_event", "tcp");
    put("/sys/kernel/tracing/set_event", "sock");
    say("\n[P1] after tcp+sock arming:\n");
    dump_file("/sys/kernel/tracing/set_event", 512);
    put("/sys/kernel/tracing/set_event", "!tcp");
    put("/sys/kernel/tracing/set_event", "!sock");

    /* P2: lock records under the contention storm. TWO windows: the
     * per-CPU ring holds only 1024 records, and a storm's spinlock
     * contention pair (2 records per contended acquire) would flood
     * the mutex records out of the view — so the mutex quartet and
     * the contention pair are proven in separate windows. */
    put("/sys/kernel/tracing/tracing_on", "1");
    /* window 1: the mutex quartet only */
    put("/sys/kernel/tracing/events/lock/lock_acquire/enable", "1");
    put("/sys/kernel/tracing/events/lock/lock_acquired/enable", "1");
    put("/sys/kernel/tracing/events/lock/lock_contended/enable", "1");
    put("/sys/kernel/tracing/events/lock/lock_release/enable", "1");
    churn_storm(4, 2500);
    /* reap the children */
    while (wait(NULL) > 0)
        ;
    put("/sys/kernel/tracing/events/enable", "0");
    say("\n[P2] mutex-quartet line counts:\n");
    long mq[4];
    {
        const char *classes[] = {
            "lock_acquire:", "lock_acquired:", "lock_contended:", "lock_release:",
        };
        for (unsigned c = 0; c < 4; c++) {
            mq[c] = count_lines("/sys/kernel/tracing/trace", classes[c], 2);
            char msg[96];
            int n = snprintf(msg, sizeof(msg), "%-20s %ld\n", classes[c], mq[c]);
            write(1, msg, n);
        }
    }
    put("/sys/kernel/tracing/trace", "\n");
    /* window 2: the spinlock contention pair only */
    put("/sys/kernel/tracing/events/lock/contention_begin/enable", "1");
    put("/sys/kernel/tracing/events/lock/contention_end/enable", "1");
    churn_storm(4, 1500);
    while (wait(NULL) > 0)
        ;
    put("/sys/kernel/tracing/events/enable", "0");
    say("\n[P2] contention-pair line counts:\n");
    long cb = 0, ce = 0;
    {
        cb = count_lines("/sys/kernel/tracing/trace", "contention_begin:", 2);
        ce = count_lines("/sys/kernel/tracing/trace", "contention_end:", 2);
        char msg[96];
        int n = snprintf(msg, sizeof(msg),
                         "contention_begin:  %ld\ncontention_end:    %ld\n", cb, ce);
        write(1, msg, n);
        n = snprintf(msg, sizeof(msg),
                     "LOCKDBG: acquire=%ld acquired=%ld contended=%ld release=%ld"
                     " cbeg=%ld cend=%ld\n",
                     mq[0], mq[1], mq[2], mq[3], cb, ce);
        write(1, msg, n);
    }
    put("/sys/kernel/tracing/trace", "\n");

    /* P3: net records */
    put("/sys/kernel/tracing/set_event", "sock");
    put("/sys/kernel/tracing/set_event", "tcp");
    put("/sys/kernel/tracing/tracing_on", "1");
    add_default_route();
    int lo_ok = lo_lifecycle();
    blackhole_connect();
    refused_connect();
    put("/sys/kernel/tracing/tracing_on", "0");
    say("\n[P3] net line counts:\n");
    {
        long states = count_lines("/sys/kernel/tracing/trace", "inet_sock_set_state:", 3);
        long est = count_lines("/sys/kernel/tracing/trace",
                               "newstate=TCP_ESTABLISHED", 1);
        long lst = count_lines("/sys/kernel/tracing/trace",
                               "newstate=TCP_LISTEN", 1);
        long destroy = count_lines("/sys/kernel/tracing/trace", "tcp_destroy_sock:", 1);
        long retx = count_lines("/sys/kernel/tracing/trace", "tcp_retransmit_skb:", 2);
        long rst = count_lines("/sys/kernel/tracing/trace", "tcp_receive_reset:", 1);
        char msg[224];
        int n = snprintf(msg, sizeof(msg),
                         "lo_lifecycle=%d NETDBG: states=%ld est=%ld listen=%ld"
                         " destroy=%ld retx=%ld rst=%ld\n",
                         lo_ok, states, est, lst, destroy, retx, rst);
        write(1, msg, n);
    }
    put("/sys/kernel/tracing/events/enable", "0");
    put("/sys/kernel/tracing/trace", "\n");

    /* P4: differentials (events-off baseline, alternating reps). No
     * marker pairing: the per-CPU ring holds 1024 records and a 200-op
     * armed window produces ~4-8 records/op — the opening marker would
     * be overwritten mid-window (the run-1 lesson). Instead: clear
     * before the armed pass, disable after, then count what the window
     * left in the ring. */
    say("\n[P4] churn differential (ns per 200 create+write+unlink ops):\n");
    put("/sys/kernel/tracing/tracing_on", "1");
    long long off[3], on[3];
    long recs = 0;
    for (int rep = 0; rep < 3; rep++) {
        put("/sys/kernel/tracing/events/enable", "0");
        put("/sys/kernel/tracing/trace", "\n");
        off[rep] = bench_churn(200);
        put("/sys/kernel/tracing/set_event", "lock");
        put("/sys/kernel/tracing/trace", "\n");
        on[rep] = bench_churn(200);
        put("/sys/kernel/tracing/events/enable", "0");
        recs = count_lines("/sys/kernel/tracing/trace", "lock_acquire:", 0);
        put("/sys/kernel/tracing/trace", "\n");
    }
    put("/sys/kernel/tracing/tracing_on", "0");
    {
        long long mn(long long *v) { long long m = v[0]; for (int i=1;i<3;i++) if (v[i]<m) m=v[i]; return m; }
        long long o = mn(off), n_on = mn(on);
        char msg[288];
        int n = snprintf(msg, sizeof(msg),
                         "off: %lld %lld %lld (min %lld)\n"
                         "on : %lld %lld %lld (min %lld) delta %lld ns/op\n"
                         "records in last on-window: acquire=%ld (release pairs it;"
                         " ~%ld rec/op → %lld ns/record)\n",
                         off[0], off[1], off[2], o, on[0], on[1], on[2], n_on,
                         (n_on - o) / 200, recs, (recs * 2) / 200,
                         recs ? ((n_on - o) * 200) / (recs * 2) : 0);
        write(1, msg, n);
    }

    say("\n[P4] loopback-connection differential (ns per lifecycle):\n");
    {
        long long off2[5], on2[5];
        put("/sys/kernel/tracing/tracing_on", "1");
        for (int rep = 0; rep < 5; rep++) {
            put("/sys/kernel/tracing/events/enable", "0");
            off2[rep] = bench_lo_lifecycle(50);
            put("/sys/kernel/tracing/set_event", "sock");
            put("/sys/kernel/tracing/set_event", "tcp");
            on2[rep] = bench_lo_lifecycle(50);
            put("/sys/kernel/tracing/events/enable", "0");
        }
        put("/sys/kernel/tracing/tracing_on", "0");
        long long mn(long long *v) { long long m = v[0]; for (int i=1;i<5;i++) if (v[i]<m) m=v[i]; return m; }
        long long o = mn(off2), n_on = mn(on2);
        char msg[288];
        int n = snprintf(msg, sizeof(msg),
                         "off: %lld %lld %lld %lld %lld (min %lld)\n"
                         "on : %lld %lld %lld %lld %lld (min %lld) delta %lld ns/lifecycle\n",
                         off2[0], off2[1], off2[2], off2[3], off2[4], o,
                         on2[0], on2[1], on2[2], on2[3], on2[4], n_on,
                         (n_on - o) / 50);
        write(1, msg, n);
    }
    put("/sys/kernel/tracing/tracing_on", "0");
    put("/sys/kernel/tracing/events/enable", "0");

    /* P5: trace_pipe drain */
    put("/sys/kernel/tracing/set_event", "lock");
    put("/sys/kernel/tracing/tracing_on", "1");
    bench_churn(20);
    put("/sys/kernel/tracing/tracing_on", "0");
    {
        char buf[8192];
        int fd = open("/sys/kernel/tracing/trace_pipe", O_RDONLY | O_NONBLOCK);
        long total = 0;
        ssize_t r;
        while (fd >= 0 && (r = read(fd, buf, sizeof(buf))) > 0)
            total += r;
        if (fd >= 0)
            close(fd);
        long left = count_lines("/sys/kernel/tracing/trace", "lock_acquire:", 0);
        char msg[128];
        int n = snprintf(msg, sizeof(msg),
                         "PIPDBG: drained=%ld begin_left=%ld (expect drained>0)\n",
                         total, left);
        write(1, msg, n);
    }
    put("/sys/kernel/tracing/events/enable", "0");
    put("/sys/kernel/tracing/trace", "\n");

    say("\n===TR4-PROOF-INIT-DONE===\n");

    while (1) {
        struct timespec ts = { 60, 0 };
        nanosleep(&ts, NULL);
    }
    return 0;
}
