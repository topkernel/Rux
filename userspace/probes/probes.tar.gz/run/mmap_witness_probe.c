/* mmap-witness probe: tag every live mmap in a shared record; on SIGSEGV
 * (altstack handler) report the faulting address's owner tag + the maps
 * excerpt around it. Turns the one-line crash into a full witness. */
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <signal.h>
#include <unistd.h>
#include <sys/mman.h>
#include <fcntl.h>

#define MAXREC 256
struct rec { uintptr_t s, e; int tid, iter; };
static struct rec recs[MAXREC];
static volatile int nrec;
static volatile int stop;

static void add_rec(uintptr_t s, size_t len, int tid, int iter)
{
    int i = __sync_fetch_and_add(&nrec, 1);
    if (i < MAXREC) {
        recs[i].s = s; recs[i].e = s + len;
        recs[i].tid = tid; recs[i].iter = iter;
    }
}
static void del_rec(uintptr_t s)
{
    int n = nrec;
    for (int i = 0; i < n && i < MAXREC; i++)
        if (recs[i].s == s) { recs[i].s = 0; recs[i].e = 0; }
}

static void dump_maps_around(uintptr_t a)
{
    char buf[65536];
    int fd = open("/proc/self/maps", O_RDONLY);
    if (fd < 0) { printf("  maps: open failed\n"); return; }
    int n = read(fd, buf, sizeof(buf) - 1);
    close(fd);
    if (n <= 0) { printf("  maps: read failed\n"); return; }
    buf[n] = 0;
    char *p = buf;
    while (*p) {
        uintptr_t s, e;
        char *nl = strchr(p, '\n');
        if (sscanf(p, "%lx-%lx", &s, &e) == 2 &&
            (e + 0x400000 > a && s < a + 0x400000))
            printf("  map %lx-%lx%s", s, e, nl ? "\n" : "");
        if (!nl) break;
        p = nl + 1;
    }
}

static void segv_handler(int sig, siginfo_t *si, void *uc)
{
    (void)sig; (void)uc;
    uintptr_t a = (uintptr_t)si->si_addr;
    printf("WITNESS-SEGV addr=%lx\n", (unsigned long)a);
    int n = nrec;
    for (int i = 0; i < n && i < MAXREC; i++)
        if (recs[i].s != 0)
            printf("  live t%d iter%d %lx-%lx%s\n", recs[i].tid,
                   recs[i].iter, recs[i].s, recs[i].e,
                   (a >= recs[i].s && a < recs[i].e) ? "  <== FAULT IN THIS" : "");
    dump_maps_around(a);
    _exit(42);
}

static void *churn(void *arg)
{
    int tid = (int)(uintptr_t)arg;
    for (int i = 0; i < 3000 && !stop; i++) {
        size_t sz = 0x100000 + (i % 7) * 0x31000;
        void *m = mmap(NULL, sz, PROT_READ | PROT_WRITE,
                       MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (m == MAP_FAILED) continue;
        add_rec((uintptr_t)m, sz, tid, i);
        memset(m, 3, 4096);            /* first touch */
        memset(m, 3, sz);              /* touch EVERYTHING (audit: whole span) */
        del_rec((uintptr_t)m);
        munmap(m, sz);
    }
    return NULL;
}

int main(void)
{
    setvbuf(stdout, NULL, _IONBF, 0);
    stack_t ss = { malloc(SIGSTKSZ), 0, SIGSTKSZ };
    sigaltstack(&ss, NULL);
    struct sigaction sa = { 0 };
    sa.sa_sigaction = segv_handler;
    sa.sa_flags = SA_SIGINFO | SA_ONSTACK;
    sigaction(SIGSEGV, &sa, NULL);

    /* the discriminator from the ov1 crash: a big fully-faulted anon
     * region changes where churn mmaps land (above it, interleaved with
     * thread stacks) — ov1 crashed WITH it, wt1 (churn only) did not. */
    size_t big = 64UL << 20;
    void *b = mmap(NULL, big, PROT_READ | PROT_WRITE,
                   MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (b != MAP_FAILED) {
        memset(b, 0xAB, big);
        add_rec((uintptr_t)b, big, -1, -1);
        printf("big %lx-%lx\n", (unsigned long)b, (unsigned long)b + big);
    }
    pthread_t th[4];
    for (int i = 0; i < 4; i++)
        pthread_create(&th[i], NULL, churn, (void *)(uintptr_t)i);
    for (int i = 0; i < 4; i++) pthread_join(th[i], NULL);
    stop = 1;
    printf("WITNESS-DONE (no crash)\n");
    return 0;
}
