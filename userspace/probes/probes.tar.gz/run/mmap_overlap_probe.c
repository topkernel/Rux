/* mmap-overlap probe: does the address allocator ever hand out a range
 * INSIDE an existing VMA? Maps a big anon region, then churns small
 * mmaps (as threads do) and asserts every returned address range is
 * disjoint from the big one. Any overlap = the allocator bug (the
 * subsequent munmap of the small mapping carves the big one). */
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <sys/mman.h>
#include <pthread.h>
#include <unistd.h>

static uintptr_t big_start, big_end;
static volatile int overlaps, checked;

static void *churn(void *arg)
{
    (void)arg;
    for (int i = 0; i < 3000; i++) {
        size_t sz = 0x100000 + (i % 7) * 0x31000;
        void *m = mmap(NULL, sz, PROT_READ | PROT_WRITE,
                       MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (m == MAP_FAILED) continue;
        uintptr_t s = (uintptr_t)m, e = s + sz;
        __sync_fetch_and_add(&checked, 1);
        if (s < big_end && e > big_start) {
            printf("OVERLAP! mmap returned %p-%p inside big %lx-%lx\n",
                   m, (char *)m + sz,
                   (unsigned long)big_start, (unsigned long)big_end);
            __sync_fetch_and_add(&overlaps, 1);
        } else {
            memset(m, 3, 4096);
            munmap(m, sz);
        }
    }
    return NULL;
}

int main(void)
{
    size_t big = 64UL << 20;
    void *b = mmap(NULL, big, PROT_READ | PROT_WRITE,
                   MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (b == MAP_FAILED) { printf("big mmap failed\n"); return 2; }
    big_start = (uintptr_t)b;
    big_end = big_start + big;
    memset(b, 0xAB, big);              /* fault the WHOLE region in */
    printf("big region %lx-%lx\n", (unsigned long)big_start, (unsigned long)big_end);

    pthread_t th[4];
    for (int i = 0; i < 4; i++) pthread_create(&th[i], NULL, churn, NULL);
    for (int i = 0; i < 4; i++) pthread_join(th[i], NULL);

    unsigned char *p = b;
    long bad = 0;
    for (size_t i = 0; i < big; i += 4096)
        if (p[i] != 0xAB) bad++;
    printf("OVERLAP-DONE checked=%d overlaps=%d badpages=%ld\n",
           checked, overlaps, bad);
    return (overlaps || bad) ? 1 : 0;
}
