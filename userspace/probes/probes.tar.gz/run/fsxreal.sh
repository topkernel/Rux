#!/bin/bash
# fsxreal.sh — run the real LTP fsx-linux binary in the guest with TMPDIR
# on tmpfs; on failure fsx dumps its full operation log to stdout.
set -u
cd /home/william/rux-agents/ltp-fsx
K=run/fsx-bzImage
IMG=run/r4ltp-iso.img
LOG=run/fsxreal.log
FIFO=run/fsxreal.fifo
NOPS="${1:-50000}"
rm -f "$FIFO" "$LOG"; mkfifo "$FIFO"
exec 3<>"$FIFO"
(
  sleep 40
  printf '\n' >&3; sleep 2
  printf 'LTP_ENABLE_DEBUG=1 TMPDIR=/tmp /test/linux-ltp/testcases/bin/fsx-linux -N %s; echo FXW-RC=$?\n' "$NOPS" >&3
) &
FEEDER=$!
timeout --kill-after=10 420 qemu-system-x86_64 -M q35 -accel kvm -cpu max -m 2G -smp 2 \
  -display none -serial stdio -monitor none -no-reboot -snapshot \
  -drive file="${IMG}",if=none,id=rootfs,format=raw,file.locking=off \
  -device virtio-blk-pci,drive=rootfs \
  -kernel "$K" \
  -append "root=/dev/vda rw init=/bin/sh console=ttyS0" \
  < "$FIFO" > "$LOG" 2>&1
RC=$?
kill $FEEDER 2>/dev/null; exec 3>&-; rm -f "$FIFO"
echo "== fsxreal (qemu rc=$RC) =="
tr -d '\0' < "$LOG" | grep -vE 'ENQ-CLAIMED|open ENOENT|WW-P1|PARKWALK' | tail -95
