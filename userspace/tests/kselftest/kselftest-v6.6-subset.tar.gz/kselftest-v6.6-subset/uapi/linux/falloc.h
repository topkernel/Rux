/* Empty shim: musl <fcntl.h> already defines the FALLOC_FL_* constants
 * (KEEP_SIZE, PUNCH_HOLE, COLLAPSE_RANGE, ZERO_RANGE, INSERT_RANGE);
 * the reference v6.6 uapi/linux/falloc.h carries the same values. */
#ifndef _UAPI_LINUX_FALLOC_H_COMPAT
#define _UAPI_LINUX_FALLOC_H_COMPAT
#endif
