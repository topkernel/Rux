/* Shim: redirect to musl <fcntl.h>, which carries everything the memfd
 * test uses from the uapi header (F_ADD_SEALS/F_GET_SEALS/F_SEAL_*
 * consumers get them from there; the F_SEAL_* values themselves live in
 * the compat linux/memfd.h next to this file). The reference v6.6
 * uapi/linux/fcntl.h additionally defines F_NOTIFY/DN_* and
 * AT_RECURSIVE constants under their own guards. */
#ifndef _UAPI_LINUX_FCNTL_H_COMPAT
#define _UAPI_LINUX_FCNTL_H_COMPAT
#include <fcntl.h>
#endif
