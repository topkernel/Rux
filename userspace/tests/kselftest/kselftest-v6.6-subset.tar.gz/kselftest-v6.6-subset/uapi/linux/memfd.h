/* F_SEAL_* constants only, values verbatim from the reference kernel
 * v6.6 include/uapi/linux/memfd.h. The MFD_* flag block of the uapi
 * header is intentionally omitted: musl's <sys/mman.h> already owns
 * MFD_CLOEXEC/MFD_ALLOW_SEALING/MFD_HUGETLB/MFD_NOEXEC_SEAL/MFD_EXEC
 * and the duplicate definitions would collide. The upstream header's
 * asm-generic/hugetlb_encode.h include chain does not exist in musl. */
#ifndef _UAPI_LINUX_MEMFD_H_COMPAT
#define _UAPI_LINUX_MEMFD_H_COMPAT
#define F_SEAL_SEAL	0x0001
#define F_SEAL_SHRINK	0x0002
#define F_SEAL_GROW	0x0004
#define F_SEAL_WRITE	0x0008
#define F_SEAL_FUTURE_WRITE	0x0010
#ifndef MFD_EXEC
#define MFD_EXEC 0x0010
#endif
#ifndef MFD_HUGETLB
#define MFD_HUGETLB 0x0400
#endif
#ifndef MFD_NOEXEC_SEAL
#define MFD_NOEXEC_SEAL 0x0008
#endif
#endif
