/* tfprobe - SYSRET TF-guard + user-#DB SIGTRAP A/B probe.
 *
 * Arms TF once per iteration, lets the kernel deliver SIGTRAP for the
 * first stepped instruction (the kernel clears TF in the trap frame,
 * so the handler does NOT re-arm), then makes a syscall and repeats.
 * With the old unconditional do_exit in handle_debug this died on the
 * first trap; now it must run to completion.
 */
#include <stdio.h>
#include <unistd.h>
#include <signal.h>
#include <stdint.h>

static volatile unsigned long traps;

static void trap_handler(int sig) {
    (void)sig;
    traps++;
}

static inline void set_tf(void) {
    uint64_t flags;
    __asm__ volatile("pushfq\n\tpopq %0\n\torq $0x100, %0\n\tpushq %0\n\tpopfq"
                     : "=&r"(flags) :: "memory");
}
static inline void clear_tf(void) {
    uint64_t flags;
    __asm__ volatile("pushfq\n\tpopq %0\n\tbtrq $8, %0\n\tpushq %0\n\tpopfq"
                     : "=&r"(flags) :: "memory");
}

int main(void) {
    struct sigaction sa = {0};
    sa.sa_handler = trap_handler;
    sigaction(SIGTRAP, &sa, NULL);

    const int N = 200;
    unsigned long syscalls = 0;
    for (int i = 0; i < N; i++) {
        set_tf();
        (void)getppid();
        syscalls++;
        clear_tf();
    }
    printf("tfprobe: cycles=%lu traps=%lu\n", syscalls, traps);
    if (traps >= N / 2 && traps < N * 4) {
        printf("tfprobe: PASS\n");
        return 0;
    }
    printf("tfprobe: UNEXPECTED trap count\n");
    return 1;
}
