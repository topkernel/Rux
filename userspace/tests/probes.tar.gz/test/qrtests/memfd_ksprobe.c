/* memfd_ksprobe.c — the exact calls kselftest memfd_test.c makes in
 * its CREATE subtest before it can abort: empty-name create, size-0
 * ftruncate, size-set ftruncate. Prints errno via stderr + fflush so
 * nothing is lost if the guest dies (the kselftest binary aborts with
 * its stdout still buffered — that is what hid the failing call in the
 * first run). */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/syscall.h>
#include <unistd.h>

static int failures;

static void step(const char *what, long rc)
{
    fflush(stdout);
    if (rc < 0)
        failures++;
    fprintf(stderr, "KS-STEP %s: rc=%ld errno=%d (%s)\n", what, rc,
            rc < 0 ? errno : 0, rc < 0 ? strerror(errno) : "ok");
    fflush(stderr);
}

int main(void)
{
    long fd;

    errno = 0;
    fd = syscall(SYS_memfd_create, "", 0);
    step("memfd_create(\"\", 0)", fd);
    if (fd < 0)
        return 1;

    errno = 0;
    step("ftruncate(fd, 0)", ftruncate((int)fd, 0));

    errno = 0;
    step("ftruncate(fd, 4096)", ftruncate((int)fd, 4096));

    /* kselftest's second subtest BASIC also does mmap+write. Probe the
     * write path on the 4096-sized fd. */
    errno = 0;
    step("lseek(fd, 0, SEEK_SET)", lseek((int)fd, 0, SEEK_SET));
    errno = 0;
    step("write(fd, \"..\", 2)", write((int)fd, "..", 2));
    errno = 0;
    step("ftruncate(fd, 8192)", ftruncate((int)fd, 8192));

    close((int)fd);

    /* kselftest BASIC first block: create WITH MFD_ALLOW_SEALING,
     * ftruncate, then F_GET_SEALS must be 0. */
    errno = 0;
    fd = syscall(SYS_memfd_create, "kern_memfd_basic",
                 MFD_CLOEXEC | MFD_ALLOW_SEALING);
    step("memfd_create(basic, CLOEXEC|ALLOW_SEALING)", fd);
    if (fd < 0)
        return 1;
    errno = 0;
    step("ftruncate(fd, 512)", ftruncate((int)fd, 512));
    errno = 0;
    step("F_GET_SEALS (expect 0)", fcntl((int)fd, F_GET_SEALS));
    errno = 0;
    step("F_ADD_SEALS(SHRINK|WRITE) (expect 0)",
         fcntl((int)fd, F_ADD_SEALS, 0x0002 | 0x0008));
    errno = 0;
    step("F_GET_SEALS (expect 10)", fcntl((int)fd, F_GET_SEALS));
    close((int)fd);

    fprintf(stderr, "KS-VERDICT %s (%d failures)\n",
            failures ? "FAIL" : "PASS", failures);
    fflush(stderr);
    return failures ? 1 : 0;
}
