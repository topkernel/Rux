/*
 * qsrun.c — qa-suites lane PID-1 runner (the rsrun.c pattern, uniform
 * exec form). Reads /test/qa/cmds.txt, one invocation per line:
 *
 *   [<budget-secs>] <prog> [args...]
 *
 * budget defaults to 90s when omitted; prog without '/' resolves
 * under /test/qa/. Wall-clock guard: TERM at budget+30s, KILL at
 * budget+60s, "unreapable" at +120s. Stdout/stderr of the child are
 * captured to /tmp/qsrun.out and the flattened tail rides the RES
 * line. Protocol on serial:
 *
 *   QSRUN-BEGIN cmds=<file>
 *   QS-RUN <i>/<n> <line>
 *   RES|<name>|<rc>|<tail>[ T=<elapsed>s]     rc: 128+sig for signal
 *                                             deaths; TIMEOUT-TERM /
 *                                             TIMEOUT-KILL suffix marks
 *                                             the guard firing (= P0)
 *   QS-ALL-DONE
 *
 * PID 1 parks forever afterwards. Build: musl-gcc -static -O2 -Wall.
 */
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#define QA_DIR "/test/qa"
#define CMDS_FILE QA_DIR "/cmds.txt"
#define OUT_FILE "/tmp/qsrun.out"
#define TAIL_BYTES 400

static void emit_res(const char *name, int rc, const char *file,
                     long elapsed, const char *guard)
{
    char buf[TAIL_BYTES + 1];
    ssize_t got = 0;
    int fd = open(file, O_RDONLY);
    if (fd >= 0) {
        off_t sz = lseek(fd, 0, SEEK_END);
        ssize_t want = TAIL_BYTES;
        if (sz >= 0) {
            if (want > sz)
                want = (ssize_t)sz;
            if (lseek(fd, sz - want, SEEK_SET) >= 0)
                got = read(fd, buf, want);
        }
        close(fd);
    }
    char flat[TAIL_BYTES * 2 + 1];
    size_t o = 0;
    for (ssize_t i = 0; i < got; i++) {
        char c = buf[i];
        if (c == '\n' || c == '\r' || c == '\t')
            flat[o++] = ' ';
        else if ((unsigned char)c >= 0x20)
            flat[o++] = c;
        if (o >= sizeof(flat) - 1)
            break;
    }
    while (o > 0 && flat[o - 1] == ' ')
        o--;
    flat[o] = '\0';
    printf("RES|%s|%d|%s T=%lds%s\n", name, rc, flat, elapsed,
           guard && guard[0] ? guard : "");
    fflush(stdout);
}

static void run_one(int idx, int total, const char *line)
{
    static char tok[1024];
    char *args[64];
    int nargs = 0;
    snprintf(tok, sizeof tok, "%s", line);

    int budget = 90;
    char *save = NULL, *t = strtok_r(tok, " \t", &save);
    if (!t)
        return;
    /* optional leading all-digit budget token */
    int allnum = t[0] >= '0' && t[0] <= '9' && t[1];
    for (const char *c = t; *c; c++)
        if (*c < '0' || *c > '9')
            allnum = 0;
    if (allnum) {
        budget = atoi(t);
        if (budget < 1)
            budget = 1;
        t = strtok_r(NULL, " \t", &save);
        if (!t)
            return;
    }
    /* program token: resolve bare names under QA_DIR */
    static char prog[512];
    if (strchr(t, '/'))
        snprintf(prog, sizeof prog, "%s", t);
    else
        snprintf(prog, sizeof prog, "%s/%s", QA_DIR, t);
    args[nargs++] = prog;
    t = strtok_r(NULL, " \t", &save);
    while (t && nargs < 62) {
        args[nargs++] = t;
        t = strtok_r(NULL, " \t", &save);
    }
    args[nargs] = NULL;

    const char *b = strrchr(prog, '/');
    char name[64];
    snprintf(name, sizeof name, "%s", b ? b + 1 : prog);

    printf("QS-RUN %d/%d %s\n", idx, total, line);
    fflush(stdout);

    int outfd = open(OUT_FILE, O_CREAT | O_TRUNC | O_RDWR, 0644);
    int devnull = open("/dev/null", O_RDONLY);
    if (outfd < 0) {
        printf("RES|%s|252|open-out-failed\n", name);
        fflush(stdout);
        return;
    }
    pid_t pid = fork();
    if (pid < 0) {
        printf("RES|%s|253|fork-failed\n", name);
        fflush(stdout);
        close(outfd);
        return;
    }
    if (pid == 0) {
        if (devnull >= 0)
            dup2(devnull, 0);
        dup2(outfd, 1);
        dup2(outfd, 2);
        setenv("PATH", "/bin:/sbin:" QA_DIR, 1);
        setenv("TMPDIR", "/tmp", 1);
        execv(prog, args);
        dprintf(1, "exec-failed: %s: %s\n", prog, strerror(errno));
        _exit(127);
    }
    if (devnull >= 0)
        close(devnull);

    long term_ms = (long)budget * 1000 + 30000;
    long kill_ms = (long)budget * 1000 + 60000;
    struct timespec ts200 = { 0, 200 * 1000 * 1000 };
    long elapsed_ms = 0;
    int termd = 0, killed = 0, status = 0;
    const char *guard = "";
    for (;;) {
        pid_t r = waitpid(pid, &status, WNOHANG);
        if (r == pid)
            break;
        if (r < 0 && errno != EINTR) {
            status = 254;
            break;
        }
        nanosleep(&ts200, NULL);
        elapsed_ms += 200;
        if (elapsed_ms >= kill_ms && !killed) {
            kill(pid, SIGKILL);
            killed = 1;
            guard = " TIMEOUT-KILL";
        } else if (elapsed_ms >= term_ms && !termd) {
            kill(pid, SIGTERM);
            termd = 1;
            guard = " TIMEOUT-TERM";
        } else if (killed && elapsed_ms >= kill_ms + 60000) {
            printf("RES|%s|251|unreapable T=%lds\n", name, elapsed_ms / 1000);
            fflush(stdout);
            close(outfd);
            return;
        }
    }
    close(outfd);

    int rc;
    if (WIFSIGNALED(status))
        rc = 128 + WTERMSIG(status);
    else if (WIFEXITED(status))
        rc = WEXITSTATUS(status);
    else
        rc = 255;
    emit_res(name, rc, OUT_FILE, elapsed_ms / 1000, guard);
}

int main(void)
{
    int cons = open("/dev/console", O_WRONLY);
    if (cons >= 0) {
        dup2(cons, 1);
        dup2(cons, 2);
        if (cons > 2)
            close(cons);
    }
    setvbuf(stdout, NULL, _IONBF, 0);
    setenv("PATH", "/bin:/sbin:" QA_DIR, 1);
    setenv("TMPDIR", "/tmp", 1);

    /* count lines first so QS-RUN can carry i/n */
    int total = 0;
    FILE *f = fopen(CMDS_FILE, "r");
    if (f) {
        char line[1024];
        while (fgets(line, sizeof line, f)) {
            size_t n = strlen(line);
            while (n > 0 && (line[n - 1] == '\n' || line[n - 1] == '\r'))
                line[--n] = '\0';
            if (n == 0 || line[0] == '#')
                continue;
            total++;
        }
        fclose(f);
    }

    printf("QSRUN-BEGIN cmds=%s n=%d\n", CMDS_FILE, total);
    fflush(stdout);
    f = fopen(CMDS_FILE, "r");
    if (!f) {
        printf("QSRUN-NO-CMDS\n");
        fflush(stdout);
    } else {
        char line[1024];
        int idx = 0;
        while (fgets(line, sizeof line, f)) {
            size_t n = strlen(line);
            while (n > 0 && (line[n - 1] == '\n' || line[n - 1] == '\r'))
                line[--n] = '\0';
            if (n == 0 || line[0] == '#')
                continue;
            run_one(++idx, total, line);
        }
        fclose(f);
        printf("QS-ALL-DONE\n");
        fflush(stdout);
    }
    for (;;)
        sleep(3600);
    return 0;
}
