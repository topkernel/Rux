/*
 * memfdsysctl.c — step-isolated replica of kselftest memfd_test's
 * test_sysctl_nested "0 -> 1 after fork" leg (the round-4 F-4 next
 * failure site: "write sysctl 0 succeeded, but failure expected").
 * Every step prints before it runs, so the serial log names the exact
 * leg. Expected reference behavior:
 *   - C1 (ns-A init) writes 0 to /proc/sys/vm/memfd_noexec  -> ok
 *   - C1 spawns C2 (CLONE_NEWPID, ns-C) which SIGSTOPs itself
 *   - C1 writes 1                                              -> ok
 *   - C1 SIGCONTs C2; C2 reads the sysctl (effective = 1 via the
 *     ancestor chain) and writes "0" -> must FAIL (EINVAL: a write
 *     below the parent chain's effective scope is refused).
 * Build: musl-gcc -static -O2 -Wall -D_GNU_SOURCE
 */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <sched.h>
#include <stdio.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>

#define STACK_SIZE (256 * 1024)
#define SYSCTL "/proc/sys/vm/memfd_noexec"

#define STEP(msg) do { printf("STEP %s\n", msg); fflush(stdout); } while (0)
#define OK(msg) do { printf("OK   %s\n", msg); fflush(stdout); } while (0)
#define BAD(fmt, ...) do { \
    printf("BAD  " fmt "\n", ##__VA_ARGS__); fflush(stdout); _exit(9); \
} while (0)

static int sysctl_read(void)
{
    char buf[32];
    int fd = open(SYSCTL, O_RDONLY | O_CLOEXEC);
    ssize_t n;

    if (fd < 0)
        BAD("open sysctl read: errno=%d", errno);
    n = read(fd, buf, sizeof(buf) - 1);
    close(fd);
    if (n <= 0)
        BAD("read sysctl: errno=%d", errno);
    buf[n] = 0;
    printf("     sysctl reads [%.*s]\n", (int)(n && buf[n-1]=='\n' ? n-1 : n), buf);
    fflush(stdout);
    return atoi(buf);
}

/* returns 0 ok, -1 failed (errno printed) */
static int sysctl_write(const char *val)
{
    int fd = open(SYSCTL, O_WRONLY | O_CLOEXEC);
    ssize_t r;

    if (fd < 0)
        BAD("open sysctl write: errno=%d", errno);
    r = write(fd, val, strlen(val));
    if (r < 0)
        printf("     write '%s' -> -1 errno=%d (%s)\n", val, errno, strerror(errno));
    else
        printf("     write '%s' -> %zd\n", val, r);
    fflush(stdout);
    close(fd);
    return r < 0 ? -1 : 0;
}

static int nested_wait_child(void *arg)
{
    (void)arg;
    STEP("c2-spawned (fresh pidns); SIGSTOP self");
    kill(getpid(), SIGSTOP);
    STEP("c2-awake (SIGCONT)");
    if (sysctl_read() != 1)
        BAD("c2 effective read != 1 (chain max broken)");
    if (sysctl_write("0") == 0)
        BAD("c2 write 0 SUCCEEDED — reference refuses (floor = parent effective 1)");
    OK("c2 write 0 refused as reference requires");
    STEP("c2-done");
    _exit(0);
}

static int ns_child(void *arg)
{
    (void)arg;
    STEP("c1-in-new-pidns");
    sysctl_read();
    if (sysctl_write("0") != 0)
        BAD("c1 write 0 failed");
    OK("c1 write 0 ok");

    {
        char *stack = malloc(STACK_SIZE);
        pid_t c2;
        int st;

        if (!stack)
            BAD("malloc stack");
        STEP("c1-spawn-c2 CLONE_NEWPID (self-SIGSTOP child)");
        c2 = clone(nested_wait_child, stack + STACK_SIZE, SIGCHLD | CLONE_NEWPID, NULL);
        if (c2 < 0)
            BAD("clone c2: errno=%d", errno);
        /* give the child a moment to reach its SIGSTOP park */
        sleep(1);
        STEP("c1-write-1");
        if (sysctl_write("1") != 0)
            BAD("c1 write 1 failed");
        OK("c1 write 1 ok");
        STEP("c1-sigcont-c2");
        if (kill(c2, SIGCONT) < 0)
            BAD("kill SIGCONT: errno=%d", errno);
        if (waitpid(c2, &st, 0) < 0)
            BAD("c1 waitpid c2: errno=%d", errno);
        if (WIFEXITED(st) && WEXITSTATUS(st) == 0)
            OK("c2 exited 0");
        else
            BAD("c2 bad status: %d", st);
        STEP("c1-done");
    }
    _exit(0);
}

int main(void)
{
    char *stack;
    pid_t c1;
    int st;

    STEP("p0-root-ns start; sysctl read");
    sysctl_read();

    stack = malloc(STACK_SIZE);
    if (!stack)
        BAD("malloc stack");
    STEP("p0-spawn-c1 CLONE_NEWPID");
    c1 = clone(ns_child, stack + STACK_SIZE, SIGCHLD | CLONE_NEWPID, NULL);
    if (c1 < 0)
        BAD("clone c1: errno=%d", errno);
    if (waitpid(c1, &st, 0) < 0)
        BAD("p0 waitpid c1: errno=%d", errno);
    if (!(WIFEXITED(st) && WEXITSTATUS(st) == 0))
        BAD("c1 bad status: %d", st);
    OK("p0-all-green");
    return 0;
}
