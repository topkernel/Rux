/* schedprobe.c — qa-suites lane: which sched call fails and with what
 * errno (cyclictest check_privs dies at "unable to get scheduler
 * parameters"). Prints one line per call on serial. musl static. */
#include <errno.h>
#include <sched.h>
#include <stdio.h>
#include <string.h>
#include <sys/syscall.h>
#include <unistd.h>

int main(void)
{
    struct sched_param sp;
    int pol, rc;
    errno = 0;
    pol = sched_getscheduler(0);
    printf("P sched_getscheduler=%d errno=%d (%s)\n", pol, errno,
           strerror(errno));

    memset(&sp, 0xab, sizeof sp);
    errno = 0;
    rc = sched_getparam(0, &sp);
    printf("P sched_getparam=%d errno=%d (%s) prio=%d\n", rc, errno,
           strerror(errno), sp.sched_priority);

    errno = 0;
    rc = syscall(SYS_sched_getparam, 0, &sp);
    printf("P raw SYS_sched_getparam=%ld errno=%d (%s)\n", (long)rc, errno,
           strerror(errno));

    sp.sched_priority = 1;
    errno = 0;
    rc = sched_setscheduler(0, SCHED_FIFO, &sp);
    printf("P sched_setscheduler(FIFO,1)=%d errno=%d (%s)\n", rc, errno,
           strerror(errno));

    errno = 0;
    pol = sched_getscheduler(0);
    printf("P sched_getscheduler(after)=%d errno=%d (%s)\n", pol, errno,
           strerror(errno));
    fflush(stdout);
    return 0;
}
