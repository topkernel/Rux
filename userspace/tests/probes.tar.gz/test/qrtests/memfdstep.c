/*
 * memfdstep.c — step-isolated replica of kselftest memfd_test's
 * test_seal_future_write (the round-3 abort site). Prints STEP markers
 * so the serial log names the failing leg without a debugger.
 * Build: musl-gcc -static -O2 -Wall -D_GNU_SOURCE
 */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>

#ifndef F_ADD_SEALS
#define F_ADD_SEALS 1031
#define F_GET_SEALS 1032
#endif
#ifndef F_SEAL_FUTURE_WRITE
#define F_SEAL_FUTURE_WRITE 0x0010
#endif
#ifndef MFD_ALLOW_SEALING
#define MFD_ALLOW_SEALING 0x0002
#endif
#ifndef MFD_CLOEXEC
#define MFD_CLOEXEC 0x0001
#endif

#define SIZE (8 * 1024 * 1024)

static int memfd_create_(const char *name, unsigned int flags)
{
    return syscall(__NR_memfd_create, name, flags);
}

#define STEP(msg) do { printf("STEP %s\n", msg); fflush(stdout); } while (0)
#define OK(msg) do { printf("OK   %s\n", msg); fflush(stdout); } while (0)
#define BAD(msg) do { printf("BAD  %s errno=%d (%s)\n", msg, errno, strerror(errno)); fflush(stdout); _exit(9); } while (0)

int main(void)
{
    char buf[128];
    int fd, fd2, r;
    void *p;

    STEP("create");
    fd = memfd_create_("probe", MFD_CLOEXEC | MFD_ALLOW_SEALING);
    if (fd < 0) BAD("memfd_create");
    if (ftruncate(fd, SIZE) < 0) BAD("ftruncate");

    STEP("mmap-shared");
    p = mmap(NULL, SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, fd, 0);
    if (p == MAP_FAILED) BAD("mmap shared");
    memset(p, 0xaa, 4096);
    OK("shared write via mapping");

    STEP("add-FUTURE_WRITE");
    r = fcntl(fd, F_ADD_SEALS, F_SEAL_FUTURE_WRITE);
    if (r < 0) BAD("F_ADD_SEALS");
    r = fcntl(fd, F_GET_SEALS);
    printf("     seals=0x%x\n", r); fflush(stdout);

    STEP("read");
    r = pread(fd, buf, 8, 0);
    if (r != 8) BAD("pread");

    STEP("fail-write");
    r = pwrite(fd, "xx", 2, 0);
    if (r >= 0) BAD("write under FUTURE_WRITE succeeded");
    if (errno != EPERM) BAD("write errno != EPERM");
    OK("write EPERM");

    STEP("reopen-/proc/self/fd");
    snprintf(buf, sizeof buf, "/proc/self/fd/%d", fd);
    fd2 = open(buf, O_RDWR);
    if (fd2 < 0) BAD("reopen /proc/self/fd");
    OK("reopen ok");

    STEP("read-via-fd2");
    r = pread(fd2, buf, 8, 0);
    if (r != 8) BAD("pread fd2");

    STEP("fail-write-via-fd2");
    r = pwrite(fd2, "xx", 2, 0);
    if (r >= 0) BAD("write via fd2 succeeded");
    if (errno != EPERM) BAD("write fd2 errno != EPERM");
    OK("fd2 write EPERM");

    STEP("fork-private-write upstream-shape");
    {
        int *q = mmap(NULL, SIZE, PROT_READ | PROT_WRITE, MAP_PRIVATE, fd, 0);
        if (q == MAP_FAILED) BAD("mmap private");
        STEP("parent-private-write");
        q[0] = 22;
        pid_t pid = fork();
        if (pid < 0) BAD("fork");
        if (pid == 0) {
            STEP("child-cow-write");
            q[0] = 33;
            OK("child wrote 33");
            _exit(0);
        }
        r = waitpid(pid, NULL, 0);
        if (r != pid) BAD("waitpid");
        STEP("parent-cow-check");
        if (q[0] != 22) BAD("COW failed: parent saw child's write");
        OK("COW isolated");
        munmap(q, SIZE);
    }

    STEP("child-reopen-private (round-3 probe variant)");
    {
        pid_t pid = fork();
        if (pid < 0) BAD("fork2");
        if (pid == 0) {
            char pbuf[128];
            int cfd;
            void *cp;
            snprintf(pbuf, sizeof pbuf, "/proc/%d/fd/%d", getppid(), fd);
            cfd = open(pbuf, O_RDWR);
            if (cfd < 0) BAD("child open /proc/ppid/fd");
            cp = mmap(NULL, SIZE, PROT_READ | PROT_WRITE, MAP_PRIVATE, cfd, 0);
            if (cp == MAP_FAILED) BAD("child mmap private");
            memset(cp, 0xbb, 4096);
            OK("child private write done");
            _exit(0);
        }
        r = waitpid(pid, NULL, 0);
        if (r != pid) BAD("waitpid2");
        OK("child2 reaped");
    }

    STEP("parent-map-intact");
    if (*((unsigned char *)p) != 0xaa) BAD("parent map corrupted by child");
    OK("parent map intact");

    STEP("DONE");
    return 0;
}
