/*
 * futex_requeue_probe.c — FUTEX_REQUEUE chain-migration reproducer.
 *
 * The OH FFRT wedge shape (ffrt-park-analysis.md §4-5): musl's
 * pthread_cond_timedwait chains cond wakeups through the kernel —
 * a signaled waiter leaving the cv requeues the NEXT waiter of the
 * signaled batch off that waiter's own "barrier" word and onto the
 * mutex word (FUTEX_REQUEUE|PRIVATE, wake=0, requeue=1), and the
 * mutex unlock's FUTEX_WAKE(mutex,1) hands off to it.  If the kernel
 * drops a waiter during the chain migration (stale-bucket unlink,
 * lost relink), the unlock's wake never reaches that waiter and it
 * parks until its watchdog timeout — a MISSED WAKE.
 *
 * Phase A replays the exact musl protocol with raw futex syscalls
 * (musl src/thread/pthread_cond_timedwait.c, unlock_requeue lines
 * 48-54 / epilogue lines 149-160):
 *
 *   waiter i: barrier=2 (own stack word), park on WAIT(barrier==2)
 *   signaler: store 0 to the oldest barrier + WAKE(oldest,1)
 *             (musl __private_cond_signal unlocks only the FIRST
 *              barrier — the rest travel by requeue)
 *   woken i:  relock mutex word (futex WAIT on it while held),
 *             stamp 0x80000000, store 0 + REQUEUE(succ barrier ->
 *             mutex word, 0, 1), unlock with WAKE(mutex,1)
 *
 * A waiter that returns ETIMEDOUT instead of being delivered is a
 * miss.  An optional SIGUSR1 kicker widens the signal-vs-requeue
 * races (the kernel's sleeper-side unlink window).
 *
 * Phase B does the same at the library level: pthread_cond_broadcast
 * + mutex relock churn with timed waits (musl REQUEUE / glibc
 * CMP_REQUEUE under the hood, whichever libc this binary was built
 * with).
 *
 * Verdict: "FRQ PROBE RESULT: PASS|FAIL ..." as the last line.
 * Usage: futex_requeue_probe [rounds] [kick|nokick]
 */
#define _GNU_SOURCE
#include <errno.h>
#include <pthread.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/syscall.h>
#include <time.h>
#include <unistd.h>

#ifndef SYS_futex
#if defined(__x86_64__) || defined(_M_X64)
#define SYS_futex 202
#elif defined(__riscv) && __riscv_xlen == 64
#define SYS_futex 226
#elif defined(__aarch64__)
#define SYS_futex 98
#else
#error "no SYS_futex for this arch"
#endif
#endif

#ifndef FUTEX_WAIT
#define FUTEX_WAIT 0
#define FUTEX_WAKE 1
#define FUTEX_REQUEUE 3
#define FUTEX_PRIVATE_FLAG 128
#endif

#define NWAIT 8
#define WATCHDOG_MS 2000

static long fr(long a, long b, long c, long d, long e, long f)
{
    return syscall(SYS_futex, a, b, c, d, e, f);
}

static long fx_wait(volatile uint32_t *a, uint32_t v, const struct timespec *to)
{
    return fr((long)a, FUTEX_WAIT | FUTEX_PRIVATE_FLAG, v, (long)to, 0, 0);
}

static long fx_wake(volatile uint32_t *a, int n)
{
    return fr((long)a, FUTEX_WAKE | FUTEX_PRIVATE_FLAG, n, 0, 0, 0);
}

/* musl unlock_requeue: REQUEUE(uaddr, wake=0, requeue=1, uaddr2=mutex),
 * falling back to non-private on ENOSYS exactly like musl. */
static long fx_requeue(volatile uint32_t *a, volatile uint32_t *m)
{
    long r = fr((long)a, FUTEX_REQUEUE | FUTEX_PRIVATE_FLAG, 0, 1, (long)m, 0);
    if (r == -1 && errno == ENOSYS)
        r = fr((long)a, FUTEX_REQUEUE, 0, 1, (long)m, 0);
    return r;
}

static struct timespec abs_deadline_clock(long ms, clockid_t clk)
{
    struct timespec now, to;
    clock_gettime(clk, &now);
    to.tv_sec = now.tv_sec + ms / 1000;
    to.tv_nsec = now.tv_nsec + (ms % 1000) * 1000000L;
    if (to.tv_nsec >= 1000000000L) {
        to.tv_sec++;
        to.tv_nsec -= 1000000000L;
    }
    return to;
}

/* Raw FUTEX_WAIT timeouts are relative to CLOCK_MONOTONIC. */
static struct timespec rel_deadline(long ms)
{
    return abs_deadline_clock(ms, CLOCK_MONOTONIC);
}

/* pthread_cond_timedwait deadlines are in the condvar's clock —
 * CLOCK_REALTIME unless attr-changed (musl and glibc both). */
static struct timespec cond_deadline(long ms)
{
    return abs_deadline_clock(ms, CLOCK_REALTIME);
}

/* ---------------- Phase A: raw-syscall musl protocol ---------------- */

struct slot {
    uint32_t barrier;   /* waiter's "own stack" barrier word */
    volatile int published;
};
static struct slot A[NWAIT];
static volatile uint32_t mlock;         /* the mutex word */
static volatile int a_parked;           /* waiters currently parked */
static volatile long a_completed[NWAIT];
static volatile long a_miss;            /* ETIMEDOUT deliveries = missed wakes */
static volatile long a_requeue_calls;
static volatile long a_requeue_err;     /* REQUEUE syscalls that errored */
static volatile long a_rounds_done;
static volatile int a_stop;
static int a_kick;
static pthread_t a_th[NWAIT];

static void kick_handler(int sig)
{
    (void)sig;
}

static void *a_waiter(void *arg)
{
    long id = (long)arg;
    int succ_ok = id + 1 < NWAIT;
    struct slot *succ = &A[id + 1];

    while (!a_stop) {
        /* arm and publish, musl waiter-node style */
        A[id].barrier = 2;
        __sync_synchronize();
        __sync_fetch_and_add(&a_parked, 1);

        for (;;) {
            if (A[id].barrier == 0)
                break;              /* signaled before the WAIT issued */
            struct timespec to = rel_deadline(WATCHDOG_MS);
            long r = fx_wait(&A[id].barrier, 2, &to);
            if (r == 0)
                break;              /* delivered: barrier wake or requeue
                                   handoff through the mutex word */
            if (errno == ETIMEDOUT) {
                __sync_fetch_and_add(&a_miss, 1);
                break;
            }
            if (errno == EAGAIN || errno == EINTR)
                continue;           /* word moved under us / kicker */
            fprintf(stderr, "A[%ld]: WAIT errno %d\n", id, errno);
            exit(3);
        }
        __sync_fetch_and_add(&a_parked, -1);

        /* musl epilogue: relock the mutex (contend on the word), requeue
         * the successor onto it, unlock with a single wake. */
        for (;;) {
            uint32_t v = mlock;
            if (v == 0) {
                if (__sync_bool_compare_and_swap(&mlock, 0, 1))
                    break;
                continue;
            }
            uint32_t w = v | 0x80000000u;
            if (w == v || __sync_bool_compare_and_swap(&mlock, v, w)) {
                struct timespec to = rel_deadline(WATCHDOG_MS);
                long r = fx_wait(&mlock, w, &to);
                if (r == -1 && errno == ETIMEDOUT)
                    __sync_fetch_and_add(&a_miss, 1);
            }
        }
        if (succ_ok) {
            __sync_synchronize();
            __sync_fetch_and_add(&a_requeue_calls, 1);
            __sync_synchronize();
            succ->barrier = 0;      /* musl a_store(l,0) in unlock_requeue */
            long r = fx_requeue(&succ->barrier, &mlock);
            if (r == -1 && errno != ENOSYS)
                __sync_fetch_and_add(&a_requeue_err, 1);
        }
        /* unlock: the 0x80000000 stamp means a waiter is parked on the
         * word — musl unlock wakes exactly one. */
        __sync_lock_test_and_set(&mlock, 0);
        fx_wake(&mlock, 1);
        __sync_fetch_and_add(&a_completed[id], 1);
    }
    return NULL;
}

static void *a_kicker(void *arg)
{
    (void)arg;
    unsigned seed = 12345;
    while (!a_stop) {
        usleep(20 + rand_r(&seed) % 80);
        if (!a_stop)
            pthread_kill(a_th[rand_r(&seed) % NWAIT], SIGUSR1);
    }
    return NULL;
}

static int phase_a(int rounds)
{
    if (a_kick) {
        signal(SIGUSR1, kick_handler);
    }
    pthread_t th[NWAIT];
    for (long i = 0; i < NWAIT; i++)
        if (pthread_create(&th[i], NULL, a_waiter, (void *)i) != 0) {
            fprintf(stderr, "FRQ A: pthread_create failed\n");
            exit(3);
        }
    for (long i = 0; i < NWAIT; i++)
        a_th[i] = th[i];
    pthread_t kick_th = {0};
    if (a_kick)
        pthread_create(&kick_th, NULL, a_kicker, NULL);

    long stuck = 0;
    for (int r = 1; r <= rounds; r++) {
        /* wait for all waiters parked */
        long deadline = time(NULL) + (WATCHDOG_MS / 1000) * 2 + 4;
        while (__sync_fetch_and_add(&a_parked, 0) != NWAIT) {
            if (time(NULL) > deadline)
                break;              /* a waiter never parked: heal below */
            sched_yield();
        }
        /* signal: musl __private_cond_signal wakes only the OLDEST
         * waiter's barrier; the rest must travel by REQUEUE. */
        __sync_synchronize();
        A[0].barrier = 0;
        fx_wake(&A[0].barrier, 1);

        /* wait for the round to complete */
        long want = (long)r;
        deadline = time(NULL) + (WATCHDOG_MS / 1000) * 2 + 4;
        for (;;) {
            int all = 1;
            for (int i = 0; i < NWAIT; i++)
                if (__sync_fetch_and_add(&a_completed[i], 0) < want) {
                    all = 0;
                    break;
                }
            if (all)
                break;
            if (time(NULL) > deadline) {
                /* chain stalled: force-heal every word so the run can
                 * continue and the stall is counted. */
                stuck++;
                for (int i = 0; i < NWAIT; i++) {
                    A[i].barrier = 0;
                    fx_wake(&A[i].barrier, 1);
                }
                fx_wake(&mlock, NWAIT);
                deadline = time(NULL) + (WATCHDOG_MS / 1000) * 2 + 4;
            }
            sched_yield();
        }
        if (r % 1000 == 0) {
            printf("FRQ A: round %d/%d misses=%ld stuck=%ld\n",
                   r, rounds, a_miss, stuck);
            fflush(stdout);
        }
    }
    a_stop = 1;
    for (int i = 0; i < NWAIT; i++) {
        A[i].barrier = 0;
        fx_wake(&A[i].barrier, 1);
    }
    fx_wake(&mlock, NWAIT);
    if (a_kick)
        pthread_join(kick_th, NULL);
    for (int i = 0; i < NWAIT; i++)
        pthread_join(th[i], NULL);
    a_rounds_done = rounds;
    printf("FRQ A: rounds=%ld misses=%ld stuck=%ld requeue_calls=%ld requeue_err=%ld\n",
           a_rounds_done, a_miss, stuck, a_requeue_calls, a_requeue_err);
    fflush(stdout);
    return a_miss == 0 && stuck == 0 && a_requeue_err == 0;
}

/* ---------------- Phase B: library-level cond churn ---------------- */

static pthread_mutex_t bm = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t bc = PTHREAD_COND_INITIALIZER;
static volatile long b_gen;
static volatile long b_completed[NWAIT];
static volatile long b_miss;
static volatile int b_stop;

static void *b_waiter(void *arg)
{
    long id = (long)arg;
    long seen = 0;
    while (!b_stop) {
        pthread_mutex_lock(&bm);
        while (!b_stop && b_gen == seen) {
            struct timespec to = cond_deadline(WATCHDOG_MS);
            int rc = pthread_cond_timedwait(&bc, &bm, &to);
            if (rc == ETIMEDOUT)
                __sync_fetch_and_add(&b_miss, 1);
            else if (rc != 0) {
                fprintf(stderr, "B[%ld]: cond_timedwait rc=%d\n", id, rc);
                pthread_mutex_unlock(&bm);
                exit(3);
            }
        }
        if (b_stop) {
            pthread_mutex_unlock(&bm);
            break;
        }
        seen = b_gen;
        pthread_mutex_unlock(&bm);
        __sync_fetch_and_add(&b_completed[id], 1);
    }
    return NULL;
}

static int phase_b(int rounds)
{
    pthread_t th[NWAIT];
    for (long i = 0; i < NWAIT; i++)
        if (pthread_create(&th[i], NULL, b_waiter, (void *)i) != 0) {
            fprintf(stderr, "FRQ B: pthread_create failed\n");
            exit(3);
        }
    for (int r = 1; r <= rounds; r++) {
        pthread_mutex_lock(&bm);
        b_gen++;
        pthread_cond_broadcast(&bc);
        pthread_mutex_unlock(&bm);
        long want = (long)r;
        long deadline = time(NULL) + (WATCHDOG_MS / 1000) * 2 + 4;
        for (;;) {
            int all = 1;
            for (int i = 0; i < NWAIT; i++)
                if (__sync_fetch_and_add(&b_completed[i], 0) < want) {
                    all = 0;
                    break;
                }
            if (all)
                break;
            if (time(NULL) > deadline) {
                /* stalled: re-broadcast to heal; count it via misses */
                __sync_fetch_and_add(&b_miss, 1);
                pthread_mutex_lock(&bm);
                pthread_cond_broadcast(&bc);
                pthread_mutex_unlock(&bm);
                deadline = time(NULL) + (WATCHDOG_MS / 1000) * 2 + 4;
            }
            sched_yield();
        }
        if (r % 1000 == 0) {
            printf("FRQ B: round %d/%d misses=%ld\n", r, rounds, b_miss);
            fflush(stdout);
        }
    }
    b_stop = 1;
    pthread_mutex_lock(&bm);
    pthread_cond_broadcast(&bc);
    pthread_mutex_unlock(&bm);
    for (int i = 0; i < NWAIT; i++)
        pthread_join(th[i], NULL);
    printf("FRQ B: rounds=%d misses=%ld\n", rounds, b_miss);
    fflush(stdout);
    return b_miss == 0;
}

int main(int argc, char **argv)
{
    int rounds = argc > 1 ? atoi(argv[1]) : 10000;
    /* kicker ON by default (the kernel drops init argv, so the boot
     * runs defaults): SIGUSR1 rain widens the signal-vs-requeue races */
    a_kick = argc > 2 ? strcmp(argv[2], "kick") == 0 : 1;

    printf("FRQ: futex requeue chain probe rounds=%d waiters=%d kick=%d\n",
           rounds, NWAIT, a_kick);
    fflush(stdout);

    /* warm-up: 50 rounds to shake out setup issues before counting */
    int a_ok = phase_a(rounds);
    int b_ok = phase_b(rounds);

    if (a_ok && b_ok) {
        printf("FRQ PROBE RESULT: PASS misses=0\n");
        return 0;
    }
    printf("FRQ PROBE RESULT: FAIL a_ok=%d b_ok=%d a_miss=%ld a_requeue_err=%ld b_miss=%ld\n",
           a_ok, b_ok, a_miss, a_requeue_err, b_miss);
    return 1;
}
