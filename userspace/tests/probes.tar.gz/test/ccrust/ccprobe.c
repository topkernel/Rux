// ccprobe.c — ext4 crash-consistency marker probe (static, x86_64).
//
// Run as init (init=/ccprobe). Mounts /dev/vdb (ext4) on /mnt, then writes
// marker files. Modes:
//   ccprobe fsync-loop [N] [gap_ms]   write N markers, fsync each, paced
//   ccprobe plain-loop [N] [gap_ms]   write N markers, NO fsync (writeback)
//   ccprobe fsync-once                ONE marker + fsync + DONE line
// Prints "MARK <i> done" per marker (after fsync returns where applicable)
// and "CCLOOP-DONE" at the end, all to stdout (serial console).
#define _GNU_SOURCE
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mount.h>
#include <sys/stat.h>
#include <time.h>
#include <sys/types.h>
#include <unistd.h>

static int emit(const char *s)
{
    return (int)write(1, s, strlen(s));
}

int main(int argc, char **argv)
{
    char mode[32] = "fsync-loop";
    int n = 3000, gap_ms = 30;

    // Mode comes from /cc.cfg (debugfs-injected per run): "mode n gap_ms".
    FILE *cfg = fopen("/cc.cfg", "r");
    if (cfg) {
        char cm[32];
        if (fscanf(cfg, "%31s %d %d", cm, &n, &gap_ms) == 3)
            memcpy(mode, cm, sizeof(mode));
        fclose(cfg);
    }
    emit("CCPROBE: mode=");
    emit(mode);
    emit("\n");

    mkdir("/mnt", 0755);
    emit("CCPROBE: mounting /dev/vdb\n");
    if (mount("/dev/vdb", "/mnt", "ext4", 0, NULL) != 0) {
        emit("CCMOUNT-FAIL\n");
        return 3;
    }
    emit("CCMOUNT-OK\n");

    int do_fsync = strcmp(mode, "plain-loop") != 0;

    for (int i = 1; i <= n; i++) {
        char path[64], buf[64], msg[64];
        snprintf(path, sizeof(path), "/mnt/m%d", i);
        int fd = open(path, O_CREAT | O_WRONLY | O_TRUNC, 0644);
        if (fd < 0) {
            snprintf(msg, sizeof(msg), "CCOPEN-FAIL %d\n", i);
            emit(msg);
            return 4;
        }
        int len = snprintf(buf, sizeof(buf), "marker-%d-cc\n", i);
        if (write(fd, buf, len) != len) {
            emit("CCWRITE-FAIL\n");
            return 5;
        }
        if (do_fsync && fsync(fd) != 0) {
            snprintf(msg, sizeof(msg), "CCFSYNC-FAIL %d\n", i);
            emit(msg);
            return 6;
        }
        close(fd);
        snprintf(msg, sizeof(msg), "MARK %d done\n", i);
        emit(msg);
        if (gap_ms > 0) {
            struct timespec ts = {gap_ms / 1000, (gap_ms % 1000) * 1000000L};
            nanosleep(&ts, NULL);
        }
    }
    emit("CCLOOP-DONE\n");

    if (strcmp(mode, "fsync-clean") == 0) {
        // Orderly close: sync(2) + umount, then park. The kill still comes,
        // but only AFTER everything was synced and unmounted — the fs state
        // on disk is then exactly what the kernel believes is consistent.
        sync();
        if (umount("/mnt") != 0)
            emit("CCUMOUNT-FAIL\n");
        else
            emit("CCUMOUNT-OK\n");
        emit("CCCLEAN-DONE\n");
    }
    // Park forever: the driver kill -9's the VM at its chosen offset.
    for (;;) pause();
}
