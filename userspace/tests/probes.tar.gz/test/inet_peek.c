/*
 * inet_peek.c — MSG_PEEK on AF_INET sockets (review-func F7 A/B probe).
 *
 * Verdict line: INETPEEK-DONE fails=<n>
 *
 * Cases:
 *   udp-peek-same      two MSG_PEEK recvfroms return the same datagram
 *   udp-peek-consume   plain recvfrom after peek still returns it (peek
 *                      did not consume), then EAGAIN
 *   udp-peek-trunc     a short peek buffer returns a prefix and leaves
 *                      the datagram queued
 *   tcp-peek-same      two MSG_PEEK recvs on a stream return the same
 *                      prefix
 *   tcp-peek-consume   plain recv after peek returns the same bytes and
 *                      drains them
 */
#define _GNU_SOURCE
#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/un.h>

/* musl sysroot has no linux/netlink.h — define the minimal ABI shape. */
#define AF_NETLINK_Q 16
struct sockaddr_nl_q {
    unsigned short nl_family;
    unsigned short nl_pad;
    unsigned int nl_pid;
    unsigned int nl_groups;
};

static int fails = 0;


static void check(const char *name, int ok, const char *detail)
{
    printf("INETPEEK-CASE %s %s (%s)\n", name, ok ? "PASS" : "FAIL", detail);
    if (!ok)
        fails++;
}


int main(void)
{
    /* ---- UDP over loopback ---- */
    {
        int s = socket(AF_INET, SOCK_DGRAM, 0);
        struct sockaddr_in a;
        socklen_t al = sizeof a;
        memset(&a, 0, sizeof a);
        a.sin_family = AF_INET;
        a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
        a.sin_port = 0;
        if (bind(s, (struct sockaddr *)&a, sizeof a) < 0) {
            check("udp-peek-same", 0, "bind failed");
            close(s);
        } else {
            getsockname(s, (struct sockaddr *)&a, &al);
            const char *msg = "peek-datagram";
            sendto(s, msg, strlen(msg), 0, (struct sockaddr *)&a, sizeof a);
            char b1[64] = {0}, b2[64] = {0}, b3[64] = {0};
            ssize_t n1 = recvfrom(s, b1, sizeof b1 - 1, MSG_PEEK, NULL, NULL);
            /* Second peek is DONTWAIT: on a kernel where the first peek
                 * consumed the datagram this returns EAGAIN instead of
                 * wedging the probe in a blocking receive. */
            ssize_t n2 = recvfrom(s, b2, sizeof b2 - 1, MSG_PEEK | MSG_DONTWAIT, NULL, NULL);
            char d[256];
            snprintf(d, sizeof d, "n1=%zd '%s' n2=%zd '%s' expect same '%s'",
                     n1, b1, n2, b2, msg);
            check("udp-peek-same",
                  n1 == (ssize_t)strlen(msg) && n2 == n1 &&
                      strcmp(b1, msg) == 0 && strcmp(b2, msg) == 0,
                  d);
            ssize_t n3 = recvfrom(s, b3, sizeof b3 - 1, MSG_DONTWAIT, NULL, NULL);
            ssize_t n4 = recvfrom(s, b1, sizeof b1 - 1, MSG_DONTWAIT, NULL, NULL);
            snprintf(d, sizeof d, "n3=%zd '%s' n4=%zd errno=%d expect n3=len n4=-1",
                     n3, b3, n4, errno);
            check("udp-peek-consume",
                  n3 == (ssize_t)strlen(msg) && strcmp(b3, msg) == 0 && n4 < 0,
                  d);
            /* truncated peek leaves the datagram queued */
            sendto(s, "0123456789AB", 12, 0, (struct sockaddr *)&a, sizeof a);
            char pre[5] = {0};
            ssize_t pt = recvfrom(s, pre, 4, MSG_PEEK, NULL, NULL);
            char full[16] = {0};
            ssize_t pf = recvfrom(s, full, sizeof full - 1, MSG_DONTWAIT, NULL, NULL);
            snprintf(d, sizeof d, "peek=%zd '%s' then=%zd '%s' expect peek=4 '0123' then=12",
                     pt, pre, pf, full);
            check("udp-peek-trunc",
                  pt == 4 && strcmp(pre, "0123") == 0 && pf == 12,
                  d);
            close(s);
        }
    }

    /* ---- TCP over loopback (in-process: connect+accept) ---- */
    {
        int ls = socket(AF_INET, SOCK_STREAM, 0);
        struct sockaddr_in a;
        socklen_t al = sizeof a;
        memset(&a, 0, sizeof a);
        a.sin_family = AF_INET;
        a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
        a.sin_port = 0;
        if (bind(ls, (struct sockaddr *)&a, sizeof a) < 0 ||
            listen(ls, 4) < 0) {
            check("tcp-peek-same", 0, "bind/listen failed");
            close(ls);
        } else {
            getsockname(ls, (struct sockaddr *)&a, &al);
            int c = socket(AF_INET, SOCK_STREAM, 0);
            if (connect(c, (struct sockaddr *)&a, sizeof a) < 0) {
                check("tcp-peek-same", 0, "connect failed");
                close(c);
                close(ls);
            } else {
                int fcntl_fl = fcntl(ls, F_GETFL, 0);
                fcntl(ls, F_SETFL, fcntl_fl | O_NONBLOCK);
                int afd = -1;
                for (int i = 0; i < 200; i++) {
                    afd = accept(ls, NULL, NULL);
                    if (afd >= 0 || errno != EAGAIN)
                        break;
                    usleep(20000);
                }
                fcntl(ls, F_SETFL, fcntl_fl);
                if (afd < 0) {
                    check("tcp-peek-same", 0, "accept failed");
                } else {
                    const char *msg = "stream-peek-payload";
                    send(afd, msg, strlen(msg), 0);
                    usleep(100000); /* let loopback deliver */
                    char b1[64] = {0}, b2[64] = {0}, b3[64] = {0};
                    ssize_t n1 = recv(c, b1, sizeof b1 - 1, MSG_PEEK);
                    /* DONTWAIT: see the UDP note — a consuming peek
                     * must fail fast here, not wedge the probe. */
                    ssize_t n2 = recv(c, b2, sizeof b2 - 1, MSG_PEEK | MSG_DONTWAIT);
                    char d[256];
                    snprintf(d, sizeof d, "n1=%zd n2=%zd expect %zd both '%s'",
                             n1, n2, (ssize_t)strlen(msg), msg);
                    check("tcp-peek-same",
                          n1 == (ssize_t)strlen(msg) && n2 == n1 &&
                              strcmp(b1, msg) == 0 && strcmp(b2, msg) == 0,
                          d);
                    ssize_t n3 = recv(c, b3, sizeof b3 - 1, MSG_DONTWAIT);
                    snprintf(d, sizeof d, "n3=%zd '%s' expect %zd '%s'",
                             n3, b3, (ssize_t)strlen(msg), msg);
                    check("tcp-peek-consume",
                          n3 == (ssize_t)strlen(msg) && strcmp(b3, msg) == 0,
                          d);
                    close(afd);
                }
                close(c);
                close(ls);
            }
        }
    }


    /* ---- shutdown ENOTCONN (review F10) ---- */
    {
        int s = socket(AF_INET, SOCK_STREAM, 0);
        int r = shutdown(s, SHUT_RDWR);
        int e = errno;
        char d[128];
        snprintf(d, sizeof d, "r=%d errno=%d expect -1/107", r, e);
        check("shutdown-unconnected", r == -1 && e == 107, d);
        close(s);

        /* listener: SHUT_WR -> ENOTCONN, SHUT_RD -> 0 */
        int ls = socket(AF_INET, SOCK_STREAM, 0);
        struct sockaddr_in la;
        memset(&la, 0, sizeof la);
        la.sin_family = AF_INET;
        la.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
        la.sin_port = 0;
        if (bind(ls, (struct sockaddr *)&la, sizeof la) == 0 &&
            listen(ls, 2) == 0) {
            r = shutdown(ls, SHUT_WR);
            e = errno;
            snprintf(d, sizeof d, "wr r=%d errno=%d expect -1/107", r, e);
            check("shutdown-listen-wr", r == -1 && e == 107, d);
            r = shutdown(ls, SHUT_RD);
            e = errno;
            snprintf(d, sizeof d, "rd r=%d errno=%d expect 0", r, e);
            check("shutdown-listen-rd", r == 0, d);
        } else {
            check("shutdown-listen-wr", 0, "bind/listen failed");
            check("shutdown-listen-rd", 0, "bind/listen failed");
        }
        close(ls);
    }


    /* ---- sockaddr_un / sockaddr_nl write-back clamp (review F6) ---- */
    {
        int us = socket(AF_UNIX, SOCK_DGRAM, 0);
        struct {
            unsigned char sa[8];
            volatile unsigned long canary;
        } obj;
        struct sockaddr_un ua;
        socklen_t sl;
        obj.canary = 0xdeadbeefcafe1234UL;
        memset(&ua, 0, sizeof ua);
        ua.sun_family = AF_UNIX;
        ua.sun_path[0] = '\0'; /* abstract namespace — no fs */
        memcpy(ua.sun_path + 1, "f6probe", 7);
        char d[160];
        if (bind(us, (struct sockaddr *)&ua, sizeof ua) < 0) {
            snprintf(d, sizeof d, "unix bind errno=%d", errno);
            check("unix-getsockname-shortlen", 0, d);
        } else {
            sl = 8;
            int r = getsockname(us, (struct sockaddr *)obj.sa, &sl);
            int intact = obj.canary == 0xdeadbeefcafe1234UL;
            snprintf(d, sizeof d, "r=%d sl=%u canary=%s expect r=0 sl=%zu canary-intact",
                     r, sl, intact ? "intact" : "CLOBBERED",
                     (size_t)(2 + 8));
            check("unix-getsockname-shortlen",
                  r == 0 && sl == 2 + 8 && intact, d);
        }
        close(us);

        int ns = socket(16 /*AF_NETLINK*/, SOCK_RAW, 15 /* NETLINK_KOBJECT_UEVENT */);
        if (ns < 0) {
            snprintf(d, sizeof d, "netlink socket errno=%d", errno);
            check("nl-getsockname-shortlen", 0, d);
        } else {
            struct sockaddr_nl_q na;
            memset(&na, 0, sizeof na);
            na.nl_family = 16;
            if (bind(ns, (struct sockaddr *)&na, sizeof na) < 0) {
                snprintf(d, sizeof d, "netlink bind errno=%d", errno);
                check("nl-getsockname-shortlen", 0, d);
            } else {
                obj.canary = 0xdeadbeefcafe1234UL;
                sl = 6;
                int r = getsockname(ns, (struct sockaddr *)obj.sa, &sl);
                int intact = obj.canary == 0xdeadbeefcafe1234UL;
                snprintf(d, sizeof d, "r=%d sl=%u canary=%s expect r=0 sl=12 canary-intact",
                         r, sl, intact ? "intact" : "CLOBBERED");
                check("nl-getsockname-shortlen",
                      r == 0 && sl == 12 && intact, d);
            }
            close(ns);
        }
    }


    /* ---- netlink nl_pid bind + portid unicast (review F11) ---- */
    {
        int a = socket(16 /*AF_NETLINK*/, SOCK_RAW, 0 /*NETLINK_ROUTE*/);
        int b = socket(16, SOCK_RAW, 0);
        char d[160];
        if (a < 0 || b < 0) {
            snprintf(d, sizeof d, "socket errno=%d", errno);
            check("nl-bind-pid-getname", 0, d);
            check("nl-unicast-rx", 0, d);
            check("nl-unicast-refused", 0, d);
            check("nl-bind-collision", 0, d);
        } else {
            struct sockaddr_nl_q na;
            memset(&na, 0, sizeof na);
            na.nl_family = 16;
            na.nl_pid = 5555;
            int rb = bind(a, (struct sockaddr *)&na, sizeof na);
            socklen_t sl = sizeof na;
            int gn = getsockname(a, (struct sockaddr *)&na, &sl);
            snprintf(d, sizeof d, "bind=%d getsockname=%d pid=%u expect bind=0 gn=0 pid=5555",
                     rb, gn, na.nl_pid);
            check("nl-bind-pid-getname", rb == 0 && gn == 0 && na.nl_pid == 5555, d);

            /* unicast b -> a's port id */
            struct sockaddr_nl_q dst;
            memset(&dst, 0, sizeof dst);
            dst.nl_family = 16;
            dst.nl_pid = 5555;
            const char *pl = "unicast-payload-00";
            ssize_t sn = sendto(b, pl, strlen(pl), 0,
                                (struct sockaddr *)&dst, sizeof dst);
            char rb2[64] = {0};
            ssize_t rn = recv(a, rb2, sizeof rb2 - 1, MSG_DONTWAIT);
            snprintf(d, sizeof d, "send=%zd recv=%zd '%s' expect 18/18 '%s'",
                     sn, rn, rb2, pl);
            check("nl-unicast-rx",
                  sn == (ssize_t)strlen(pl) && rn == (ssize_t)strlen(pl) &&
                      strcmp(rb2, pl) == 0,
                  d);

            /* unicast to an unbound port id: ECONNREFUSED */
            dst.nl_pid = 4242;
            sn = sendto(b, pl, strlen(pl), 0, (struct sockaddr *)&dst, sizeof dst);
            int e = errno;
            snprintf(d, sizeof d, "send=%zd errno=%d expect -1/111", sn, e);
            check("nl-unicast-refused", sn == -1 && e == 111, d);

            /* second bind at the taken port id: EADDRINUSE */
            int c = socket(16, SOCK_RAW, 0);
            na.nl_pid = 5555;
            rb = bind(c, (struct sockaddr *)&na, sizeof na);
            e = errno;
            snprintf(d, sizeof d, "bind=%d errno=%d expect -1/98", rb, e);
            check("nl-bind-collision", rb == -1 && e == 98, d);
            close(c);
        }
        if (a >= 0) close(a);
        if (b >= 0) close(b);
    }


    /* ---- sendmmsg/recvmmsg zero-length + EAFNOSUPPORT (review F8/F9) ---- */
    {
        int s = socket(AF_INET, SOCK_DGRAM, 0);
        struct sockaddr_in a;
        socklen_t al = sizeof a;
        memset(&a, 0, sizeof a);
        a.sin_family = AF_INET;
        a.sin_addr.s_addr = htonl(INADDR_LOOPBACK);
        a.sin_port = 0;
        char d[160];
        if (bind(s, (struct sockaddr *)&a, sizeof a) < 0) {
            snprintf(d, sizeof d, "bind errno=%d", errno);
            check("sendmmsg-zerolen-count", 0, d);
            check("recvmmsg-zerolen-count", 0, d);
            check("sendmmsg-eafnosupport", 0, d);
        } else {
            getsockname(s, (struct sockaddr *)&a, &al);
            char one = 'x';
            struct iovec iov0 = { .iov_base = NULL, .iov_len = 0 };
            struct iovec iov1 = { .iov_base = &one, .iov_len = 1 };
            struct mmsghdr mm[2];
            memset(mm, 0, sizeof mm);
            mm[0].msg_hdr.msg_name = &a; mm[0].msg_hdr.msg_namelen = sizeof a;
            mm[0].msg_hdr.msg_iov = &iov0; mm[0].msg_hdr.msg_iovlen = 1;
            mm[1].msg_hdr.msg_name = &a; mm[1].msg_hdr.msg_namelen = sizeof a;
            mm[1].msg_hdr.msg_iov = &iov1; mm[1].msg_hdr.msg_iovlen = 1;
            int n = sendmmsg(s, mm, 2, 0);
            snprintf(d, sizeof d, "sendmmsg=%d len0=%u len1=%u expect 2 0 1",
                     n, mm[0].msg_len, mm[1].msg_len);
            check("sendmmsg-zerolen-count",
                  n == 2 && mm[0].msg_len == 0 && mm[1].msg_len == 1, d);

            /* receive both back: the empty datagram counts too */
            char z = 0, y = 0;
            struct iovec riov0 = { .iov_base = &z, .iov_len = 0 };
            struct iovec riov1 = { .iov_base = &y, .iov_len = 1 };
            struct mmsghdr rm[2];
            memset(rm, 0, sizeof rm);
            rm[0].msg_hdr.msg_iov = &riov0; rm[0].msg_hdr.msg_iovlen = 1;
            rm[1].msg_hdr.msg_iov = &riov1; rm[1].msg_hdr.msg_iovlen = 1;
            n = recvmmsg(s, rm, 2, MSG_DONTWAIT, NULL);
            snprintf(d, sizeof d, "recvmmsg=%d len0=%u len1=%u expect 2 0 1",
                     n, rm[0].msg_len, rm[1].msg_len);
            check("recvmmsg-zerolen-count",
                  n == 2 && rm[0].msg_len == 0 && rm[1].msg_len == 1 && y == 'x', d);

            /* a msg_name whose family does not match the socket:
             * EAFNOSUPPORT (review F9) */
            struct sockaddr_un bad;
            memset(&bad, 0, sizeof bad);
            bad.sun_family = AF_UNIX;
            struct iovec iovx = { .iov_base = &one, .iov_len = 1 };
            struct mmsghdr xm[1];
            memset(xm, 0, sizeof xm);
            xm[0].msg_hdr.msg_name = &bad; xm[0].msg_hdr.msg_namelen = sizeof bad;
            xm[0].msg_hdr.msg_iov = &iovx; xm[0].msg_hdr.msg_iovlen = 1;
            n = sendmmsg(s, xm, 1, 0);
            int e = errno;
            snprintf(d, sizeof d, "sendmmsg=%d errno=%d expect -1/97", n, e);
            check("sendmmsg-eafnosupport", n == -1 && e == 97, d);
        }
        close(s);
    }

    printf("INETPEEK-DONE fails=%d\n", fails);
    return fails ? 1 : 0;
}
