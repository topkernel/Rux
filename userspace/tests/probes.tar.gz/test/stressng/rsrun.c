/*
 * rsrun.c — stress-class PID-1 runner for the Rux kernel (stress-port
 * lane). The ltpscan.c pattern, retargeted at the rs (rux-stress)
 * suite: reads /test/stress-ng/cmds.txt, one rs invocation per line
 * (args whitespace-split), runs each sequentially with a generous
 * wall-clock kill (TERM at <timeout>+30s, KILL at +60s), echoes the
 * child's serial protocol through, and brackets the run:
 *
 *   RS-RUN <line>            (before each invocation)
 *   RES|<class>|<rc>|<tail>  (after each; rc as in ltpscan: 128+sig for
 *                             signal deaths)
 *   RS-ALL-DONE
 *
 * PID 1 parks forever afterwards (init exit would take the kernel
 * down). Build: musl-gcc -static -O2 -Wall -o rsrun rsrun.c
 */
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#define RS_BIN "/test/stress-ng/rs"
#define CMDS_FILE "/test/stress-ng/cmds.txt"
#define OUT_FILE "/tmp/rsrun.out"
#define TAIL_BYTES 400

static void emit_res(const char *name, int rc, const char *file)
{
    char buf[TAIL_BYTES + 1];
    int fd = open(file, O_RDONLY);
    ssize_t got = 0;
    if (fd >= 0) {
        off_t sz = lseek(fd, 0, SEEK_END);
        ssize_t want = TAIL_BYTES;
        if (sz >= 0) {
            if (want > sz)
                want = (ssize_t)sz;
            if (lseek(fd, sz - want, SEEK_SET) >= 0)
                got = read(fd, buf, want);
        }
        close(fd);
    }
    /* flatten to one line */
    char flat[TAIL_BYTES * 2 + 1];
    size_t o = 0;
    for (ssize_t i = 0; i < got; i++) {
        char c = buf[i];
        if (c == '\n' || c == '\r' || c == '\t')
            flat[o++] = ' ';
        else if ((unsigned char)c >= 0x20)
            flat[o++] = c;
        if (o >= sizeof(flat) - 1)
            break;
    }
    while (o > 0 && flat[o - 1] == ' ')
        o--;
    flat[o] = '\0';
    printf("RES|%s|%d|%s\n", name, rc, flat);
    fflush(stdout);
}

/* run_one: split the line into argv, exec RS_BIN with those args.
 * Round 2: lines of the form "exec <budget-secs> <path> [args...]"
 * run an arbitrary guest binary (LTP robustness long-loops etc.) with
 * the same TERM/KILL discipline but a long budget (TERM at budget+30,
 * KILL at budget+60; budget defaults to 3600). The child also gets
 * the LTP environment ltpscan.c sets (LTPROOT, LTP_IPC_PATH, TMPDIR)
 * plus a chdir to the LTP bin dir when the path lives under
 * /test/linux-ltp — runltp starts each test from there. */
static void run_one(const char *line)
{
    char *args[64];
    int nargs = 0;
    static char tok[512];
    strncpy(tok, line, sizeof tok - 1);
    tok[sizeof tok - 1] = '\0';
    int is_exec = !strncmp(line, "exec ", 5);
    if (!is_exec)
        args[nargs++] = (char *)RS_BIN; /* argv[0] = program */
    char *save = NULL, *t = strtok_r(tok, " \t", &save);
    while (t && nargs < 62) {
        args[nargs++] = t;
        t = strtok_r(NULL, " \t", &save);
    }
    args[nargs] = NULL;
    if (nargs <= (is_exec ? 1 : 0))
        return;
    int exec_budget = 3600;
    if (is_exec) {
        /* drop the literal "exec" token; first remaining token is the
         * budget in seconds (must be all digits), then the binary path */
        for (int i = 0; i < nargs - 1; i++)
            args[i] = args[i + 1];
        nargs--;
        int allnum = args[0][0] >= '0' && args[0][0] <= '9';
        for (const char *c = args[0]; *c; c++)
            if (*c < '0' || *c > '9')
                allnum = 0;
        if (allnum) {
            exec_budget = atoi(args[0]);
            for (int i = 0; i < nargs - 1; i++)
                args[i] = args[i + 1];
            nargs--;
        }
        if (args[0][0] != '/') {
            printf("RES|exec|250|need-absolute-path %s\n", args[0]);
            fflush(stdout);
            return;
        }
        /* the NULL terminator was placed at the pre-shift nargs — the
         * two shifts above left stale tail pointers after the new
         * nargs (host-verified: argv gained duplicated tail args);
         * re-terminate at the shifted position */
        args[nargs] = NULL;
    }

    /* class name for the RES line: first --<class> token, or the
     * basename for exec lines */
    char name[64] = "?";
    if (is_exec) {
        const char *b = strrchr(args[0], '/');
        snprintf(name, sizeof name, "%s", b ? b + 1 : args[0]);
    } else
    for (int i = 1; i < nargs; i++)
        if (!strncmp(args[i], "--", 2) && args[i][2] &&
            strncmp(args[i], "--timeout", 9) &&
            strncmp(args[i], "--vm-bytes", 10) &&
            strncmp(args[i], "--fs-root", 9) &&
            strncmp(args[i], "--shm-bytes", 11) &&
            strncmp(args[i], "--block", 7) &&
            strncmp(args[i], "--exec-child", 12)) {
            snprintf(name, sizeof name, "%s", args[i] + 2);
            break;
        }

    printf("RS-RUN %s\n", line);
    fflush(stdout);

    int outfd = open(OUT_FILE, O_CREAT | O_TRUNC | O_RDWR, 0644);
    int devnull = open("/dev/null", O_RDONLY);
    if (outfd < 0) {
        printf("RES|%s|252|open-out-failed\n", name);
        fflush(stdout);
        return;
    }
    pid_t pid = fork();
    if (pid < 0) {
        printf("RES|%s|253|fork-failed\n", name);
        fflush(stdout);
        close(outfd);
        return;
    }
    if (pid == 0) {
        dup2(devnull >= 0 ? devnull : outfd, 0);
        dup2(outfd, 1);
        dup2(outfd, 2);
        if (is_exec) {
            /* ltpscan.c parity: the LTP env + bin-dir cwd */
            setenv("PATH", "/bin:/sbin:/test/linux-ltp/testcases/bin", 1);
            setenv("TMPDIR", "/tmp", 1);
            setenv("LTP_IPC_PATH", "/tmp/ltp-ipc", 1);
            setenv("HOME", "/", 1);
            setenv("LTPROOT", "/test/linux-ltp", 1);
            if (!strncmp(args[0], "/test/linux-ltp", 15))
                (void)!chdir("/test/linux-ltp/testcases/bin");
            /* ltpscan parity: argv[0] = basename (execl(binpath, name)) —
             * the new LTP API rejects a path-shaped argv[0] household */
            char path0[512];
            snprintf(path0, sizeof path0, "%s", args[0]);
            args[0] = name;
            execv(path0, args);
        } else {
            execv(RS_BIN, args);
        }
        dprintf(1, "exec-failed: %s: %s\n", is_exec ? args[0] : RS_BIN,
                strerror(errno));
        _exit(127);
    }
    if (devnull >= 0)
        close(devnull);

    /* wall-clock guard: rs exits by its own --timeout (parsed below);
     * TERM 30s past that, KILL 60s past (a wedged class is a finding).
     * exec lines use their explicit budget instead. */
    int class_timeout = is_exec ? exec_budget : 60;
    for (int i = 1; i < nargs; i++)
        if (!strcmp(args[i], "--timeout") && i + 1 < nargs)
            class_timeout = atoi(args[i + 1]);
    int term_ms = class_timeout * 1000 + 30000;
    int kill_ms = class_timeout * 1000 + 60000;
    struct timespec ts200 = { 0, 200 * 1000 * 1000 };
    int elapsed_ms = 0, termd = 0, killed = 0, status = 0;
    for (;;) {
        pid_t r = waitpid(pid, &status, WNOHANG);
        if (r == pid)
            break;
        if (r < 0 && errno != EINTR) {
            status = 254;
            break;
        }
        nanosleep(&ts200, NULL);
        elapsed_ms += 200;
        if (elapsed_ms >= term_ms && !termd) {
            kill(pid, SIGTERM);
            termd = 1;
        } else if (elapsed_ms >= kill_ms && !killed) {
            kill(pid, SIGKILL);
            killed = 1;
        } else if (killed && elapsed_ms >= kill_ms + 60000) {
            printf("RES|%s|251|unreapable\n", name);
            fflush(stdout);
            close(outfd);
            return;
        }
    }
    close(outfd);

    int rc;
    if (WIFSIGNALED(status))
        rc = 128 + WTERMSIG(status);
    else if (WIFEXITED(status))
        rc = WEXITSTATUS(status);
    else
        rc = 255;
    emit_res(name, rc, OUT_FILE);
}

int main(void)
{
    int cons = open("/dev/console", O_WRONLY);
    if (cons >= 0) {
        dup2(cons, 1);
        dup2(cons, 2);
        if (cons > 2)
            close(cons);
    }
    setvbuf(stdout, NULL, _IONBF, 0);
    setenv("PATH", "/bin:/sbin:/test/stress-ng", 1);
    setenv("TMPDIR", "/tmp", 1);

    printf("RSRUN-BEGIN cmds=%s\n", CMDS_FILE);
    FILE *f = fopen(CMDS_FILE, "r");
    if (!f) {
        printf("RSRUN-NO-CMDS\n");
        fflush(stdout);
    } else {
        char line[512];
        while (fgets(line, sizeof line, f)) {
            size_t n = strlen(line);
            while (n > 0 && (line[n - 1] == '\n' || line[n - 1] == '\r'))
                line[--n] = '\0';
            if (n == 0 || line[0] == '#')
                continue;
            run_one(line);
        }
        fclose(f);
        printf("RS-ALL-DONE\n");
        fflush(stdout);
    }
    for (;;)
        sleep(3600);
    return 0;
}
