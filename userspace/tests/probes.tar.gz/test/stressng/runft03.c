/* runft03.c — exec wrapper for the real LTP ftest03 (stress-port r10).
 * Boots as init, forks the real binary with a generous budget, forwards
 * SIGTERM fan-out at budget end (like ltpscan would), then reaps the
 * wrapper tree and reports. Usage: init=/test/stress-ng/runft03 [secs]
 */
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#include <errno.h>

int main(int argc, char **argv)
{
    int budget = argc > 1 ? atoi(argv[1]) : 120;
    printf("RUNFT03 budget=%d\n", budget);
    fflush(stdout);
    pid_t p = fork();
    if (p == 0) {
        char *av[] = { "ftest03", 0 };
        execv("/test/linux-ltp/testcases/bin/ftest03", av);
        printf("exec fail %d\n", errno);
        return 2;
    }
    sleep(budget);
    printf("RUNFT03 budget expired, TERM to %d\n", p);
    fflush(stdout);
    kill(p, SIGTERM);
    sleep(5);
    kill(p, SIGKILL);
    int st;
    wait(&st);
    printf("RUNFT03 reaped raw=0x%x\n", st);
    fflush(stdout);
    return 0;
}
