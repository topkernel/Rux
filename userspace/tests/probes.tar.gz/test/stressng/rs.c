/*
 * rs.c — rux-stress: stress-ng stressor-logic port for the Rux kernel
 * (stress-port lane, charter 2026-11-02). One binary, one class per
 * invocation, stress-ng-shaped CLI:
 *
 *   rs --malloc   4 --timeout 120 --vm-bytes 256M   malloc/free churn w/ page touch
 *   rs --mmap     4 --timeout 120                    anon mmap/munmap + mremap churn
 *   rs --bigheap  2 --timeout 120 --vm-bytes 384M    sbrk grow/touch/shrink waves
 *   rs --fork     4 --timeout 120                    fork+exit+waitpid churn (COW touch)
 *   rs --exec     4 --timeout 120                    fork+execve churn (/bin/true + self)
 *   rs --fsmeta   4 --timeout 120 --fs-root /st      mkdir/rmdir/creat/unlink/link/
 *                                                    symlink/rename/chmod storm
 *   rs --pipe     4 --timeout 120 --pipe-size 4096   writer/reader pairs, seq-validated
 *   rs --sock     4 --timeout 120                    AF_UNIX SOCK_STREAM pairs
 *   rs --sem      4 --timeout 120                    SysV semop + id create/rmid churn
 *   rs --msg      4 --timeout 120                    SysV msgsnd/msgrcv + sentinel audit
 *   rs --shm      2 --timeout 120 --shm-bytes 4M     SysV shm create/attach/verify/rmid
 *   rs --futex    8 --timeout 120                    futex wait/wake storm (threads)
 *   rs --sched    8 --timeout 120                    sched_yield + wakeup (SIGUSR1) storm
 *   rs --timer    4 --timeout 120                    POSIX timer create/settime/delete
 *                                                    + clock_gettime + nanosleep storm
 *
 * Exit code 0 = clean run to timeout; 1 = self-detected failure (RS-ERR
 * lines on stdout name it). Serial protocol (one line each):
 *   RS-START class=<c> workers=<n> timeout=<s> ...
 *   RS-BEAT  t=<s> ops=<n> <class extras>      every 10s per invocation (parent sums)
 *   RS-DONE  class=<c> ops=<n> rc=0
 *   RS-ERR   ...                               any unexpected errno / corruption
 *
 * Build (static, x86_64 musl SDK):
 *   musl-gcc -static -O2 -Wall -o rs rs.c
 * Vehicle: injected at /test/stress-ng/rs by run/boot image; PID-1
 * wrapper rsrun.c runs it from /test/stress-ng/cmds.txt.
 */
#define _GNU_SOURCE
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <pthread.h>
#include <stdarg.h>
#include <sched.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/ipc.h>
#include <sys/mman.h>
#include <sys/msg.h>
#include <sys/sem.h>
#include <sys/shm.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/syscall.h>
#include <sys/time.h>
#include <sys/types.h>
#include <sys/un.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#define BEAT_SECS 10
#define MAX_WORKERS 64

/* musl SDK lacks linux/futex.h — the two op codes we use */
#define FUTEX_WAIT_PRIVATE 128
#define FUTEX_WAKE_PRIVATE 129

/* ---- shared state (MAP_SHARED|ANON page; forked workers share it) ---- */
struct shared {
    volatile uint64_t ops[MAX_WORKERS];   /* per-worker bogo-op counters */
    volatile int stop;                    /* parent sets at deadline      */
    volatile uint64_t err_count;
};
static struct shared *sh;
static const char *g_class;

static int reap_all(pid_t *pids, int n, int grace);

static void rs_err(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    fputs("RS-ERR ", stdout);
    vprintf(fmt, ap);
    putchar('\n');
    fflush(stdout);
    va_end(ap);
    __sync_fetch_and_add(&sh->err_count, 1);
}

static double monotime(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return (double)ts.tv_sec + (double)ts.tv_nsec / 1e9;
}

static uint64_t total_ops(void)
{
    uint64_t t = 0;
    for (int i = 0; i < MAX_WORKERS; i++)
        t += sh->ops[i];
    return t;
}

/* SIGTERM: set local flag so blocked syscalls (EINTR) unwind cleanly. */
static volatile sig_atomic_t g_term;
static void on_term(int sig) { (void)sig; g_term = 1; }

static void install_term_handler(void)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = on_term;
    sigemptyset(&sa.sa_mask);
    sa.sa_flags = SA_RESTART; /* want EINTR-free beats, flag still checked */
    sigaction(SIGTERM, &sa, NULL);
    sigaction(SIGINT, &sa, NULL);
}

static int should_stop(void) { return g_term || sh->stop; }

/* Touch one byte per page — forces the fault path without memset cost. */
static void touch_pages(void *p, size_t len)
{
    unsigned char *c = p;
    for (size_t off = 0; off < len; off += 4096)
        c[off] = (unsigned char)(off >> 12);
    if (len)
        c[len - 1] = 0xAA;
}

/* =====================================================================
 * class: malloc — stress-ng --vm (malloc method) shape: per pass,
 * allocate random-size chunks (256B..64KB) until the per-worker byte
 * budget is reached, touch every page, then free all.
 * ===================================================================== */
static size_t g_vm_bytes = 256UL << 20;

static void worker_malloc(int id)
{
    unsigned seed = 0xC0FFEE + id;
    enum { SLOTS = 8192 };
    static void *ptrs[SLOTS];
    while (!should_stop()) {
        size_t held = 0;
        int n = 0;
        while (held < g_vm_bytes && n < SLOTS && !should_stop()) {
            size_t sz = 256 + (size_t)(rand_r(&seed) % 65536);
            ptrs[n] = malloc(sz);
            if (!ptrs[n]) {
                rs_err("malloc worker=%d sz=%zu errno=%d (ENOMEM)", id, sz, errno);
                _exit(1);
            }
            touch_pages(ptrs[n], sz);
            held += sz;
            n++;
        }
        for (int i = 0; i < n; i++)
            free(ptrs[i]);
        sh->ops[id] += n;
    }
    _exit(0);
}

/* =====================================================================
 * class: mmap — stress-ng --mmap / --mmapaddr shape: anon
 * mmap+touch+munmap of random sizes, periodic mremap
 * grow/move, plus a MAP_FIXED re-map wave over a reserved region.
 * ===================================================================== */
static void worker_mmap(int id)
{
    unsigned seed = 0xBEEF + id;
    /* reserve a fixed-address arena for MAP_FIXED churn */
    char *arena = mmap(NULL, 32UL << 20, PROT_READ | PROT_WRITE,
                       MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (arena == MAP_FAILED) {
        rs_err("mmap arena failed errno=%d", errno);
        _exit(1);
    }
    uint64_t ops = 0;
    while (!should_stop()) {
        size_t len = (size_t)(1 + rand_r(&seed) % 64) << 12;
        char *p = mmap(NULL, len, PROT_READ | PROT_WRITE,
                       MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
        if (p == MAP_FAILED) {
            rs_err("mmap worker=%d len=%zu errno=%d", id, len, errno);
            _exit(1);
        }
        touch_pages(p, len);
        if ((++ops & 15) == 0) {
            /* grow in place (or move) — mremap churn */
            char *q = mremap(p, len, len * 2, MREMAP_MAYMOVE);
            if (q == MAP_FAILED) {
                rs_err("mremap grow worker=%d errno=%d", id, errno);
                _exit(1);
            }
            touch_pages(q + len, len); /* touch the new half */
            p = q;
            len *= 2;
        }
        if (munmap(p, len) != 0) {
            rs_err("munmap worker=%d errno=%d", id, errno);
            _exit(1);
        }
        /* MAP_FIXED wave: punch a hole, refill it at the same address */
        if ((ops & 31) == 0) {
            size_t off = (size_t)(rand_r(&seed) % (16UL << 20)) & ~4095UL;
            if (munmap(arena + off, 1 << 16) != 0) {
                rs_err("munmap arena worker=%d errno=%d", id, errno);
                _exit(1);
            }
            char *f = mmap(arena + off, 1 << 16, PROT_READ | PROT_WRITE,
                           MAP_PRIVATE | MAP_ANONYMOUS | MAP_FIXED, -1, 0);
            if (f != arena + off) {
                rs_err("mmap MAP_FIXED worker=%d want=%p got=%p errno=%d",
                       id, (void *)(arena + off), (void *)f, errno);
                _exit(1);
            }
            touch_pages(f, 1 << 16);
        }
        sh->ops[id]++;
    }
    munmap(arena, 32UL << 20);
    _exit(0);
}

/* =====================================================================
 * class: bigheap — stress-ng --bigheap shape: grow the brk heap by
 * 1MB sbrk steps up to the byte budget touching every page, then
 * verify the pattern while shrinking back down.
 * ===================================================================== */
static void worker_bigheap(int id)
{
    /* brk grow/shrink churn; falls back to malloc-realloc churn when the
     * binary layout pins brk (musl static maps TLS adjacent to BSS — an
     * immediate total-growth failure is a userspace artifact, not a
     * kernel finding, so it's a NOTE, not an ERR). */
    int brk_mode = 1;
    size_t step = 1 << 20; /* adaptive grow step: halve on ENOMEM (64K floor) */
    while (!should_stop()) {
        if (brk_mode) {
            intptr_t base = (intptr_t)sbrk(0);
            intptr_t cur = base;
            while (cur - base < (intptr_t)g_vm_bytes && !should_stop()) {
                if (sbrk(step) == (void *)-1) {
                    if (step > (64 << 10)) {
                        step >>= 1; /* smaller step may fit under ceiling */
                        continue;
                    }
                    printf("RS-NOTE bigheap brk-grow-limit worker=%d at=%zd "
                           "errno=%d -> malloc mode\n",
                           id, (ssize_t)(cur - base), errno);
                    fflush(stdout);
                    brk_mode = 0;
                    break;
                }
                cur += step;
                touch_pages((void *)(cur - step), step);
                sh->ops[id]++;
            }
            /* shrink with verify: first byte of each page carries the
             * stamp touch_pages wrote — page index within its block */
            while (cur > base && !should_stop()) {
                size_t blk = step;
                if ((size_t)(cur - base) < blk)
                    blk = (size_t)(cur - base);
                cur -= blk;
                unsigned char *pg = (unsigned char *)cur;
                for (size_t off = 0; off < blk; off += 4096)
                    if (pg[off] != (unsigned char)((off >> 12) & 0xFF)) {
                        rs_err("bigheap CORRUPT worker=%d addr=%p off=%zu v=%u",
                               id, (void *)(pg + off), off, pg[off]);
                        _exit(1);
                    }
                if (sbrk(-(intptr_t)blk) == (void *)-1) {
                    rs_err("bigheap sbrk shrink failed worker=%d errno=%d", id,
                           errno);
                    _exit(1);
                }
            }
        } else {
            /* malloc fallback: single region grown by doubling (stress-ng
             * bigheap is realloc-shaped), fully touched, freed per wave */
            size_t sz = 1 << 20;
            unsigned char *p = malloc(sz);
            if (!p)
                _exit(1);
            while (sz < g_vm_bytes && !should_stop()) {
                unsigned char *q = realloc(p, sz * 2);
                if (!q)
                    break; /* allocation ceiling reached this wave */
                p = q;
                touch_pages(p + sz, sz); /* touch only the new half */
                sz *= 2;
                sh->ops[id]++;
            }
            free(p);
        }
    }
    _exit(0);
}

/* =====================================================================
 * class: fork — stress-ng --fork shape: child stamps a COW page, does a
 * few pid calls, exits; parent reaps. Any waitpid error is a bug.
 * ===================================================================== */
static void worker_fork(int id)
{
    volatile char cowpage[4096] __attribute__((aligned(4096)));
    (void)cowpage;
    while (!should_stop()) {
        pid_t p = fork();
        if (p < 0) {
            rs_err("fork worker=%d errno=%d", id, errno);
            _exit(1);
        }
        if (p == 0) {
            cowpage[7] = (char)getpid(); /* COW fault in the child */
            pid_t pp = getppid();
            if (pp <= 1)
                rs_err("fork child getppid=%d", (int)pp);
            _exit(0);
        }
        int st;
        if (waitpid(p, &st, 0) != p) {
            rs_err("waitpid worker=%d child=%d errno=%d", id, (int)p, errno);
            _exit(1);
        }
        if (!WIFEXITED(st) || WEXITSTATUS(st) != 0)
            rs_err("fork child bad status worker=%d st=%d", id, st);
        sh->ops[id]++;
    }
    _exit(0);
}

/* =====================================================================
 * class: exec — stress-ng --exec shape: alternate exec of /bin/true
 * (small) and of this binary re-exec'd as a no-op child (larger ELF,
 * more mmap/page-cache exec work). Child-side marker: --exec-child.
 * ===================================================================== */
static char g_self[512];

static void worker_exec(int id)
{
    while (!should_stop()) {
        pid_t p = fork();
        if (p < 0) {
            rs_err("exec: fork worker=%d errno=%d", id, errno);
            _exit(1);
        }
        if (p == 0) {
            if (id & 1)
                execl("/bin/true", "true", (char *)NULL);
            else
                execl(g_self, "rs", "--exec-child", (char *)NULL);
            rs_err("execve worker=%d errno=%d", id, errno);
            _exit(127);
        }
        int st;
        if (waitpid(p, &st, 0) != p) {
            rs_err("exec: waitpid worker=%d errno=%d", id, errno);
            _exit(1);
        }
        if (!WIFEXITED(st) || WEXITSTATUS(st) != 0)
            rs_err("exec child bad status worker=%d st=%d", id, st);
        sh->ops[id]++;
    }
    _exit(0);
}

/* =====================================================================
 * class: fsmeta — mkdir/rmdir/creat/unlink/link/symlink/rename/chmod
 * churn. Each worker OWNS its directory tree, so every errno is a bug
 * (unlike dirstorm's shared-tree legal race sets).
 * ===================================================================== */
static const char *g_fs_root = "/st";

#define CHK(call, name)                                                    \
    do {                                                                   \
        if ((call) != 0) {                                                 \
            rs_err("fsmeta %s worker=%d path=%s errno=%d", name, id, path, \
                   errno);                                                 \
            _exit(1);                                                      \
        }                                                                  \
    } while (0)

static void worker_fsmeta(int id)
{
    char path[512], path2[512];
    snprintf(path, sizeof path, "%s/w%d", g_fs_root, id);
    CHK(mkdir(path, 0755), "mkdir-root");
    unsigned seed = 0xF00D + id;
    uint64_t pass = 0;
    while (!should_stop()) {
        long f = (long)(rand_r(&seed) % 512);
        /* mkdir + rmdir */
        snprintf(path, sizeof path, "%s/w%d/d%ld", g_fs_root, id, f);
        CHK(mkdir(path, 0755), "mkdir");
        CHK(rmdir(path), "rmdir");
        /* creat + write + close + link + symlink + rename + unlink */
        snprintf(path, sizeof path, "%s/w%d/f%ld", g_fs_root, id, f);
        int fd = open(path, O_CREAT | O_RDWR | O_EXCL, 0644);
        if (fd < 0) {
            rs_err("fsmeta creat worker=%d path=%s errno=%d", id, path, errno);
            _exit(1);
        }
        char buf[64];
        snprintf(buf, sizeof buf, "RS%016llx",
                 (unsigned long long)((pass << 20) | (unsigned)f));
        if (write(fd, buf, sizeof buf) != sizeof buf) {
            rs_err("fsmeta write worker=%d errno=%d", id, errno);
            _exit(1);
        }
        CHK(close(fd), "close");
        snprintf(path2, sizeof path2, "%s/w%d/l%ld", g_fs_root, id, f);
        CHK(link(path, path2), "link");
        snprintf(path2, sizeof path2, "%s/w%d/s%ld", g_fs_root, id, f);
        CHK(symlink(path, path2), "symlink");
        snprintf(path2, sizeof path2, "%s/w%d/r%ld", g_fs_root, id, f);
        CHK(rename(path, path2), "rename");
        /* chmod storm on the moved file (OH chmod-storm shape) */
        for (int m = 0; m < 4; m++)
            CHK(chmod(path2, 0600 | (m << 3)), "chmod");
        /* read back and validate the pattern (enriched adjudication:
         * want/got bytes, size, hardlink cross-read, retry after 50ms —
         * separates transient rename-path cache incoherence from
         * persistent wrong data) */
        fd = open(path2, O_RDONLY);
        if (fd < 0) {
            rs_err("fsmeta reopen worker=%d errno=%d", id, errno);
            _exit(1);
        }
        char rb[64];
        ssize_t rn = read(fd, rb, sizeof rb);
        struct stat st_after;
        fstat(fd, &st_after);
        CHK(close(fd), "close2");
        if (rn != (ssize_t)sizeof rb || memcmp(rb, buf, sizeof rb) != 0) {
            char lpath[512];
            struct timespec rs50 = { 0, 50 * 1000 * 1000 };
            nanosleep(&rs50, NULL);
            /* cross-read through the hardlink (same inode, other name) */
            snprintf(lpath, sizeof lpath, "%s/w%d/l%ld", g_fs_root, id, f);
            int lfd = open(lpath, O_RDONLY);
            char lb[64];
            ssize_t ln = lfd >= 0 ? read(lfd, lb, sizeof lb) : -1;
            if (lfd >= 0)
                close(lfd);
            /* retry the renamed name */
            fd = open(path2, O_RDONLY);
            char rb2[64];
            ssize_t rn2 = fd >= 0 ? read(fd, rb2, sizeof rb2) : -1;
            if (fd >= 0)
                close(fd);
            rs_err("fsmeta CORRUPT worker=%d file=%s n=%zd size=%lld "
                   "want=%.24s got=%.24s retry_n=%zd retry_ok=%d "
                   "link_n=%zd link_ok=%d",
                   id, path2, rn, (long long)st_after.st_size, buf, rb,
                   rn2, rn2 == 64 && memcmp(rb2, buf, 64) == 0, ln,
                   ln == 64 && memcmp(lb, buf, 64) == 0);
            if (!(rn2 == 64 && memcmp(rb2, buf, 64) == 0))
                _exit(1); /* persistent corruption: fail the class */
        }
        CHK(unlink(path2), "unlink");
        snprintf(path2, sizeof path2, "%s/w%d/l%ld", g_fs_root, id, f);
        CHK(unlink(path2), "unlink-link");
        snprintf(path2, sizeof path2, "%s/w%d/s%ld", g_fs_root, id, f);
        CHK(unlink(path2), "unlink-symlink");
        sh->ops[id] += 12;
        pass++;
    }
    snprintf(path, sizeof path, "%s/w%d", g_fs_root, id);
    rmdir(path);
    _exit(0);
}
#undef CHK

/* =====================================================================
 * classes: pipe / sock — writer/reader pairs pumping seq-stamped
 * blocks; reader validates monotonic sequence and byte count. Reader
 * verdict propagates via exit code (0 clean, 1 corrupt).
 * ===================================================================== */
static size_t g_block = 4096;

static int pump_pair(int id, int use_socket)
{
    int fds[2];
    if (use_socket ? socketpair(AF_UNIX, SOCK_STREAM, 0, fds) : pipe(fds)) {
        rs_err("%s pair worker=%d errno=%d", use_socket ? "sock" : "pipe", id,
               errno);
        return -1;
    }
    pid_t r = fork();
    if (r < 0) {
        rs_err("pair fork worker=%d errno=%d", id, errno);
        return -1;
    }
    if (r == 0) {
        /* reader child */
        close(fds[1]);
        install_term_handler();
        uint64_t expect = 0, got_bytes = 0, blocks = 0;
        char *rb = malloc(g_block);
        if (!rb)
            _exit(1);
        for (;;) {
            ssize_t n = read(fds[0], rb, g_block);
            if (n < 0) {
                if (errno == EINTR && should_stop())
                    break;
                rs_err("reader read errno=%d", errno);
                _exit(1);
            }
            if (n == 0)
                break; /* EOF: clean stop */
            uint64_t seq;
            memcpy(&seq, rb, 8);
            if (seq != expect) {
                rs_err("%s CORRUPT seq worker=%d want=%llu got=%llu",
                       use_socket ? "sock" : "pipe", id,
                       (unsigned long long)expect, (unsigned long long)seq);
                _exit(1);
            }
            expect++;
            got_bytes += (uint64_t)n;
            blocks++;
        }
        _exit(got_bytes % 1 == 0 && blocks == expect ? 0 : 1);
    }
    /* writer (the worker process itself) */
    close(fds[0]);
    uint64_t seq = 0;
    char *wb = malloc(g_block);
    if (!wb)
        _exit(1);
    memset(wb, 0x5A, g_block);
    while (!should_stop()) {
        memcpy(wb, &seq, 8);
        ssize_t n = write(fds[1], wb, g_block);
        if (n < 0) {
            if (errno == EINTR && should_stop())
                break;
            rs_err("writer write errno=%d", errno);
            _exit(1);
        }
        if (n != (ssize_t)g_block) {
            rs_err("short write worker=%d n=%zd", id, n);
            _exit(1);
        }
        seq++;
        sh->ops[id]++;
    }
    close(fds[1]); /* EOF */
    int st;
    if (waitpid(r, &st, 0) != r) {
        rs_err("reader waitpid errno=%d", errno);
        return -1;
    }
    if (!WIFEXITED(st) || WEXITSTATUS(st) != 0) {
        rs_err("reader verdict worker=%d st=%d", id, st);
        return -1;
    }
    return 0;
}

static void worker_pipe(int id)  { _exit(pump_pair(id, 0)); }
static void worker_sock(int id)  { _exit(pump_pair(id, 1)); }

/* =====================================================================
 * class: sem — SysV semaphore ops on a shared set + periodic
 * create/destroy of side sets (id churn through the ipc namespace).
 * ===================================================================== */
static void worker_sem(int id)
{
    key_t priv = IPC_PRIVATE;
    int sid = semget(priv, 1, IPC_CREAT | 0666);
    if (sid < 0) {
        rs_err("semget worker=%d errno=%d", id, errno);
        _exit(1);
    }
    if (semctl(sid, 0, SETVAL, 1) == -1) {
        rs_err("semctl SETVAL worker=%d errno=%d", id, errno);
        _exit(1);
    }
    uint64_t ops = 0;
    while (!should_stop()) {
        struct sembuf sv[2];
        sv[0].sem_num = 0;
        sv[0].sem_op = -1;
        sv[0].sem_flg = 0;
        sv[1].sem_num = 0;
        sv[1].sem_op = 1;
        sv[1].sem_flg = 0;
        if (semop(sid, sv, 2) != 0) {
            if (errno == EINTR && should_stop())
                break;
            rs_err("semop worker=%d errno=%d", id, errno);
            _exit(1);
        }
        ops++;
        /* every 4096 ops: side-set id churn */
        if ((ops & 4095) == 0) {
            int s2 = semget(IPC_PRIVATE, 4, IPC_CREAT | 0600);
            if (s2 < 0) {
                rs_err("semget churn worker=%d errno=%d", id, errno);
                _exit(1);
            }
            struct sembuf z;
            z.sem_num = 3;
            z.sem_op = 2;
            z.sem_flg = 0;
            if (semop(s2, &z, 1) != 0) {
                rs_err("semop churn worker=%d errno=%d", id, errno);
                _exit(1);
            }
            if (semctl(s2, 0, IPC_RMID) != 0) {
                rs_err("semctl RMID worker=%d errno=%d", id, errno);
                _exit(1);
            }
        }
        sh->ops[id] += 2;
    }
    if (semctl(sid, 0, IPC_RMID) != 0 && !should_stop())
        rs_err("semctl final RMID errno=%d", errno);
    _exit(0);
}

/* =====================================================================
 * class: msg — N/2 producers msgsnd, N/2 consumers msgrcv on a shared
 * queue; consumers count; stop = per-consumer sentinel messages; a
 * final totals audit (sent == received) closes the run.
 * ===================================================================== */
struct rmsg { long mtype; char data[16]; };
static int g_msgid;

static void msg_producer(int id)
{
    struct rmsg m;
    m.mtype = 1;
    memset(m.data, (int)(id & 255), sizeof m.data);
    while (!should_stop()) {
        if (msgsnd(g_msgid, &m, sizeof m.data, IPC_NOWAIT) != 0) {
            if (errno == EAGAIN) /* queue full: consumers behind, retry */
                continue;
            if (errno == EINTR && should_stop())
                break;
            rs_err("msgsnd worker=%d errno=%d", id, errno);
            _exit(1);
        }
        sh->ops[id]++;
    }
    _exit(0);
}

static void msg_consumer(int id)
{
    struct rmsg m;
    while (!should_stop()) {
        ssize_t n = msgrcv(g_msgid, &m, sizeof m.data, 0, IPC_NOWAIT);
        if (n < 0) {
            if (errno == ENOMSG) /* empty: retry */
                continue;
            if (errno == EINTR && should_stop())
                break;
            rs_err("msgrcv worker=%d errno=%d", id, errno);
            _exit(1);
        }
        if (m.mtype == 0xFFFF) /* sentinel */
            break;
        sh->ops[id]++;
    }
    _exit(0);
}

static int run_msg(int workers, int timeout)
{
    g_msgid = msgget(IPC_PRIVATE, IPC_CREAT | 0666);
    if (g_msgid < 0) {
        rs_err("msgget errno=%d", errno);
        return 1;
    }
    pid_t pids[MAX_WORKERS];
    int nprod = workers / 2 > 0 ? workers / 2 : 1;
    int ncons = workers - nprod;
    if (ncons < 1) { ncons = 1; nprod--; }
    for (int i = 0; i < nprod + ncons; i++) {
        pid_t p = fork();
        if (p < 0) {
            rs_err("msg fork errno=%d", errno);
            return 1;
        }
        if (p == 0) {
            install_term_handler();
            if (i < nprod)
                msg_producer(i);
            else
                msg_consumer(i);
        }
        pids[i] = p;
    }
    double t0 = monotime();
    int last_beat = 0;
    while (1) {
        double el = monotime() - t0;
        if ((int)el / BEAT_SECS != last_beat) {
            last_beat = (int)el / BEAT_SECS;
            printf("RS-BEAT t=%d ops=%llu\n", (int)el,
                   (unsigned long long)total_ops());
            fflush(stdout);
        }
        if (el >= timeout || sh->err_count) {
            sh->stop = 1;
            break;
        }
        usleep(200000);
    }
    /* consumers stop on the shared flag; audit + teardown */
    int fails = reap_all(pids, nprod + ncons, 15);
    struct msqid_ds ds;
    if (msgctl(g_msgid, IPC_STAT, &ds) == 0) {
        /* consumers exit on the stop flag with the queue possibly holding
         * backlog; drain what remains and count it */
        struct rmsg m;
        uint64_t drained = 0;
        while (msgrcv(g_msgid, &m, sizeof m.data, 0, IPC_NOWAIT) >= 0)
            drained++;
        if (msgctl(g_msgid, IPC_STAT, &ds) == 0 && ds.msg_qnum != 0)
            rs_err("msg audit: queue not drainable qnum=%llu",
                   (unsigned long long)ds.msg_qnum);
    } else {
        rs_err("msgctl IPC_STAT errno=%d", errno);
    }
    if (msgctl(g_msgid, IPC_RMID, NULL) != 0)
        rs_err("msgctl RMID errno=%d", errno);
    printf("RS-DONE class=msg ops=%llu rc=%d\n",
           (unsigned long long)total_ops(), fails || sh->err_count ? 1 : 0);
    fflush(stdout);
    return fails || sh->err_count ? 1 : 0;
}

/* =====================================================================
 * class: shm — create/attach/verify/detach/rmid of private segments
 * (page-stamp verified), plus one shared segment forked attachers
 * increment in.
 * ===================================================================== */
static size_t g_shm_bytes = 4UL << 20;

static void worker_shm(int id)
{
    while (!should_stop()) {
        int sid = shmget(IPC_PRIVATE, g_shm_bytes, IPC_CREAT | 0600);
        if (sid < 0) {
            rs_err("shmget worker=%d errno=%d", id, errno);
            _exit(1);
        }
        unsigned char *a = shmat(sid, NULL, 0);
        if (a == (unsigned char *)-1) {
            rs_err("shmat worker=%d errno=%d", id, errno);
            _exit(1);
        }
        for (size_t off = 0; off < g_shm_bytes; off += 4096)
            a[off] = (unsigned char)((off >> 12) + id);
        for (size_t off = 0; off < g_shm_bytes; off += 4096)
            if (a[off] != (unsigned char)((off >> 12) + id)) {
                rs_err("shm CORRUPT worker=%d off=%zu v=%u", id, off, a[off]);
                _exit(1);
            }
        if (shmdt(a) != 0) {
            rs_err("shmdt worker=%d errno=%d", id, errno);
            _exit(1);
        }
        if (shmctl(sid, IPC_RMID, NULL) != 0) {
            rs_err("shmctl RMID worker=%d errno=%d", id, errno);
            _exit(1);
        }
        sh->ops[id]++;
    }
    _exit(0);
}

/* =====================================================================
 * class: futex — waiters/waker storm on one word (threads; exercises
 * the wake path the WAKE-STRANDED census watches).
 * ===================================================================== */
static volatile uint32_t ftx;
static volatile uint64_t ftx_wakes, ftx_wait_hits;
static pthread_t ftx_threads[MAX_WORKERS];

static void *ftx_waiter(void *arg)
{
    long id = (long)arg;
    uint32_t v;
    while (!should_stop()) {
        v = ftx;
        if (syscall(SYS_futex, &ftx, FUTEX_WAIT_PRIVATE, v, NULL) == 0)
            __sync_fetch_and_add(&ftx_wait_hits, 1);
        else if (errno != EAGAIN && errno != EINTR)
            rs_err("futex wait rc errno=%d", errno);
        sh->ops[id]++;
    }
    return NULL;
}

static int run_futex(int workers, int timeout)
{
    ftx = 0;
    int nwait = workers > 1 ? workers - 1 : 1;
    for (long i = 0; i < nwait; i++)
        if (pthread_create(&ftx_threads[i], NULL, ftx_waiter, (void *)i)) {
            rs_err("pthread_create errno=%d", errno);
            return 1;
        }
    double t0 = monotime();
    int last_beat = 0;
    while (monotime() - t0 < timeout && !sh->err_count) {
        double el = monotime() - t0;
        if ((int)el / BEAT_SECS != last_beat) {
            last_beat = (int)el / BEAT_SECS;
            printf("RS-BEAT t=%d ops=%llu wakes=%llu hits=%llu\n", (int)el,
                   (unsigned long long)total_ops(),
                   (unsigned long long)ftx_wakes,
                   (unsigned long long)ftx_wait_hits);
            fflush(stdout);
        }
        /* flip the word and wake everything */
        __sync_synchronize();
        ftx++;
        int n = syscall(SYS_futex, &ftx, FUTEX_WAKE_PRIVATE, INT_MAX, NULL);
        if (n < 0)
            rs_err("futex wake errno=%d", errno);
        ftx_wakes += n > 0 ? (uint64_t)n : 0;
        sh->ops[workers - 1]++;
        usleep(2000); /* ~500 wake rounds/s: storm, not livelock */
    }
    sh->stop = 1;
    ftx++;
    syscall(SYS_futex, &ftx, FUTEX_WAKE_PRIVATE, INT_MAX, NULL);
    for (int i = 0; i < nwait; i++)
        pthread_join(ftx_threads[i], NULL);
    printf("RS-DONE class=futex ops=%llu rc=%d\n",
           (unsigned long long)total_ops(), sh->err_count ? 1 : 0);
    fflush(stdout);
    return sh->err_count ? 1 : 0;
}

/* =====================================================================
 * class: sched — sched_yield storm + SIGUSR1 wakeup ping-pong pairs
 * (process pairs on the same CPU: kill → pending → delivered on yield).
 * ===================================================================== */
static volatile sig_atomic_t g_sig_count;

static void on_usr1(int sig) { (void)sig; g_sig_count++; }

static void sched_pair_child(int id, volatile uint32_t *flag)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = on_usr1;
    sigaction(SIGUSR1, &sa, NULL);
    while (!should_stop()) {
        sched_yield();
        if (*flag == 1) {
            *flag = 0;
            __sync_synchronize();
            kill(getppid(), SIGUSR1);
            sh->ops[id]++;
        }
    }
    _exit(0);
}

static int run_sched(int workers, int timeout)
{
    /* parent registers the handler for pong counting */
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_handler = on_usr1;
    sigaction(SIGUSR1, &sa, NULL);
    pid_t pids[MAX_WORKERS];
    volatile uint32_t *flags = mmap(NULL, 4096, PROT_READ | PROT_WRITE,
                                    MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (flags == MAP_FAILED) {
        rs_err("sched flag mmap errno=%d", errno);
        return 1;
    }
    int pairs = workers / 2 > 0 ? workers / 2 : 1;
    for (int i = 0; i < pairs; i++) {
        pid_t p = fork();
        if (p < 0) {
            rs_err("sched fork errno=%d", errno);
            return 1;
        }
        if (p == 0) {
            install_term_handler();
            sched_pair_child(i, &flags[i]);
        }
        pids[i] = p;
    }
    double t0 = monotime();
    int last_beat = 0, turn = 0;
    while (monotime() - t0 < timeout && !sh->err_count) {
        double el = monotime() - t0;
        if ((int)el / BEAT_SECS != last_beat) {
            last_beat = (int)el / BEAT_SECS;
            printf("RS-BEAT t=%d ops=%llu sigs=%d\n", (int)el,
                   (unsigned long long)total_ops(), g_sig_count);
            fflush(stdout);
        }
        for (int i = 0; i < pairs; i++) {
            flags[i] = 1; /* child will pong us back */
            turn++;
        }
        sh->ops[pairs] += pairs;
        sched_yield();
        usleep(1000);
    }
    sh->stop = 1;
    int fails = reap_all(pids, pairs, 10);
    munmap((void *)flags, 4096);
    printf("RS-DONE class=sched ops=%llu rc=%d\n",
           (unsigned long long)total_ops(), fails || sh->err_count ? 1 : 0);
    fflush(stdout);
    return fails || sh->err_count ? 1 : 0;
}

/* =====================================================================
 * class: timer — POSIX timer create/settime(1ms interval)/delete
 * churn + clock_gettime monotonicity check + nanosleep(2ms) latency
 * storm (tick discipline).
 * ===================================================================== */
static volatile uint64_t g_timer_sigs;

static void on_alrm(int sig, siginfo_t *si, void *uc)
{
    (void)sig; (void)si; (void)uc;
    g_timer_sigs++;
}

static void worker_timer(int id)
{
    struct sigaction sa;
    memset(&sa, 0, sizeof sa);
    sa.sa_sigaction = on_alrm;
    sa.sa_flags = SA_SIGINFO | SA_RESTART;
    sigaction(SIGRTMIN, &sa, NULL);
    struct timespec prev = { 0, 0 };
    uint64_t sleeps = 0;
    double over_ns = 0, worst_ns = 0;
    while (!should_stop()) {
        /* create/arm/delete churn */
        timer_t tid;
        struct sigevent sev;
        memset(&sev, 0, sizeof sev);
        sev.sigev_notify = SIGEV_SIGNAL;
        sev.sigev_signo = SIGRTMIN;
        if (timer_create(CLOCK_MONOTONIC, &sev, &tid) != 0) {
            rs_err("timer_create worker=%d errno=%d", id, errno);
            _exit(1);
        }
        struct itimerspec its;
        its.it_interval.tv_sec = 0;
        its.it_interval.tv_nsec = 1000000; /* 1ms */
        its.it_value = its.it_interval;
        if (timer_settime(tid, 0, &its, NULL) != 0) {
            rs_err("timer_settime worker=%d errno=%d", id, errno);
            _exit(1);
        }
        /* clock discipline: monotonic must not go backwards */
        struct timespec now;
        clock_gettime(CLOCK_MONOTONIC, &now);
        if (now.tv_sec < prev.tv_sec ||
            (now.tv_sec == prev.tv_sec && now.tv_nsec < prev.tv_nsec)) {
            rs_err("CLOCK_MONOTONIC went BACKWARDS worker=%d %ld.%09ld -> %ld.%09ld",
                   id, prev.tv_sec, prev.tv_nsec, now.tv_sec, now.tv_nsec);
            _exit(1);
        }
        prev = now;
        /* nanosleep(2ms) latency storm: measure overshoot */
        struct timespec req = { 0, 2000000 }, rem;
        struct timespec a, b;
        clock_gettime(CLOCK_MONOTONIC, &a);
        if (nanosleep(&req, &rem) != 0 && errno != EINTR) {
            rs_err("nanosleep worker=%d errno=%d", id, errno);
            _exit(1);
        }
        clock_gettime(CLOCK_MONOTONIC, &b);
        double dt = (b.tv_sec - a.tv_sec) * 1e9 + (b.tv_nsec - a.tv_nsec);
        over_ns += dt - 2000000.0;
        if (dt - 2000000.0 > worst_ns)
            worst_ns = dt - 2000000.0;
        sleeps++;
        if (timer_delete(tid) != 0) {
            rs_err("timer_delete worker=%d errno=%d", id, errno);
            _exit(1);
        }
        sh->ops[id] += 4;
        if ((sleeps & 1023) == 0)
            printf("RS-TIMER w%d sleeps=%llu avg_over_us=%.0f worst_over_us=%.0f sigs=%llu\n",
                   id, (unsigned long long)sleeps, over_ns / sleeps / 1000.0,
                   worst_ns / 1000.0, (unsigned long long)g_timer_sigs),
            fflush(stdout);
    }
    _exit(0);
}

/* =====================================================================
 * class: spawn — run an external probe binary (argv passthrough) so
 * the rsrun vehicle can drive minimal reproducers (e.g. renameco).
 * Ops counter = exit status != 0.
 * ===================================================================== */
static char *g_spawn_args[32];
static int g_spawn_nargs;

static void worker_spawn(int id)
{
    (void)id;
    pid_t p = fork();
    if (p < 0)
        _exit(1);
    if (p == 0) {
        execv(g_spawn_args[0], g_spawn_args);
        rs_err("spawn exec %s errno=%d", g_spawn_args[0], errno);
        _exit(127);
    }
    int st;
    if (waitpid(p, &st, 0) != p)
        _exit(1);
    _exit(WIFEXITED(st) ? WEXITSTATUS(st) : 128 + WTERMSIG(st));
}

/* =====================================================================
 * parent machinery
 * ===================================================================== */
typedef void (*worker_fn)(int);

static int reap_all(pid_t *pids, int n, int grace)
{
    int alive = n;
    double t0 = monotime();
    while (alive > 0 && monotime() - t0 < grace) {
        for (int i = 0; i < n; i++) {
            int st;
            if (pids[i] <= 0)
                continue;
            pid_t r = waitpid(pids[i], &st, WNOHANG);
            if (r == pids[i]) {
                if (!WIFEXITED(st) || WEXITSTATUS(st) != 0) {
                    if (WIFSIGNALED(st) && WTERMSIG(st) == SIGKILL)
                        rs_err("worker %d needed SIGKILL (wedge)", (int)pids[i]);
                    else
                        rs_err("worker %d bad status %d", (int)pids[i], st);
                    return 1;
                }
                pids[i] = 0;
                alive--;
            }
        }
        usleep(50000);
    }
    if (alive > 0) {
        for (int i = 0; i < n; i++)
            if (pids[i] > 0) {
                kill(pids[i], SIGKILL);
                rs_err("worker %d unreapable, SIGKILLed", (int)pids[i]);
            }
        for (int i = 0; i < n; i++)
            if (pids[i] > 0)
                waitpid(pids[i], NULL, 0);
        return 1;
    }
    return 0;
}

static int run_class(worker_fn fn, int workers, int timeout, const char *klass)
{
    pid_t pids[MAX_WORKERS];
    for (int i = 0; i < workers; i++) {
        pid_t p = fork();
        if (p < 0) {
            rs_err("fork worker=%d errno=%d", i, errno);
            sh->stop = 1;
            reap_all(pids, i, 10);
            return 1;
        }
        if (p == 0) {
            install_term_handler();
            fn(i); /* _exit()s */
        }
        pids[i] = p;
    }
    double t0 = monotime();
    int last_beat = 0;
    while (1) {
        double el = monotime() - t0;
        if ((int)el / BEAT_SECS != last_beat) {
            last_beat = (int)el / BEAT_SECS;
            printf("RS-BEAT t=%d ops=%llu\n", (int)el,
                   (unsigned long long)total_ops());
            fflush(stdout);
        }
        if (el >= timeout || sh->err_count)
            break;
        usleep(200000);
    }
    sh->stop = 1;
    int fails = reap_all(pids, workers, 15);
    printf("RS-DONE class=%s ops=%llu rc=%d\n", klass,
           (unsigned long long)total_ops(), fails || sh->err_count ? 1 : 0);
    fflush(stdout);
    return fails || sh->err_count ? 1 : 0;
}

static size_t parse_bytes(const char *s)
{
    char *end;
    unsigned long long v = strtoull(s, &end, 10);
    if (end && *end) {
        if (*end == 'K' || *end == 'k') v <<= 10;
        else if (*end == 'M' || *end == 'm') v <<= 20;
        else if (*end == 'G' || *end == 'g') v <<= 30;
    }
    return (size_t)v;
}

int main(int argc, char **argv)
{
    int workers = 1;
    int timeout = 60;
    const char *klass = NULL;

    /* exec-class child marker: exit immediately after re-exec */
    if (argc == 2 && !strcmp(argv[1], "--exec-child")) {
        struct timespec ts = { 0, 2 * 1000 * 1000 };
        nanosleep(&ts, NULL); /* minimal user work */
        _exit(0);
    }

    for (int i = 1; i < argc; i++) {
        if (!strncmp(argv[i], "--", 2) && argv[i][2] && !strstr(argv[i], "=") &&
            i + 1 < argc && !strncmp(argv[i + 1], "--", 2)) {
            /* flag-style class with implicit worker count of 1 */
            klass = argv[i] + 2;
            workers = 1;
            continue;
        }
        if (i + 1 >= argc)
            break;
        const char *k = argv[i];
        const char *v = argv[i + 1];
        if (!strcmp(k, "--timeout")) timeout = atoi(v);
        else if (!strcmp(k, "--vm-bytes")) g_vm_bytes = parse_bytes(v);
        else if (!strcmp(k, "--block")) g_block = parse_bytes(v);
        else if (!strcmp(k, "--fs-root")) g_fs_root = v;
        else if (!strcmp(k, "--shm-bytes")) g_shm_bytes = parse_bytes(v);
        else if (!strcmp(k, "--spawn")) {
            klass = "spawn";
            workers = 1;
            /* everything after --spawn is the probe argv */
            for (int j = i + 1; j < argc && g_spawn_nargs < 31; j++)
                g_spawn_args[g_spawn_nargs++] = argv[j];
            break;
        }
        else if (!strncmp(k, "--", 2) && k[2] != '\0') {
            klass = k + 2;
            workers = atoi(v);
        }
        i++;
    }
    if (!klass) {
        fprintf(stderr, "rs: no stressor class given\n");
        return 2;
    }
    g_class = klass;
    if (readlink("/proc/self/exe", g_self, sizeof g_self - 1) < 0)
        snprintf(g_self, sizeof g_self, "/test/stress-ng/rs");

    sh = mmap(NULL, 4096, PROT_READ | PROT_WRITE,
              MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (sh == MAP_FAILED) {
        fprintf(stderr, "rs: shared page mmap failed\n");
        return 2;
    }
    install_term_handler();
    if (workers < 1) workers = 1;
    if (workers > MAX_WORKERS) workers = MAX_WORKERS;

    printf("RS-START class=%s workers=%d timeout=%d vm-bytes=%zu\n", klass,
           workers, timeout, g_vm_bytes);
    fflush(stdout);

    int rc;
    if (!strcmp(klass, "malloc"))  rc = run_class(worker_malloc, workers, timeout, klass);
    else if (!strcmp(klass, "mmap"))    rc = run_class(worker_mmap, workers, timeout, klass);
    else if (!strcmp(klass, "bigheap")) rc = run_class(worker_bigheap, workers, timeout, klass);
    else if (!strcmp(klass, "fork"))    rc = run_class(worker_fork, workers, timeout, klass);
    else if (!strcmp(klass, "exec"))    rc = run_class(worker_exec, workers, timeout, klass);
    else if (!strcmp(klass, "fsmeta")) {
        mkdir(g_fs_root, 0755); /* may EEXIST — fine */
        rc = run_class(worker_fsmeta, workers, timeout, klass);
    }
    else if (!strcmp(klass, "pipe"))    rc = run_class(worker_pipe, workers, timeout, klass);
    else if (!strcmp(klass, "sock"))    rc = run_class(worker_sock, workers, timeout, klass);
    else if (!strcmp(klass, "sem"))     rc = run_class(worker_sem, workers, timeout, klass);
    else if (!strcmp(klass, "msg"))     rc = run_msg(workers, timeout);
    else if (!strcmp(klass, "shm"))     rc = run_class(worker_shm, workers, timeout, klass);
    else if (!strcmp(klass, "futex"))   rc = run_futex(workers, timeout);
    else if (!strcmp(klass, "sched"))   rc = run_sched(workers, timeout);
    else if (!strcmp(klass, "timer"))   rc = run_class(worker_timer, workers, timeout, klass);
    else if (!strcmp(klass, "spawn"))   rc = run_class(worker_spawn, workers, timeout, klass);
    else {
        fprintf(stderr, "rs: unknown class %s\n", klass);
        return 2;
    }
    printf("RS-EXIT class=%s rc=%d\n", klass, rc);
    fflush(stdout);
    return rc;
}
