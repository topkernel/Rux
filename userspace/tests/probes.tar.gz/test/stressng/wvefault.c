/*
 * wvefault.c — writev/readv iovec-shape semantics probe (round 15).
 *
 * Decode vehicle for the r14 relay #2 lead: one EFAULTTRAC nr=66
 * (writev) per usage()-style fprintf on the lmbench error path, with
 * the text still fully delivered. Static decode of musl 1.2.5's
 * vfprintf unbuffered-stderr path:
 *   - fprintf(stderr, FMT) on a buf_size==0 stream stages into a
 *     stack internal_buf[80]; when a chunk does not fit, __fwritex
 *     calls f->write(stderr, chunk, len) = __stdio_write ->
 *     writev(2, [{internal_buf, staged}, {chunk, len}], 2)  (mid-
 *     format flush, both iovs non-empty);
 *   - vfprintf then ALWAYS calls f->write(f, 0, 0) = writev(2,
 *     [{internal_buf, 0}, {NULL, 0}], 2)  (final flush, total 0).
 * The observed EFAULT-with-text-out matches the final-flush call:
 * the text was already delivered by the mid-format flush, so only the
 * total-0 call fails.
 *
 * This probe exercises every shape against a pipe write-end (the
 * lmbench_run rig wires the bench child's fd 1/2 to a pipe) plus the
 * real musl fprintf flow, and prints one result line per shape:
 *   S<n> r=<ret> e=<errno>
 * The host reference kernel (generic distro 7.0.x) is the expected
 * column; the Rux boot is compared against it.
 */
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <string.h>
#include <sys/uio.h>
#include <unistd.h>

static char staging[80]; /* vfprintf's internal_buf analog (stack/BSS) */
static const char usage_str[] =
    "-s\n OR [-S] [-m <message size>] [-P <parallelism>] [-W <warmup>]"
    " [-N <repetitions>] server\n NOTE: message size must be >= 4\n";

static char outbuf[4096];
static int outpos;

static void emit(const char *s)
{
    int l = strlen(s);
    if (write(1, s, l)) {
    }
    memcpy(outbuf + outpos, s, l);
    outpos += l;
}

static int pfd[2]; /* write end = the probe's victim fd */

static void drain(const char *tag)
{
    char buf[512];
    int r = read(pfd[0], buf, sizeof(buf));
    char line[64];
    int n = snprintf(line, sizeof(line), "%s drained=%d\n", tag, r);
    if (write(1, line, n)) {}

    if (r > 0) {
        n = snprintf(line, sizeof(line), "%s data='%.*s'\n", tag,
                     r > 40 ? 40 : r, buf);
        if (write(1, line, n)) {}

    }
}

static void tryv(const char *tag, struct iovec *iov, int cnt)
{
    int r, e;
    char line[128];
    errno = 0;
    r = writev(pfd[1], iov, cnt);
    e = errno;
    snprintf(line, sizeof(line), "%s r=%d e=%d\n", tag, r, e);
    if (write(1, line, strlen(line))) {}
}

int main(int argc, char **argv)
{
    char line[128];
    int r, e, n;
    struct iovec v[2];

    emit("WV-EFAULT PROBE start\n");

    if (pipe(pfd)) {
        emit("pipe fail\n");
        return 1;
    }
    fcntl(pfd[0], F_SETFL, O_NONBLOCK);
    memcpy(staging, "Usage: /test/lat_udp ", 21);

    /* S0 control: one plain iov */
    v[0].iov_base = staging;
    v[0].iov_len = 5;
    tryv("S0[{stack,5}]", v, 1);
    drain("S0");

    /* S1 mid-format flush: [{internal_buf,staged},{rodata chunk,150}] */
    v[0].iov_base = staging;
    v[0].iov_len = 21;
    v[1].iov_base = (void *)usage_str;
    v[1].iov_len = strlen(usage_str);
    tryv("S1[{stack21},{rodata,150}]", v, 2);
    drain("S1");

    /* S2 musl vfprintf FINAL flush: [{internal_buf,0},{NULL,0}] total 0 */
    v[0].iov_base = staging;
    v[0].iov_len = 0;
    v[1].iov_base = NULL;
    v[1].iov_len = 0;
    tryv("S2[{stack,0},{NULL,0}]", v, 2);
    drain("S2");

    /* S2b single zero-length iov */
    v[0].iov_base = staging;
    v[0].iov_len = 0;
    tryv("S2b[{stack,0}]", v, 1);
    drain("S2b");

    /* S3 fwrite shape, empty first iov: [{NULL,0},{stack,18}] */
    v[0].iov_base = NULL;
    v[0].iov_len = 0;
    v[1].iov_base = staging;
    v[1].iov_len = 18;
    tryv("S3[{NULL,0},{stack,18}]", v, 2);
    drain("S3");

    /* S4 all-NULL zero-length vector */
    v[0].iov_base = NULL;
    v[0].iov_len = 0;
    v[1].iov_base = NULL;
    v[1].iov_len = 0;
    tryv("S4[{NULL,0},{NULL,0}]", v, 2);
    drain("S4");

    /* S5 mixed: valid first, kernel-range second (import_iovec must
     * reject the WHOLE vector before writing anything) */
    v[0].iov_base = staging;
    v[0].iov_len = 3;
    v[1].iov_base = (void *)0xffff800000000000UL;
    v[1].iov_len = 5;
    tryv("S5[{stack,3},{KERNADDR,5}]", v, 2);
    drain("S5");

    /* S6 mixed: valid first, NULL base with len>0 second */
    v[0].iov_base = staging;
    v[0].iov_len = 3;
    v[1].iov_base = NULL;
    v[1].iov_len = 5;
    tryv("S6[{stack,3},{NULL,5}]", v, 2);
    drain("S6");

    /* S7 iovcnt = 0 */
    tryv("S7 iovcnt=0", v, 0);

    /* S8 negative length: EINVAL (established LTP shape, control) */
    v[0].iov_base = staging;
    v[0].iov_len = (size_t)-1;
    tryv("S8[{stack,-1}]", v, 1);

    /* S9 readv with the total-0 vector (nothing in the pipe):
     * must not block, must not EFAULT */
    {
        struct iovec rv[2];
        rv[0].iov_base = staging;
        rv[0].iov_len = 0;
        rv[1].iov_base = NULL;
        rv[1].iov_len = 0;
        errno = 0;
        r = readv(pfd[0], rv, 2);
        e = errno;
        n = snprintf(line, sizeof(line), "S9 readv total0 r=%d e=%d\n", r, e);
        if (write(1, line, n)) {}

    }

    /* S10 the REAL musl flow: fresh pipe on fd 2, one fprintf with a
     * format that exceeds internal_buf[80] (forces the mid-format
     * flush + total-0 final flush), then ferror check + drain. */
    {
        int p2[2];
        char buf[512];
        if (pipe(p2) == 0) {
            dup2(p2[1], 2);
            close(p2[1]);
            fcntl(p2[0], F_SETFL, O_NONBLOCK);
            errno = 0;
            r = fprintf(stderr, "Usage: %s %s", "/test/lat_udp", usage_str);
            e = errno;
            int ferr = ferror(stderr);
            n = snprintf(line, sizeof(line),
                         "S10 fprintf r=%d e=%d ferror=%d\n", r, e, ferr);
            if (write(1, line, n)) {}

            r = read(p2[0], buf, sizeof(buf));
            n = snprintf(line, sizeof(line), "S10 drained=%d (expect %d)\n",
                         r, (int)(21 + strlen(usage_str) - 21 + 21));
            if (write(1, line, n)) {}

            close(p2[0]);
        }
    }

    emit("WV-EFAULT PROBE done\n");
    return 0;
}
