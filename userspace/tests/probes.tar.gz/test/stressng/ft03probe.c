/* ft03probe.c — instrumented ftest03 clone (stress-port r10, LTP r24
 * ftest03 handoff). Reproduces the ftest03.c workload faithfully:
 * 5 children, per-child file, random-chunk readv/writev with per-child
 * pattern verification, misc ops (fsync / truncate+ftruncate / fstat),
 * SIGTERM fan-out. Differences are diagnostics only:
 *   - parent prints each child's RAW wait status (signaled vs exit code)
 *   - children print the exact failing detail (chunk, xfr, expected vs
 *     got bytes, surrounding words) before exiting
 *   - per-iteration heartbeat with val/count/collide
 *   - deterministic seed control via argv (default: getpid like LTP)
 * Usage: ft03probe [iterations] [nchild] [seed]
 */
#define _XOPEN_SOURCE 500
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/uio.h>
#include <sys/stat.h>
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <time.h>

#define MAXCHILD 25
#define K_1 1024
#define MAXIOVCNT 16
#define NMISC 4

static int csize, iterations, max_size, misc_intvl, nchild;
static int fd_arr[MAXCHILD];
static pid_t pidlist[MAXCHILD];
static int parent_pid;
static char test_name[MAXCHILD][2];
static char fuss[256];

static void term(int sig)
{
    (void)sig;
    if (parent_pid == getpid()) {
        for (int i = 0; i < nchild; i++)
            if (pidlist[i])
                kill(pidlist[i], SIGTERM);
        return;
    }
    _exit(0); /* children: die 0 on TERM (LTP's handler unlinks + exits 0) */
}

static void dump_fail(int me, const char *tag, int chunk, int val, int xfr,
                      int file_max, struct iovec *iov, struct iovec *exp)
{
    /* Print the first 4 mismatching bytes with addresses and neighbors */
    printf("FAIL c%d %s chunk=%d(0x%x) val=%d xfr=%d file_max=0x%x errno=%d\n",
           me, tag, chunk, chunk * csize, val, xfr, file_max, errno);
    for (int i = 0; i < MAXIOVCNT; i++) {
        unsigned char *g = (unsigned char *)iov[i].iov_base;
        unsigned char *e = (unsigned char *)exp[i].iov_base;
        for (size_t j = 0; j < iov[i].iov_len; j++) {
            if (g[j] != e[j]) {
                int lo = (int)j - 4; if (lo < 0) lo = 0;
                printf("  iov%d off+%zu: got", i, j);
                for (int k = lo; k < lo + 9 && (size_t)k < iov[i].iov_len; k++)
                    printf(" %02x", g[k]);
                printf("\n  iov%d        exp", i);
                for (int k = lo; k < lo + 9 && (size_t)k < iov[i].iov_len; k++)
                    printf(" %02x", e[k]);
                printf("\n");
                return;
            }
        }
    }
    printf("  (no byte mismatch found?!)\n");
}

static void domisc(int me, int fd, char *bits, int *file_max, int *last_trunc,
                   int *tr_flag)
{
    static int type;
    struct stat sb;
    if (type > 2) type = 0;
    switch (type) {
    case 0:
        if (fsync(fd) < 0)
            printf("FAIL c%d fsync errno=%d\n", me, errno);
        break;
    case 1: {
        int chunk = rand() % (*file_max / csize);
        *file_max = chunk * csize;
        *last_trunc = *file_max;
        int rc;
        if (*tr_flag) {
            rc = ftruncate(fd, *file_max);
            *tr_flag = 0;
        } else {
            rc = truncate(test_name[me], *file_max);
            *tr_flag = 1;
        }
        if (rc < 0)
            printf("FAIL c%d trunc errno=%d @0x%x\n", me, errno, *file_max);
        for (; chunk % 8 != 0; chunk++)
            bits[chunk / 8] &= ~(1 << (chunk % 8));
        for (; chunk < max_size / csize; chunk += 8)
            bits[chunk / 8] = 0;
        break;
    }
    case 2:
        if (fstat(fd, &sb) < 0)
            printf("FAIL c%d fstat errno=%d\n", me, errno);
        else if (sb.st_size != *file_max)
            printf("FAIL c%d fstat size=%llx != file_max=0x%x\n", me,
                   (unsigned long long)sb.st_size, *file_max);
        break;
    }
    type++;
}

static void dotest(int me, int fd, int seed)
{
    int nchunks = max_size / csize;
    char *bits = calloc((nchunks + 7) / 8, 1);
    char *hold_bits = calloc((nchunks + 7) / 8, 1);
    struct iovec r_iovec[MAXIOVCNT], val_iovec[MAXIOVCNT], zero_iovec[MAXIOVCNT];
    int rlen = csize / MAXIOVCNT;
    int file_max = 0, last_trunc = -1, tr_flag = 0, val, iter = 0;
    char name[2] = { (char)('a' + me), 0 };

    for (int i = 0; i < MAXIOVCNT; i++) {
        r_iovec[i].iov_base = calloc(rlen, 1);
        r_iovec[i].iov_len = rlen;
        val_iovec[i].iov_base = calloc(rlen, 1);
        val_iovec[i].iov_len = rlen;
        zero_iovec[i].iov_base = calloc(rlen, 1);
        zero_iovec[i].iov_len = rlen;
    }
    val = (64 / nchild) * me + 1;
    srand(seed);
    printf("CHILD c%d start pid=%d seed=%d val0=%d\n", me, getpid(), seed, val);
    fflush(stdout);

    while (iterations-- > 0) {
        int count = 0, collide = 0, whenmisc = (rand() % misc_intvl) + 5;
        ftruncate(fd, 0);
        file_max = 0;
        memset(bits, 0, (nchunks + 7) / 8);
        memset(hold_bits, 0, (nchunks + 7) / 8);
        for (int i = 0; i < MAXIOVCNT; i++) {
            memset(val_iovec[i].iov_base, val, rlen);
            memset(zero_iovec[i].iov_base, 0, rlen);
        }
        while (count < nchunks) {
            int chunk = rand() % nchunks;
            if (lseek(fd, (long)chunk * csize, 0) < 0) {
                printf("FAIL c%d lseek errno=%d @0x%x\n", me, errno, chunk * csize);
                fflush(stdout); _exit(3);
            }
            int xfr = (int)readv(fd, r_iovec, MAXIOVCNT);
            if (xfr < 0) {
                printf("FAIL c%d readv errno=%d @0x%x\n", me, errno, chunk * csize);
                fflush(stdout); _exit(4);
            }
            if ((long)chunk * csize >= file_max) {
                bits[chunk / 8] |= (1 << (chunk % 8));
                ++count;
            } else if (!(bits[chunk / 8] & (1 << (chunk % 8)))) {
                if (xfr != csize) {
                    printf("FAIL c%d zero-read xfr=%d != %d @0x%x fmax=0x%x ltrunc=0x%x\n",
                           me, xfr, csize, chunk * csize, file_max, last_trunc);
                    fflush(stdout); _exit(5);
                }
                for (int i = 0; i < MAXIOVCNT; i++)
                    if (memcmp(r_iovec[i].iov_base, zero_iovec[i].iov_base, rlen)) {
                        dump_fail(me, "ZERO-verify", chunk, val, xfr, file_max, r_iovec, zero_iovec);
                        fflush(stdout); _exit(6);
                    }
                bits[chunk / 8] |= (1 << (chunk % 8));
                ++count;
            } else {
                if (xfr != csize) {
                    printf("FAIL c%d val-read xfr=%d != %d @0x%x fmax=0x%x ltrunc=0x%x\n",
                           me, xfr, csize, chunk * csize, file_max, last_trunc);
                    fflush(stdout); _exit(7);
                }
                ++collide;
                for (int i = 0; i < MAXIOVCNT; i++)
                    if (memcmp(r_iovec[i].iov_base, val_iovec[i].iov_base, rlen)) {
                        dump_fail(me, "VAL-verify", chunk, val, xfr, file_max, r_iovec, val_iovec);
                        fflush(stdout); _exit(8);
                    }
            }
            if (lseek(fd, -xfr, 1) < 0) {
                printf("FAIL c%d lseek2 errno=%d\n", me, errno);
                fflush(stdout); _exit(9);
            }
            xfr = (int)writev(fd, val_iovec, MAXIOVCNT);
            if (xfr < csize) {
                printf("FAIL c%d writev xfr=%d errno=%d @0x%x\n", me, xfr, errno, chunk * csize);
                fflush(stdout); _exit(10);
            }
            if ((long)chunk * csize + csize > file_max)
                file_max = chunk * csize + csize;
            if (misc_intvl && --whenmisc <= 0) {
                domisc(me, fd, bits, &file_max, &last_trunc, &tr_flag);
                whenmisc = (rand() % misc_intvl) + 5;
            }
            if (count + collide > 2 * nchunks)
                break;
        }
        fsync(fd);
        printf("HEART c%d t=%ld iter=%d val=%d count=%d collide=%d fmax=0x%x\n",
               me, (long)time(NULL), iter, val, count, collide, file_max);
        fflush(stdout);
        ++val; ++iter;
    }
    close(fd);
    unlink(name);
    printf("CHILD c%d done rc=0\n", me);
    fflush(stdout);
    _exit(0);
}

int main(int argc, char **argv)
{
    iterations = argc > 1 ? atoi(argv[1]) : 10;
    nchild = argc > 2 ? atoi(argv[2]) : 5;
    int seed = argc > 3 ? atoi(argv[3]) : 0;
    csize = K_1 * 2;
    max_size = K_1 * K_1;
    misc_intvl = 10;
    parent_pid = getpid();

    signal(SIGTERM, term);
    snprintf(fuss, sizeof(fuss), "/ft03p.%d", getpid());
    mkdir(fuss, 0755);
    if (chdir(fuss) < 0) { printf("chdir fail %d\n", errno); return 2; }

    printf("PROBE-BEGIN nchild=%d iters=%d seed=%d dir=%s\n", nchild, iterations, seed, fuss);
    fflush(stdout);
    for (int i = 0; i < nchild; i++) {
        test_name[i][0] = 'a' + i;
        test_name[i][1] = 0;
        int fd = open(test_name[i], O_RDWR | O_CREAT | O_TRUNC, 0666);
        if (fd < 0) { printf("open fail %d\n", errno); return 2; }
        pid_t c = fork();
        if (c == 0) {
            int cseed = seed ? seed + i : getpid();
            dotest(i, fd, cseed);
        }
        fd_arr[i] = fd;
        close(fd);
        pidlist[i] = c;
    }
    int bad = 0;
    for (int i = 0; i < nchild; i++) {
        int st;
        pid_t p = wait(&st);
        if (p < 0) { printf("wait err %d\n", errno); break; }
        const char *how;
        if (WIFSIGNALED(st)) how = "SIGNALED";
        else if (WIFEXITED(st)) how = "EXITED";
        else how = "?";
        printf("PARENT reaped pid=%d %s code=%d sig=%d raw=0x%x\n", p, how,
               WIFEXITED(st) ? WEXITSTATUS(st) : -1,
               WIFSIGNALED(st) ? WTERMSIG(st) : -1, st);
        fflush(stdout);
        if (st != 0) bad++;
    }
    printf("PROBE-END bad=%d\n", bad);
    fflush(stdout);
    return bad ? 1 : 0;
}
