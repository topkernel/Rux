/* k10loop.c — guest-side kill10 hunt loop (stress-port r9).
 * Runs as PID 1 (init=/test/stress-ng/k10loop): loops kill10 with
 * completion marks, polls /proc/timer_list around each run, then
 * execs /bin/sh. No serial input needed (the UART RX path is itself
 * flaky under this load — the hunt must not depend on it). */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

static void run(const char *cmd) {
    int rc = system(cmd);
    printf("K10LOOP: [%s] rc=%d\n", cmd, rc);
    fflush(stdout);
}

static void poll_timers(int i, int j) {
    char cmd[128];
    snprintf(cmd, sizeof(cmd),
             "echo POLL-%d-%d $(wc -l < /proc/timer_list) > /dev/console; "
             "tail -n 40 /proc/timer_list > /dev/console",
             i, j);
    run(cmd);
}

int main(void) {
    for (int i = 1; i <= 8; i++) {
        char cmd[256];
        snprintf(cmd, sizeof(cmd),
                 "( /test/linux-ltp/testcases/bin/kill10 -d 4 -n 10 -g 2 "
                 "> /tmp/k10-%d.out 2>&1 < /dev/null; "
                 "echo K10RET-%d=$? > /dev/console ) &",
                 i, i);
        run(cmd); /* returns immediately (backgrounded inside sh -c) */
        for (int j = 1; j <= 5; j++) {
            sleep(11);
            poll_timers(i, j);
        }
        /* reap any finished loop */
        int st;
        while (waitpid(-1, &st, WNOHANG) > 0) {}
    }
    printf("K10LOOP-DONE\n");
    fflush(stdout);
    execl("/bin/sh", "sh", (char *)0);
    return 0;
}
