/*
 * renameco.c — minimal reproducer for the fsmeta CORRUPT finding
 * (stress-port r1): after creat+write+close, reading the file back
 * through a mutated name/metadata returns wrong bytes. Runs each op
 * sequence in its own subdirectory, N iterations, reporting the first
 * mismatch per sequence with want/got bytes, then a summary:
 *
 *   SEQ <name> iters=<n> fail=<n> first_fail_it=<n|-> [detail]
 *
 * Sequences:
 *   plain    : creat w, read back                    (write/read sanity)
 *   chmod    : creat w, chmod, read
 *   rename   : creat f, rename f->r, read r
 *   renchmod : creat f, rename f->r, chmod r, read r  (rs fsmeta shape)
 *   link     : creat f, link f->l, read l
 *   symlink  : creat f, symlink s->f, read s
 *   unlink   : creat f, unlink f (ENOENT sanity)
 * Exit 0 iff every sequence reports fail=0.
 */
#include <errno.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>

static const char *root = "/rc";

static int seq_fails;

static int check_read(const char *path, const char *want, int it)
{
    char rb[64];
    int fd = open(path, O_RDONLY);
    if (fd < 0)
        return -1;
    ssize_t n = read(fd, rb, sizeof rb);
    close(fd);
    if (n != 64 || memcmp(rb, want, 64) != 0) {
        printf("  first_fail_it=%d n=%zd want=%.24s got=%.24s\n", it, n,
               want, rb);
        fflush(stdout);
        return 1;
    }
    return 0;
}

static int run_seq(const char *name, int iters)
{
    char d[256], f[256], r[256], l[256], s[256];
    snprintf(d, sizeof d, "%s/%s", root, name);
    mkdir(d, 0755);
    snprintf(f, sizeof f, "%s/f", d);
    snprintf(r, sizeof r, "%s/r", d);
    snprintf(l, sizeof l, "%s/l", d);
    snprintf(s, sizeof s, "%s/s", d);
    int fails = 0, first = -1;
    for (int i = 0; i < iters; i++) {
        char want[64];
        snprintf(want, sizeof want, "RC%016llx%016llx",
                 (unsigned long long)i, (unsigned long long)0xABCD ^ i);
        unlink(f); unlink(r); unlink(l); unlink(s);
        int fd = open(f, O_CREAT | O_RDWR | O_TRUNC, 0644);
        if (fd < 0) {
            printf("SEQ %s creat errno=%d\n", name, errno);
            return 1;
        }
        if (write(fd, want, 64) != 64) {
            printf("SEQ %s write errno=%d\n", name, errno);
            close(fd);
            return 1;
        }
        close(fd);
        int bad = 0;
        if (!strcmp(name, "plain")) {
            bad = check_read(f, want, i) != 0;
        } else if (!strcmp(name, "chmod")) {
            chmod(f, 0640);
            bad = check_read(f, want, i) != 0;
        } else if (!strcmp(name, "rename")) {
            rename(f, r);
            bad = check_read(r, want, i) != 0;
        } else if (!strcmp(name, "renchmod")) {
            rename(f, r);
            for (int m = 0; m < 4; m++)
                chmod(r, 0600 | (m << 3));
            bad = check_read(r, want, i) != 0;
        } else if (!strcmp(name, "link")) {
            link(f, l);
            bad = check_read(l, want, i) != 0;
        } else if (!strcmp(name, "symlink")) {
            symlink(f, s);
            bad = check_read(s, want, i) != 0;
        }
        if (bad) {
            fails++;
            if (first < 0)
                first = i;
            if (fails >= 3)
                break; /* enough evidence */
        }
    }
    printf("SEQ %s iters=%d fail=%d first_fail_it=%d\n", name, iters, fails,
           first);
    fflush(stdout);
    seq_fails = fails;
    return fails != 0;
}

int main(int argc, char **argv)
{
    int iters = argc > 1 ? atoi(argv[1]) : 200;
    if (argc > 2)
        root = argv[2];
    mkdir(root, 0755);
    int rc = 0;
    static char summary[512];
    int off = 0;
#define RUN_SEQ(nm)                                                    \
    do {                                                               \
        int f = run_seq(nm, iters);                                    \
        rc |= f;                                                       \
        off += snprintf(summary + off, sizeof(summary) - off, " %s=%d", \
                        nm, seq_fails);                                \
    } while (0)
    RUN_SEQ("plain");
    RUN_SEQ("chmod");
    RUN_SEQ("rename");
    RUN_SEQ("renchmod");
    RUN_SEQ("link");
    RUN_SEQ("symlink");
    printf("RENAMECO-SUMMARY iters=%d%s RENAMECO-DONE rc=%d\n", iters,
           summary, rc);
    fflush(stdout);
    return rc;
}
