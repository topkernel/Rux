/*
 * brkchurn.c — brk-path churn through glibc (stress-port round 2).
 *
 * Round-1 finding: musl-static binaries cannot grow the brk region
 * (TLS layout pins it — verified on the reference kernel host too), so
 * the rs bigheap class fell back to malloc churn and the sys_brk
 * grow/shrink paths stayed uncovered. glibc serves main-arena blocks
 * from the brk heap and trims it back on free (M_TRIM_THRESHOLD /
 * M_MMAP_THRESHOLD), so a glibc-static binary exercises brk through
 * the allocator itself.
 *
 * Three processes (raw sbrk and glibc malloc must NOT mix in one
 * arena — moving the break behind glibc's back corrupts its top-chunk
 * bookkeeping):
 *   child A: raw sbrk waves — grow 64..512 KB, touch every page with
 *            the wave pattern, verify, sbrk back down, repeat.
 *   child B: glibc malloc/free churn straddling the trim threshold —
 *            alloc waves (16 B..64 KB blocks, patterned), verify, free
 *            storms; crossing ~256 KB live forces arena grow + trim.
 *   parent : watchdog — BRK-BEAT lines every 10 s, stops children at
 *            the deadline, reaps, reports BRK-DONE.
 *
 * usage: brkchurn <seconds>
 * Output: BRK-BEAT t=<s> sbrk_ops=<n> sbrk_bytes=<n> malloc_ops=<n>
 *                malloc_bytes=<n> enomem=<n>
 *         BRK-BUG ... on any verify mismatch / unexpected failure
 *         (any BRK-BUG or nonzero child exit = exit 1). ENOMEM on grow
 *         under pressure is counted, not a failure. Exit 0 at deadline.
 * Build (host glibc, static — guest and host are both x86_64):
 *   gcc -static -O2 -Wall -o brkchurn brkchurn.c
 */
#include <errno.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

#define NBLK 96

static double monotime(void)
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec + ts.tv_nsec / 1e9;
}

struct cnt {
    volatile int stop;
    uint64_t sbrk_ops, sbrk_bytes, malloc_ops, malloc_bytes, enomem, bug;
};

static struct cnt *c;

static void on_term(int s) { (void)s; c->stop = 1; }

static void pat_fill(unsigned char *p, size_t n, uint64_t seed)
{
    for (size_t i = 0; i + 8 <= n; i += 8) {
        uint64_t v = seed ^ (uint64_t)i;
        memcpy(p + i, &v, 8);
    }
}

static int pat_ok(const unsigned char *p, size_t n, uint64_t seed)
{
    for (size_t i = 0; i + 8 <= n; i += 8) {
        uint64_t v = seed ^ (uint64_t)i, got;
        memcpy(&got, p + i, 8);
        if (got != v)
            return 0;
    }
    return 1;
}

/* child A: raw sbrk waves */
static int sbrk_child(void)
{
    unsigned wave = 0;
    while (!c->stop) {
        size_t chunk = 64u * 1024 << (wave % 4); /* 64/128/256/512 KB */
        void *p = sbrk((intptr_t)chunk);
        if (p == (void *)-1) {
            if (errno == ENOMEM) {
                c->enomem++;
                struct timespec ts = { 0, 50 * 1000 * 1000 };
                nanosleep(&ts, NULL);
            } else {
                printf("BRK-BUG sbrk-grow errno=%d\n", errno);
                c->bug++;
                return 1;
            }
        } else {
            uint64_t seed = 0x5B2ull << 32 | wave;
            pat_fill(p, chunk, seed);
            if (!pat_ok(p, chunk, seed)) {
                printf("BRK-BUG sbrk-verify wave=%u\n", wave);
                c->bug++;
                return 1;
            }
            if (sbrk(-(intptr_t)chunk) == (void *)-1) {
                printf("BRK-BUG sbrk-shrink errno=%d\n", errno);
                c->bug++;
                return 1;
            }
            c->sbrk_ops++;
            c->sbrk_bytes += chunk;
        }
        wave++;
    }
    return 0;
}

/* child B: glibc malloc/free churn straddling the trim threshold */
static int malloc_child(void)
{
    unsigned char *blk[NBLK];
    size_t sz[NBLK];
    unsigned wave = 0;
    while (!c->stop) {
        size_t total = 0;
        for (int i = 0; i < NBLK; i++) {
            /* 16 B .. 64 KB: below glibc's mmap threshold -> brk arena */
            sz[i] = 16u << ((unsigned)(i * 7 + wave) % 13);
            blk[i] = malloc(sz[i]);
            if (!blk[i]) {
                printf("BRK-BUG malloc i=%d sz=%zu\n", i, sz[i]);
                c->bug++;
                return 1;
            }
            pat_fill(blk[i], sz[i], 0xA10ull << 32 | (uint64_t)wave << 8 | (unsigned)i);
            total += sz[i];
        }
        if (total < 200u * 1024) { /* force the arena past trim threshold */
            unsigned char *b = realloc(blk[0], 256u * 1024);
            if (!b) {
                printf("BRK-BUG realloc\n");
                c->bug++;
                return 1;
            }
            blk[0] = b;
            sz[0] = 256u * 1024;
            pat_fill(blk[0], sz[0], 0xA10ull << 32 | (uint64_t)wave << 8);
            total += sz[0];
        }
        for (int i = 0; i < NBLK; i++)
            if (!pat_ok(blk[i], sz[i],
                        0xA10ull << 32 | (uint64_t)wave << 8 | (unsigned)i)) {
                printf("BRK-BUG malloc-verify wave=%u i=%d\n", wave, i);
                c->bug++;
                return 1;
            }
        /* free storm: reverse order, then immediately the next wave
         * (grow-after-trim is the brk churn shape) */
        for (int i = NBLK - 1; i >= 0; i--)
            free(blk[i]);
        c->malloc_ops += NBLK + 1;
        c->malloc_bytes += total;
        wave++;
    }
    return 0;
}

int main(int argc, char **argv)
{
    int secs = argc > 1 ? atoi(argv[1]) : 60;
    if (secs < 1)
        secs = 60;
    struct timespec ts50 = { 0, 50 * 1000 * 1000 };

    c = mmap(NULL, 4096, PROT_READ | PROT_WRITE,
             MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (c == MAP_FAILED) {
        printf("BRK-BUG mmap-counters\n");
        return 1;
    }
    signal(SIGTERM, on_term);
    signal(SIGINT, on_term);

    void *b0 = sbrk(0);
    pid_t a = fork();
    if (a == 0)
        _exit(sbrk_child());
    pid_t b = fork();
    if (b == 0)
        _exit(malloc_child());

    printf("BRK-START secs=%d brk0=%p\n", secs, b0);
    fflush(stdout);
    double t0 = monotime();
    int last_beat = 0, rc = 0;
    while (!c->stop) {
        double el = monotime() - t0;
        if ((int)el / 10 != last_beat) {
            last_beat = (int)el / 10;
            printf("BRK-BEAT t=%d sbrk_ops=%llu sbrk_bytes=%llu "
                   "malloc_ops=%llu malloc_bytes=%llu enomem=%llu\n",
                   (int)el, (unsigned long long)c->sbrk_ops,
                   (unsigned long long)c->sbrk_bytes,
                   (unsigned long long)c->malloc_ops,
                   (unsigned long long)c->malloc_bytes,
                   (unsigned long long)c->enomem);
            fflush(stdout);
        }
        if (c->bug) {
            rc = 1;
            break;
        }
        if (el >= secs)
            break;
        nanosleep(&ts50, NULL);
    }
    c->stop = 1;
    int st = 0;
    kill(a, SIGTERM);
    kill(b, SIGTERM);
    pid_t r;
    int bad = 0;
    while ((r = waitpid(-1, &st, 0)) > 0)
        if ((r == a || r == b) && (!WIFEXITED(st) || WEXITSTATUS(st) != 0))
            bad = 1;
    if (bad)
        rc = 1;
    printf("BRK-DONE sbrk_ops=%llu malloc_ops=%llu enomem=%llu bug=%llu "
           "rc=%d\n",
           (unsigned long long)c->sbrk_ops, (unsigned long long)c->malloc_ops,
           (unsigned long long)c->enomem, (unsigned long long)c->bug, rc);
    fflush(stdout);
    return rc;
}
