/*
 * execaudit.c — rc=254 silent-child-death reproducer (stress-port r3).
 *
 * Round-2 family (SP-4 candidate): rsrun's exec'd glibc-static LTP
 * children intermittently died before ANY output and waitpid returned
 * ECHILD (rsrun's rc=254 marker), ~1 boot in 2, always under fork-heavy
 * tests (fork_procs, growfiles, msgstress01 mixed TBROK + 254 in ONE
 * boot = race, not the binary). Same boots carried the strand/leak
 * family, so the suspect is a fork/exec + wake interaction.
 *
 * This probe makes the race's contract explicit and audits it hard:
 *   - rounds of B children forked in a burst, each IMMEDIATELY execv'ing
 *     a glibc-static target (default /test/stress-ng/brkchurn 1) so the
 *     exec page-fault storm is the same shape as the LTP binaries;
 *   - the parent reaps with BOTH disciplines rsrun uses: blocking
 *     waitpid and WNOHANG + 200us nanosleep polling;
 *   - every deviation is an audit event: waitpid ECHILD, wrong-pid
 *     return, unexpected exit status (127 = exec failed in child,
 *     signals, nonzero rc), or a child that never got reaped in the
 *     guard window;
 *   - optional sibling forker (-f N) keeps fork+reap pressure hot on
 *     the side, matching the fork-heavy LTP context where the family
 *     fired.
 *
 * usage: execaudit [-r rounds] [-b burst] [-f forkers] [-t target] [-w]
 *   -r rounds    total rounds (default 40)
 *   -b burst     children per round (default 8)
 *   -f forkers   sibling fork-pressure processes (default 1)
 *   -t target    exec target path (default /test/stress-ng/brkchurn)
 *   -w           WNOHANG polling reap (default: blocking)
 * Output: EA-BEGIN/EA-ROUND/EA-DONE lines; exit 1 on any audit event.
 * Build (musl static, like the other rs probes):
 *   musl-gcc -static -O2 -Wall -o execaudit execaudit.c
 */
#include <errno.h>
#include <fcntl.h>
#include <signal.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/wait.h>
#include <time.h>
#include <unistd.h>

static double monotime(void) /* milliseconds since boot */
{
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000.0 + ts.tv_nsec / 1.0e6;
}

/* One audited child: fork + immediate exec; returns 0 = clean. */
static int run_one(const char *target, int wnohang, int *echild,
                   int *badstatus, int *wrongpid)
{
    char *cargv[3];
    cargv[0] = (char *)target;
    cargv[1] = (char *)"1"; /* brkchurn seconds; harmless as an LTP arg */
    cargv[2] = NULL;

    pid_t pid = fork();
    if (pid < 0) {
        printf("EA-EVENT fork-failed errno=%d (%s)\n", errno, strerror(errno));
        return 1;
    }
    if (pid == 0) {
        /* rsrun shape: stdio to a file we do not read back; the family's
         * signature was EMPTY output — any child that runs writes plenty. */
        int out = open("/tmp/ea-child.out", O_WRONLY | O_CREAT | O_TRUNC,
                       0644);
        if (out >= 0) {
            dup2(out, 1);
            dup2(out, 2);
            if (out > 2)
                close(out);
        }
        int devnull = open("/dev/null", 0);
        if (devnull >= 0)
            dup2(devnull, 0);
        execv(target, cargv);
        dprintf(1, "EA-EVENT exec-failed target=%s errno=%d (%s)\n",
                target, errno, strerror(errno));
        _exit(127);
    }

    int status = 0;
    pid_t r;
    if (wnohang) {
        struct timespec ts200 = { 0, 200 * 1000 * 1000 };
        for (;;) {
            r = waitpid(pid, &status, WNOHANG);
            if (r == pid)
                break;
            if (r < 0 && errno != EINTR)
                break;
            if (r == 0 || (r < 0 && errno == EINTR))
                nanosleep(&ts200, NULL);
        }
    } else {
        do {
            r = waitpid(pid, &status, 0);
        } while (r < 0 && errno == EINTR);
    }
    if (r < 0) {
        /* THE family: our own child is not reapable. */
        printf("EA-EVENT echild pid=%d errno=%d (%s) wnohang=%d\n",
               pid, errno, strerror(errno), wnohang);
        (*echild)++;
        return 1;
    }
    if (r != pid) {
        printf("EA-EVENT wrong-pid want=%d got=%d\n", pid, r);
        (*wrongpid)++;
        return 1;
    }
    if (WIFSIGNALED(status)) {
        printf("EA-EVENT signaled pid=%d sig=%d\n", pid, WTERMSIG(status));
        (*badstatus)++;
        return 1;
    }
    if (!WIFEXITED(status)) {
        printf("EA-EVENT noexit pid=%d status=%d\n", pid, status);
        (*badstatus)++;
        return 1;
    }
    int rc = WEXITSTATUS(status);
    if (rc == 127) {
        printf("EA-EVENT exec127 pid=%d (child could not exec)\n", pid);
        (*badstatus)++;
        return 1;
    }
    if (rc != 0) {
        /* target's own nonzero exit: recorded, not fatal — brkchurn
         * exits 1 only on verify bugs, so this stays visible. */
        printf("EA-EVENT rc pid=%d rc=%d\n", pid, rc);
        (*badstatus)++;
        return 1;
    }
    return 0;
}

int main(int argc, char **argv)
{
    int rounds = 40, burst = 8, forkers = 1, wnohang = 0;
    const char *target = "/test/stress-ng/brkchurn";
    /* Park mode: the sibling forker's self-exec children land here and
     * exit immediately (short-lived fork pressure only). */
    if (argc == 2 && !strcmp(argv[1], "-p"))
        return 0;
    int opt;
    while ((opt = getopt(argc, argv, "r:b:f:t:w")) != -1) {
        switch (opt) {
        case 'r': rounds = atoi(optarg); break;
        case 'b': burst = atoi(optarg); break;
        case 'f': forkers = atoi(optarg); break;
        case 't': target = optarg; break;
        case 'w': wnohang = 1; break;
        default:
            dprintf(2, "usage: %s [-r rounds] [-b burst] [-f forkers] "
                       "[-t target] [-w]\n", argv[0]);
            return 2;
        }
    }
    signal(SIGCHLD, SIG_DFL);

    printf("EA-BEGIN rounds=%d burst=%d forkers=%d target=%s wnohang=%d\n",
           rounds, burst, forkers, target, wnohang);

    /* Sibling fork pressure: short-lived self-exec children reaped in a
     * tight loop, exactly the fork-heavy LTP context of the family. */
    pid_t fkpids[16];
    if (forkers > 16)
        forkers = 16;
    for (int i = 0; i < forkers; i++) {
        pid_t fk = fork();
        if (fk == 0) {
            for (;;) {
                pid_t c = fork();
                if (c == 0) {
                    char *self[3];
                    self[0] = argv[0];
                    self[1] = (char *)"-p";
                    self[2] = NULL;
                    execv(argv[0], self); /* -p: park child, below */
                    _exit(127);
                }
                if (c > 0) {
                    int st;
                    while (waitpid(c, &st, 0) < 0 && errno == EINTR)
                        ;
                }
            }
        }
        fkpids[i] = fk;
    }

    int echild = 0, badstatus = 0, wrongpid = 0, events = 0;
    double t0 = monotime();
    for (int r = 1; r <= rounds; r++) {
        for (int b = 0; b < burst; b++) {
            if (run_one(target, wnohang, &echild, &badstatus, &wrongpid))
                events++;
        }
        if (r % 5 == 0 || r == rounds) {
            printf("EA-ROUND r=%d/%d children=%d events=%d echild=%d "
                   "badstatus=%d wrongpid=%d t=%.0fms\n",
                   r, rounds, r * burst, events, echild, badstatus,
                   wrongpid, monotime() - t0);
            fflush(stdout);
        }
    }

    printf("EA-DONE children=%d events=%d echild=%d badstatus=%d "
           "wrongpid=%d t=%.0fms verdict=%s\n",
           rounds * burst, events, echild, badstatus, wrongpid,
           monotime() - t0, events ? "FAIL" : "PASS");
    fflush(stdout);
    /* Stop the pressure forkers (SIGKILL: they run a bare fork loop). */
    for (int i = 0; i < forkers; i++) {
        kill(fkpids[i], SIGKILL);
        int st;
        while (waitpid(fkpids[i], &st, 0) < 0 && errno == EINTR)
            ;
    }
    return events ? 1 : 0;
}
