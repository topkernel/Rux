printf '%s\n' "`echo"
